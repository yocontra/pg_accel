# pg_accel Architecture

This document describes the resident-v2 architecture at the current source
revision. It distinguishes production planner admission from dormant executor
and kernel code. The public capability snapshot is in [README.md](README.md).

## Production boundary

`_PG_init` registers the Custom Scan provider and planner hooks at
`pg_accel/src/lib.rs:301-305`. Normal planning currently adds one family of
candidate: a childless resident aggregate path at `UPPERREL_GROUP_AGG`.

| Planner stage | Production behavior |
|---|---|
| Upper aggregate | Analyze a reducing aggregate shape and, if every gate passes, add `Custom Scan (GpuAccelAgg)`. |
| Base relation | Observe scan/filter/sort/function opportunities, record a resident-pipeline decline, and add no path. |
| Join relation | Observe join opportunities, record a resident-pipeline decline, and add no row-returning join path. |
| Window upper relation | Record the missing resident pipeline and add no path. |
| Final target-list SRF | Record the missing resident pipeline and add no path. |
| Raster | Observe catalog/shape facts in production; forced path construction is compiled only for tests. |

The upper hook dispatch is explicit at
`pg_accel/src/engine/ffi/planner_hooks/mod.rs:190-236`. The base and join
boundaries are explicit at
`pg_accel/src/engine/ffi/planner_hooks/rel_pathlist.rs:483-502` and
`pg_accel/src/engine/ffi/planner_hooks/join_pathlist.rs:123-131`.

A compiled kernel, FFI bridge, executor module, or adapter entry is therefore
not sufficient to make SQL planner-selectable. Production selection also
requires a path injection site, a complete logical contract, exact residency
proof, runtime capability validation, and a winning cost.

Upper-path admission additionally requires a database-local `pg_accel` catalog
entry and declines while extension installation/update scripts are running.
Shared preloading alone is not installation. PostgreSQL's invalidation-aware
extension syscache is consulted directly, so CREATE/DROP and rollback do not
leave a stale backend-local presence flag.

## Component map

| Layer | Current source | Responsibility |
|---|---|---|
| Planner hooks | `pg_accel/src/engine/ffi/planner_hooks/` | Observe PostgreSQL paths; extract, validate, cost, and inject the resident aggregate candidate. |
| Shape model | `pg_accel/src/engine/ffi/planner_hooks/shape/` | Convert PostgreSQL planner nodes into a stable reducing-query model or a stable decline code. |
| Neutral spec | `pg_accel/src/engine/spec/` | Own `AggQuerySpec` (AQS6), output projection (AOP2), validation, and codecs without device pointers. |
| Plan wire | `pg_accel/src/engine/ffi/custom_scan/private_data.rs` | Serialize strategy, spec, projection, and resident proof through PostgreSQL `custom_private`. |
| Residency | `pg_accel/src/engine/residency/` | Load columns, track generations, enforce the byte ledger, cache derived artifacts, and bind device inputs. |
| Aggregate executor | `pg_accel/src/engine/executor/agg/` | Validate the descriptor contract, prepare artifacts, bind ABI descriptors, dispatch, and emit final tuples. |
| Kernel ABI | `pg_accel/src/engine/spec/abi.rs` and `pgaccel-kernels/include/pgaccel_olap.h` | Define the frozen Rust/C grouped-aggregate descriptor and output layout. |
| GPU bridge and kernels | `pg_accel/src/gpu/` and `pgaccel-kernels/src/` | Own device allocation, status conversion, synchronous calls, and kernel implementations. |

## Planner pipeline

### 1. Cheap preflight

The aggregate hook first rejects shapes that can be ruled out without device
initialization. It then checks device usability before building the full shape.
The ordering is visible at
`pg_accel/src/engine/ffi/planner_hooks/generic_groupagg.rs:567-590`.

### 2. Reducing shape extraction

The shared shape pass accepts a reducing aggregate query, not an arbitrary
PostgreSQL plan tree. Its output is `ShapePlan`:

- `spec`: neutral aggregate semantics;
- `projections`: ordered PostgreSQL output slots;
- `required_relations`: relation/attribute dependencies;
- `digest_words`: stable artifact identity input;
- descriptor resolution and hidden measure accounting;
- residency estimates and typed costs.

The structure is defined at
`pg_accel/src/engine/ffi/planner_hooks/shape/mod.rs:288-301`. Unsupported SQL
features become `ShapeDecline` values with stable stats keys rather than
partially accelerated plans; the mapping is at
`pg_accel/src/engine/ffi/planner_hooks/shape/mod.rs:303-515`.

The reducing shape may represent:

- an aggregate over one resident fact relation;
- grouped aggregates over covered key and measure types;
- covered filters represented by ranges, masks, or expression bytecode;
- a bounded star schema whose dimension joins are consumed inside the
  aggregate descriptor;
- covered H3 transformations used as group keys.

It does not create a row-returning join pipeline. The aggregate is childless at
the PostgreSQL executor boundary: relations named in the spec are read from the
residency store, and only the bounded aggregate result is materialized.

### 3. Capability, residency, and cost gates

The planner validates the extracted spec against the actual descriptor
executor, estimates exact required columns and derived artifacts, checks the
cluster budget, includes amortized load cost, compares against the cheapest
native path, and only then adds the CustomPath. This sequence is at
`pg_accel/src/engine/ffi/planner_hooks/generic_groupagg.rs:636-675`.

`pg_accel.auto_load=off` is an admission constraint: every missing relation
must already be pinned/resident in the current backend. The planner-side check
is at `pg_accel/src/engine/ffi/planner_hooks/generic_groupagg.rs:235-247`.

## Neutral query contract

`AggQuerySpec` contains logical PostgreSQL identities and operations only:

```text
AggQuerySpec
  fact_rel
  group_keys[]
  measures[]
  fact_filter
  star_dims[]
  having
```

The exact definition is
`pg_accel/src/engine/spec/mod.rs:284-292`. Column references carry relation OID,
attribute number, and type OID. Filters, aggregate measures, dimension joins,
and group-key expressions are typed enums. Catalog-local function OIDs and
backend memory addresses are not wire tags.

The current spec version is AQS6
(`pg_accel/src/engine/spec/mod.rs:23`). `AggOutputProjection` is separate so the
logical operation does not depend on the order or labels of PostgreSQL result
slots; its public types are exported at
`pg_accel/src/engine/spec/mod.rs:16-20`.

AQS6 adds checked two-column INT4 addition to multiplication and subtraction.
The dense integer executor evaluates these expressions before COUNT as well as
SUM/AVG/MIN/MAX, after WHERE and per-aggregate filters. Independent predicates
use raw-input bindings; they cannot replace an arithmetic RHS. An otherwise
unbound predicate requires a hidden state within the existing four-state cap.
This does not admit nested expressions or broaden arithmetic type semantics.

The separate SPG1 scalar-program foundation has a bounded typed control-flow
validator and a device evaluator for INT4/Boolean arithmetic, comparisons,
NULL tests and lazy CASE/COALESCE/Boolean branches. Native dense aggregate
descriptors now accept an additive SCALAR operation with a versioned host view;
outer ABI sizes and existing discriminants remain unchanged. Complete program
validation precedes staging into sized workspace. Dedicated kernel variants
evaluate the program after filters, without an intermediate result column,
and preserve distinct overflow/division-by-zero failures even for COUNT.
Chunk callers slice nested resident inputs; lifecycle identity includes the
program. Hash/dimension/serial-generic scalar execution remains unsupported.
The Rust facade validates and owns scalar view/word/binding snapshots. Bounded
chunks advance nested typed resident lanes, never the host view, and sessions
own independent metadata across plan lifetimes. Program contents participate
in lifecycle and workspace-pool identity. The executor's resident binder now
validates SPG1 against fact-column identities, exact OIDs, row/NULL lengths and
output lanes, and owns the resulting metadata. Independent raw INT4 FILTERs
use RHS bindings. Runtime wire/control-flow validation uses bounded stack
scratch without heap allocation. Each bound/plan/session/sliced-chunk metadata
snapshot reserves its exact requested heap payload before allocation and
releases it on drop; borrowed chunks reuse the plan snapshot. Scalar workspace
and output buffers also carry execution-ledger charges, including pooled
buffers. Allocator bookkeeping and unrelated Rust owner/pool-key allocations
are not included in this payload accounting. Runtime capability now accepts
validated fact-only dense scalar states: INT4 SUM/AVG/COUNT/MIN/MAX, Boolean
COUNT, optional raw integer states and final COUNT(*), within the four-state
cap. The scalar specialization is distinct from binary integer expressions;
hash and dimension scalar compositions remain rejected. Qualified point/polygon
spatial scalar compositions reuse the exact rechecked SQL mask and the bounded
dense-integer executor; geometry, orientation and residency gates still apply. Normal
admission now passes this typed family through exact loaded row/NULL evidence,
memory, device and cost gates. It does not admit unknown cold footprints.
Grouped scalar extraction obtains PostgreSQL's per-key cardinalities for the
workspace forecast, just like NUMERIC. It uses their Cartesian product plus
resident NULL slots, not the joint output-group estimate; actual artifact and
execution reservations still enforce the budget when estimates differ.
Invalidating DML can therefore leave newly planned queries native until refresh;
already selected prepared plans retain execution-time revalidation/reload.
SQL128 exercises normal selection separately from direct executor tests.
SQL129 adds spatial/global/one-to-three-key scalar programs, independent FILTERs,
Boolean COUNT, prepared geometry/value/dictionary changes and error suppression
outside the spatial mask, with native and independent coordinate/arithmetic oracles.
AQS6 is unchanged.

The residency-budget calculation now includes a conservative four-snapshot
scalar metadata peak (session, bound descriptor, resolved plan and row chunk),
independent of estimated row count. Native workspace/output layout queries now
add the corresponding device/host execution footprint, using exact resident
row/NULL metadata, dense-slot estimates and the executor's one-shot/chunk rules.
Stack-owned query metadata and borrowed words never escape into execution;
payload pointers are presence markers and no row values are read. The query
does not reserve memory, create execution owners or touch allocation pools.
Dense artifact preparation now reserves measure-program input/word vector
payloads before cloning, then transfers the host and device reservations into
the cached or query-local owner. Cache hits reuse the reservation; failed
preparation/builds release it. Actual retained capacities must match the
declaration, and prospective admission includes this retained program payload.
Spatial preparation reserves the program payload in both published and transient
charges before snapshots/clones: two temporary program owners can coexist.
Workspace accounting includes the retained base program, publication transfers
that owner, and planner memory adds the extra transient copy. Spatial scalar
costing also includes the bounded aggregate launch count.
Output validation borrows the pinned artifact spec rather than cloning it;
bounded execution also validates output under its final fresh residency borrow
and no longer retains a duplicate spec across chunks. Other logical-spec
containers, encoded artifact identities and allocator overhead are outside this
payload accounting; this is not a complete host-memory proof. A live cached
artifact/resident-store test checks invalidation and reload across scalar-only
input changes; production
planner selection and concurrent/between-chunk invalidation are separate gates.

The PostgreSQL-node lowerer preserves searched and simple CASE/COALESCE and
Boolean short-circuit order, checks built-in operator implementation identities,
deduplicates catalog-proved inputs and rejects mixed range-table occurrences.
It does not strip casts or reinterpret domains/custom operators. Simple CASE
retains its once-evaluated INT4/Boolean test on the bounded stack, duplicates
only that value for built-in equality checks and discards it before the chosen
result/default. Boolean equality simplifications are also recognized; nested
CASE nodes have separate stack slots. The final WHEN consumes the test value
directly, removing a redundant duplicate/discard. A single built-in WHEN has
the same bytecode as its searched-CASE equivalent, without changing cost coefficients or
assuming branch selectivity. The additive SPG1 DROP opcode (5, zero
operand) is checked by both validators and the evaluator; older consumers fail
closed on the unknown opcode. Outer AQS6 and native descriptor layouts do not
change. Unqualified CaseTestExpr uses still decline. SPG1 can be carried inside
the existing opaque measure-program envelope without changing AQS6 framing;
recognized SPG1 measures additionally validate their program and bound column/
result types. Other dormant program formats and H3/filter contracts are unchanged.
Extraction alone is not descriptor capability or production admission.

A planning-only SPG1 fusion pass combines equality followed by CASE branching
and COALESCE with an INT4 literal fallback. Additive opcodes 55 and 6 consume
the same typed inputs without materializing an intermediate Boolean or taking
a literal-fallback branch. Fusion never crosses a branch entry; all forward
targets and the program exit are relocated before full revalidation. Rust and
native validators, the device VM and the non-NULL proof agree on both stack
effects. Existing instruction-work costing sees the shorter program without
changing coefficients, admission gates or assumed branch selectivity.

Aggregate extraction now invokes that lowerer after the existing raw-column
and binary-measure cases, preserving their released representation. It lowers
the original argument without inheriting the legacy probe's coercion stripping.
Shape building shares identical program/filter states, keeps COUNT(*) last,
tracks every required input and budgets hidden WHERE carriers within the same
state cap. A bounded, allocation-free forward dataflow proof intersects
definitely-non-NULL stack slots at branch joins, treating all input columns as
nullable and refining only COALESCE's retained non-NULL branch. COUNT(*) may
share a required scalar expression's COUNT lane only if every successful path
is non-NULL and the FILTER matches exactly. Expressions still execute, including
errors. Strict FILTER-normalized counts of the predicate column can share too;
a NULL-accepting filter cannot prove that column count covers every accepted row.
Sharing precedes the state cap and is independent of target order;
projection metadata records the physical scalar source while preserving the
SQL non-NULL INT8 result. No AQS/AOP or native ABI version changes are needed.
PostgreSQL simplification precedes extraction: for example, PG19 may replace a
provably non-NULL COUNT argument entirely. Native-equivalence tests therefore
compare each major's actual errors/results, not an assumed common evaluation.
The conservative expression-work model charges each scalar state
by the longest forward instruction path using the existing typed operation
coefficient. Loads, literals and branches count; mutually exclusive arms are
not summed, and no favorable FILTER/short-circuit selectivity is assumed. This
allocation-free work bound reuses the existing typed operation coefficient;
it does not promise that every eligible scalar query wins admission or latency.

Device pointers appear only after execution-time binding to the C ABI. The ABI
version and maximum descriptor dimensions are defined at
`pg_accel/src/engine/spec/abi.rs:11-15`; `PgaccelGroupedAggDesc` begins at
`pg_accel/src/engine/spec/abi.rs:141-167`.

## Plan serialization

PostgreSQL copies and serializes `CustomScan.custom_private`, so Rust objects and
raw pointers cannot be stored there. `private_data.rs` encodes a framed list of
PostgreSQL integer nodes containing:

1. wire magic and version;
2. execution-method identity and strategy;
3. AQS6 logical spec;
4. AOP2 output projection;
5. resident proof snapshot and footer.

The framing constants and AQS6/AOP2 sentinels are at
`pg_accel/src/engine/ffi/custom_scan/private_data.rs:30-43`. Decoders validate
lengths, discriminants, execution-method identity, spec/projection semantics,
and proof fields before executor state is allocated.

## Residency model

### Backend-local data, cluster-wide accounting

Each PostgreSQL backend owns a thread-local `RelationStore`
(`pg_accel/src/engine/residency/store.rs:42-48`). It contains raw lossless
columns, pin metadata, derived artifacts, relation generations, and LRU state.
Resident pointers never cross backend processes.

Allocation accounting is cluster-wide. Every charged raw, retained-exact,
derived, and transient byte participates in the shared ledger. The exact live
total is exposed by `pg_accel_resident_live_bytes()` at
`pg_accel/src/engine/residency/store.rs:2032-2043`. A pin changes local eviction
eligibility; it does not override the budget.

### Selected-plan preparation

At `BeginCustomScan`, the descriptor executor:

1. processes invalidations;
2. ensures every required relation/column as one protected dependency set;
3. validates generation/currentness evidence;
4. builds or reuses a dependency-stamped derived artifact;
5. binds resident buffers into the ABI descriptor.

The multi-relation ensure operation is
`pg_accel/src/engine/residency/store.rs:1903-1937`. `auto_load` authorization is
checked at `pg_accel/src/engine/residency/store.rs:1827-1865`.

Explicit operations are SQL wrappers over the same store:

- `pg_accel_pin`: load selected columns and retain the pin;
- `pg_accel_unpin`: remove the pin without requiring immediate eviction;
- `pg_accel_refresh`: reload the pin set or currently resident columns;
- `pg_accel_evict`: remove the backend-local relation entry;
- `pg_accel_resident_status`: expose columns, bytes, pin, generation, and
  timing state.

Their SQL definitions and status tuple are at
`pg_accel/src/engine/residency/store.rs:3352-3427`.

### Resident proof

A selected path carries a `ResidentProofSnapshot`. It identifies the resident
operator class, participating stages, device column count, and permitted
materialization boundary. Intermediate host materialization blocks resident
admission; final bounded output materialization is allowed. The boundary rules
are defined at `pg_accel/src/engine/residency/proof.rs:263-301`.

This proof is planner/executor evidence, not ownership of a pointer. Live device
buffers are borrowed only while synchronous descriptor binding and dispatch are
in progress.

## Descriptor execution

`AggExecState` is a childless Custom Scan executor over AQS6/AOP2. Construction
validates the neutral contract and prepares its dependency-stamped artifact;
the first `ExecCustomScan` call dispatches and stores bounded output, and later
calls emit PostgreSQL tuples. Rescan revalidates residency and rebuilds stale
artifacts. The lifecycle is implemented at
`pg_accel/src/engine/executor/agg/execute.rs:70-216`.

The descriptor layer performs runtime capability validation before binding
resident columns. It translates logical keys, measures, filters, and dimensions
into `PgaccelGroupedAggDesc`, then uses bounded synchronous calls where required.
Errors are raised through the Custom Scan; execution does not switch to a
different PostgreSQL child plan.

The atomic integer kernel uses one work-item per row and value state. Its
one-million-row batch cap permits a single 32-bit atomic increment for group
and nonnull counts: both words are reset before each batch, and no batch count
can carry into the high word. SUM retains exact two-word atomic addition.
Bounded execution can use this kernel when cumulative selected rows plus the
current batch's row count prove every INT4 SUM prefix fits int64. Per-batch
SUM/COUNT/extrema merge into persistent states; FINALIZE does not merge again.
Outside that proof the existing ordered GPU partial reducer runs, preserving
overflow detection even if later values cancel. Both paths' scratch is included
in native workspace queries, including queries for a maximum chunk that cannot
itself use atomics but whose shorter chunks can. Low-cardinality hierarchical
reduction and the one-shot cap are unchanged. Row-fusion and adaptive-cooperative
experiments did not establish a latency benefit and were not retained.

Output reconstruction is governed by AOP2, not by assumed target-list order.
Each slot names its source (group key or aggregate result) and PostgreSQL result
type. Descriptor output rejects uncertainty that cannot be resolved by the
selected contract at `pg_accel/src/engine/executor/agg/output.rs:54-80`.

## EXPLAIN contract

Every selected Custom Scan reports strategy, selection, batch/thread metadata,
resident proof, operator class, stage mask, and device-column count. Aggregate
descriptors additionally report logical keys, aggregate lanes, filters, star
dimensions, output projection, residency state, artifact outcome, generations,
and bytes. `EXPLAIN ANALYZE` adds dispatch and row/batch counters.

The common properties are emitted at
`pg_accel/src/engine/ffi/custom_scan/explain.rs:43-148`; descriptor-specific
properties are emitted at
`pg_accel/src/engine/ffi/custom_scan/explain.rs:829-855`. See
[docs/EXPLAIN_EXAMPLES.md](docs/EXPLAIN_EXAMPLES.md) for use.

## Configuration ownership

The complete released inventory and exact defaults/ranges are maintained in
[README.md](README.md#configuration). Architecturally, the GUCs divide into:

| Control plane | GUCs | Semantics |
|---|---|---|
| Planning admission | `enabled`, `gpu_enabled` | Affect new plans only; `enabled=off` also fails closed if an existing Custom Scan reaches execution. |
| Resident admission | `auto_load`, `resident_memory_budget_mb` | Authorize missing-column loads and cap all cluster residency bytes. |
| Aggregate cost | `cost_multiplier`, `soft_fp64_cost_multiplier` | Adjust resident aggregate candidate cost; the fp64 multiplier applies only without native fp64. |
| Legacy execution | `min_batch_size` | Row-fed fill target, not the resident descriptor admission floor. |
| Dispatch observation | `kernel_timeout_ms` | Post-return warning threshold, not asynchronous cancellation. |
| Host-thread ledger | `max_workers_total` | Cluster cap for pg_accel-owned host threads; current executors request none. |
| Tracing | `log_level`, `otel_log_max_mb`, `otel_log_max_rotations` | Sampled when backend tracing initializes. |
| Compatibility/roadmap no-ops | `assert_dispatch`, `parallel_fused_count`, `fp64_enabled` | Retained settings with no current planning or execution effect. |

Production registrations are at `pg_accel/src/engine/gucs.rs:105-245` and
`pg_accel/src/lib.rs:260-283`. Test-only settings at
`pg_accel/src/engine/gucs.rs:247-265` are not released configuration.

## Invariants

1. Planner selection requires a complete resident producer-to-consumer proof.
2. `AggQuerySpec` contains logical identities, never device pointers.
3. `custom_private` contains validated integer-node wire data, never Rust
   allocations.
4. Resident relation pointers stay inside the owning PostgreSQL backend.
5. Pins affect eviction, not accounting or budget authorization.
6. Only bounded final output may cross from the resident aggregate pipeline to
   PostgreSQL tuples.
7. Registered adapter metadata does not imply a planner path.
8. Normal planning never uses test-only force GUCs.
