//! Live SPG1 lowering and owned GPU-binding tests, not planner-admission tests.

#[cfg(any(test, feature = "pg_test"))]
#[pgrx::pg_schema]
mod tests {
    use std::ffi::CString;

    use pgrx::pg_sys;
    use pgrx::prelude::*;

    use crate::engine::ffi::planner_hooks::shape::{
        LoweredScalarExpression, lower_scalar_expression,
    };
    use crate::engine::spec::abi;
    use crate::engine::spec::scalar::tests::{Value, evaluate};
    use crate::engine::spec::scalar::{ScalarInstruction as I, ScalarType};
    use crate::gpu::{
        ExprDeviceBuffer, GpuStatusDetail, GroupedAggKernelMode, GroupedAggOutputStorage,
        GroupedAggSession, GroupedAggStateLane, ResolvedGroupedAggPlan,
        execute_grouped_agg_one_shot_with_mode,
    };

    #[pg_test]
    fn pg_scalar_fused_owned_binding_matches_native_aggregates() {
        use crate::engine::residency::resident_live_bytes;
        crate::gpu::cleanup_grouped_allocation_pools();
        let ledger_baseline = resident_live_bytes();
        Spi::run(
            "SET pg_accel.enabled=off; CREATE TEMP TABLE scalar_fused_rows AS \
            SELECT i id, CASE WHEN i%5=0 THEN NULL ELSE i%31-15 END a, \
            i%7-3 b, i%3=0 p FROM generate_series(0,4096) s(i)",
        )
        .expect("native reference rows");
        let a: Vec<i32> = (0..4097)
            .map(|i| if i % 5 == 0 { 0 } else { i % 31 - 15 })
            .collect();
        let b: Vec<i32> = (0..4097).map(|i| i % 7 - 3).collect();
        let p: Vec<u8> = (0..4097).map(|i| u8::from(i % 3 == 0)).collect();
        let an: Vec<u8> = (0..4097).map(|i| u8::from(i % 5 == 0)).collect();
        let a = ExprDeviceBuffer::copy_from_slice(&a).expect("resident a");
        let b = ExprDeviceBuffer::copy_from_slice(&b).expect("resident b");
        let p = ExprDeviceBuffer::copy_from_slice(&p).expect("resident p");
        let an = ExprDeviceBuffer::copy_from_slice(&an).expect("resident NULLs");
        let short_nulls =
            ExprDeviceBuffer::copy_from_slice(&[0_u8]).expect("short sidecar fixture");
        for expression in [
            "CASE WHEN p THEN COALESCE(a,7)+b ELSE NULL END",
            "CASE WHEN b<>0 THEN a/b ELSE 42 END",
            "COALESCE(a,b*2)-3",
        ] {
            let lowered = lower(&format!("SELECT {expression} FROM scalar_fused_rows"))
                .expect("catalog-proved program");
            let fact_rel = lowered.inputs[0].column.relation_oid;
            let logical = lowered.clone().into_measure_expression();
            let requests: Vec<_> = [2, 3, 4]
                .into_iter()
                .map(|attno| crate::engine::residency::ResidentColumnRef {
                    relid: pg_sys::Oid::from(fact_rel),
                    attno,
                })
                .collect();
            let views = [
                crate::engine::residency::ResidentColumnView::I32 {
                    type_oid: pg_sys::INT4OID,
                    values: &a,
                    nulls: Some(&an),
                },
                crate::engine::residency::ResidentColumnView::I32 {
                    type_oid: pg_sys::INT4OID,
                    values: &b,
                    nulls: None,
                },
                crate::engine::residency::ResidentColumnView::Bool {
                    type_oid: pg_sys::BOOLOID,
                    values: &p,
                    nulls: None,
                },
            ];
            let bad_views = [
                crate::engine::residency::ResidentColumnView::I32 {
                    type_oid: pg_sys::INT4OID,
                    values: &a,
                    nulls: Some(&short_nulls),
                },
                crate::engine::residency::ResidentColumnView::I32 {
                    type_oid: pg_sys::INT4OID,
                    values: &b,
                    nulls: None,
                },
                crate::engine::residency::ResidentColumnView::Bool {
                    type_oid: pg_sys::BOOLOID,
                    values: &p,
                    nulls: None,
                },
            ];
            assert!(
                crate::engine::executor::agg::scalar_measure_column(
                    &logical,
                    fact_rel,
                    &requests,
                    &bad_views,
                    4097,
                    abi::PGACCEL_GROUPED_AGG_LANE_COUNT
                )
                .is_err()
            );
            let words = lowered.program.encode();
            let inputs: Vec<_> = lowered
                .inputs
                .iter()
                .map(|col| {
                    let (values, nulls, physical_type) = match col.column.attno {
                        2 => (a.as_ptr().cast(), an.as_ptr(), 2),
                        3 => (b.as_ptr().cast(), std::ptr::null(), 2),
                        4 => (p.as_ptr().cast(), std::ptr::null(), 1),
                        _ => panic!("unexpected scalar input"),
                    };
                    abi::PgaccelScalarInput {
                        values,
                        nulls,
                        physical_type,
                        reserved: 0,
                    }
                })
                .collect();
            for groups in [1_usize, 3, 17] {
                let keys: Vec<i32> = (0..4097).map(|i| (i % groups) as i32).collect();
                let keys = ExprDeviceBuffer::copy_from_slice(&keys).expect("resident keys");
                let view = abi::PgaccelScalarView {
                    version: 1,
                    word_count: words.len() as u32,
                    input_count: inputs.len() as u32,
                    reserved: 0,
                    row_count: 4097,
                    words: words.as_ptr(),
                    inputs: inputs.as_ptr(),
                };
                // SAFETY: zero is valid for the ABI fields; required fields follow.
                let mut desc: abi::PgaccelGroupedAggDesc = unsafe { std::mem::zeroed() };
                desc.abi_version = abi::PGACCEL_OLAP_ABI_VERSION;
                desc.size_bytes = size_of::<abi::PgaccelGroupedAggDesc>() as u32;
                desc.row_count = 4097;
                desc.group_capacity = groups;
                desc.where_filter.value_cmp_opcode =
                    crate::engine::expr_compiler::opcode::ALWAYS_TRUE;
                for filter in &mut desc.measure_filters {
                    filter.value_cmp_opcode = crate::engine::expr_compiler::opcode::ALWAYS_TRUE;
                }
                if groups > 1 {
                    desc.key_count = 1;
                    desc.keys[0].values.values = keys.as_ptr().cast();
                    desc.keys[0].values.tag = crate::gpu::PgaccelValTag::Int32;
                    desc.keys[0].cardinality = groups as u32;
                    desc.keys[0].null_code = abi::PGACCEL_GROUPED_AGG_KEY_NO_NULL_CODE;
                }
                desc.measure_count = 1;
                let measure = &mut desc.measures[0];
                measure.op = abi::PGACCEL_GROUPED_AGG_MEASURE_SCALAR;
                measure.agg_mask = abi::PGACCEL_GROUPED_AGG_LANE_SUM
                    | abi::PGACCEL_GROUPED_AGG_LANE_MIN
                    | abi::PGACCEL_GROUPED_AGG_LANE_MAX
                    | abi::PGACCEL_GROUPED_AGG_LANE_COUNT;
                measure.accumulator_kind = abi::PGACCEL_GROUPED_AGG_ACCUM_I64;
                measure.state_bytes = 8;
                measure.value.values = std::ptr::from_ref(&view).cast();
                measure.value.physical_type = 2;
                measure.value.element_bytes = size_of::<abi::PgaccelScalarView>() as u32;
                measure.value.flags = abi::PGACCEL_GROUPED_AGG_SCALAR_VIEW_V1;
                // Exercise the production executor's logical-to-resident
                // binding, not only hand-written ABI metadata.
                let before_binding = resident_live_bytes();
                Spi::run("SET pg_accel.resident_memory_budget_mb=0").expect("zero budget");
                assert!(
                    crate::engine::executor::agg::scalar_measure_column(
                        &logical,
                        fact_rel,
                        &requests,
                        &views,
                        4097,
                        measure.agg_mask,
                    )
                    .is_err()
                );
                // Budget failure may reclaim idle pools but cannot release any
                // active owner's charge or allocate a new metadata snapshot.
                assert!(resident_live_bytes() <= before_binding);
                let before_binding = resident_live_bytes();
                Spi::run("RESET pg_accel.resident_memory_budget_mb").expect("restore budget");
                let (bound_column, _binding_owner) =
                    crate::engine::executor::agg::scalar_measure_column(
                        &logical,
                        fact_rel,
                        &requests,
                        &views,
                        4097,
                        measure.agg_mask,
                    )
                    .expect("executor scalar binding");
                let metadata_bytes = crate::gpu::scalar_metadata_bytes(words.len(), inputs.len())
                    .expect("exact metadata bytes") as u64;
                assert_eq!(resident_live_bytes(), before_binding + metadata_bytes);
                measure.value = bound_column;
                // SAFETY: all input buffers live through synchronous GPU execution;
                // the facade copies host metadata and never reads resident rows.
                let plan = unsafe { ResolvedGroupedAggPlan::from_abi(desc) }.expect("owned plan");
                assert_eq!(resident_live_bytes(), before_binding + 2 * metadata_bytes);
                Spi::run("SET pg_accel.resident_memory_budget_mb=0")
                    .expect("zero execution budget");
                assert!(plan.row_chunk(0, 1).is_err());
                assert!(GroupedAggOutputStorage::new(&plan).is_err());
                assert!(crate::gpu::GroupedAggWorkspace::allocate(&plan).is_err());
                assert!(GroupedAggSession::start(&plan, 113).is_err());
                // SAFETY: bound metadata and resident inputs are still live;
                // adoption must fail solely because its snapshot cannot fit.
                assert!(unsafe { ResolvedGroupedAggPlan::from_abi(desc) }.is_err());
                assert_eq!(resident_live_bytes(), before_binding + 2 * metadata_bytes);
                Spi::run("RESET pg_accel.resident_memory_budget_mb")
                    .expect("restore execution budget");
                let mut output = GroupedAggOutputStorage::new(&plan).expect("output");
                let (_, mode) = execute_grouped_agg_one_shot_with_mode(&plan, &mut output)
                    .expect("fused device execution");
                assert_eq!(mode, GroupedAggKernelMode::ParallelDenseInteger);
                Spi::connect(|client| {
                    for row in client.select(&format!("SELECT id%{groups} g, sum(v) s, min(v)::bigint lo, \
                        max(v)::bigint hi, count(v) n FROM (SELECT id,{expression} v FROM scalar_fused_rows) t GROUP BY 1"),
                        None, &[]).expect("native aggregate oracle") {
                        let group = row.get::<i32>(1).expect("group datum").expect("group") as usize;
                        let count = row.get::<i64>(5).expect("count datum").expect("count") as u64;
                        assert_eq!(output.measure_count(0).expect("COUNT lane")[group], count);
                        assert_eq!(output.measure_nonnull_count(0).expect("validity lane")[group], count);
                        for (index, lane) in [(2,GroupedAggStateLane::Sum), (3,GroupedAggStateLane::Min),
                            (4,GroupedAggStateLane::Max)] {
                            if let Some(value) = row.get::<i64>(index).expect("native lane") {
                                assert_eq!(output.measure_i64_at(0,lane,group).expect("device lane"), value,
                                    "{expression}: group {group}");
                            }
                        }
                    }
                });
                let mut session = GroupedAggSession::start(&plan, 113).expect("bounded session");
                drop(plan);
                // SAFETY: resident buffers remain live across fresh metadata adoption.
                let plan = unsafe { ResolvedGroupedAggPlan::from_abi(desc) }.expect("fresh plan");
                for first in (0..4097).step_by(113) {
                    session
                        .accumulate(
                            &plan
                                .row_chunk(first, (4097 - first).min(113))
                                .expect("chunk"),
                        )
                        .expect("owned chunk execution");
                }
                session
                    .accumulate(&plan.row_chunk(4097, 0).expect("empty chunk"))
                    .expect("empty chunk");
                let mut chunked = GroupedAggOutputStorage::new(&plan).expect("chunked output");
                session
                    .finalize(&plan, &mut chunked)
                    .expect("finalize fresh plan");
                assert_eq!(chunked.measure_count(0), output.measure_count(0));
                for lane in [
                    GroupedAggStateLane::Sum,
                    GroupedAggStateLane::Min,
                    GroupedAggStateLane::Max,
                ] {
                    assert_eq!(
                        chunked.measure_state(0, lane),
                        output.measure_state(0, lane)
                    );
                }
                session.reset(&plan).expect("reset");
                session
                    .accumulate(&plan.row_chunk(0, 113).expect("reset chunk"))
                    .expect("reused session");
                // Reuse a valid typed binding with an unguarded division program.
                if expression == "CASE WHEN b<>0 THEN a/b ELSE 42 END" {
                    let failing =
                        lower("SELECT a/b FROM scalar_fused_rows").expect("division program");
                    let fault_words = failing.program.encode();
                    let fault_inputs = [
                        abi::PgaccelScalarInput {
                            values: a.as_ptr().cast(),
                            nulls: an.as_ptr(),
                            physical_type: 2,
                            reserved: 0,
                        },
                        abi::PgaccelScalarInput {
                            values: b.as_ptr().cast(),
                            nulls: std::ptr::null(),
                            physical_type: 2,
                            reserved: 0,
                        },
                    ];
                    let fault_view = abi::PgaccelScalarView {
                        word_count: fault_words.len() as u32,
                        input_count: 2,
                        words: fault_words.as_ptr(),
                        inputs: fault_inputs.as_ptr(),
                        ..view
                    };
                    desc.measures[0].value.values = std::ptr::from_ref(&fault_view).cast();
                    desc.measures[0].agg_mask = abi::PGACCEL_GROUPED_AGG_LANE_COUNT;
                    let (fault_column, _fault_owner) =
                        crate::engine::executor::agg::scalar_measure_column(
                            &failing.into_measure_expression(),
                            fact_rel,
                            &requests,
                            &views,
                            4097,
                            abi::PGACCEL_GROUPED_AGG_LANE_COUNT,
                        )
                        .expect("executor error binding");
                    desc.measures[0].value = fault_column;
                    // SAFETY: both resident inputs and host metadata stay valid.
                    let fault_plan =
                        unsafe { ResolvedGroupedAggPlan::from_abi(desc) }.expect("fault plan");
                    let mut fault_output =
                        GroupedAggOutputStorage::new(&fault_plan).expect("fault output");
                    let error =
                        execute_grouped_agg_one_shot_with_mode(&fault_plan, &mut fault_output)
                            .expect_err("COUNT must evaluate its expression");
                    assert_eq!(error.status, GpuStatusDetail::DivisionByZero);
                }
            }
        }
        crate::gpu::cleanup_grouped_allocation_pools();
        assert_eq!(
            resident_live_bytes(),
            ledger_baseline,
            "all snapshots and pooled execution buffers released"
        );
    }

    fn lower(
        sql: &str,
    ) -> Result<LoweredScalarExpression, crate::engine::ffi::planner_hooks::shape::ShapeDecline>
    {
        let text = CString::new(sql).expect("fixture SQL");
        // SAFETY: this pg_test runs on the backend main thread in an active
        // transaction. Parser/analyzer allocations stay alive for the whole
        // synchronous lowering call; no PostgreSQL pointers are returned.
        unsafe {
            let raw = pg_sys::pg_parse_query(text.as_ptr());
            assert_eq!(pg_sys::list_length(raw), 1);
            let statement = pg_sys::list_nth(raw, 0).cast::<pg_sys::RawStmt>();
            let query = pg_sys::parse_analyze_fixedparams(
                statement,
                text.as_ptr(),
                std::ptr::null(),
                0,
                std::ptr::null_mut(),
            );
            assert!(!query.is_null());
            let target = pg_sys::list_nth((*query).targetList, 0).cast::<pg_sys::TargetEntry>();
            let expression =
                pg_sys::eval_const_expressions(std::ptr::null_mut(), (*target).expr.cast());
            lower_scalar_expression(expression, &*query)
        }
    }

    fn setup() {
        Spi::run("SET pg_accel.enabled=off; CREATE TEMP TABLE scalar_rows(id int4,a int4,b int4,c int4,p bool,q bool,w int8,d date); \
            INSERT INTO scalar_rows VALUES \
            (1,7,3,-2,true,false,1,'2026-01-01'), \
            (2,-7,3,2,false,true,2,'2026-01-02'), \
            (3,NULL,3,0,NULL,false,3,'2026-01-03'), \
            (4,7,NULL,-1,true,NULL,4,'2026-01-04'), \
            (5,NULL,NULL,NULL,NULL,NULL,5,'2026-01-05');")
            .expect("native scalar fixture");
    }

    fn verify(expression: &str) {
        let lowered = lower(&format!("SELECT {expression} FROM scalar_rows")).expect(expression);
        let logical = lowered.clone().into_measure_expression();
        let crate::engine::spec::MeasureExpr::Bytecode {
            inputs,
            program,
            result_type_oid,
        } = logical
        else {
            panic!("lowering must preserve the versioned program envelope");
        };
        assert_eq!(program, lowered.program.encode());
        assert_eq!(
            inputs,
            lowered
                .inputs
                .iter()
                .map(|input| input.column)
                .collect::<Vec<_>>()
        );
        assert_eq!(
            result_type_oid,
            if lowered.program.result_type() == ScalarType::Int4 {
                23
            } else {
                16
            }
        );
        for id in 1..=5 {
            let values = lowered
                .inputs
                .iter()
                .map(|column| {
                    let name = match column.column.attno {
                        2 => "a",
                        3 => "b",
                        4 => "c",
                        5 => "p",
                        6 => "q",
                        _ => panic!("unexpected lowered input {column:?}"),
                    };
                    let sql = format!("SELECT {name} FROM scalar_rows WHERE id={id}");
                    match column.column.type_oid {
                        23 => Spi::get_one::<i32>(&sql)
                            .expect("int4 input")
                            .map_or(Value::Null(ScalarType::Int4), Value::Int4),
                        16 => Spi::get_one::<bool>(&sql)
                            .expect("Boolean input")
                            .map_or(Value::Null(ScalarType::Bool), Value::Bool),
                        _ => panic!("unsupported input type"),
                    }
                })
                .collect::<Vec<_>>();
            let expected = match lowered.program.result_type() {
                ScalarType::Int4 => Spi::get_one::<i32>(&format!(
                    "SELECT {expression} FROM scalar_rows WHERE id={id}"
                ))
                .expect(expression)
                .map_or(Value::Null(ScalarType::Int4), Value::Int4),
                ScalarType::Bool => Spi::get_one::<bool>(&format!(
                    "SELECT {expression} FROM scalar_rows WHERE id={id}"
                ))
                .expect(expression)
                .map_or(Value::Null(ScalarType::Bool), Value::Bool),
            };
            assert_eq!(
                evaluate(&lowered.program, &values),
                Ok(expected),
                "{expression}, row {id}"
            );
        }
    }

    #[pg_test]
    fn pg_scalar_lowering_matches_native_simplified_trees() {
        setup();
        for expression in [
            "a+(b*c)-(-a)",
            "a/b",
            "a%b",
            "a=b",
            "a<>b",
            "a<b",
            "a<=b",
            "a>b",
            "a>=b",
            "p=q",
            "p<>q",
            "p<q",
            "p<=q",
            "p>q",
            "p>=q",
            "p AND q",
            "p OR q",
            "NOT p",
            "a IS NULL",
            "p IS NOT NULL",
            "p AND q AND a>0",
            "p OR q OR a>0",
            "(a>0 OR b<0) AND (p OR NOT q)",
            "CASE WHEN p THEN a*b WHEN q THEN a+b ELSE c END",
            "CASE WHEN a IS NULL THEN COALESCE(b,c,42) ELSE a+COALESCE(b,c,0) END",
            "COALESCE(a,b,c,42)",
            "COALESCE(p,q,false)",
            "CASE WHEN a IS NULL THEN NULL ELSE a*2 END",
            "CASE WHEN p THEN CASE WHEN q THEN a ELSE b END ELSE c END",
            "42",
            "NULL::int4",
            "true",
            "NULL::boolean",
            "a+a+a",
            "ROW(a,b) IS NULL",
            "ROW(a,b) IS NOT NULL",
            "NOT (ROW(a,b) IS NULL)",
        ] {
            verify(expression);
        }
        let repeated = lower("SELECT a+a+a FROM scalar_rows").expect("deduplicated input");
        assert_eq!(repeated.inputs.len(), 1);
        let folded =
            lower("SELECT NULL::int4+(a/0) FROM scalar_rows").expect("PG folded literal NULL");
        assert!(folded.inputs.is_empty());
        assert_eq!(folded.program.instructions(), &[I::Null(ScalarType::Int4)]);
        let row_null = lower("SELECT a+(b/0) FROM scalar_rows").expect("runtime NULL");
        assert_eq!(
            evaluate(
                &row_null.program,
                &[Value::Null(ScalarType::Int4), Value::Int4(1)]
            ),
            Err(crate::engine::spec::scalar::tests::Fault::DivisionByZero)
        );
    }

    #[pg_test]
    fn pg_scalar_lowering_preserves_lazy_error_branches() {
        setup();
        for expression in [
            "CASE WHEN a IS NULL THEN 42 ELSE CASE WHEN b IS NULL THEN 7 ELSE a/b END END",
            "CASE WHEN a IS NOT NULL THEN a ELSE COALESCE(b,c,42) END",
            "CASE WHEN p IS NULL THEN 42 ELSE CASE WHEN p THEN a ELSE b END END",
            "COALESCE(a,COALESCE(b,c,42),a/0)",
            "(p IS NULL OR p IS NOT NULL) OR a/0>0",
            "(p IS NULL AND p IS NOT NULL) AND a/0>0",
        ] {
            verify(expression);
        }
        let lazy = lower("SELECT CASE WHEN p THEN a/0 ELSE 42 END FROM scalar_rows")
            .expect("searched CASE");
        assert_eq!(
            evaluate(&lazy.program, &[Value::Bool(false), Value::Int4(7)]),
            Ok(Value::Int4(42))
        );
        assert_eq!(
            evaluate(
                &lazy.program,
                &[Value::Null(ScalarType::Bool), Value::Int4(7)]
            ),
            Ok(Value::Int4(42))
        );
        assert_eq!(
            evaluate(&lazy.program, &[Value::Bool(true), Value::Int4(7)]),
            Err(crate::engine::spec::scalar::tests::Fault::DivisionByZero)
        );
    }

    #[pg_test]
    fn pg_scalar_lowering_matches_native_error_states() {
        setup();
        Spi::run("CREATE FUNCTION pg_temp.scalar_try(query text) RETURNS text LANGUAGE plpgsql AS $$ \
            DECLARE value text; BEGIN EXECUTE query INTO value; \
            RETURN 'ok:'||COALESCE(value,'NULL'); EXCEPTION WHEN OTHERS THEN RETURN 'error:'||SQLSTATE; END $$")
            .expect("native subtransaction error oracle");
        for expression in [
            "a+2147483647",
            "a-2147483647",
            "a*2147483647",
            "-(a+2147483647)",
            "a/(b-b)",
            "a%(b-b)",
            "a+(b/0)",
            "NULL::int4+(b/0)",
            "CASE WHEN p THEN a+2147483647 ELSE a/(b-b) END",
            "COALESCE(a,b/0)",
            "p AND a/0>0",
            "p OR a/0>0",
        ] {
            let lowered =
                lower(&format!("SELECT {expression} FROM scalar_rows")).expect(expression);
            for id in 1..=5 {
                let mut values = Vec::new();
                for column in &lowered.inputs {
                    let name = match column.column.attno {
                        2 => "a",
                        3 => "b",
                        5 => "p",
                        _ => panic!("unexpected input"),
                    };
                    let sql = format!("SELECT {name} FROM scalar_rows WHERE id={id}");
                    values.push(if column.column.type_oid == 23 {
                        Spi::get_one::<i32>(&sql)
                            .expect("integer input")
                            .map_or(Value::Null(ScalarType::Int4), Value::Int4)
                    } else {
                        Spi::get_one::<bool>(&sql)
                            .expect("Boolean input")
                            .map_or(Value::Null(ScalarType::Bool), Value::Bool)
                    });
                }
                let interpreted = match evaluate(&lowered.program, &values) {
                    Ok(Value::Null(_)) => "ok:NULL".to_owned(),
                    Ok(Value::Int4(value)) => format!("ok:{value}"),
                    Ok(Value::Bool(value)) => format!("ok:{value}"),
                    Err(crate::engine::spec::scalar::tests::Fault::Overflow) => {
                        "error:22003".to_owned()
                    }
                    Err(crate::engine::spec::scalar::tests::Fault::DivisionByZero) => {
                        "error:22012".to_owned()
                    }
                };
                let native = Spi::get_one::<String>(&format!("SELECT pg_temp.scalar_try($scalar$SELECT {expression} FROM scalar_rows WHERE id={id}$scalar$)"))
                    .expect("native error oracle").expect("non-null outcome");
                assert_eq!(interpreted, native, "{expression}, row {id}");
            }
        }
    }

    #[pg_test]
    fn pg_scalar_lowering_rejects_unqualified_catalog_and_relation_shapes() {
        setup();
        Spi::run("CREATE DOMAIN pg_temp.scalar_positive AS int4 CHECK(VALUE>0); \
            CREATE FUNCTION pg_temp.scalar_fake_add(int4,int4) RETURNS int4 LANGUAGE plpgsql VOLATILE AS $$ BEGIN RETURN $1-$2; END $$; \
            CREATE OPERATOR pg_temp.+ (FUNCTION=pg_temp.scalar_fake_add,LEFTARG=int4,RIGHTARG=int4)")
            .expect("adversarial catalogs");
        for expression in [
            "w::int4",
            "a::int8",
            "(a::int2)::int4",
            "(a::pg_temp.scalar_positive)::int4",
            "a OPERATOR(pg_temp.+) b",
            "pg_temp.scalar_fake_add(a,b)",
            "CASE a WHEN 1 THEN b ELSE c END",
            "scalar_rows IS NULL",
            "random()>0",
            "d>date '2026-01-02'",
            "a+(SELECT max(b) FROM scalar_rows)",
            "generate_series(1,a)",
        ] {
            assert!(
                lower(&format!("SELECT {expression} FROM scalar_rows")).is_err(),
                "must decline {expression}"
            );
        }
        assert!(
            lower("SELECT x.a+y.a FROM scalar_rows x CROSS JOIN scalar_rows y").is_err(),
            "same OID does not mean same occurrence"
        );
        assert!(
            lower("SELECT x.a+x.b FROM scalar_rows x CROSS JOIN scalar_rows y").is_ok(),
            "one occurrence's expression is representable; caller still rejects self join"
        );
    }

    #[pg_test]
    fn pg_scalar_lowering_enforces_instruction_stack_and_input_bounds() {
        setup();
        let expression = format!("-COALESCE({})", vec!["a"; 128].join(","));
        let exact =
            lower(&format!("SELECT {expression} FROM scalar_rows")).expect("256 instructions");
        assert_eq!(exact.program.instructions().len(), 256);
        let expression = format!("-COALESCE({})", vec!["a"; 129].join(","));
        assert!(lower(&format!("SELECT {expression} FROM scalar_rows")).is_err());
        let mut expression = "a".to_owned();
        for _ in 1..32 {
            expression = format!("a+({expression})");
        }
        assert_eq!(
            lower(&format!("SELECT {expression} FROM scalar_rows"))
                .expect("32 stack slots")
                .program
                .max_stack(),
            32
        );
        assert!(lower(&format!("SELECT a+({expression}) FROM scalar_rows")).is_err());
        Spi::run(&format!(
            "CREATE TEMP TABLE scalar_wide({})",
            (0..65)
                .map(|i| format!("c{i} int4"))
                .collect::<Vec<_>>()
                .join(",")
        ))
        .expect("wide input fixture");
        fn balanced(columns: &[String]) -> String {
            if columns.len() == 1 {
                return columns[0].clone();
            }
            let middle = columns.len() / 2;
            format!(
                "({})+({})",
                balanced(&columns[..middle]),
                balanced(&columns[middle..])
            )
        }
        let columns = (0..65).map(|i| format!("c{i}")).collect::<Vec<_>>();
        assert_eq!(
            lower(&format!(
                "SELECT {} FROM scalar_wide",
                balanced(&columns[..64])
            ))
            .expect("64 inputs")
            .inputs
            .len(),
            64
        );
        assert!(lower(&format!("SELECT {} FROM scalar_wide", balanced(&columns))).is_err());
    }
}
