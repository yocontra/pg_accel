//! Bounded PostgreSQL-node lowering into SPG1. This does not inject a path or
//! bypass descriptor capability/cost admission. Call on planner-simplified
//! nodes: PostgreSQL's constant-folding and error timing remain authoritative.

use pgrx::pg_sys::{self, Node, NodeTag};

use crate::engine::spec::scalar::{
    MAX_SCALAR_INPUTS, MAX_SCALAR_INSTRUCTIONS, ScalarInstruction as I, ScalarProgram, ScalarType,
};

use super::postgres::{direct_var, list_item, list_len};
use super::{PlannerColumn, ShapeDecline};

const MAX_LOWERING_DEPTH: usize = 64;

/// Logical inputs retain range-table occurrence identity until the caller
/// proves its single-fact relation contract. No resident pointers are stored.
#[derive(Debug, Clone)]
pub struct LoweredScalarExpression {
    pub inputs: Vec<PlannerColumn>,
    pub program: ScalarProgram,
}

impl LoweredScalarExpression {
    /// Encode into the existing opaque measure-program envelope. SPG1 owns
    /// its inner version; this does not change the outer AQS6 grammar or make
    /// the descriptor executor capable of consuming the program.
    #[must_use]
    pub fn into_measure_expression(self) -> crate::engine::spec::MeasureExpr {
        crate::engine::spec::MeasureExpr::Bytecode {
            inputs: self.inputs.into_iter().map(|input| input.column).collect(),
            result_type_oid: u32::from(match self.program.result_type() {
                ScalarType::Bool => pg_sys::BOOLOID,
                ScalarType::Int4 => pg_sys::INT4OID,
            }),
            program: self.program.encode(),
        }
    }
}

fn declined<T>() -> Result<T, ShapeDecline> {
    Err(ShapeDecline::UnsupportedMeasureExpression)
}

fn scalar_type(oid: pg_sys::Oid) -> Result<ScalarType, ShapeDecline> {
    match oid {
        pg_sys::INT4OID => Ok(ScalarType::Int4),
        pg_sys::BOOLOID => Ok(ScalarType::Bool),
        _ => declined(),
    }
}

/// Exact built-in implementation identity, never the operator's spelling.
fn operation(function: u32) -> Option<(I, usize)> {
    Some(match function {
        pg_sys::F_INT4PL => (I::Add, 2),
        pg_sys::F_INT4MI => (I::Sub, 2),
        pg_sys::F_INT4MUL => (I::Mul, 2),
        pg_sys::F_INT4DIV => (I::Div, 2),
        pg_sys::F_INT4MOD => (I::Mod, 2),
        pg_sys::F_INT4UM => (I::Neg, 1),
        pg_sys::F_INT4EQ | pg_sys::F_BOOLEQ => (I::Eq, 2),
        pg_sys::F_INT4NE | pg_sys::F_BOOLNE => (I::Ne, 2),
        pg_sys::F_INT4LT | pg_sys::F_BOOLLT => (I::Lt, 2),
        pg_sys::F_INT4LE | pg_sys::F_BOOLLE => (I::Le, 2),
        pg_sys::F_INT4GT | pg_sys::F_BOOLGT => (I::Gt, 2),
        pg_sys::F_INT4GE | pg_sys::F_BOOLGE => (I::Ge, 2),
        _ => return None,
    })
}

#[derive(Default)]
struct Lowerer {
    inputs: Vec<PlannerColumn>,
    code: Vec<I>,
    visited: usize,
}

impl Lowerer {
    fn emit(&mut self, instruction: I) -> Result<usize, ShapeDecline> {
        if self.code.len() >= MAX_SCALAR_INSTRUCTIONS {
            return declined();
        }
        let index = self.code.len();
        self.code.push(instruction);
        Ok(index)
    }

    fn patch(&mut self, index: usize) -> Result<(), ShapeDecline> {
        let target = self.code.len() as u32; // bounded by emit
        let Some(instruction) = self.code.get_mut(index) else {
            return declined();
        };
        *instruction = match *instruction {
            I::Jump(_) => I::Jump(target),
            I::JumpIfNotTrue(_) => I::JumpIfNotTrue(target),
            I::JumpIfTrue(_) => I::JumpIfTrue(target),
            I::JumpIfFalse(_) => I::JumpIfFalse(target),
            I::JumpIfNotNull(_) => I::JumpIfNotNull(target),
            _ => return declined(),
        };
        Ok(())
    }

    unsafe fn node(
        &mut self,
        node: *mut Node,
        query: &pg_sys::Query,
        depth: usize,
    ) -> Result<(), ShapeDecline> {
        if node.is_null() || depth >= MAX_LOWERING_DEPTH || self.visited >= MAX_SCALAR_INSTRUCTIONS
        {
            return declined();
        }
        self.visited += 1;
        // SAFETY: node is an analyzed expression owned by the caller's active
        // planner tree; exprType reads its declared SQL result type.
        let result = scalar_type(unsafe { pg_sys::exprType(node) })?;
        // SAFETY: the caller supplies valid PostgreSQL nodes; each following
        // cast is guarded by this concrete NodeTag and stays in this call.
        match unsafe { (*node).type_ } {
            NodeTag::T_Var => {
                // SAFETY: node/query belong to the same active planner tree.
                let column = unsafe { direct_var(node, query) }
                    .ok_or(ShapeDecline::UnsupportedMeasureExpression)?;
                // ColumnRef alone cannot distinguish aliases of one relation.
                // Keep this single-input-relation producer fail-closed until
                // relation-occurrence identities exist throughout the spec.
                if self
                    .inputs
                    .first()
                    .is_some_and(|first| first.varno != column.varno)
                {
                    return declined();
                }
                let index =
                    if let Some(index) = self.inputs.iter().position(|input| *input == column) {
                        index
                    } else {
                        if self.inputs.len() >= MAX_SCALAR_INPUTS {
                            return declined();
                        }
                        self.inputs.push(column);
                        self.inputs.len() - 1
                    };
                self.emit(I::Input(index as u32))?;
            }
            NodeTag::T_Const => {
                // SAFETY: the NodeTag proves Const layout.
                let constant = unsafe { &*node.cast::<pg_sys::Const>() };
                if !constant.constbyval
                    || constant.constlen != if result == ScalarType::Int4 { 4 } else { 1 }
                    || constant.constcollid != pg_sys::InvalidOid
                {
                    return declined();
                }
                let instruction = if constant.constisnull {
                    I::Null(result)
                } else {
                    // SAFETY: exact type, by-value representation and width
                    // were checked above before interpreting the Datum.
                    unsafe {
                        match result {
                            ScalarType::Int4 => I::Int4(pg_sys::DatumGetInt32(constant.constvalue)),
                            ScalarType::Bool => I::Bool(pg_sys::DatumGetBool(constant.constvalue)),
                        }
                    }
                };
                self.emit(instruction)?;
            }
            NodeTag::T_OpExpr => {
                // SAFETY: the NodeTag proves OpExpr layout.
                let op = unsafe { &*node.cast::<pg_sys::OpExpr>() };
                if op.opretset
                    || op.opcollid != pg_sys::InvalidOid
                    || op.inputcollid != pg_sys::InvalidOid
                {
                    return declined();
                }
                // SAFETY: opno is the analyzed operator catalog identity.
                let function = unsafe { pg_sys::get_opcode(op.opno) };
                if op.opfuncid != pg_sys::InvalidOid && op.opfuncid != function {
                    return declined();
                }
                let (instruction, arity) = operation(u32::from(function))
                    .ok_or(ShapeDecline::UnsupportedMeasureExpression)?;
                if list_len(op.args) != arity {
                    return declined();
                }
                for index in 0..arity {
                    // SAFETY: the analyzed argument list is length-checked;
                    // recursive lowering retains the same planner lifetime.
                    unsafe { self.argument(op.args, index, query, depth)? };
                }
                self.emit(instruction)?;
            }
            NodeTag::T_BoolExpr => {
                // SAFETY: the NodeTag proves BoolExpr layout.
                let expr = unsafe { &*node.cast::<pg_sys::BoolExpr>() };
                let count = list_len(expr.args);
                if count == 0 || count > MAX_SCALAR_INSTRUCTIONS {
                    return declined();
                }
                // SAFETY: nonempty analyzed argument list, bounded recursion.
                unsafe { self.argument(expr.args, 0, query, depth)? };
                match expr.boolop {
                    pg_sys::BoolExprType::NOT_EXPR if count == 1 => {
                        self.emit(I::Not)?;
                    }
                    pg_sys::BoolExprType::AND_EXPR | pg_sys::BoolExprType::OR_EXPR => {
                        let is_and = expr.boolop == pg_sys::BoolExprType::AND_EXPR;
                        let mut ends = Vec::new();
                        for index in 1..count {
                            self.emit(I::Dup)?;
                            ends.push(self.emit(if is_and {
                                I::JumpIfFalse(0)
                            } else {
                                I::JumpIfTrue(0)
                            })?);
                            // SAFETY: index is bounded by the analyzed list.
                            unsafe { self.argument(expr.args, index, query, depth)? };
                            self.emit(if is_and { I::And } else { I::Or })?;
                        }
                        for end in ends {
                            self.patch(end)?;
                        }
                    }
                    _ => return declined(),
                }
            }
            NodeTag::T_CaseExpr => {
                // SAFETY: the NodeTag proves CaseExpr layout.
                let expr = unsafe { &*node.cast::<pg_sys::CaseExpr>() };
                let count = list_len(expr.args);
                // Simple CASE needs a once-evaluated CaseTestExpr local; do
                // not duplicate its input expression to simulate that local.
                if !expr.arg.is_null()
                    || count > MAX_SCALAR_INSTRUCTIONS
                    || expr.casecollid != pg_sys::InvalidOid
                {
                    return declined();
                }
                let mut ends = Vec::new();
                for index in 0..count {
                    // SAFETY: CaseExpr.args contains planner-owned CaseWhen
                    // nodes; list_item bounds-checks before dereferencing.
                    let branch = unsafe { list_item::<pg_sys::CaseWhen>(expr.args, index) }
                        .ok_or(ShapeDecline::UnsupportedMeasureExpression)?;
                    // SAFETY: returned pointer is a live CaseWhen list entry.
                    let branch = unsafe { &*branch };
                    if branch.xpr.type_ != NodeTag::T_CaseWhen {
                        return declined();
                    }
                    // SAFETY: condition/result belong to the active CaseWhen.
                    unsafe { self.node(branch.expr.cast(), query, depth + 1)? };
                    let next = self.emit(I::JumpIfNotTrue(0))?;
                    // SAFETY: result belongs to the same active tree.
                    unsafe { self.node(branch.result.cast(), query, depth + 1)? };
                    ends.push(self.emit(I::Jump(0))?);
                    self.patch(next)?;
                }
                // SAFETY: analyzed CASE has a typed default (possibly NULL).
                unsafe { self.node(expr.defresult.cast(), query, depth + 1)? };
                for end in ends {
                    self.patch(end)?;
                }
            }
            NodeTag::T_CoalesceExpr => {
                // SAFETY: the NodeTag proves CoalesceExpr layout.
                let expr = unsafe { &*node.cast::<pg_sys::CoalesceExpr>() };
                let count = list_len(expr.args);
                if count == 0
                    || count > MAX_SCALAR_INSTRUCTIONS
                    || expr.coalescecollid != pg_sys::InvalidOid
                {
                    return declined();
                }
                let mut ends = Vec::new();
                for index in 0..count {
                    // SAFETY: index is bounded by the analyzed argument list.
                    unsafe { self.argument(expr.args, index, query, depth)? };
                    if index + 1 < count {
                        ends.push(self.emit(I::JumpIfNotNull(0))?);
                    }
                }
                for end in ends {
                    self.patch(end)?;
                }
            }
            NodeTag::T_NullTest => {
                // SAFETY: the NodeTag proves NullTest layout.
                let expr = unsafe { &*node.cast::<pg_sys::NullTest>() };
                if expr.argisrow {
                    return declined();
                }
                // SAFETY: argument belongs to this scalar NullTest.
                unsafe { self.node(expr.arg.cast(), query, depth + 1)? };
                self.emit(match expr.nulltesttype {
                    pg_sys::NullTestType::IS_NULL => I::IsNull,
                    pg_sys::NullTestType::IS_NOT_NULL => I::IsNotNull,
                    _ => return declined(),
                })?;
            }
            // No implicit/explicit cast stripping: domains, narrowing casts,
            // custom functions, Params, SRFs and subqueries stay unsupported.
            _ => return declined(),
        }
        Ok(())
    }

    unsafe fn argument(
        &mut self,
        args: *mut pg_sys::List,
        index: usize,
        query: &pg_sys::Query,
        depth: usize,
    ) -> Result<(), ShapeDecline> {
        // SAFETY: args belongs to the active expression; list_item bounds-checks.
        let node = unsafe { list_item::<Node>(args, index) }
            .ok_or(ShapeDecline::UnsupportedMeasureExpression)?;
        // SAFETY: argument has the caller's planner lifetime.
        unsafe { self.node(node, query, depth + 1) }
    }
}

/// Lower a planner-simplified expression without changing SQL admission.
///
/// # Safety
/// `node` and `query` must belong to the same live analyzed PostgreSQL query,
/// on the backend main thread. They must outlive this synchronous call.
pub unsafe fn lower_scalar_expression(
    node: *mut Node,
    query: &pg_sys::Query,
) -> Result<LoweredScalarExpression, ShapeDecline> {
    if node.is_null() {
        return declined();
    }
    // SAFETY: node is live analyzed planner memory under the caller's contract.
    let result = scalar_type(unsafe { pg_sys::exprType(node) })?;
    let mut lowerer = Lowerer::default();
    // SAFETY: forwards the same valid planner tree and bounded initial depth.
    unsafe { lowerer.node(node, query, 0)? };
    let types = lowerer
        .inputs
        .iter()
        .map(|input| scalar_type(pg_sys::Oid::from(input.column.type_oid)))
        .collect::<Result<Vec<_>, _>>()?;
    let program = ScalarProgram::new(types, result, lowerer.code)
        .map_err(|_| ShapeDecline::UnsupportedMeasureExpression)?;
    Ok(LoweredScalarExpression {
        inputs: lowerer.inputs,
        program,
    })
}
