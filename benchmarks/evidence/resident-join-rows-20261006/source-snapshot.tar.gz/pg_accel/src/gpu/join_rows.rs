//! Resident integer equijoin row mappings. This is an execution primitive, not
//! SQL planner admission. Input residency/currentness and work-size admission
//! belong to the future pipeline caller; there is no CPU join fallback here.

use std::ffi::c_void;
use std::marker::PhantomData;

use crate::engine::residency::ExecutionMemoryCharge;

use super::{
    ExprDeviceBuffer, GpuError, GpuErrorDomain, GpuOperation, GpuResult, GpuStatusDetail,
    PgaccelStatus, bridge, status_to_result,
};

const VERSION: u32 = 1;
const MAX_KEYS: usize = 4;
#[cfg_attr(not(feature = "pg_test"), allow(dead_code))] // ABI sentinel; live oracle caller, pending pipeline admission.
pub const JOIN_NULL_ROW: u64 = u64::MAX;

#[repr(C)]
#[derive(Clone, Copy, Default)]
pub struct NativeJoinKey {
    values: *const c_void,
    nulls: *const u8,
    value_bytes: u64,
    null_bytes: u64,
    kind: u32,
    reserved: u32,
}

#[repr(C)]
pub struct NativeJoinRequest {
    version: u32,
    kind: u32,
    key_count: u32,
    reserved: u32,
    outer_rows: u64,
    inner_rows: u64,
    outer_keys: [NativeJoinKey; MAX_KEYS],
    inner_keys: [NativeJoinKey; MAX_KEYS],
}

#[repr(C)]
#[derive(Clone, Copy, Default, Debug, PartialEq, Eq, PartialOrd, Ord)]
pub struct JoinRowPair {
    pub outer_row: u64,
    /// JOIN_NULL_ROW for unmatched LEFT rows and every SEMI/ANTI row.
    pub inner_row: u64,
}

#[repr(C)]
#[derive(Default)]
pub struct NativeJoinResult {
    required_rows: u64,
    emitted_rows: u64,
    kernel_launches: u64,
}

#[derive(Clone, Copy)]
#[repr(u32)]
#[cfg_attr(not(feature = "pg_test"), allow(dead_code))] // Native producer kinds; live-tested before SQL wiring.
pub enum ResidentJoinKind {
    Inner = 0,
    Left = 1,
    Semi = 2,
    Anti = 3,
}

/// A typed borrow of already-resident keys. None represents an empty column,
/// not a NULL column; a missing sidecar means all values are non-NULL.
#[derive(Clone, Copy)]
#[cfg_attr(not(feature = "pg_test"), allow(dead_code))] // Typed native producer inputs; pending pipeline caller.
pub enum ResidentJoinKey<'a> {
    Int32 {
        values: Option<&'a ExprDeviceBuffer<i32>>,
        nulls: Option<&'a ExprDeviceBuffer<u8>>,
    },
    Int64 {
        values: Option<&'a ExprDeviceBuffer<i64>>,
        nulls: Option<&'a ExprDeviceBuffer<u8>>,
    },
}

fn contract_error(detail: &'static str) -> GpuError {
    GpuError::with_detail(
        GpuErrorDomain::HashJoin,
        GpuOperation::ValidateDeviceInput,
        GpuStatusDetail::ShapeMismatch,
        detail,
    )
}

fn allocation_error(detail: &'static str) -> GpuError {
    GpuError::with_detail(
        GpuErrorDomain::HashJoin,
        GpuOperation::BuildColumnBatch,
        GpuStatusDetail::OutOfMemory,
        detail,
    )
}

fn bind_key<T>(
    values: Option<&ExprDeviceBuffer<T>>,
    nulls: Option<&ExprDeviceBuffer<u8>>,
    kind: u32,
) -> GpuResult<(NativeJoinKey, usize)> {
    let rows = values.map_or(0, ExprDeviceBuffer::len);
    if rows > i32::MAX as usize || nulls.is_some_and(|sidecar| sidecar.len() != rows) {
        return Err(contract_error("join input row/NULL lengths are invalid"));
    }
    let bytes = rows
        .checked_mul(size_of::<T>())
        .ok_or_else(|| contract_error("join input byte count overflow"))?;
    Ok((
        NativeJoinKey {
            values: values.map_or(std::ptr::null(), |buffer| buffer.as_ptr().cast()),
            nulls: nulls.map_or(std::ptr::null(), ExprDeviceBuffer::as_ptr),
            value_bytes: bytes as u64,
            null_bytes: nulls.map_or(0, |buffer| buffer.len() as u64),
            kind,
            reserved: 0,
        },
        rows,
    ))
}

impl ResidentJoinKey<'_> {
    fn bind(self) -> GpuResult<(NativeJoinKey, usize)> {
        match self {
            Self::Int32 { values, nulls } => bind_key(values, nulls, 1),
            Self::Int64 { values, nulls } => bind_key(values, nulls, 2),
        }
    }
}

/// Borrows every input through the synchronous dispatch. Raw descriptors never
/// escape to a plan wire, another backend or a sendable owner.
#[cfg_attr(not(feature = "pg_test"), allow(dead_code))] // Live-tested resident producer owner, not planner-selected yet.
pub struct ResidentJoin<'a> {
    request: NativeJoinRequest,
    _inputs: PhantomData<ResidentJoinKey<'a>>,
}

#[cfg_attr(not(feature = "pg_test"), allow(dead_code))] // Staged facade exercised by live PostgreSQL oracle tests.
impl<'a> ResidentJoin<'a> {
    pub fn new(
        kind: ResidentJoinKind,
        outer: &[ResidentJoinKey<'a>],
        inner: &[ResidentJoinKey<'a>],
    ) -> GpuResult<Self> {
        if outer.is_empty() || outer.len() > MAX_KEYS || outer.len() != inner.len() {
            return Err(contract_error(
                "join requires one to four matching key pairs",
            ));
        }
        let mut request = NativeJoinRequest {
            version: VERSION,
            kind: kind as u32,
            key_count: outer.len() as u32,
            reserved: 0,
            outer_rows: 0,
            inner_rows: 0,
            outer_keys: [NativeJoinKey::default(); MAX_KEYS],
            inner_keys: [NativeJoinKey::default(); MAX_KEYS],
        };
        for (index, (left, right)) in outer.iter().zip(inner).enumerate() {
            let (left, left_rows) = left.bind()?;
            let (right, right_rows) = right.bind()?;
            if left.kind != right.kind
                || (index != 0
                    && (request.outer_rows != left_rows as u64
                        || request.inner_rows != right_rows as u64))
            {
                return Err(contract_error("join key types or column lengths disagree"));
            }
            request.outer_rows = left_rows as u64;
            request.inner_rows = right_rows as u64;
            request.outer_keys[index] = left;
            request.inner_keys[index] = right;
        }
        Ok(Self {
            request,
            _inputs: PhantomData,
        })
    }

    /// Exact device workspace bytes; does not initialize or allocate a GPU.
    pub fn workspace_bytes(&self) -> GpuResult<usize> {
        let mut bytes = 0;
        // SAFETY: request is an initialized ABI mirror with typed borrowed
        // buffers; bytes is a disjoint host scalar. The query reads no rows.
        let status = unsafe {
            bridge::pgaccel_join_rows_workspace_bytes(&raw const self.request, &raw mut bytes)
        };
        status_to_result(
            status,
            GpuErrorDomain::HashJoin,
            GpuOperation::Kernel("pgaccel_join_rows_workspace_bytes"),
        )?;
        if bytes == 0 || bytes % size_of::<u64>() as u64 != 0 {
            return Err(contract_error("native join workspace is not u64-aligned"));
        }
        usize::try_from(bytes).map_err(|_| contract_error("join workspace exceeds address space"))
    }

    /// Caller admits bounded work before dispatch. Capacity is a hard row-pair
    /// limit, not an estimate: exhaustion returns metadata without partial rows.
    /// All scratch/output bytes are reserved before either allocation. Input
    /// buffers remain charged by their residency owner, not charged twice here.
    pub fn execute(&self, capacity: usize) -> GpuResult<ResidentJoinOutcome> {
        let workspace_bytes = self.workspace_bytes()?;
        let output_bytes = capacity
            .checked_mul(size_of::<JoinRowPair>())
            .ok_or_else(|| contract_error("join output capacity overflows bytes"))?;
        let budget = crate::engine::gucs::resident_memory_budget_bytes();
        let _workspace_charge = ExecutionMemoryCharge::reserve(workspace_bytes as u64, budget)
            .map_err(|_| allocation_error("join workspace exceeds resident memory budget"))?;
        let output_charge = ExecutionMemoryCharge::reserve(output_bytes as u64, budget)
            .map_err(|_| allocation_error("join output exceeds resident memory budget"))?;
        // Use u64 storage to make the native workspace alignment explicit.
        let workspace = ExprDeviceBuffer::<u64>::new(workspace_bytes / size_of::<u64>())
            .ok_or_else(|| allocation_error("join workspace allocation failed"))?;
        let output = if capacity == 0 {
            None
        } else {
            Some(
                ExprDeviceBuffer::<JoinRowPair>::new(capacity)
                    .ok_or_else(|| allocation_error("join output allocation failed"))?,
            )
        };
        let mut result = NativeJoinResult::default();
        // SAFETY: typed borrowed inputs outlive this synchronous call. Scratch
        // and output are fresh, disjoint, aligned allocations of the declared
        // sizes; stack request/result are disjoint. Empty output is canonical.
        let status = unsafe {
            bridge::pgaccel_join_rows_execute(
                &raw const self.request,
                workspace.as_mut_ptr().cast(),
                workspace_bytes as u64,
                output
                    .as_ref()
                    .map_or(std::ptr::null_mut(), ExprDeviceBuffer::as_mut_ptr),
                capacity as u64,
                &raw mut result,
            )
        };
        if status == PgaccelStatus::ErrorOom
            && result.required_rows > capacity as u64
            && result.emitted_rows == 0
        {
            return Ok(ResidentJoinOutcome::NeedsCapacity {
                required_rows: result.required_rows,
                kernel_launches: result.kernel_launches,
            });
        }
        status_to_result(
            status,
            GpuErrorDomain::HashJoin,
            GpuOperation::Kernel("pgaccel_join_rows_execute"),
        )?;
        if result.emitted_rows != result.required_rows || result.emitted_rows > capacity as u64 {
            return Err(contract_error(
                "native join returned invalid output cardinality",
            ));
        }
        Ok(ResidentJoinOutcome::Complete(ResidentJoinOutput {
            buffer: output,
            rows: result.emitted_rows as usize,
            kernel_launches: result.kernel_launches,
            _charge: output_charge,
        }))
    }
}

#[cfg_attr(not(feature = "pg_test"), allow(dead_code))] // Capacity outcome for staged resident producer.
pub enum ResidentJoinOutcome {
    Complete(ResidentJoinOutput),
    NeedsCapacity {
        required_rows: u64,
        kernel_launches: u64,
    },
}

/// Only successful initialized rows are exposed. Device allocation precedes
/// the charge field so drop frees memory before releasing its ledger charge.
#[cfg_attr(not(feature = "pg_test"), allow(dead_code))] // Charged resident result, pending pipeline consumer.
pub struct ResidentJoinOutput {
    buffer: Option<ExprDeviceBuffer<JoinRowPair>>,
    rows: usize,
    kernel_launches: u64,
    _charge: ExecutionMemoryCharge,
}

#[cfg_attr(not(feature = "pg_test"), allow(dead_code))] // Live-tested output boundary; no production caller yet.
impl ResidentJoinOutput {
    pub fn len(&self) -> usize {
        self.rows
    }

    pub fn is_empty(&self) -> bool {
        self.rows == 0
    }

    pub fn kernel_launches(&self) -> u64 {
        self.kernel_launches
    }

    /// GPU consumer input, valid for len() row pairs while this owner lives.
    /// No row data is copied to the host by the producer.
    pub fn as_device_ptr(&self) -> *const JoinRowPair {
        self.buffer
            .as_ref()
            .map_or(std::ptr::null(), ExprDeviceBuffer::as_ptr)
    }

    /// Explicit final materialization boundary, also used by oracle tests.
    /// Intermediate pipeline consumers must use the resident pointer instead.
    pub fn copy_final_rows(&self, output: &mut [JoinRowPair]) -> GpuResult<()> {
        if output.len() != self.rows {
            return Err(contract_error(
                "join final output length must equal initialized rows",
            ));
        }
        if let Some(buffer) = &self.buffer {
            buffer.copy_prefix_to_slice(output)?;
        }
        Ok(())
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use static_assertions::assert_not_impl_any;

    assert_not_impl_any!(ResidentJoin<'static>: Send, Sync);
    assert_not_impl_any!(ResidentJoinOutput: Send, Sync);

    #[test]
    fn resident_join_abi_layout() {
        assert_eq!(size_of::<NativeJoinKey>(), 40);
        assert_eq!(size_of::<NativeJoinRequest>(), 352);
        assert_eq!(size_of::<JoinRowPair>(), 16);
        assert_eq!(size_of::<NativeJoinResult>(), 24);
        assert_eq!(std::mem::offset_of!(NativeJoinKey, kind), 32);
        assert_eq!(std::mem::offset_of!(NativeJoinRequest, outer_keys), 32);
        assert_eq!(std::mem::offset_of!(NativeJoinRequest, inner_keys), 192);
        assert_eq!(std::mem::offset_of!(NativeJoinResult, kernel_launches), 16);
        assert_eq!(VERSION, 1);
    }

    #[test]
    fn resident_join_metadata_rejects_bad_key_pairs() {
        let empty = ResidentJoinKey::Int32 {
            values: None,
            nulls: None,
        };
        let wide = ResidentJoinKey::Int64 {
            values: None,
            nulls: None,
        };
        assert!(ResidentJoin::new(ResidentJoinKind::Inner, &[], &[]).is_err());
        assert!(ResidentJoin::new(ResidentJoinKind::Inner, &[empty; 5], &[empty; 5]).is_err());
        assert!(ResidentJoin::new(ResidentJoinKind::Inner, &[empty], &[empty; 2]).is_err());
        assert!(ResidentJoin::new(ResidentJoinKind::Inner, &[empty], &[wide]).is_err());
        for kind in [
            ResidentJoinKind::Inner,
            ResidentJoinKind::Left,
            ResidentJoinKind::Semi,
            ResidentJoinKind::Anti,
        ] {
            let plan =
                ResidentJoin::new(kind, &[empty, wide], &[empty, wide]).expect("empty typed plan");
            assert_eq!(
                plan.workspace_bytes().expect("empty workspace forecast"),
                64
            );
        }
    }
}
