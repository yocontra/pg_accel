//! Direct resident producer tests against PostgreSQL's join semantics. These
//! deliberately do not claim normal SQL planner selection of a row join.

#[pgrx::pg_schema]
mod tests {
    use pgrx::prelude::*;

    use crate::engine::residency::{ExecutionMemoryCharge, resident_live_bytes};
    use crate::gpu::ExprDeviceBuffer;
    use crate::gpu::join_rows::{
        JOIN_NULL_ROW, JoinRowPair, ResidentJoin, ResidentJoinKey, ResidentJoinKind,
        ResidentJoinOutcome,
    };

    struct Keys {
        a: Option<ExprDeviceBuffer<i32>>,
        a_nulls: Option<ExprDeviceBuffer<u8>>,
        b: Option<ExprDeviceBuffer<i64>>,
        b_nulls: Option<ExprDeviceBuffer<u8>>,
        _charge: ExecutionMemoryCharge,
    }

    impl Keys {
        fn upload(table: &str, rows: &[(Option<i32>, Option<i64>)]) -> Self {
            Spi::run(&format!(
                "CREATE TEMP TABLE {table}(id int8, a int4, b int8)"
            ))
            .expect("join oracle table");
            for (index, (a, b)) in rows.iter().enumerate() {
                Spi::run(&format!(
                    "INSERT INTO {table} VALUES ({index},{},{})",
                    a.map_or_else(|| "NULL".into(), |x| x.to_string()),
                    b.map_or_else(|| "NULL".into(), |x| x.to_string()),
                ))
                .expect("join oracle fixture");
            }
            let charge = ExecutionMemoryCharge::reserve(
                (rows.len() * 14) as u64,
                crate::engine::gucs::resident_memory_budget_bytes(),
            )
            .expect("test input reservation");
            let a: Vec<_> = rows.iter().map(|r| r.0.unwrap_or_default()).collect();
            let b: Vec<_> = rows.iter().map(|r| r.1.unwrap_or_default()).collect();
            let a_nulls: Vec<_> = rows.iter().map(|r| u8::from(r.0.is_none())).collect();
            let b_nulls: Vec<_> = rows.iter().map(|r| u8::from(r.1.is_none())).collect();
            let result = Self {
                a: ExprDeviceBuffer::copy_from_slice(&a),
                a_nulls: ExprDeviceBuffer::copy_from_slice(&a_nulls),
                b: ExprDeviceBuffer::copy_from_slice(&b),
                b_nulls: ExprDeviceBuffer::copy_from_slice(&b_nulls),
                _charge: charge,
            };
            if !rows.is_empty() {
                assert!(result.a.is_some() && result.b.is_some());
                assert!(result.a_nulls.is_some() && result.b_nulls.is_some());
            }
            result
        }

        fn keys(&self) -> [ResidentJoinKey<'_>; 2] {
            [
                ResidentJoinKey::Int32 {
                    values: self.a.as_ref(),
                    nulls: self.a_nulls.as_ref(),
                },
                ResidentJoinKey::Int64 {
                    values: self.b.as_ref(),
                    nulls: self.b_nulls.as_ref(),
                },
            ]
        }
    }

    fn oracle(
        kind: ResidentJoinKind,
        left: &str,
        right: &str,
        composite: bool,
    ) -> Vec<JoinRowPair> {
        let equality = if composite {
            "l.a=r.a AND l.b=r.b"
        } else {
            "l.a=r.a"
        };
        let query = match kind {
            ResidentJoinKind::Inner => {
                format!("SELECT l.id,r.id FROM {left} l JOIN {right} r ON {equality}")
            }
            ResidentJoinKind::Left => {
                format!("SELECT l.id,r.id FROM {left} l LEFT JOIN {right} r ON {equality}")
            }
            ResidentJoinKind::Semi => format!(
                "SELECT l.id,NULL::int8 FROM {left} l WHERE EXISTS (SELECT FROM {right} r WHERE {equality})"
            ),
            ResidentJoinKind::Anti => format!(
                "SELECT l.id,NULL::int8 FROM {left} l WHERE NOT EXISTS (SELECT FROM {right} r WHERE {equality})"
            ),
        };
        Spi::connect(|client| {
            client
                .select(&query, None, &[])
                .expect("native join oracle")
                .map(|row| JoinRowPair {
                    outer_row: row.get::<i64>(1).expect("outer id").expect("nonnull id") as u64,
                    inner_row: row
                        .get::<i64>(2)
                        .expect("inner id")
                        .map_or(JOIN_NULL_ROW, |id| id as u64),
                })
                .collect()
        })
    }

    #[pg_test]
    fn pg_resident_join_rows_native_parity_and_ownership() {
        Spi::run("SET pg_accel.enabled=off").expect("native SQL oracles");
        let initial_bytes = resident_live_bytes();
        let left = Keys::upload(
            "jl",
            &[
                (Some(1), Some(i64::MIN)),
                (Some(1), Some(i64::MIN)),
                (Some(1), Some(i64::MAX)),
                (Some(-1), Some(-1)),
                (None, Some(0)),
                (Some(7), None),
                (Some(9), Some(3)),
            ],
        );
        let right = Keys::upload(
            "jr",
            &[
                (Some(1), Some(i64::MIN)),
                (Some(1), Some(i64::MIN)),
                (Some(-1), Some(-1)),
                (None, Some(0)),
                (Some(7), None),
            ],
        );
        let empty = Keys::upload("je", &[]);
        for (outer, inner, left_table, right_table) in [
            (&left, &right, "jl", "jr"),
            (&left, &left, "jl", "jl"),
            (&left, &empty, "jl", "je"),
            (&empty, &right, "je", "jr"),
            (&empty, &empty, "je", "je"),
        ] {
            for key_count in [1, 2] {
                for kind in [
                    ResidentJoinKind::Inner,
                    ResidentJoinKind::Left,
                    ResidentJoinKind::Semi,
                    ResidentJoinKind::Anti,
                ] {
                    let baseline = resident_live_bytes();
                    let mut expected = oracle(kind, left_table, right_table, key_count == 2);
                    expected.sort();
                    let plan = ResidentJoin::new(
                        kind,
                        &outer.keys()[..key_count],
                        &inner.keys()[..key_count],
                    )
                    .expect("borrowed join plan");
                    if !expected.is_empty() {
                        match plan
                            .execute(expected.len() - 1)
                            .expect("capacity detection")
                        {
                            ResidentJoinOutcome::NeedsCapacity {
                                required_rows,
                                kernel_launches,
                            } => {
                                assert_eq!(required_rows, expected.len() as u64);
                                assert!(kernel_launches > 0);
                            }
                            ResidentJoinOutcome::Complete(_) => {
                                panic!("capacity must not truncate duplicates")
                            }
                        }
                        assert_eq!(
                            resident_live_bytes(),
                            baseline,
                            "failed capacity releases both allocations"
                        );
                    }
                    let ResidentJoinOutcome::Complete(output) =
                        plan.execute(expected.len()).expect("exact capacity join")
                    else {
                        panic!("oracle exact capacity must fit");
                    };
                    assert_eq!(
                        resident_live_bytes(),
                        baseline + (expected.len() * 16) as u64,
                        "only output charge survives"
                    );
                    assert_eq!(output.len(), expected.len());
                    assert_eq!(output.is_empty(), expected.is_empty());
                    if outer.a.is_some() {
                        assert!(output.kernel_launches() > 0);
                    }
                    if !output.is_empty() {
                        assert!(!output.as_device_ptr().is_null());
                    }
                    let mut actual = vec![JoinRowPair::default(); output.len()];
                    output
                        .copy_final_rows(&mut actual)
                        .expect("bounded final copy");
                    actual.sort();
                    assert_eq!(actual, expected);
                    assert!(
                        output
                            .copy_final_rows(&mut vec![JoinRowPair::default(); output.len() + 1])
                            .is_err()
                    );
                    drop(output);
                    assert_eq!(resident_live_bytes(), baseline);
                }
            }
        }
        let left_keys = left.keys();
        let mismatched_rows = [left_keys[0], right.keys()[1]];
        assert!(ResidentJoin::new(ResidentJoinKind::Inner, &mismatched_rows, &left_keys).is_err());
        let short_nulls =
            ExprDeviceBuffer::copy_from_slice(&[0_u8]).expect("invalid sidecar fixture");
        let malformed = ResidentJoinKey::Int32 {
            values: left.a.as_ref(),
            nulls: Some(&short_nulls),
        };
        assert!(ResidentJoin::new(ResidentJoinKind::Inner, &[malformed], &[left_keys[0]]).is_err());
        let baseline = resident_live_bytes();
        let plan =
            ResidentJoin::new(ResidentJoinKind::Inner, &left_keys, &left_keys).expect("self join");
        assert!(plan.execute(usize::MAX).is_err());
        assert_eq!(resident_live_bytes(), baseline);
        let budget = crate::engine::gucs::resident_memory_budget_bytes();
        let held = ExecutionMemoryCharge::reserve(
            budget - baseline - plan.workspace_bytes().expect("workspace forecast") as u64,
            budget,
        )
        .expect("leave only workspace budget");
        assert!(
            plan.execute(1).is_err(),
            "output budget rejects before either allocation"
        );
        drop(held);
        assert_eq!(
            resident_live_bytes(),
            baseline,
            "partial reservation unwinds"
        );
        drop((left, right, empty));
        assert_eq!(
            resident_live_bytes(),
            initial_bytes,
            "inputs and outputs released"
        );
    }
}
