// Resident row mappings for composable join consumers. All row work is device work.
#include <sycl/sycl.hpp>

#include <array>
#include <cstddef>
#include <cstdint>
#include <cstring>
#include <limits>

#include "pgaccel_join_rows.h"
#include "pgaccel_queue.h"

namespace {
constexpr uint64_t kBlock = 256;
constexpr size_t kMaxLevels = 4; // ceil(INT32_MAX / 256^3) <= 256
constexpr int32_t kEmpty = -1;

static_assert(sizeof(pgaccel_join_rows_key) == 40);
static_assert(sizeof(pgaccel_join_rows_request) == 352);
static_assert(sizeof(pgaccel_join_row_pair) == 16);
static_assert(sizeof(pgaccel_join_rows_result) == 24);
static_assert(offsetof(pgaccel_join_rows_key, type) == 32);
static_assert(offsetof(pgaccel_join_rows_request, outer_keys) == 32);
static_assert(offsetof(pgaccel_join_rows_request, inner_keys) == 192);
static_assert(offsetof(pgaccel_join_rows_result, kernel_launches) == 16);

struct Span {
  uintptr_t begin = 0;
  uintptr_t end = 0;
};

bool span(const void* pointer, uint64_t bytes, Span* out) {
  if (bytes == 0) {
    *out = {};
    return pointer == nullptr;
  }
  if (pointer == nullptr || bytes > SIZE_MAX)
    return false;
  const uintptr_t begin = reinterpret_cast<uintptr_t>(pointer);
  if (bytes > UINTPTR_MAX - begin)
    return false;
  *out = {begin, begin + static_cast<uintptr_t>(bytes)};
  return true;
}

bool overlaps(Span a, Span b) {
  return a.begin < b.end && b.begin < a.end;
}

bool aligned(const void* pointer, size_t alignment) {
  return reinterpret_cast<uintptr_t>(pointer) % alignment == 0;
}

struct Level {
  uint64_t count = 0;
  uint64_t offsets = 0;
  uint64_t sums = 0;
};

struct Layout {
  uint64_t bytes = 0;
  uint64_t capacity = 16;
  uint64_t heads = 0;
  uint64_t next = 0;
  uint64_t counts = 0;
  std::array<Level, kMaxLevels> levels{};
  size_t level_count = 0;
};

bool reserve(Layout* layout, uint64_t count, uint64_t width, uint64_t* offset) {
  if (count > (SIZE_MAX - 7) / width || layout->bytes > SIZE_MAX - 7)
    return false;
  const uint64_t bytes = (count * width + 7) & ~UINT64_C(7);
  if (bytes > SIZE_MAX - layout->bytes)
    return false;
  *offset = layout->bytes;
  layout->bytes += bytes;
  return true;
}

bool valid_key(const pgaccel_join_rows_key& key, uint64_t rows) {
  const uint64_t width = key.type == PGACCEL_JOIN_ROWS_INT32 ? 4 : 8;
  Span ignored;
  if ((key.type != PGACCEL_JOIN_ROWS_INT32 && key.type != PGACCEL_JOIN_ROWS_INT64) ||
      key.reserved != 0 || !aligned(key.values, width) ||
      !span(key.values, key.value_bytes, &ignored) ||
      !span(key.nulls, key.null_bytes, &ignored))
    return false;
  if (rows == 0)
    return key.value_bytes == 0 && key.null_bytes == 0;
  return key.values != nullptr && key.value_bytes >= rows * width &&
         (key.nulls == nullptr || key.null_bytes >= rows);
}

pgaccel_status layout_for(const pgaccel_join_rows_request& request, Layout* layout) {
  if (request.version != PGACCEL_JOIN_ROWS_VERSION)
    return PGACCEL_UNSUPPORTED;
  if (request.kind > PGACCEL_JOIN_ROWS_ANTI || request.reserved != 0 ||
      request.key_count == 0 || request.key_count > PGACCEL_JOIN_ROWS_MAX_KEYS)
    return PGACCEL_INVALID_ARGUMENT;
  if (request.outer_rows > INT32_MAX || request.inner_rows > INT32_MAX)
    return PGACCEL_UNSUPPORTED;
  const pgaccel_join_rows_key zero{};
  for (size_t key = 0; key < PGACCEL_JOIN_ROWS_MAX_KEYS; ++key) {
    if (key >= request.key_count) {
      if (std::memcmp(&request.outer_keys[key], &zero, sizeof(zero)) != 0 ||
          std::memcmp(&request.inner_keys[key], &zero, sizeof(zero)) != 0)
        return PGACCEL_INVALID_ARGUMENT;
    } else if (!valid_key(request.outer_keys[key], request.outer_rows) ||
               !valid_key(request.inner_keys[key], request.inner_rows) ||
               request.outer_keys[key].type != request.inner_keys[key].type) {
      return PGACCEL_INVALID_ARGUMENT;
    }
  }
  while (layout->capacity < request.inner_rows * 2)
    layout->capacity *= 2;
  if (!reserve(layout, layout->capacity, 4, &layout->heads) ||
      !reserve(layout, request.inner_rows, 4, &layout->next) ||
      !reserve(layout, request.outer_rows, 8, &layout->counts))
    return PGACCEL_UNSUPPORTED;
  uint64_t count = request.outer_rows;
  while (count != 0) {
    if (layout->level_count == kMaxLevels)
      return PGACCEL_UNSUPPORTED;
    auto& level = layout->levels[layout->level_count++];
    level.count = count;
    count = (count + kBlock - 1) / kBlock;
    if (!reserve(layout, level.count, 8, &level.offsets) ||
        !reserve(layout, count, 8, &level.sums))
      return PGACCEL_UNSUPPORTED;
    if (count == 1)
      break;
  }
  return PGACCEL_OK;
}

bool accessible(sycl::queue& queue, const void* pointer) {
  if (pointer == nullptr)
    return true;
  try {
    const auto type = sycl::get_pointer_type(pointer, queue.get_context());
    return (type == sycl::usm::alloc::device || type == sycl::usm::alloc::shared) &&
           sycl::get_pointer_device(pointer, queue.get_context()) == queue.get_device();
  } catch (...) {
    return false;
  }
}

bool valid_aliases(const pgaccel_join_rows_request& request, const void* request_pointer,
                   void* workspace, uint64_t workspace_bytes, pgaccel_join_row_pair* output,
                   uint64_t capacity, pgaccel_join_rows_result* result) {
  if (capacity > SIZE_MAX / sizeof(*output) || !aligned(workspace, 8) ||
      !aligned(output, alignof(pgaccel_join_row_pair)) ||
      !aligned(result, alignof(pgaccel_join_rows_result)))
    return false;
  std::array<Span, 3> writes{};
  Span metadata;
  if (!span(workspace, workspace_bytes, &writes[0]) ||
      !span(output, capacity * sizeof(*output), &writes[1]) ||
      !span(result, sizeof(*result), &writes[2]) ||
      !span(request_pointer, sizeof(request), &metadata))
    return false;
  for (size_t i = 0; i < writes.size(); ++i) {
    if (overlaps(writes[i], metadata))
      return false;
    for (size_t j = i + 1; j < writes.size(); ++j)
      if (overlaps(writes[i], writes[j]))
        return false;
    for (size_t key = 0; key < request.key_count; ++key) {
      for (const auto* input : {&request.outer_keys[key], &request.inner_keys[key]}) {
        Span values, nulls;
        if (!span(input->values, input->value_bytes, &values) ||
            !span(input->nulls, input->null_bytes, &nulls) ||
            overlaps(writes[i], values) || overlaps(writes[i], nulls))
          return false;
      }
    }
  }
  return true;
}

uint64_t mix(uint64_t value) {
  value ^= value >> 33;
  value *= UINT64_C(0xff51afd7ed558ccd);
  value ^= value >> 33;
  value *= UINT64_C(0xc4ceb9fe1a85ec53);
  return value ^ (value >> 33);
}

uint64_t key_value(const pgaccel_join_rows_key& key, uint64_t row) {
  return key.type == PGACCEL_JOIN_ROWS_INT32
             ? static_cast<uint64_t>(static_cast<int64_t>(static_cast<const int32_t*>(key.values)[row]))
             : static_cast<const uint64_t*>(key.values)[row];
}

bool key_hash(const pgaccel_join_rows_key* keys, uint32_t count, uint64_t row,
              uint64_t* hash) {
  uint64_t value = UINT64_C(0x9e3779b97f4a7c15);
  for (uint32_t i = 0; i < count; ++i) {
    if (keys[i].nulls != nullptr && keys[i].nulls[row] != 0)
      return false;
    value = mix(value ^ mix(key_value(keys[i], row)) ^ i);
  }
  *hash = value;
  return true;
}

bool equal_keys(const pgaccel_join_rows_request& request, uint64_t outer, uint64_t inner) {
  for (uint32_t i = 0; i < request.key_count; ++i)
    if (key_value(request.outer_keys[i], outer) != key_value(request.inner_keys[i], inner))
      return false;
  return true;
}

template <typename T>
T* at(void* workspace, uint64_t offset) {
  return reinterpret_cast<T*>(static_cast<uint8_t*>(workspace) + offset);
}

template <typename Event>
void completed(Event event, uint64_t* launches) {
  event.wait_and_throw();
  ++*launches;
  pgaccel_record_gpu_exec();
}

pgaccel_status execute(const pgaccel_join_rows_request& request, const Layout& layout,
                       sycl::queue& queue, void* workspace, pgaccel_join_row_pair* output,
                       uint64_t capacity, pgaccel_join_rows_result* result) {
  pgaccel_join_rows_result produced{};
  if (request.outer_rows == 0) {
    *result = produced;
    return PGACCEL_OK;
  }
  auto* heads = at<int32_t>(workspace, layout.heads);
  auto* next = at<int32_t>(workspace, layout.next);
  auto* counts = at<uint64_t>(workspace, layout.counts);
  const uint64_t buckets = layout.capacity;
  completed(queue.fill(heads, kEmpty, buckets), &produced.kernel_launches);
  if (request.inner_rows != 0) {
    completed(queue.parallel_for(sycl::range<1>(request.inner_rows), [=](sycl::id<1> id) {
      const uint64_t row = id[0];
      uint64_t hash = 0;
      if (!key_hash(request.inner_keys, request.key_count, row, &hash))
        return;
      sycl::atomic_ref<int32_t, sycl::memory_order::relaxed, sycl::memory_scope::device,
                       sycl::access::address_space::global_space> head(heads[hash & (buckets - 1)]);
      // Nobody follows next pointers until this entire build kernel completes.
      // Distinct-key hash collisions and duplicates share the same safe chain.
      next[row] = head.exchange(static_cast<int32_t>(row));
    }), &produced.kernel_launches);
  }
  completed(queue.parallel_for(sycl::range<1>(request.outer_rows), [=](sycl::id<1> id) {
    const uint64_t row = id[0];
    uint64_t matches = 0, hash = 0;
    if (key_hash(request.outer_keys, request.key_count, row, &hash)) {
      for (int32_t inner = heads[hash & (buckets - 1)]; inner != kEmpty; inner = next[inner]) {
        if (equal_keys(request, row, static_cast<uint64_t>(inner))) {
          ++matches;
          if (request.kind == PGACCEL_JOIN_ROWS_SEMI || request.kind == PGACCEL_JOIN_ROWS_ANTI)
            break;
        }
      }
    }
    if (request.kind == PGACCEL_JOIN_ROWS_LEFT && matches == 0)
      matches = 1;
    else if (request.kind == PGACCEL_JOIN_ROWS_SEMI)
      matches = matches != 0 ? 1 : 0;
    else if (request.kind == PGACCEL_JOIN_ROWS_ANTI)
      matches = matches == 0 ? 1 : 0;
    counts[row] = matches;
  }), &produced.kernel_launches);

  // Block-local scans plus recursively scanned block sums. No whole-input
  // serial scan or row-proportional host copyback. INT32_MAX per input proves
  // every prefix and the total fit in uint64, including duplicate products.
  for (size_t level_index = 0; level_index < layout.level_count; ++level_index) {
    const auto level = layout.levels[level_index];
    const auto* input = level_index == 0 ? counts : at<uint64_t>(workspace, layout.levels[level_index - 1].sums);
    auto* offsets = at<uint64_t>(workspace, level.offsets);
    auto* sums = at<uint64_t>(workspace, level.sums);
    completed(queue.parallel_for(sycl::range<1>((level.count + kBlock - 1) / kBlock), [=](sycl::id<1> id) {
      const uint64_t begin = id[0] * kBlock;
      uint64_t sum = 0;
      const uint64_t end = sycl::min(begin + kBlock, level.count);
      for (uint64_t row = begin; row < end; ++row) {
        offsets[row] = sum;
        sum += input[row];
      }
      sums[id[0]] = sum;
    }), &produced.kernel_launches);
  }
  for (size_t level_index = layout.level_count - 1; level_index != 0; --level_index) {
    const auto lower = layout.levels[level_index - 1];
    auto* child = at<uint64_t>(workspace, lower.offsets);
    const auto* parent = at<uint64_t>(workspace, layout.levels[level_index].offsets);
    completed(queue.parallel_for(sycl::range<1>(lower.count), [=](sycl::id<1> id) {
      child[id[0]] += parent[id[0] / kBlock];
    }), &produced.kernel_launches);
  }
  const auto* total = at<uint64_t>(workspace, layout.levels[layout.level_count - 1].sums);
  queue.memcpy(&produced.required_rows, total, sizeof(produced.required_rows)).wait_and_throw();
  if (produced.required_rows > capacity) {
    *result = produced;
    return PGACCEL_OOM;
  }
  if (produced.required_rows != 0) {
    const auto* offsets = at<uint64_t>(workspace, layout.levels[0].offsets);
    completed(queue.parallel_for(sycl::range<1>(request.outer_rows), [=](sycl::id<1> id) {
      const uint64_t row = id[0];
      if (counts[row] == 0)
        return;
      uint64_t position = offsets[row];
      if (request.kind == PGACCEL_JOIN_ROWS_SEMI || request.kind == PGACCEL_JOIN_ROWS_ANTI) {
        output[position] = {row, PGACCEL_JOIN_ROWS_NULL_ROW};
        return;
      }
      uint64_t hash = 0;
      if (key_hash(request.outer_keys, request.key_count, row, &hash)) {
        for (int32_t inner = heads[hash & (buckets - 1)]; inner != kEmpty; inner = next[inner]) {
          if (equal_keys(request, row, static_cast<uint64_t>(inner)))
            output[position++] = {row, static_cast<uint64_t>(inner)};
        }
      }
      if (position == offsets[row] && request.kind == PGACCEL_JOIN_ROWS_LEFT)
        output[position] = {row, PGACCEL_JOIN_ROWS_NULL_ROW};
    }), &produced.kernel_launches);
  }
  produced.emitted_rows = produced.required_rows;
  *result = produced;
  return PGACCEL_OK;
}
} // namespace

extern "C" pgaccel_status pgaccel_join_rows_workspace_bytes(
    const pgaccel_join_rows_request* request, uint64_t* bytes) {
  if (request == nullptr || bytes == nullptr || !aligned(request, alignof(pgaccel_join_rows_request)) ||
      !aligned(bytes, alignof(uint64_t)))
    return PGACCEL_INVALID_ARGUMENT;
  Span input, output;
  if (!span(request, sizeof(*request), &input) || !span(bytes, sizeof(*bytes), &output) || overlaps(input, output))
    return PGACCEL_INVALID_ARGUMENT;
  Layout layout;
  const auto status = layout_for(*request, &layout);
  if (status != PGACCEL_OK)
    return status;
  for (size_t key = 0; key < request->key_count; ++key) {
    for (const auto* column : {&request->outer_keys[key], &request->inner_keys[key]}) {
      Span values, nulls;
      if (!span(column->values, column->value_bytes, &values) ||
          !span(column->nulls, column->null_bytes, &nulls) ||
          overlaps(output, values) || overlaps(output, nulls))
        return PGACCEL_INVALID_ARGUMENT;
    }
  }
  *bytes = layout.bytes;
  return PGACCEL_OK;
}

extern "C" pgaccel_status pgaccel_join_rows_execute(
    const pgaccel_join_rows_request* request, void* workspace, uint64_t workspace_bytes,
    pgaccel_join_row_pair* output, uint64_t output_capacity,
    pgaccel_join_rows_result* result) try {
  if (request == nullptr || result == nullptr || !aligned(request, alignof(pgaccel_join_rows_request)))
    return PGACCEL_INVALID_ARGUMENT;
  const auto snapshot = *request;
  Layout layout;
  const auto status = layout_for(snapshot, &layout);
  if (status != PGACCEL_OK)
    return status;
  if (workspace_bytes < layout.bytes || !valid_aliases(snapshot, request, workspace, workspace_bytes,
                                                      output, output_capacity, result))
    return PGACCEL_INVALID_ARGUMENT;
  auto& queue = pgaccel_require_queue();
  if (!accessible(queue, workspace) || !accessible(queue, output))
    return PGACCEL_INVALID_ARGUMENT;
  for (size_t key = 0; key < snapshot.key_count; ++key)
    for (const auto* input : {&snapshot.outer_keys[key], &snapshot.inner_keys[key]})
      if (!accessible(queue, input->values) || !accessible(queue, input->nulls))
        return PGACCEL_INVALID_ARGUMENT;
  return execute(snapshot, layout, queue, workspace, output, output_capacity, result);
} catch (const pgaccel_no_device_error&) {
  return PGACCEL_ERROR_NO_DEVICE;
} catch (const std::bad_alloc&) {
  return PGACCEL_OOM;
} catch (const std::exception& error) {
  return pgaccel_kernel_failure("pgaccel_join_rows_execute", &error);
} catch (...) {
  return pgaccel_kernel_failure("pgaccel_join_rows_execute", nullptr);
}
