/* Versioned resident row-mapping producer. This is not SQL planner admission. */
#ifndef PGACCEL_JOIN_ROWS_H
#define PGACCEL_JOIN_ROWS_H

#include "pgaccel_ffi.h"

#ifdef __cplusplus
extern "C" {
#endif

#define PGACCEL_JOIN_ROWS_VERSION 1u
#define PGACCEL_JOIN_ROWS_MAX_KEYS 4u
#define PGACCEL_JOIN_ROWS_NULL_ROW UINT64_MAX

typedef enum {
  PGACCEL_JOIN_ROWS_INNER = 0,
  PGACCEL_JOIN_ROWS_LEFT = 1,
  PGACCEL_JOIN_ROWS_SEMI = 2,
  PGACCEL_JOIN_ROWS_ANTI = 3,
} pgaccel_join_rows_kind;

typedef enum {
  PGACCEL_JOIN_ROWS_INT32 = 1,
  PGACCEL_JOIN_ROWS_INT64 = 2,
} pgaccel_join_rows_key_type;

typedef struct {
  const void* values;
  const uint8_t* nulls; /* Any nonzero byte is SQL NULL. */
  uint64_t value_bytes;
  uint64_t null_bytes;
  uint32_t type;
  uint32_t reserved;
} pgaccel_join_rows_key;

typedef struct {
  uint32_t version;
  uint32_t kind;
  uint32_t key_count;
  uint32_t reserved;
  uint64_t outer_rows;
  uint64_t inner_rows;
  pgaccel_join_rows_key outer_keys[PGACCEL_JOIN_ROWS_MAX_KEYS];
  pgaccel_join_rows_key inner_keys[PGACCEL_JOIN_ROWS_MAX_KEYS];
} pgaccel_join_rows_request;

typedef struct {
  uint64_t outer_row;
  /* NULL_ROW for unmatched LEFT and all SEMI/ANTI outputs. */
  uint64_t inner_row;
} pgaccel_join_row_pair;

typedef struct {
  uint64_t required_rows;
  uint64_t emitted_rows;
  /* Completed device fills/kernels; scalar copyback is not a launch. */
  uint64_t kernel_launches;
} pgaccel_join_rows_result;

/* Pure layout query: no device discovery/allocation or row-value reads.
 * Each input side is bounded by INT32_MAX rows in v1. Output indices,
 * cardinalities, offsets and byte forecasts are 64-bit. Inactive keys must
 * be zero; corresponding active key types must match exactly. Empty sides
 * have NULL pointers/zero byte lengths but retain the active key types.
 * The host bytes output must not alias the request or any declared input. */
pgaccel_status pgaccel_join_rows_workspace_bytes(
    const pgaccel_join_rows_request* request, uint64_t* bytes);

/* All keys/NULL sidecars remain immutable device/shared USM for this call.
 * Declared byte spans must refer to real live allocations on the current
 * device. Input-input aliasing is legal, including self joins. Workspace
 * (8-byte aligned) and output must be disjoint from each other, every input,
 * request and host result. The caller owns and budgets all large buffers.
 * Zero output capacity requires a NULL output pointer.
 *
 * Hash build, SQL equality/NULL handling, counts, hierarchical prefix sums
 * and row emission run on the GPU. Only a scalar cardinality crosses back.
 * Output is ordered by outer row; matched inner row order is unspecified.
 * Duplicate matches retain their full multiplicity. SEMI/ANTI are EXISTS /
 * NOT EXISTS, not SQL NOT IN (a NULL inner key never matches).
 *
 * Capacity exhaustion returns PGACCEL_OOM with required_rows set and
 * emitted_rows=0, without writing any output pair. Invalid contracts leave
 * all outputs untouched. Other failures may modify workspace/output and
 * must be treated as poisoned; no successful result is published. Each
 * invocation resets workspace, so explicit retry/reuse is safe. No hidden
 * allocation of row-proportional storage or CPU join fallback is permitted.
 */
pgaccel_status pgaccel_join_rows_execute(
    const pgaccel_join_rows_request* request, void* workspace, uint64_t workspace_bytes,
    pgaccel_join_row_pair* output, uint64_t output_capacity,
    pgaccel_join_rows_result* result);

#ifdef __cplusplus
}
#endif
#endif
