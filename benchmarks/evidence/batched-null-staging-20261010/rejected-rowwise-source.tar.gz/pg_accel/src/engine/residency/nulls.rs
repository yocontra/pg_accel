//! Lazy host staging of the existing byte-per-row NULL sidecar.
//!
//! Non-NULL prefixes need no allocation or writes. The first NULL backfills
//! that prefix and preserves the already established resident/device format.

pub(super) fn reserve(
    nulls: &mut Vec<u8>,
    saw_null: bool,
    additional: usize,
) -> Result<(), std::collections::TryReserveError> {
    if saw_null {
        nulls.try_reserve(additional)
    } else {
        Ok(())
    }
}

/// Call after validating the value, before publishing its row. Allocation
/// failure leaves both the sidecar contents and its presence flag unchanged.
/// The value lane's capacity is only a growth hint, never a logical row count.
#[inline]
pub(super) fn push(
    nulls: &mut Vec<u8>,
    saw_null: &mut bool,
    prior_rows: usize,
    row_capacity: usize,
    is_null: bool,
) -> Result<(), String> {
    debug_assert_eq!(nulls.len(), if *saw_null { prior_rows } else { 0 });
    if *saw_null {
        if nulls.len() == nulls.capacity() {
            grow(nulls, 1)?;
        }
        nulls.push(u8::from(is_null));
        return Ok(());
    }
    if is_null {
        initialize(nulls, prior_rows, row_capacity)?;
        *saw_null = true;
    }
    Ok(())
}

#[cold]
fn grow(nulls: &mut Vec<u8>, additional: usize) -> Result<(), String> {
    nulls
        .try_reserve(additional)
        .map_err(|error| format!("resident NULL sidecar allocation failed: {error}"))
}

#[cold]
fn initialize(nulls: &mut Vec<u8>, prior_rows: usize, row_capacity: usize) -> Result<(), String> {
    let rows = prior_rows
        .checked_add(1)
        .ok_or("resident NULL sidecar row count overflow")?;
    grow(nulls, row_capacity.max(rows))?;
    nulls.resize(prior_rows, 0);
    nulls.push(1);
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn non_null_columns_never_allocate_a_sidecar() {
        let mut nulls = Vec::new();
        let mut saw_null = false;
        reserve(&mut nulls, saw_null, 1_000_000).expect("no mask allocation");
        for row in 0..1_000_000 {
            push(&mut nulls, &mut saw_null, row, 1_000_000, false).expect("present row");
        }
        assert!(!saw_null);
        assert!(nulls.is_empty());
        assert_eq!(nulls.capacity(), 0);
    }

    #[test]
    fn first_null_backfills_exactly_the_published_prefix() {
        for first_null in [0, 1, 7, 63, 64, 65, 4095, 4096, 4097, 100_000] {
            let mut nulls = Vec::new();
            let mut saw_null = false;
            for row in 0..first_null {
                push(&mut nulls, &mut saw_null, row, first_null + 8, false).expect("prefix");
            }
            push(&mut nulls, &mut saw_null, first_null, first_null + 8, true).expect("first NULL");
            push(
                &mut nulls,
                &mut saw_null,
                first_null + 1,
                first_null + 8,
                false,
            )
            .expect("suffix");
            push(
                &mut nulls,
                &mut saw_null,
                first_null + 2,
                first_null + 8,
                true,
            )
            .expect("next NULL");
            assert!(saw_null);
            assert_eq!(nulls.len(), first_null + 3);
            assert!(nulls[..first_null].iter().all(|null| *null == 0));
            assert_eq!(&nulls[first_null..], &[1, 0, 1]);
            assert!(nulls.capacity() >= first_null + 8);
        }
    }

    #[test]
    fn failed_first_allocation_or_overflow_does_not_publish_a_mask() {
        let mut nulls = Vec::new();
        let mut saw_null = false;
        assert!(push(&mut nulls, &mut saw_null, 3, usize::MAX, true).is_err());
        assert!(push(&mut nulls, &mut saw_null, usize::MAX, 0, true).is_err());
        assert!(!saw_null);
        assert!(nulls.is_empty());
        push(&mut nulls, &mut saw_null, 3, 4, true).expect("retry after allocation error");
        assert_eq!(nulls, [0, 0, 0, 1]);
        assert!(reserve(&mut nulls, saw_null, usize::MAX).is_err());
        assert_eq!(nulls, [0, 0, 0, 1]);
        push(&mut nulls, &mut saw_null, 4, 5, false).expect("retry after reserve error");
        assert_eq!(nulls, [0, 0, 0, 1, 0]);
    }
}
