#pragma once

#include <cstddef>
#include <cstdint>

#include "pgaccel_ffi.h"

namespace pgaccel_raster_detail {

// The device rule-validation pass proves strictly increasing integer sources
// within [INT32_MIN, UINT32_MAX]. They convert to double without loss. Searching
// by the unmodified pixel value avoids rounding a value +/- epsilon at large
// magnitudes. Only the predecessor and lower-bound source can match FLT_EQ.
// Inspect them in source order to preserve the original first-match policy.
inline int64_t reclass_lookup(const pgaccel_resident_raster_reclass_rule* rules,
                              size_t count, double value) {
  size_t low = 0;
  size_t high = count;
  while (low < high) {
    const size_t middle = low + (high - low) / 2;
    if (static_cast<double>(rules[middle].source) < value)
      low = middle + 1;
    else
      high = middle;
  }
  constexpr double epsilon = 1.1920928955078125e-7;
  const size_t begin = low == 0 ? 0 : low - 1;
  const size_t end = low < count ? low + 1 : count;
  for (size_t index = begin; index < end; ++index) {
    const double source = static_cast<double>(rules[index].source);
    const double difference = source - value;
    const double magnitude = difference < 0 ? -difference : difference;
    if (source == value || magnitude <= epsilon)
      return rules[index].destination;
  }
  return 0;
}

}  // namespace pgaccel_raster_detail
