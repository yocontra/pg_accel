//! Build script for `pg_accel`.
//!
//! Invokes `CMake` to build `libpgaccel_kernels` from the sibling
//! `pgaccel-kernels/` directory and emits the appropriate
//! `cargo:rustc-link-*` directives so the Rust FFI bridge can find it.
//! GPU linkage is unconditional — AdaptiveCpp/SYCL is the only supported
//! backend and there is no CPU-fallback build mode.

// Build scripts are not library code — panicking on missing env vars or
// cmake failures is the correct behaviour.
#![allow(clippy::expect_used)]

fn main() {
    // Re-run if the build script changes.
    println!("cargo::rerun-if-changed=build.rs");
    println!("cargo::rerun-if-env-changed=ACPP_PREFIX");
    println!("cargo::rerun-if-env-changed=ACPP_TARGETS");
    println!("cargo::rerun-if-env-changed=LLVM_PREFIX");
    println!("cargo::rerun-if-env-changed=LIBOMP_PREFIX");
    println!("cargo::rerun-if-env-changed=PGACCEL_PACKAGE_RELOCATABLE");
    println!("cargo::rerun-if-env-changed=PG_CONFIG");
    println!("cargo::rerun-if-env-changed=PGRX_PG_CONFIG_PATH");

    gpu_build::build_kernels();

    // Standalone Rust test executables are not loaded by PostgreSQL, so they
    // need definitions for the PostgreSQL symbols referenced through pgrx.
    // macOS Sequoia+ resolves those symbols eagerly at load time, while ELF
    // linkers reject them while producing the Linux test executable. Generate
    // test-only stubs on both supported host platforms. Production cdylibs do
    // not compile the stub module and still resolve every symbol from postgres.
    #[cfg(any(target_os = "macos", target_os = "linux"))]
    pg_stub::build_stub();
}

#[cfg(any(target_os = "macos", target_os = "linux"))]
mod pg_stub {
    use std::path::PathBuf;
    use std::process::Command;

    /// Generate Rust stubs for every referenced global symbol exported by the
    /// selected `postgres` executable.
    ///
    /// Background: macOS Sequoia+ (26.x) eagerly resolves undefined data
    /// symbols at dyld load time, even with `-undefined dynamic_lookup` plus
    /// `-no_fixup_chains`. Linux linkers reject the same unresolved references
    /// when producing a standalone test executable. pgrx library unit tests
    /// inherit hundreds of PG function and data references, even though the
    /// pure tests never call most of them.
    ///
    /// The generated file is `include!`'d from `src/pg_stubs.rs` only under
    /// `cfg(test)` on macOS/Linux, so the stubs are never compiled into the
    /// production cdylib that postgres loads. `cargo pgrx test` runs inside
    /// postgres, whose earlier global definitions win symbol resolution; the
    /// stubs exist for standalone Rust unit-test linking and loading.
    pub fn build_stub() {
        let out_dir = PathBuf::from(std::env::var("OUT_DIR").expect("OUT_DIR not set"));
        let stub_rs = out_dir.join("pg_stubs_generated.rs");

        // `cargo clippy/check --all-targets` compiles the test-only module even
        // when no unversioned `pg_config` exists on PATH. Always publish a
        // valid include target before attempting PostgreSQL discovery. The
        // selected pgrx `pg_config` is supplied by project recipes for linked
        // tests, where the complete symbol inventory is generated below.
        println!("cargo::rustc-env=PG_STUBS_GENERATED={}", stub_rs.display());
        std::fs::write(
            &stub_rs,
            "// No PostgreSQL binary was discoverable for this compile-only target.\n",
        )
        .expect("write fallback pg_stubs_generated.rs");

        // Project recipes bind PG_CONFIG to the exact requested major. Keep
        // that explicit selection authoritative over any ambient pgrx
        // override left behind by an enclosing shell.
        let pg_config_path = std::env::var("PG_CONFIG")
            .or_else(|_| std::env::var("PGRX_PG_CONFIG_PATH"))
            .unwrap_or_else(|_| "pg_config".to_string());

        let Some(bindir) = Command::new(&pg_config_path)
            .arg("--bindir")
            .output()
            .ok()
            .filter(|o| o.status.success())
            .map(|o| String::from_utf8_lossy(&o.stdout).trim().to_string())
        else {
            return;
        };

        let postgres_bin = PathBuf::from(&bindir).join("postgres");
        if !postgres_bin.exists() {
            return;
        }

        println!("cargo::rerun-if-changed={}", postgres_bin.display());

        // Extract all global T (text/function), D (data), and S (other)
        // symbols. Skip U (undefined), compiler-internal (leading double
        // underscore), and namespaced (contains '.').
        let mut nm_command = Command::new("nm");
        nm_command.arg("-gP");
        // Linux PostgreSQL executables are linked with exported backend
        // symbols, but distro binaries may have their ordinary symbol table
        // stripped. The dynamic table is the authoritative extension-facing
        // inventory and remains available in both source and package builds.
        if cfg!(target_os = "linux") {
            nm_command.arg("-D");
        }
        let nm = nm_command.arg(&postgres_bin).output().expect("nm failed");
        assert!(nm.status.success(), "nm on postgres binary failed");
        let nm_out = String::from_utf8_lossy(&nm.stdout);

        let mut funcs: Vec<&str> = Vec::new();
        let mut datas: Vec<&str> = Vec::new();
        for line in nm_out.lines() {
            let mut parts = line.split_whitespace();
            let (Some(name), Some(ty)) = (parts.next(), parts.next()) else {
                continue;
            };
            // Mach-O nm prefixes C symbols with an underscore; strip it so
            // #[no_mangle] re-adds exactly one. ELF names are already exact,
            // and stripping their leading underscore would corrupt symbols
            // such as `_PG_init`.
            let clean = if cfg!(target_os = "macos") {
                name.strip_prefix('_').unwrap_or(name)
            } else {
                name
            };
            if clean.is_empty() || clean.starts_with("__") || !is_rust_ident(clean) {
                continue;
            }
            // Skip Rust keywords — we'd need r# prefix and that's noise.
            if is_rust_keyword(clean) {
                continue;
            }
            // Reserved / auto-provided executable symbols that would clash
            // with the test binary's own entry point or runtime sections.
            if matches!(
                clean,
                "main"
                    | "_main"
                    | "mh_execute_header"
                    | "_mh_execute_header"
                    | "start"
                    | "_start"
                    | "_IO_stdin_used"
                    | "_edata"
                    | "_end"
                    | "data_start"
            ) {
                continue;
            }
            // Symbols we provide manually as passthrough implementations
            // in `src/pg_stubs.rs` (needed for standalone unit tests
            // that exercise code paths which hit PG FFI).
            if is_manual_stub(clean) {
                continue;
            }
            match ty {
                "T" => funcs.push(clean),
                // Mach-O uses D/S for exported data. ELF additionally uses B
                // (BSS), C (common), G (small initialized), R (read-only), and
                // V (weak object). A writable oversized definition is safe for
                // the pure unit-test paths and satisfies the symbol resolver.
                "B" | "C" | "D" | "G" | "R" | "S" | "V" => datas.push(clean),
                _ => {}
            }
        }
        assert!(
            !funcs.is_empty(),
            "nm found no exported PostgreSQL functions in {}",
            postgres_bin.display()
        );

        // Stub generation rules:
        //
        // - T (text/function): emit an `extern "C-unwind" fn NAME() -> usize`
        //   that returns 0. Lives in .text (executable), so calls through
        //   pgrx's `extern "C-unwind"` declarations won't SIGBUS on jump.
        //   Returns null/zero in x0 — callers that check for null handle
        //   it gracefully; everything else is undefined but never hit in
        //   practice because the guarding `pg_guard_ffi_boundary` path
        //   only reads the function pointer after touching data stubs.
        //
        // - D/S (data): emit `static mut NAME: [u64; 16] = [0; 16]` — 128
        //   bytes of mutable, zero-initialized storage. pgrx's guard
        //   writes things like `CurrentMemoryContext = ...` and
        //   `PG_exception_stack = ...` to these addresses; read-only
        //   stubs would SIGBUS. 128 bytes fits any PG extern static we
        //   might reference.
        let mut rs = String::with_capacity(1 << 20);
        rs.push_str("// AUTO-GENERATED PG symbol stubs. Do not edit.\n");
        rs.push_str("// Satisfies standalone macOS/Linux test binaries; never shipped.\n\n");
        for f in &funcs {
            rs.push_str("#[unsafe(no_mangle)]\npub extern \"C-unwind\" fn ");
            rs.push_str(f);
            rs.push_str("() -> usize { 0 }\n");
        }
        for d in &datas {
            rs.push_str("#[unsafe(no_mangle)]\npub static mut ");
            rs.push_str(d);
            rs.push_str(": [u64; 16] = [0; 16];\n");
        }

        std::fs::write(&stub_rs, &rs).expect("write pg_stubs_generated.rs");
    }

    /// True if `s` is a valid Rust identifier (ASCII-only, per PG conventions).
    fn is_rust_ident(s: &str) -> bool {
        let mut chars = s.chars();
        let Some(first) = chars.next() else {
            return false;
        };
        if !(first.is_ascii_alphabetic() || first == '_') {
            return false;
        }
        chars.all(|c| c.is_ascii_alphanumeric() || c == '_')
    }

    /// Keep these out of the auto-generated stub file; `src/pg_stubs.rs`
    /// defines real passthrough implementations so unit tests that run
    /// outside postgres can exercise the surrounding code paths.
    fn is_manual_stub(s: &str) -> bool {
        matches!(
            s,
            "pg_detoast_datum"
                | "pg_detoast_datum_copy"
                | "pg_detoast_datum_packed"
                | "pg_detoast_datum_slice"
        )
    }

    /// Rust reserved words that would collide with `pub static NAME`.
    fn is_rust_keyword(s: &str) -> bool {
        matches!(
            s,
            "as" | "break"
                | "const"
                | "continue"
                | "crate"
                | "else"
                | "enum"
                | "extern"
                | "false"
                | "fn"
                | "for"
                | "if"
                | "impl"
                | "in"
                | "let"
                | "loop"
                | "match"
                | "mod"
                | "move"
                | "mut"
                | "pub"
                | "ref"
                | "return"
                | "self"
                | "Self"
                | "static"
                | "struct"
                | "super"
                | "trait"
                | "true"
                | "type"
                | "unsafe"
                | "use"
                | "where"
                | "while"
                | "async"
                | "await"
                | "dyn"
                | "abstract"
                | "become"
                | "box"
                | "do"
                | "final"
                | "macro"
                | "override"
                | "priv"
                | "typeof"
                | "unsized"
                | "virtual"
                | "yield"
                | "try"
                | "union"
        )
    }
}

mod gpu_build {
    use std::path::{Path, PathBuf};
    use std::process::Command;

    /// Build `pgaccel-kernels` via CMake and emit linker directives.
    pub fn build_kernels() {
        let manifest_dir =
            PathBuf::from(std::env::var("CARGO_MANIFEST_DIR").expect("CARGO_MANIFEST_DIR not set"));
        let kernels_src = manifest_dir
            .parent()
            .expect("manifest dir has no parent")
            .join("pgaccel-kernels");

        assert!(
            kernels_src.join("CMakeLists.txt").exists(),
            "pgaccel-kernels source directory not found at {}",
            kernels_src.display(),
        );

        // Re-run when the kernel sources or build definition change.
        println!(
            "cargo::rerun-if-changed={}",
            kernels_src.join("CMakeLists.txt").display()
        );
        emit_rerun_if_changed_tree(&kernels_src.join("src"));
        emit_rerun_if_changed_tree(&kernels_src.join("include"));

        let out_dir = PathBuf::from(std::env::var("OUT_DIR").expect("OUT_DIR not set"));
        let build_dir = out_dir.join("pgaccel-kernels-build");
        std::fs::create_dir_all(&build_dir).expect("failed to create cmake build directory");

        cmake_configure(&kernels_src, &build_dir);
        cmake_build(&build_dir);

        // The built shared library lives in the build directory.
        emit_link_directives(&build_dir);
    }

    fn emit_rerun_if_changed_tree(root: &Path) {
        // Retain the directory watch so additions and removals invalidate the
        // build, then enumerate files because Cargo does not reliably notice
        // in-place edits when only a directory path is registered.
        println!("cargo::rerun-if-changed={}", root.display());
        let mut pending = vec![root.to_path_buf()];
        let mut files = Vec::new();
        while let Some(directory) = pending.pop() {
            let mut entries = std::fs::read_dir(&directory)
                .unwrap_or_else(|error| {
                    panic!(
                        "failed to enumerate kernel dependency directory {}: {error}",
                        directory.display()
                    )
                })
                .map(|entry| {
                    entry.unwrap_or_else(|error| {
                        panic!(
                            "failed to inspect kernel dependency under {}: {error}",
                            directory.display()
                        )
                    })
                })
                .collect::<Vec<_>>();
            entries.sort_unstable_by_key(std::fs::DirEntry::path);
            for entry in entries {
                let path = entry.path();
                let file_type = entry.file_type().unwrap_or_else(|error| {
                    panic!(
                        "failed to identify kernel dependency {}: {error}",
                        path.display()
                    )
                });
                if file_type.is_dir() {
                    pending.push(path);
                } else {
                    files.push(path);
                }
            }
        }
        files.sort_unstable();
        for file in files {
            println!("cargo::rerun-if-changed={}", file.display());
        }
    }

    fn cmake_configure(source_dir: &Path, build_dir: &Path) {
        let acpp_prefix = acpp_prefix();

        let mut cmd = Command::new("cmake");
        cmd.arg("-S")
            .arg(source_dir)
            .arg("-B")
            .arg(build_dir)
            .arg("-DCMAKE_BUILD_TYPE=Release")
            // AdaptiveCpp/SYCL is the sole GPU backend (CUDA/ROCm/L0/Metal/CPU).
            .arg("-DPGACCEL_USE_SYCL=ON");

        // `just setup-gpu` installs AdaptiveCpp into .pgaccel/acpp/current.
        // ACPP_PREFIX can override this for distro/system toolchains.
        if acpp_prefix.join("lib/cmake/AdaptiveCpp").exists() {
            cmd.arg(format!("-DCMAKE_PREFIX_PATH={}", acpp_prefix.display()));
            // Reuse the target selected by `just setup-gpu` (for example
            // `cuda` on Linux/NVIDIA or `generic` for Metal SSCP builds).
            if let Ok(targets) = std::env::var("ACPP_TARGETS") {
                cmd.arg(format!("-DACPP_TARGETS={targets}"));
            } else if let Some(targets) = repo_acpp_targets() {
                cmd.arg(format!("-DACPP_TARGETS={targets}"));
            } else {
                cmd.arg("-DACPP_TARGETS=generic");
            }

            if let Ok(llvm_prefix) = std::env::var("LLVM_PREFIX") {
                cmd.arg(format!("-DCMAKE_C_COMPILER={llvm_prefix}/bin/clang"));
                cmd.arg(format!("-DCMAKE_CXX_COMPILER={llvm_prefix}/bin/clang++"));
            }
            if let Ok(libomp_prefix) = std::env::var("LIBOMP_PREFIX") {
                cmd.arg(format!("-DCMAKE_CXX_FLAGS=-O2 -I{libomp_prefix}/include"));
                let lib_flag = format!("-L{libomp_prefix}/lib");
                cmd.arg(format!("-DCMAKE_SHARED_LINKER_FLAGS={lib_flag}"));
                cmd.arg(format!("-DCMAKE_EXE_LINKER_FLAGS={lib_flag}"));
            }
        }

        let status = cmd
            .status()
            .expect("failed to execute cmake — is cmake installed?");

        assert!(status.success(), "cmake configure step failed");
    }

    fn home_dir() -> PathBuf {
        PathBuf::from(std::env::var("HOME").expect("HOME not set"))
    }

    fn acpp_prefix() -> PathBuf {
        std::env::var_os("ACPP_PREFIX").map_or_else(
            || {
                let repo_acpp = PathBuf::from(
                    std::env::var("CARGO_MANIFEST_DIR").expect("CARGO_MANIFEST_DIR not set"),
                )
                .parent()
                .expect("manifest dir has no parent")
                .join(".pgaccel/acpp/current");
                if repo_acpp.exists() {
                    repo_acpp
                } else {
                    home_dir().join("local")
                }
            },
            PathBuf::from,
        )
    }

    fn repo_acpp_targets() -> Option<String> {
        let manifest_dir =
            PathBuf::from(std::env::var("CARGO_MANIFEST_DIR").expect("CARGO_MANIFEST_DIR not set"));
        let targets_file = manifest_dir
            .parent()
            .expect("manifest dir has no parent")
            .join(".pgaccel/acpp/current-targets");
        std::fs::read_to_string(targets_file)
            .ok()
            .map(|s| s.trim().to_owned())
            .filter(|s| !s.is_empty())
    }

    fn cmake_build(build_dir: &Path) {
        let status = Command::new("cmake")
            .arg("--build")
            .arg(build_dir)
            .arg("--config")
            .arg("Release")
            .arg("--parallel")
            .status()
            .expect("failed to execute cmake --build");

        assert!(status.success(), "cmake build step failed");
    }

    fn emit_link_directives(build_dir: &Path) {
        // CMake places the static library directly in the build directory.
        println!("cargo::rustc-link-search=native={}", build_dir.display());
        println!("cargo::rustc-link-lib=static=pgaccel_kernels");

        // AdaptiveCpp SSCP runtime — our static kernels reference hipsycl
        // symbols resolved by these shared libs at load time.
        let acpp_lib = acpp_prefix().join("lib");
        println!("cargo::rustc-link-search=native={}", acpp_lib.display());
        println!("cargo::rustc-link-lib=dylib=acpp-rt");
        println!("cargo::rustc-link-lib=dylib=acpp-common");
        // Development and pgrx-test installs resolve the repository toolchain.
        // Release packages opt into a bundled, loader-relative runtime.
        match std::env::var("PGACCEL_PACKAGE_RELOCATABLE") {
            Ok(value) if value == "1" => {
                if cfg!(target_os = "macos") {
                    println!("cargo::rustc-link-arg=-Wl,-rpath,@loader_path/pg_accel-runtime/lib");
                    println!(
                        "cargo::rustc-cdylib-link-arg=-Wl,-install_name,@rpath/pg_accel.dylib"
                    );
                } else if cfg!(target_os = "linux") {
                    println!("cargo::rustc-link-arg=-Wl,-rpath,$ORIGIN/pg_accel-runtime/lib");
                } else {
                    panic!("relocatable packages are unsupported on this platform");
                }
            }
            Ok(value) if !value.is_empty() => {
                panic!("PGACCEL_PACKAGE_RELOCATABLE must be unset or exactly 1, got {value:?}");
            }
            _ => println!("cargo::rustc-link-arg=-Wl,-rpath,{}", acpp_lib.display()),
        }

        // Link C++ standard library for static C++ code.
        if cfg!(target_os = "macos") {
            println!("cargo::rustc-link-lib=c++");
        } else {
            println!("cargo::rustc-link-lib=stdc++");
        }
    }
}
