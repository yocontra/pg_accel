//! Hardware-derived dispatch thresholds.

use std::{ffi::OsStr, fmt};

use super::platform::PlatformProfile;

/// Absolute proof bound for one synchronous atomic dense grouped aggregate.
/// At this row count every accepted int4 term still fits an exact int64 SUM.
pub(crate) const GPU_GROUPED_AGG_ONE_SHOT_ABSOLUTE_MAX_ROWS: usize = 1_000_000;

/// Bound point/polygon coordinate visits per synchronous native call. Larger
/// polygons shorten chunks instead of exceeding the previously qualified work.
pub(crate) fn spatial_point_polygon_chunk_rows(requested: usize, coordinates: usize) -> usize {
    const MAX_COORDINATE_WORK: usize = 64 * 1024 * 1024;
    requested.min((MAX_COORDINATE_WORK / coordinates.max(1)).max(1))
}

/// First row count at which the retired sort-based grouped-hash lane was
/// observed to abort the backend.  The released resident descriptor kernel is
/// a different implementation and has its own one-shot/chunk bounds above.
pub(crate) const HISTORICAL_UNSAFE_GROUPED_HASH_INPUT_ROWS: usize = 100_000;

/// First build-side row count at which the retired row-returning hash-join
/// lane entered its crash-prone sort/merge branch.
pub(crate) const HISTORICAL_UNSAFE_ROW_JOIN_BUILD_ROWS: usize = 100_000;

const HOSTED_METAL_COMPATIBILITY_ENV: &str = "PGACCEL_HOSTED_METAL_COMPATIBILITY";
const HOSTED_METAL_PLANNER_COMPUTE_UNITS: u32 = 32;

// ---------------------------------------------------------------------------
// Dynamic device limits
// ---------------------------------------------------------------------------

/// Hardware-derived thresholds for GPU dispatch decisions.
///
/// All limits are computed from the actual device capabilities reported by
/// the GPU runtime, so the extension auto-tunes to whatever hardware it
/// runs on instead of relying on constants tuned for a single machine.
#[derive(Debug, Clone)]
pub struct DeviceLimits {
    /// Default cluster-wide cap for backend-local resident GPU allocations.
    /// The `pg_accel.resident_memory_budget_mb` GUC overrides this value.
    pub resident_memory_budget_bytes: usize,
    /// Maximum retained exact varlena bytes for one resident domain value.
    ///
    /// Spatial and raster lanes retain original values for exact recheck or
    /// reconstruction. This per-value cap prevents one pathological value
    /// from consuming an unbounded share of the resident ledger.
    pub resident_domain_max_exact_value_bytes: usize,
    /// Number of expected reuses over which planner costing amortizes a
    /// synchronous first-use resident load.
    pub auto_load_amortization_queries: u32,
    /// Per-row scan cost for a resident load whose selected columns are all
    /// fixed-width (or for a zero-column `COUNT(*)` scan).
    pub resident_load_scan_per_row_cost: f64,
    /// Per estimated resident byte copied or materialized by a first-use load.
    pub resident_load_per_byte_cost: f64,
    /// Minimum rows before generic GPU dispatch is considered.
    pub gpu_min_rows: usize,
    /// Historical GPU sort executor threshold retained for calibration ABI.
    pub gpu_sort_min_rows: usize,
    /// Historical GPU sort planner threshold retained for calibration ABI.
    pub gpu_sort_planner_min_rows: usize,
    /// Historical GPU window threshold retained for calibration ABI.
    pub gpu_window_min_rows: usize,
    /// Minimum rows for GPU reduce / aggregate.
    pub gpu_reduce_min_rows: usize,
    /// Minimum rows for GPU hash aggregation (grouped agg) dispatch.
    /// Below this, PG's native HashAgg with parallel workers is faster.
    pub gpu_hash_agg_min_rows: usize,
    /// First input row count at which grouped GPU hash aggregation is
    /// considered unsafe. The C++ sort-based hashagg branch starts at about
    /// 100K rows and can abort inside Metal/AdaptiveCpp before Rust can catch
    /// anything. Until that kernel path is fixed, the planner leaves grouped
    /// hashagg at or above this threshold to PostgreSQL.
    pub gpu_hash_agg_unsafe_input_rows: usize,
    /// Maximum number of groups for GPU hash aggregation.
    pub gpu_hash_agg_max_groups: usize,
    /// H3's one-key COUNT workspace/output bound, independent of generic
    /// multi-measure hash aggregation. At most one group per input row.
    pub gpu_h3_max_groups: usize,
    /// Maximum elements per GPU reduce dispatch chunk.
    /// GPU runtime may abort on very large dispatch ranges.
    pub gpu_reduce_max_chunk: usize,
    /// Maximum fact rows in one synchronous atomic dense grouped aggregate.
    /// This is calibrated from compute throughput and capped by the absolute
    /// int4-to-int64 SUM proof bound.
    pub gpu_grouped_agg_one_shot_max_rows: usize,
    /// Historical GPU sort element cap retained for calibration ABI.
    pub gpu_sort_max_elements: usize,
    /// Historical standalone top-k LIMIT cap retained for calibration ABI.
    pub gpu_sort_topk_max_limit: usize,
    /// Historical standalone top-k output fraction retained for calibration.
    pub gpu_sort_heap_topk_max_fraction: f64,
    /// Historical standalone top-k tuple-width cap retained for calibration.
    pub gpu_sort_heap_topk_max_width_bytes: usize,
    /// Maximum output rows for GPU hash join injection.
    /// Custom Scan yield overhead (~3μs/row) makes large-output joins
    /// strictly slower than PG's native HashJoin.
    pub gpu_join_max_output_rows: usize,
    /// Minimum input rows for a GPU-resident H3 grouped aggregate.
    pub gpu_h3_group_min_rows: usize,
    /// Maximum rows in one H3 key-generation/grouping dispatch.
    pub gpu_h3_max_chunk_rows: usize,
    /// Minimum polygon vertex count for GPU spatial dispatch.
    /// Below this threshold, the GPU kernel overhead exceeds PG parallel's
    /// per-row cost, so we defer to standard PostGIS evaluation.
    pub gpu_spatial_min_vertices: usize,
    /// Maximum vertices accepted from one resident spatial value.
    /// Larger values stay native rather than creating an unbounded flattened
    /// coordinate lane or exact-recheck workload.
    pub gpu_spatial_max_vertices_per_row: usize,
    /// Maximum estimated output fraction for heap-backed GPU spatial scans.
    ///
    /// Until spatial predicates can feed a GPU-resident aggregate/filter
    /// pipeline, high-output predicates still yield most matching heap tuples
    /// back through PostgreSQL. Those rows are left native even when the
    /// point-in-ring kernel itself is compute-heavy.
    pub gpu_spatial_max_output_fraction: f64,
    /// Maximum fraction of spatial rows that may require exact recheck.
    /// Above this threshold the exact path is expected to dominate execution.
    pub gpu_spatial_max_recheck_fraction: f64,
    /// Maximum rows per linear pairwise spatial dispatch.
    ///
    /// The C bridge packs descriptors, unique coordinate/ring payloads, and
    /// one tri-state result byte into a single device allocation. Chunking
    /// bounds that allocation while preserving a linear row-wise contract.
    pub gpu_spatial_pairwise_chunk_rows: usize,
    /// Minimum flattened pixel count before raster GPU dispatch is considered.
    pub gpu_raster_min_pixels: usize,
    /// Maximum flattened pixels in one raster GPU dispatch.
    pub gpu_raster_max_chunk_pixels: usize,
    /// Minimum rows for GPU expression scan dispatch.
    /// Below this, PG's native executor with JIT is faster.
    pub gpu_expr_min_rows: usize,
    /// Maximum inner-side rows for GPU hash join build phase.
    /// The build-side hash table must fit in GPU memory.
    pub gpu_hash_join_build_max_rows: usize,
    /// Minimum rows for pipeline fusion (scan+agg) to activate.
    /// Below this, the fusion setup overhead exceeds the savings
    /// from eliminating ExecProcNode calls.
    pub gpu_pipeline_fusion_min_rows: usize,
    /// Minimum fact table rows for PreAgg (fused star-join + agg) injection.
    pub gpu_preagg_min_fact_rows: usize,
    /// Maximum dimension table rows (per dimension) for PreAgg.
    pub gpu_preagg_max_dim_rows: usize,
    /// Per-row cost for dimension materialization in PreAgg costing.
    pub preagg_dim_materialize_cost: f64,
    /// Per-row cost for fact table heap scan in PreAgg costing.
    pub preagg_fact_scan_cost: f64,
    /// Per-row cost for hash probe in PreAgg costing.
    pub preagg_probe_cost: f64,
    /// Per-row cost for aggregate accumulation in PreAgg costing.
    pub preagg_agg_cost: f64,
    /// Per-row cost for result yield in PreAgg costing.
    pub preagg_yield_cost: f64,
    /// Lower bound for `optimal_batch_size`.
    pub optimal_batch_min: usize,
    /// Upper bound for `optimal_batch_size`.
    pub optimal_batch_max: usize,
    /// Row interval between `CHECK_FOR_INTERRUPTS` calls in fused
    /// scan+agg. Balances responsiveness vs call overhead.
    pub fused_interrupt_interval: usize,

    // -- Per-strategy GPU op costs (cost units per row) ----------------------
    /// GPU reduce (sum/min/max/count) per-row op cost.
    /// Includes kernel dispatch amortised over batch.
    pub gpu_op_cost_reduce: f64,
    /// GPU hash aggregation per-row op cost.
    /// Includes hash table build + probe + per-group accumulation.
    pub gpu_op_cost_hash_agg: f64,
    /// GPU sort per-row op cost.
    /// Includes key extraction + bitonic/radix sort amortised.
    pub gpu_op_cost_sort: f64,
    /// GPU window function per-row op cost.
    /// Includes partition detect + window compute + yield.
    pub gpu_op_cost_window: f64,
    /// GPU filter (spatial/expr) per-row op cost.
    /// Includes predicate evaluation on GPU.
    pub gpu_op_cost_filter: f64,
    /// CPU PostGIS exact-recheck cost per uncertain spatial row.
    /// This stays separate from GPU filter cost so uncertainty cannot be
    /// costed as another cheap device predicate.
    pub cpu_spatial_recheck_per_row: f64,
    /// Resident H3 cell-to-parent per-row transform cost.
    ///
    /// This charges only the device-to-device integer transform after the
    /// source H3 lane is resident. Datum extraction and host staging are
    /// charged elsewhere, so they must not be folded into this coefficient.
    /// The conservative default is no cheaper than reduce and matches the
    /// filter/window coefficients; hash aggregation and each transform launch
    /// remain separate costs.
    pub gpu_op_cost_h3_parent_resident: f64,

    // -- Hash-join + partial-agg per-row planner costs (Phase 6 amortisation)
    //
    // These four fields replace four hard-coded `0.01` / `0.005` literals
    // that previously lived in `planner_hooks/hashjoin.rs` and the
    // `partial_agg.rs` / `preagg_partial.rs` cost formulas. Each was an
    // over-pessimistic estimate that included bookkeeping work (e.g.
    // ExecCopySlotMinimalTuple) that PG's stock plan does not separately
    // charge — for a 10M-row plain JOIN that single-counted overhead added
    // 200K cost units to pgaccel's path and made `add_path()` always
    // discard our `GpuHashJoin`.
    //
    // Calibration: kernel-time empirical. The GPU hash insert / probe
    // kernels run at ~50M rows/sec (50ns / row = 0.0005 cost units).
    // Partial-agg `Reduce` is the same (~50M rows/sec → 0.0005).
    // `ExecForceStoreMinimalTuple` measured ~50ns / row on M-series so we
    // charge 0.0005 / row for CustomScan yield — the stock HashJoin
    // doesn't add a separate yield term, so this is an honest delta over
    // what PG implicitly counts.
    //
    /// Per-inner-row GPU hash-join build cost (kernel insert amortised).
    /// Replaces the `0.005 + 0.002 + 0.003 = 0.01` literal that
    /// triple-counted ExecCopy + key extract + GPU insert.
    pub gpu_hashjoin_build_per_row: f64,
    /// Per-outer-row GPU hash-join probe cost (kernel probe amortised).
    /// Same accounting fix as `gpu_hashjoin_build_per_row`.
    pub gpu_hashjoin_probe_per_row: f64,
    /// Per-output-row CustomScan yield cost. Calibrated against
    /// `ExecForceStoreMinimalTuple` (~50ns / row on M-series); the stock
    /// PG HashJoin / HashAgg do not add a separate yield term, so this is
    /// an honest delta over PG's bundled `cpu_tuple_cost`.
    pub custom_scan_yield_per_row: f64,
    /// Per-row partial-aggregate per-row reduce cost (used by
    /// `partial_agg::try_inject` and `preagg_partial`). Replaces the
    /// `0.005` literal that was 10x the measured GPU reduce throughput
    /// (~50M rows/sec). Soft-fp64 multiplier (32x on Apple Silicon
    /// without native fp64) is applied at the use site, not here.
    pub gpu_partial_agg_per_row: f64,

    // -- Cost-ratio gates vs PG's best non-parallel path --------------------
    /// Max ratio of GpuAgg total cost to PG's cheapest non-parallel agg path
    /// before the planner injects our path. Our Custom Scan runs
    /// single-threaded, so we compare against PG's single-threaded baseline
    /// (stripping out Gather/GatherMerge) rather than the parallel plan. The
    /// GPU's batching then makes up for the parallel gap at runtime.
    pub gpu_agg_cost_ratio: f64,
    /// Max ratio of GpuWindow total cost to PG's cheapest non-parallel
    /// window path before injection.
    pub gpu_window_cost_ratio: f64,
    /// Max ratio of PreAgg total cost to PG's cheapest non-parallel agg path
    /// before injection.
    pub gpu_preagg_cost_ratio: f64,

    // -- Per-kernel-class break-even thresholds -----------------------------
    // These thresholds express the minimum input size (or work product) at
    // which a given GPU kernel class is expected to beat PG's parallel path
    // on the reference profile (M2 Max, 32 CUs). They are
    // calibrated from the 2026-04-11 benchmark run:
    //
    // - `reduce_*`: reduce_f32 wins earliest; fp64 and i64 pay extra
    //   precision / emulation overhead.
    // - `hashagg_min_rows_per_group`: below this avg rows/group ratio the
    //   state fits in L2 and PG wins via vectorized CPU scan.
    // - `sort_break_even_rows_{int,float}`: sort below this loses to PG
    //   merge sort because of O(n log² n) kernel launches.
    // - `spatial_point_in_ring_break_even_verts_x_rows`: the relevant work
    //   metric for PIP is `vertex_count * row_count`; transfer + kernel
    //   launch only amortises beyond this product.
    // - `window_min_partition_rows`: per-partition minimum for tiled
    //   partition dispatch to amortise launch overhead.
    // - `expr_min_predicate_complexity_x_rows`: (bytecode instructions *
    //   rows). Below this expr eval is dominated by Custom Scan framing.
    // - `hashjoin_min_build_rows`: minimum inner build side; below, PG's
    //   native HashJoin avoids DSM round-trip and wins.
    //
    // All derived from `cu_scale` where possible, and clamped so they remain
    // sane on unusual hardware. These replace ad-hoc uses of
    // `gucs::min_batch_size()` in extension-internal dispatch paths.
    /// Minimum rows for GPU reduce over fp32 values.
    pub reduce_f32_break_even_rows: usize,
    /// Minimum rows for GPU reduce over fp64 values.
    pub reduce_f64_break_even_rows: usize,
    /// Minimum rows for GPU reduce over i64 values.
    pub reduce_i64_break_even_rows: usize,
    /// Minimum rows for GPU bitwise reduction (`bit_and`, `bit_or`,
    /// `bit_xor`) over i16/i32/i64 columns. Bitwise ops are extremely
    /// cheap per row on the CPU (1 instruction in a tight loop) so the
    /// break-even is much higher than typed `sum`/`min`/`max`.
    pub reduce_bit_break_even_rows: usize,
    /// Minimum rows for GPU boolean reduction (`bool_and`, `bool_or`)
    /// over a bool column. Boolean ops are even cheaper than bitwise
    /// (early termination on first `false`/`true`) so PG's parallel
    /// scan typically wins until the buffer is very large.
    pub reduce_bool_break_even_rows: usize,
    /// Minimum average rows-per-group for GPU hash aggregation to beat PG.
    /// Below this the per-group state fits in CPU L2.
    pub hashagg_min_rows_per_group: usize,
    /// Maximum per-group state size (bytes) before GPU hash agg loses to
    /// L2-resident CPU aggregate. Above this the hashtable spills.
    pub hashagg_max_state_bytes_per_group: usize,
    /// Minimum rows for GPU sort on integer keys.
    pub sort_break_even_rows_int: usize,
    /// Minimum rows for GPU sort on floating-point keys.
    pub sort_break_even_rows_float: usize,
    /// Minimum `vertex_count * row_count` work product for GPU spatial
    /// `point_in_ring` to amortise kernel launch and data transfer.
    pub spatial_point_in_ring_break_even_verts_x_rows: u64,
    /// Maximum `vertex_count * row_count` work product above which the
    /// megapoly kernel becomes strictly worse than PG parallel (too much
    /// work per row for fp32 precision recovery, recheck blow-up).
    pub spatial_point_in_ring_max_verts_x_rows: u64,
    /// Minimum rows per window partition for GPU window dispatch.
    pub window_min_partition_rows: usize,
    /// Minimum `(instructions * rows)` complexity for GpuExpr dispatch to
    /// amortise Custom Scan framing cost.
    pub expr_min_predicate_complexity_x_rows: u64,
    /// Minimum inner build-side rows for GPU hash join dispatch.
    pub hashjoin_min_build_rows: usize,

    // -- NestedLoop scalar-inequality gates ---------------------------------
    //
    // These legacy, wire-stable values bound opportunity and decline
    // calculations. No standalone NLJ kernel ships, and these values must not
    // be interpreted as enabling dispatch.
    //
    // Per CLAUDE.md rule #10, these live here rather than as constants
    // anywhere in dispatch / executor / planner code.
    /// Minimum outer-side rows for a potentially useful resident NLJ shape.
    pub gpu_nlj_min_outer_rows: usize,
    /// Minimum inner-side rows for the same opportunity calculation.
    pub gpu_nlj_min_inner_rows: usize,
    /// Maximum estimated output rows retained for decline diagnostics.
    pub gpu_nlj_max_output_rows: usize,
    /// Legacy per-pair cost factor retained for wire-stable diagnostics.
    pub gpu_nlj_per_pair_cost: f64,

    // -- fp64 emulation cost gate -------------------------------------------
    /// Whether the GPU device reports native hardware fp64. Drives the
    /// `soft_fp64_cost_multiplier` in cost functions — when false, fp64 ops
    /// are soft-emulated (via soft-fp64 on Metal) at ~1/32 native throughput.
    pub has_native_fp64: bool,
    /// Cost multiplier applied to GPU fp64 op cost when `has_native_fp64 == false`.
    /// Default 32.0 (micro-bench throughput ratio). Empirically tuned by the
    /// bench harness. Bounded [1.0, 64.0]; values past 64.0 require explicit
    /// user sign-off (see plan). Read from
    /// [`crate::soft_fp64_cost_multiplier`] at `from_profile` time.
    pub soft_fp64_cost_multiplier: f64,
}

/// A violated invariant in a [`DeviceLimits`] contract.
#[derive(Debug, Clone, Copy, PartialEq)]
pub enum DeviceLimitsValidationError {
    /// A row, element, byte, vertex, pixel, or reuse count is zero.
    ZeroCount { field: &'static str },
    /// A lower bound exceeds its corresponding upper bound.
    InvertedRange {
        lower_field: &'static str,
        lower: u128,
        upper_field: &'static str,
        upper: u128,
    },
    /// A fraction is non-finite or outside the inclusive range `[0, 1]`.
    InvalidFraction { field: &'static str, value: f64 },
    /// A cost coefficient or ratio is non-finite or not strictly positive.
    InvalidPositiveFloat { field: &'static str, value: f64 },
    /// The software fp64 multiplier is non-finite or outside `[1, 64]`.
    InvalidSoftFp64Multiplier { value: f64 },
    /// A configurable limit would expose a historically crash-prone retired
    /// kernel branch.
    HistoricalCrashBandExposed {
        field: &'static str,
        value: usize,
        exclusive_upper_bound: usize,
    },
}

impl fmt::Display for DeviceLimitsValidationError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::ZeroCount { field } => write!(f, "device limit {field} must be nonzero"),
            Self::InvertedRange {
                lower_field,
                lower,
                upper_field,
                upper,
            } => write!(
                f,
                "device limit range is inverted: {lower_field}={lower} exceeds {upper_field}={upper}"
            ),
            Self::InvalidFraction { field, value } => write!(
                f,
                "device limit {field} must be finite and within [0, 1], got {value}"
            ),
            Self::InvalidPositiveFloat { field, value } => write!(
                f,
                "device limit {field} must be finite and positive, got {value}"
            ),
            Self::InvalidSoftFp64Multiplier { value } => write!(
                f,
                "device limit soft_fp64_cost_multiplier must be finite and within [1, 64], got {value}"
            ),
            Self::HistoricalCrashBandExposed {
                field,
                value,
                exclusive_upper_bound,
            } => write!(
                f,
                "device limit {field}={value} exposes the historical crash band at {exclusive_upper_bound} rows"
            ),
        }
    }
}

impl std::error::Error for DeviceLimitsValidationError {}

#[derive(Debug, Clone, PartialEq, Eq)]
enum HostedMetalCompatibilityError {
    InvalidMode(String),
    ProfileMismatch,
}

impl fmt::Display for HostedMetalCompatibilityError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::InvalidMode(value) => write!(
                f,
                "{HOSTED_METAL_COMPATIBILITY_ENV} must be 0 or 1, got {value:?}"
            ),
            Self::ProfileMismatch => write!(
                f,
                "{HOSTED_METAL_COMPATIBILITY_ENV}=1 requires the exact hosted virtual-M1 Metal profile"
            ),
        }
    }
}

impl std::error::Error for HostedMetalCompatibilityError {}

/// Returns the planner-only compatibility profile for the exact hosted
/// virtual-M1 runner. The physical device remains unchanged; only the
/// throughput calibration used to admit compatibility/coverage fixtures is
/// pinned to the 32-CU reference baseline. This mode is never performance
/// evidence and rejects every non-exact host instead of broadening normal
/// production admission.
fn hosted_metal_planner_profile(
    profile: &PlatformProfile,
    mode: Option<&OsStr>,
    is_macos_arm64: bool,
) -> Result<Option<PlatformProfile>, HostedMetalCompatibilityError> {
    let Some(mode) = mode else {
        return Ok(None);
    };
    let Some(mode) = mode.to_str() else {
        return Err(HostedMetalCompatibilityError::InvalidMode(
            mode.to_string_lossy().into_owned(),
        ));
    };
    match mode {
        "0" => return Ok(None),
        "1" => {}
        other => {
            return Err(HostedMetalCompatibilityError::InvalidMode(other.to_owned()));
        }
    }

    if !is_macos_arm64
        || profile.cpu_cores != 3
        || !profile.has_gpu
        || profile.compute_units != 1
        || profile.device_name != "Apple Paravirtual device"
        || profile.backend_name != "metal"
        || profile.gpu_max_alloc_bytes == 0
        || profile.has_native_fp64
    {
        return Err(HostedMetalCompatibilityError::ProfileMismatch);
    }

    let mut calibrated = profile.clone();
    calibrated.compute_units = HOSTED_METAL_PLANNER_COMPUTE_UNITS;
    calibrated.estimated_gpu_gflops = f64::from(HOSTED_METAL_PLANNER_COMPUTE_UNITS) * 2.0;
    Ok(Some(calibrated))
}

impl DeviceLimits {
    /// Reference baseline: 32 compute units (Apple M2 Max GPU).
    /// Thresholds scale inversely with CU count relative to this baseline.
    const BASELINE_CUS: u32 = 32;

    /// Compute dynamic limits from a hardware profile.
    #[must_use]
    #[allow(clippy::cast_possible_truncation)]
    pub fn from_profile(profile: &PlatformProfile) -> Self {
        let cus = profile.compute_units.max(1);
        let mem = profile.gpu_max_alloc_bytes;
        let resident_memory_budget_bytes = if mem == 0 {
            256 * 1024 * 1024
        } else {
            (mem / 4).clamp(64 * 1024 * 1024, 8 * 1024 * 1024 * 1024)
        };

        // Scale factor: more CUs -> lower thresholds (better GPU).
        let cu_scale = |base: usize| -> usize {
            let scaled = (base as u64 * Self::BASELINE_CUS as u64) / cus as u64;
            scaled as usize
        };

        let gpu_min_rows = cu_scale(10_000).clamp(1_000, 100_000);
        let gpu_sort_min_rows = cu_scale(100_000).clamp(10_000, 1_000_000);
        // Retain matching historical sort thresholds so calibration snapshots
        // and serialized device profiles remain stable. No production
        // standalone-sort admission consumes either value.
        let gpu_sort_planner_min_rows = gpu_sort_min_rows;
        let gpu_window_min_rows = cu_scale(100_000).clamp(50_000, 500_000);
        // 2026-04-12: raised from 10K to 25K. GPU reduce at 10K is 0.11x
        // due to dispatch overhead dominating kernel time (~50µs).
        // At 25K+ the kernel amortizes the overhead.
        let gpu_reduce_min_rows = cu_scale(25_000).clamp(5_000, 200_000);
        let gpu_hash_agg_min_rows = cu_scale(250_000).clamp(50_000, 2_000_000);
        let gpu_hash_agg_unsafe_input_rows = HISTORICAL_UNSAFE_GROUPED_HASH_INPUT_ROWS;

        // H3 grouping stages exact/f32 coordinates, generated keys, validity,
        // and face/IJK state in one slab. Reserve at most 1/16th of a device
        // allocation and budget 64 bytes per row, then retain a useful floor.
        let gpu_h3_max_chunk_rows = if mem > 0 {
            (mem / 16 / 64).clamp(100_000, 4_000_000)
        } else {
            1_000_000
        };
        let gpu_h3_group_min_rows = cu_scale(100_000)
            .clamp(10_000, 1_000_000)
            .min(gpu_h3_max_chunk_rows);

        // Raster kernels retain native typed pixel bytes. Budgeting the widest
        // eight-byte pixel keeps metadata, output, and multi-input headroom.
        let gpu_raster_max_chunk_pixels = if mem > 0 {
            (mem / 8 / 8).clamp(65_536, 4_000_000)
        } else {
            1_000_000
        };
        let gpu_raster_min_pixels = cu_scale(65_536)
            .clamp(16_384, 1_048_576)
            .min(gpu_raster_max_chunk_pixels);

        // ~64 bytes per hash entry; use 1/256th of GPU memory as budget.
        // GPU hash agg kernel uses open-addressing with atomic accumulators;
        // tested up to 100K groups on Metal.
        let gpu_hash_agg_max_groups = if mem > 0 {
            (mem / 256 / 64).clamp(1_000, 100_000)
        } else {
            100_000
        };
        // Compact H3 COUNT needs <128 bytes/capacity slot including output,
        // hash slots rounded to a power of two, and staging. Reserve 64KiB
        // for fixed descriptors/alignment. Bound this lane by one eighth of device
        // max-allocation size and one quarter of the default resident budget.
        // Parallel compaction/merge sorting removes the serial finalizer limit;
        // key generation and hash-row launches remain independently chunked.
        // Keep a 16Mi-group qualification ceiling, not an input-size clamp.
        let gpu_h3_max_groups = if mem > 0 {
            let workspace_budget = (mem / 8).min(resident_memory_budget_bytes / 4);
            (workspace_budget.saturating_sub(65_536) / 128).clamp(1, 16 * 1024 * 1024)
        } else {
            10_000
        };

        // Max elements per reduce / dense-session dispatch. All backends stage
        // through device allocations, so chunk from the device allocation
        // budget. One million rows is the independently bounded synchronous
        // limit used by the dense one-shot path; matching it here reduces a
        // 10M-row session to ten accumulate calls plus finalize without
        // weakening the established cancellation boundary.
        let gpu_reduce_max_chunk = if mem > 0 {
            (mem / 32 / 8).clamp(64_000, 1_000_000)
        } else {
            1_000_000
        };

        // The M2 Max baseline completes the resident atomic grouped sentinel
        // well below the synchronous-dispatch warning threshold at one
        // million rows. Scale weaker devices down by compute units so query
        // cancellation still reaches a boundary promptly; faster devices are
        // capped by the exact int64 accumulator proof.
        let gpu_grouped_agg_one_shot_max_rows = {
            let scaled = (GPU_GROUPED_AGG_ONE_SHOT_ABSOLUTE_MAX_ROWS as u64)
                .saturating_mul(u64::from(cus))
                / u64::from(Self::BASELINE_CUS);
            usize::try_from(scaled)
                .unwrap_or(GPU_GROUPED_AGG_ONE_SHOT_ABSOLUTE_MAX_ROWS)
                .clamp(64_000, GPU_GROUPED_AGG_ONE_SHOT_ABSOLUTE_MAX_ROWS)
        };

        // Historical direct-sort element cap. Keep its memory-derived value
        // stable for calibration snapshots; no production standalone-sort
        // admission or executor consumes it.
        let gpu_sort_max_elements = if mem > 0 {
            (mem / 32 / 12).clamp(64_000, 4_000_000)
        } else {
            2_000_000
        };
        // Max output rows for GPU hash join. Custom Scan yield overhead
        // (~3μs/row) dominates for large outputs. Scale with CUs: more
        // CUs means GPU probe is faster, tolerating more output rows.
        // Baseline: 100K output rows for 32 CUs.
        #[allow(clippy::cast_possible_truncation)]
        let gpu_join_max_output_rows = {
            let base = 100_000_usize;
            let scaled = (base as u64 * cus as u64 / Self::BASELINE_CUS as u64) as usize;
            scaled.clamp(50_000, 500_000)
        };

        // Hash join build: reject the sort-merge kernel branch that starts at
        // 100K rows. Memory may lower the cap on tiny devices but never raises
        // it into the unsafe branch.
        let gpu_hash_join_build_max_rows = if mem > 0 {
            (mem / 64 / 64).clamp(
                10_000,
                HISTORICAL_UNSAFE_ROW_JOIN_BUILD_ROWS.saturating_sub(1),
            )
        } else {
            HISTORICAL_UNSAFE_ROW_JOIN_BUILD_ROWS - 1
        };

        // Batch size bounds scale with available GPU memory.
        let optimal_batch_max = if mem > 0 {
            let base = mem / (8 * 1024);
            let clamped = base.clamp(2048, 65_536);
            clamped / 2
        } else {
            8192
        };

        Self {
            resident_memory_budget_bytes,
            resident_domain_max_exact_value_bytes: 1024 * 1024,
            auto_load_amortization_queries: 8,
            // M2 unified-memory measurements loaded 2,105,256 and 3,157,884
            // byte fixed-width integer snapshots in 16.236ms and 20.627ms.
            // These coefficients deliberately retain substantial headroom
            // before the configured reuse amortization while keeping resident
            // loading distinct from PreAgg dimension hash-table construction.
            resident_load_scan_per_row_cost: 0.01,
            resident_load_per_byte_cost: 0.001,
            gpu_min_rows,
            gpu_sort_min_rows,
            gpu_sort_planner_min_rows,
            gpu_window_min_rows,
            gpu_reduce_min_rows,
            gpu_hash_agg_min_rows,
            gpu_hash_agg_unsafe_input_rows,
            gpu_hash_agg_max_groups,
            gpu_h3_max_groups,
            gpu_reduce_max_chunk,
            gpu_grouped_agg_one_shot_max_rows,
            gpu_sort_max_elements,
            gpu_sort_topk_max_limit: 128,
            gpu_sort_heap_topk_max_fraction: 0.25,
            gpu_sort_heap_topk_max_width_bytes: 16,
            gpu_join_max_output_rows,
            gpu_h3_group_min_rows,
            gpu_h3_max_chunk_rows,
            // 2026-05-13 safety band: many polygon/selectivity fixtures crash
            // at the 100K scale, while adjacent 10K/1M cells do not show the
            // same monotonic memory profile. Keep this row-band gate narrow.
            // Spatial vertex threshold: GPU kernel overhead is constant
            // (~19ms for geom deser + seq scan), while PG parallel scales
            // linearly with vertex count. This gate rejects the obviously
            // unprofitable (sub-100-vertex) cases; the full work-product
            // gate (`spatial_point_in_ring_break_even_verts_x_rows`, applied
            // in `planner_hooks::pgaccel_set_rel_pathlist`) handles the
            // actual break-even via `vertex_count * row_count`.
            //
            // Lowered from 500 to 100 as of the 2026-04-11 bench re-run:
            // the old gate over-corrected and rejected `vsweep_256v` even at
            // large row counts where the work product (~25M) cleared
            // break-even. The work-product gate is the correct discriminator;
            // keep this only as a hard floor for truly degenerate polygons.
            gpu_spatial_min_vertices: cu_scale(100).clamp(32, 1_000),
            gpu_spatial_max_vertices_per_row: 1_000_000,
            gpu_spatial_max_output_fraction: 0.80,
            gpu_spatial_max_recheck_fraction: 0.10,
            // Pairwise spatial uses one packed device slab. Reserve 1/32 of
            // max-allocation capacity and budget 16 KiB per pair (enough for
            // two 1K-vertex payloads before pointer-based payload dedup).
            // The C bridge validates the exact byte count and returns OOM if
            // unusually large unique geometries still exceed max_alloc.
            gpu_spatial_pairwise_chunk_rows: if mem > 0 {
                (mem / 32 / (16 * 1024)).clamp(256, 65_536)
            } else {
                2_048
            },
            gpu_raster_min_pixels,
            gpu_raster_max_chunk_pixels,
            // GpuExpr scan: inline template filter avoids ExecQual overhead
            // but Custom Scan framing still adds per-row cost. Needs enough
            // rows to amortize compilation + scan overhead.
            gpu_expr_min_rows: cu_scale(250_000).clamp(50_000, 2_000_000),
            gpu_hash_join_build_max_rows,
            // Pipeline fusion: setup has overhead (scan_desc open, template
            // compile). Needs enough rows to amortize.
            gpu_pipeline_fusion_min_rows: cu_scale(10_000).clamp(5_000, 100_000),
            // PreAgg (star-join fusion): needs enough fact rows to amortize
            // dimension materialization and hash table build.
            gpu_preagg_min_fact_rows: cu_scale(50_000).clamp(10_000, 500_000),
            // Dimension tables must be small enough to fit in memory.
            gpu_preagg_max_dim_rows: if mem > 0 {
                (mem / 64 / 64).clamp(10_000, 2_000_000)
            } else {
                100_000
            },
            // PreAgg per-row cost model: derived from empirical measurement.
            // Dimension materialization is CPU-side tuple extraction + hash
            // table build; large dimensions were under-costed at 0.01 and
            // selected losing count-only join plans.
            preagg_dim_materialize_cost: 0.10,
            preagg_fact_scan_cost: 0.001,
            preagg_probe_cost: 0.003,
            preagg_agg_cost: 0.002,
            preagg_yield_cost: 0.03,
            optimal_batch_min: 256,
            optimal_batch_max: optimal_batch_max.max(256),
            // Interrupt check every 64K rows balances responsiveness
            // (~1ms at heap scan speed) vs CHECK_FOR_INTERRUPTS overhead.
            fused_interrupt_interval: 65_536,

            // Per-strategy GPU op costs include explicit staging overhead,
            // except the resident H3 parent transform. That integer-only D2D
            // kernel is conservatively priced like a resident GPU filter.
            gpu_op_cost_reduce: 0.000_5,
            gpu_op_cost_hash_agg: 0.002,
            gpu_op_cost_sort: 0.003,
            gpu_op_cost_window: 0.001,
            gpu_op_cost_filter: 0.001,
            cpu_spatial_recheck_per_row: 0.05,
            gpu_op_cost_h3_parent_resident: 0.001,

            // Phase 6 dispatch-perf calibration: per-row hash-join +
            // partial-agg + CustomScan-yield costs derived from kernel
            // throughput rather than over-pessimistic CPU-side bookkeeping.
            // Base `0.001 / row` (= 1µs / row in PG's cost-unit convention),
            // safely above the measured ~50ns / row to leave headroom for
            // micro-bench noise and explicit staging overhead.
            gpu_hashjoin_build_per_row: 0.001,
            gpu_hashjoin_probe_per_row: 0.001,
            custom_scan_yield_per_row: 0.001,
            gpu_partial_agg_per_row: 0.001,

            // Cost ratio gates vs PG's cheapest NON-parallel path. We compare
            // against the serial baseline (not the parallel Gather plan) so
            // the GPU batch speedup isn't required to overcome the
            // parallel-workers linear speedup on paper — PG's parallel plans
            // cost roughly (serial / workers). The GPU kernel's actual
            // throughput beats both at runtime.
            //
            // Values < 1.0 mean "our path must be cheaper than serial PG";
            // values >= 1.0 allow injection as long as our path is within
            // this multiple of serial PG.
            //
            // Generic aggregate admission proves that its comparison path is
            // an AGGSPLIT_SIMPLE aggregate with no parallel execution anywhere
            // in its subtree. If no such serial baseline exists, admission
            // fails closed instead of comparing against a parallel finalize
            // aggregate whose root itself reports zero workers.
            // 2026-04-12: lowered from 2.00 to 0.80 after a filtered integer
            // aggregate scored 0.30x@10M. At 0.80 the planner
            // rejects GPU agg unless estimated cheaper than 80% of PG serial.
            gpu_agg_cost_ratio: 0.80,
            gpu_window_cost_ratio: 1.50,
            gpu_preagg_cost_ratio: 1.50,

            // Per-kernel-class break-even thresholds.
            // f32 reduce wins earliest because transfer is cheapest; f64
            // pays ~2x precision overhead, i64 pays divergence penalty.
            reduce_f32_break_even_rows: cu_scale(25_000).clamp(4_000, 250_000),
            reduce_f64_break_even_rows: cu_scale(50_000).clamp(8_000, 500_000),
            reduce_i64_break_even_rows: cu_scale(75_000).clamp(10_000, 750_000),
            // Bitwise ops are ~1 inst/row on CPU and PG parallel reduces
            // 4× as fast as scalar SUM; break-even is roughly 4× the i64
            // sum threshold. Clamp keeps the floor large enough that small
            // queries skip GPU dispatch overhead (~50µs warmup).
            reduce_bit_break_even_rows: cu_scale(300_000).clamp(50_000, 3_000_000),
            // Bool ops short-circuit on CPU (first false breaks bool_and,
            // first true breaks bool_or) so they need an even larger batch
            // before GPU launch overhead amortises.
            reduce_bool_break_even_rows: cu_scale(500_000).clamp(100_000, 5_000_000),
            // HashAgg: below ~32 rows/group PG's vectorized L2 aggregate
            // beats GPU per-group atomics. Above, GPU amortises probe +
            // yield overhead.
            hashagg_min_rows_per_group: 32,
            // ~1 MB L2 per core (M2 Max). Above this the hashtable spills
            // out of L2 on CPU, so GPU wins.
            hashagg_max_state_bytes_per_group: 256,
            sort_break_even_rows_int: cu_scale(100_000).clamp(20_000, 1_000_000),
            sort_break_even_rows_float: cu_scale(80_000).clamp(16_000, 800_000),
            // Spatial PIP break-even: raised after the 2026-05-13 run showed
            // moderate polygon/selectivity cells often losing even when
            // stable. Keep only compute-heavy polygon work eligible while
            // the staging/selectivity cost model is rebuilt.
            spatial_point_in_ring_break_even_verts_x_rows: 500_000_000,
            // Upper gate: `scale_1m_mega500v` hits ~10^12 work items and is
            // strictly worse on GPU than PG parallel. Reject above ~5 * 10^10.
            spatial_point_in_ring_max_verts_x_rows: 50_000_000_000,
            window_min_partition_rows: cu_scale(10_000).clamp(2_000, 100_000),
            // GpuExpr: min_instrs=1, ~50k rows → 50k (trivial filter).
            // Used as (program.instructions * rows) lower bound.
            expr_min_predicate_complexity_x_rows: 50_000,
            hashjoin_min_build_rows: cu_scale(5_000).clamp(1_000, 50_000),

            // NestedLoop scalar-inequality opportunity gates. A future
            // resident implementation remains O(N*M), so floors are higher
            // than typical hash-join thresholds. These values do not enable
            // dispatch while the structural decline is active.
            gpu_nlj_min_outer_rows: cu_scale(1_000).clamp(200, 50_000),
            gpu_nlj_min_inner_rows: cu_scale(1_000).clamp(200, 50_000),
            // Output cap reuses the hashjoin output ceiling: above it, row
            // reconstruction would dominate any device-side pair filtering.
            gpu_nlj_max_output_rows: gpu_join_max_output_rows,
            // Legacy per-pair proxy for opportunity diagnostics. A future
            // resident implementation must recalibrate this before dispatch.
            gpu_nlj_per_pair_cost: 1.0e-7,

            // fp64 emulation cost gate. `from_profile` is the only entry
            // that sees the detected hardware, so the multiplier is latched
            // here. `#[cfg(test)]` builds skip the GUC lookup (GUCs need a
            // running backend); tests instantiate DeviceLimits directly and
            // set the multiplier manually.
            has_native_fp64: profile.has_native_fp64,
            #[cfg(not(test))]
            soft_fp64_cost_multiplier: crate::soft_fp64_cost_multiplier(),
            #[cfg(test)]
            soft_fp64_cost_multiplier: 32.0,
        }
    }

    /// Fallback limits used when no GPU is present (matches previous defaults).
    #[must_use]
    pub const fn cpu_only() -> Self {
        Self {
            resident_memory_budget_bytes: 256 * 1024 * 1024,
            resident_domain_max_exact_value_bytes: 1024 * 1024,
            auto_load_amortization_queries: 8,
            resident_load_scan_per_row_cost: 0.01,
            resident_load_per_byte_cost: 0.001,
            gpu_min_rows: 10_000,
            gpu_sort_min_rows: 100_000,
            // Planner threshold tracks the executor threshold — see comment
            // in `from_profile`.
            gpu_sort_planner_min_rows: 100_000,
            gpu_window_min_rows: 100_000,
            gpu_reduce_min_rows: 25_000,
            gpu_hash_agg_min_rows: 250_000,
            gpu_hash_agg_unsafe_input_rows: HISTORICAL_UNSAFE_GROUPED_HASH_INPUT_ROWS,
            gpu_hash_agg_max_groups: 10_000,
            gpu_h3_max_groups: 10_000,
            gpu_reduce_max_chunk: 1_000_000,
            gpu_grouped_agg_one_shot_max_rows: GPU_GROUPED_AGG_ONE_SHOT_ABSOLUTE_MAX_ROWS,
            gpu_sort_max_elements: 2_000_000,
            gpu_sort_topk_max_limit: 128,
            gpu_sort_heap_topk_max_fraction: 0.25,
            gpu_sort_heap_topk_max_width_bytes: 16,
            gpu_join_max_output_rows: 100_000,
            gpu_h3_group_min_rows: 100_000,
            gpu_h3_max_chunk_rows: 1_000_000,
            gpu_spatial_min_vertices: 50_000,
            gpu_spatial_max_vertices_per_row: 1_000_000,
            gpu_spatial_max_output_fraction: 0.80,
            gpu_spatial_max_recheck_fraction: 0.10,
            // Conservative fallback for callers that inspect limits before
            // device discovery. No GPU dispatch occurs under cpu_only().
            gpu_spatial_pairwise_chunk_rows: 2_048,
            gpu_raster_min_pixels: 65_536,
            gpu_raster_max_chunk_pixels: 1_000_000,
            gpu_expr_min_rows: 250_000,
            gpu_hash_join_build_max_rows: HISTORICAL_UNSAFE_ROW_JOIN_BUILD_ROWS - 1,
            gpu_pipeline_fusion_min_rows: 10_000,
            gpu_preagg_min_fact_rows: 50_000,
            gpu_preagg_max_dim_rows: 100_000,
            preagg_dim_materialize_cost: 0.10,
            preagg_fact_scan_cost: 0.001,
            preagg_probe_cost: 0.003,
            preagg_agg_cost: 0.002,
            preagg_yield_cost: 0.03,
            optimal_batch_min: 256,
            optimal_batch_max: 8192,
            fused_interrupt_interval: 65_536,
            gpu_op_cost_reduce: 0.000_5,
            gpu_op_cost_hash_agg: 0.002,
            gpu_op_cost_sort: 0.003,
            gpu_op_cost_window: 0.001,
            gpu_op_cost_filter: 0.001,
            cpu_spatial_recheck_per_row: 0.05,
            // Match the conservative resident-filter estimate; extraction
            // and host staging are intentionally excluded.
            gpu_op_cost_h3_parent_resident: 0.001,
            // Phase 6 dispatch-perf calibration. CPU-only fallback keeps the
            // same conservative values as detected GPU profiles.
            gpu_hashjoin_build_per_row: 0.001,
            gpu_hashjoin_probe_per_row: 0.001,
            custom_scan_yield_per_row: 0.001,
            gpu_partial_agg_per_row: 0.001,
            gpu_agg_cost_ratio: 0.80,
            gpu_window_cost_ratio: 1.50,
            gpu_preagg_cost_ratio: 1.50,

            reduce_f32_break_even_rows: 25_000,
            reduce_f64_break_even_rows: 50_000,
            reduce_i64_break_even_rows: 75_000,
            reduce_bit_break_even_rows: 300_000,
            reduce_bool_break_even_rows: 500_000,
            hashagg_min_rows_per_group: 32,
            hashagg_max_state_bytes_per_group: 256,
            sort_break_even_rows_int: 100_000,
            sort_break_even_rows_float: 80_000,
            spatial_point_in_ring_break_even_verts_x_rows: 500_000_000,
            spatial_point_in_ring_max_verts_x_rows: 50_000_000_000,
            window_min_partition_rows: 10_000,
            expr_min_predicate_complexity_x_rows: 50_000,
            hashjoin_min_build_rows: 5_000,

            // Conservative NLJ defaults — no GPU means we never dispatch
            // a NLJ batch but the planner still reads these for cost
            // formulas / SRF surfacing. Keep them on the conservative
            // side of the from_profile values.
            gpu_nlj_min_outer_rows: 1_000,
            gpu_nlj_min_inner_rows: 1_000,
            gpu_nlj_max_output_rows: 100_000,
            gpu_nlj_per_pair_cost: 1.0e-7,

            // No GPU → no native fp64. The multiplier is unused (fp64
            // strategies never dispatch without GPU), but set it to the
            // default so tests that read the field see a sane value.
            has_native_fp64: false,
            soft_fp64_cost_multiplier: 32.0,
        }
    }

    /// Validate the complete limits contract before it is consumed by a
    /// planner or executor.
    ///
    /// This method deliberately validates both hardware-derived and CPU-only
    /// values. The fallback does not dispatch work, but diagnostics and typed
    /// cost-model views still consume it and must never observe impossible
    /// ranges or non-finite coefficients.
    pub fn validate(&self) -> Result<(), DeviceLimitsValidationError> {
        macro_rules! require_nonzero {
            ($($field:ident),+ $(,)?) => {
                $(
                    if self.$field == 0 {
                        return Err(DeviceLimitsValidationError::ZeroCount {
                            field: stringify!($field),
                        });
                    }
                )+
            };
        }

        macro_rules! require_ordered {
            ($lower:ident, $upper:ident) => {
                if self.$lower > self.$upper {
                    return Err(DeviceLimitsValidationError::InvertedRange {
                        lower_field: stringify!($lower),
                        lower: self.$lower as u128,
                        upper_field: stringify!($upper),
                        upper: self.$upper as u128,
                    });
                }
            };
        }

        require_nonzero!(
            resident_memory_budget_bytes,
            resident_domain_max_exact_value_bytes,
            auto_load_amortization_queries,
            gpu_min_rows,
            gpu_sort_min_rows,
            gpu_sort_planner_min_rows,
            gpu_window_min_rows,
            gpu_reduce_min_rows,
            gpu_hash_agg_min_rows,
            gpu_hash_agg_unsafe_input_rows,
            gpu_hash_agg_max_groups,
            gpu_h3_max_groups,
            gpu_reduce_max_chunk,
            gpu_grouped_agg_one_shot_max_rows,
            gpu_sort_max_elements,
            gpu_sort_topk_max_limit,
            gpu_sort_heap_topk_max_width_bytes,
            gpu_join_max_output_rows,
            gpu_h3_group_min_rows,
            gpu_h3_max_chunk_rows,
            gpu_spatial_min_vertices,
            gpu_spatial_max_vertices_per_row,
            gpu_spatial_pairwise_chunk_rows,
            gpu_raster_min_pixels,
            gpu_raster_max_chunk_pixels,
            gpu_expr_min_rows,
            gpu_hash_join_build_max_rows,
            gpu_pipeline_fusion_min_rows,
            gpu_preagg_min_fact_rows,
            gpu_preagg_max_dim_rows,
            optimal_batch_min,
            optimal_batch_max,
            fused_interrupt_interval,
            reduce_f32_break_even_rows,
            reduce_f64_break_even_rows,
            reduce_i64_break_even_rows,
            reduce_bit_break_even_rows,
            reduce_bool_break_even_rows,
            hashagg_min_rows_per_group,
            hashagg_max_state_bytes_per_group,
            sort_break_even_rows_int,
            sort_break_even_rows_float,
            spatial_point_in_ring_break_even_verts_x_rows,
            spatial_point_in_ring_max_verts_x_rows,
            window_min_partition_rows,
            expr_min_predicate_complexity_x_rows,
            hashjoin_min_build_rows,
            gpu_nlj_min_outer_rows,
            gpu_nlj_min_inner_rows,
            gpu_nlj_max_output_rows,
        );

        require_ordered!(gpu_sort_min_rows, gpu_sort_planner_min_rows);
        if self.gpu_hash_agg_unsafe_input_rows > HISTORICAL_UNSAFE_GROUPED_HASH_INPUT_ROWS {
            return Err(DeviceLimitsValidationError::HistoricalCrashBandExposed {
                field: "gpu_hash_agg_unsafe_input_rows",
                value: self.gpu_hash_agg_unsafe_input_rows,
                exclusive_upper_bound: HISTORICAL_UNSAFE_GROUPED_HASH_INPUT_ROWS,
            });
        }
        if self.gpu_hash_join_build_max_rows >= HISTORICAL_UNSAFE_ROW_JOIN_BUILD_ROWS {
            return Err(DeviceLimitsValidationError::HistoricalCrashBandExposed {
                field: "gpu_hash_join_build_max_rows",
                value: self.gpu_hash_join_build_max_rows,
                exclusive_upper_bound: HISTORICAL_UNSAFE_ROW_JOIN_BUILD_ROWS,
            });
        }
        if self.gpu_grouped_agg_one_shot_max_rows > GPU_GROUPED_AGG_ONE_SHOT_ABSOLUTE_MAX_ROWS {
            return Err(DeviceLimitsValidationError::InvertedRange {
                lower_field: "gpu_grouped_agg_one_shot_max_rows",
                lower: self.gpu_grouped_agg_one_shot_max_rows as u128,
                upper_field: "GPU_GROUPED_AGG_ONE_SHOT_ABSOLUTE_MAX_ROWS",
                upper: GPU_GROUPED_AGG_ONE_SHOT_ABSOLUTE_MAX_ROWS as u128,
            });
        }
        require_ordered!(
            resident_domain_max_exact_value_bytes,
            resident_memory_budget_bytes
        );
        require_ordered!(gpu_h3_group_min_rows, gpu_h3_max_chunk_rows);
        require_ordered!(gpu_spatial_min_vertices, gpu_spatial_max_vertices_per_row);
        require_ordered!(gpu_raster_min_pixels, gpu_raster_max_chunk_pixels);
        require_ordered!(optimal_batch_min, optimal_batch_max);
        require_ordered!(
            spatial_point_in_ring_break_even_verts_x_rows,
            spatial_point_in_ring_max_verts_x_rows
        );

        for (field, value) in [
            (
                "gpu_sort_heap_topk_max_fraction",
                self.gpu_sort_heap_topk_max_fraction,
            ),
            (
                "gpu_spatial_max_output_fraction",
                self.gpu_spatial_max_output_fraction,
            ),
            (
                "gpu_spatial_max_recheck_fraction",
                self.gpu_spatial_max_recheck_fraction,
            ),
        ] {
            if !value.is_finite() || !(0.0..=1.0).contains(&value) {
                return Err(DeviceLimitsValidationError::InvalidFraction { field, value });
            }
        }

        for (field, value) in [
            (
                "resident_load_scan_per_row_cost",
                self.resident_load_scan_per_row_cost,
            ),
            (
                "resident_load_per_byte_cost",
                self.resident_load_per_byte_cost,
            ),
            (
                "preagg_dim_materialize_cost",
                self.preagg_dim_materialize_cost,
            ),
            ("preagg_fact_scan_cost", self.preagg_fact_scan_cost),
            ("preagg_probe_cost", self.preagg_probe_cost),
            ("preagg_agg_cost", self.preagg_agg_cost),
            ("preagg_yield_cost", self.preagg_yield_cost),
            ("gpu_op_cost_reduce", self.gpu_op_cost_reduce),
            ("gpu_op_cost_hash_agg", self.gpu_op_cost_hash_agg),
            ("gpu_op_cost_sort", self.gpu_op_cost_sort),
            ("gpu_op_cost_window", self.gpu_op_cost_window),
            ("gpu_op_cost_filter", self.gpu_op_cost_filter),
            (
                "cpu_spatial_recheck_per_row",
                self.cpu_spatial_recheck_per_row,
            ),
            (
                "gpu_op_cost_h3_parent_resident",
                self.gpu_op_cost_h3_parent_resident,
            ),
            (
                "gpu_hashjoin_build_per_row",
                self.gpu_hashjoin_build_per_row,
            ),
            (
                "gpu_hashjoin_probe_per_row",
                self.gpu_hashjoin_probe_per_row,
            ),
            ("custom_scan_yield_per_row", self.custom_scan_yield_per_row),
            ("gpu_partial_agg_per_row", self.gpu_partial_agg_per_row),
            ("gpu_agg_cost_ratio", self.gpu_agg_cost_ratio),
            ("gpu_window_cost_ratio", self.gpu_window_cost_ratio),
            ("gpu_preagg_cost_ratio", self.gpu_preagg_cost_ratio),
            ("gpu_nlj_per_pair_cost", self.gpu_nlj_per_pair_cost),
        ] {
            if !value.is_finite() || value <= 0.0 {
                return Err(DeviceLimitsValidationError::InvalidPositiveFloat { field, value });
            }
        }

        if !self.soft_fp64_cost_multiplier.is_finite()
            || !(1.0..=64.0).contains(&self.soft_fp64_cost_multiplier)
        {
            return Err(DeviceLimitsValidationError::InvalidSoftFp64Multiplier {
                value: self.soft_fp64_cost_multiplier,
            });
        }

        Ok(())
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn profile(compute_units: u32, gpu_max_alloc_bytes: usize) -> PlatformProfile {
        PlatformProfile {
            cpu_cores: 8,
            has_gpu: true,
            estimated_gpu_gflops: 2_000.0,
            compute_units,
            device_name: "test-gpu".to_owned(),
            backend_name: "metal".to_owned(),
            gpu_max_alloc_bytes,
            has_native_fp64: false,
        }
    }

    #[test]
    fn constructors_produce_valid_limits() {
        DeviceLimits::cpu_only()
            .validate()
            .expect("cpu-only device limits must satisfy the contract");

        for candidate in [
            profile(0, 0),
            profile(1, 1),
            profile(8, 64 * 1024 * 1024),
            profile(32, 256 * 1024 * 1024),
            profile(128, 8 * 1024 * 1024 * 1024),
        ] {
            DeviceLimits::from_profile(&candidate)
                .validate()
                .expect("hardware-derived device limits must satisfy the contract");
        }
    }

    #[test]
    fn historical_crash_bands_are_pinned_for_every_device_profile() {
        let mut candidates = vec![DeviceLimits::cpu_only()];
        candidates.extend(
            [
                profile(0, 0),
                profile(1, 1),
                profile(8, 64 * 1024 * 1024),
                profile(32, 256 * 1024 * 1024),
                profile(128, 8 * 1024 * 1024 * 1024),
            ]
            .iter()
            .map(DeviceLimits::from_profile),
        );

        for limits in candidates {
            assert_eq!(
                limits.gpu_hash_agg_unsafe_input_rows,
                HISTORICAL_UNSAFE_GROUPED_HASH_INPUT_ROWS,
            );
            assert!(limits.gpu_hash_join_build_max_rows < HISTORICAL_UNSAFE_ROW_JOIN_BUILD_ROWS);
            limits
                .validate()
                .expect("constructor may not expose a historical crash band");
        }
    }

    #[test]
    fn validation_rejects_attempts_to_raise_historical_crash_gates() {
        let mut grouped = DeviceLimits::cpu_only();
        grouped.gpu_hash_agg_unsafe_input_rows = HISTORICAL_UNSAFE_GROUPED_HASH_INPUT_ROWS + 1;
        assert_eq!(
            grouped.validate(),
            Err(DeviceLimitsValidationError::HistoricalCrashBandExposed {
                field: "gpu_hash_agg_unsafe_input_rows",
                value: HISTORICAL_UNSAFE_GROUPED_HASH_INPUT_ROWS + 1,
                exclusive_upper_bound: HISTORICAL_UNSAFE_GROUPED_HASH_INPUT_ROWS,
            })
        );

        let mut join = DeviceLimits::cpu_only();
        join.gpu_hash_join_build_max_rows = HISTORICAL_UNSAFE_ROW_JOIN_BUILD_ROWS;
        assert_eq!(
            join.validate(),
            Err(DeviceLimitsValidationError::HistoricalCrashBandExposed {
                field: "gpu_hash_join_build_max_rows",
                value: HISTORICAL_UNSAFE_ROW_JOIN_BUILD_ROWS,
                exclusive_upper_bound: HISTORICAL_UNSAFE_ROW_JOIN_BUILD_ROWS,
            })
        );
    }

    #[test]
    fn phase6_cpu_only_domain_limits_are_pinned() {
        let limits = DeviceLimits::cpu_only();
        assert_eq!(limits.gpu_h3_group_min_rows, 100_000);
        assert_eq!(limits.gpu_h3_max_chunk_rows, 1_000_000);
        assert_eq!(limits.gpu_op_cost_h3_parent_resident, 0.001);
        assert!(limits.gpu_op_cost_h3_parent_resident >= limits.gpu_op_cost_reduce);
        assert_eq!(
            limits.gpu_op_cost_h3_parent_resident,
            limits.gpu_op_cost_filter,
        );
        assert_eq!(
            limits.gpu_op_cost_h3_parent_resident,
            limits.gpu_op_cost_window,
        );
        assert_eq!(limits.gpu_spatial_max_vertices_per_row, 1_000_000);
        assert_eq!(limits.gpu_spatial_max_recheck_fraction, 0.10);
        assert_eq!(limits.cpu_spatial_recheck_per_row, 0.05);
        assert_eq!(limits.gpu_raster_min_pixels, 65_536);
        assert_eq!(limits.gpu_raster_max_chunk_pixels, 1_000_000);
        assert_eq!(limits.resident_domain_max_exact_value_bytes, 1024 * 1024);
    }

    #[test]
    fn domain_chunks_scale_with_device_allocation() {
        let low = DeviceLimits::from_profile(&profile(32, 64 * 1024 * 1024));
        let high = DeviceLimits::from_profile(&profile(32, 8 * 1024 * 1024 * 1024));

        assert!(high.gpu_h3_max_chunk_rows > low.gpu_h3_max_chunk_rows);
        assert!(high.gpu_raster_max_chunk_pixels > low.gpu_raster_max_chunk_pixels);
        assert_eq!(high.gpu_spatial_max_vertices_per_row, 1_000_000);
        assert_eq!(high.resident_domain_max_exact_value_bytes, 1024 * 1024);
    }

    #[test]
    fn grouped_agg_one_shot_limit_scales_with_compute_and_stays_proven() {
        let low = DeviceLimits::from_profile(&profile(8, 256 * 1024 * 1024));
        let baseline = DeviceLimits::from_profile(&profile(32, 256 * 1024 * 1024));
        let high = DeviceLimits::from_profile(&profile(128, 256 * 1024 * 1024));

        assert_eq!(low.gpu_grouped_agg_one_shot_max_rows, 250_000);
        assert_eq!(
            baseline.gpu_grouped_agg_one_shot_max_rows,
            GPU_GROUPED_AGG_ONE_SHOT_ABSOLUTE_MAX_ROWS
        );
        assert_eq!(
            high.gpu_grouped_agg_one_shot_max_rows,
            GPU_GROUPED_AGG_ONE_SHOT_ABSOLUTE_MAX_ROWS
        );
    }

    #[test]
    fn validation_rejects_zero_counts_with_the_field_name() {
        let mut limits = DeviceLimits::cpu_only();
        limits.gpu_h3_max_chunk_rows = 0;

        assert_eq!(
            limits.validate(),
            Err(DeviceLimitsValidationError::ZeroCount {
                field: "gpu_h3_max_chunk_rows",
            })
        );
    }

    #[test]
    fn validation_rejects_inverted_ranges() {
        let mut limits = DeviceLimits::cpu_only();
        limits.gpu_h3_group_min_rows = limits.gpu_h3_max_chunk_rows + 1;
        assert!(matches!(
            limits.validate(),
            Err(DeviceLimitsValidationError::InvertedRange {
                lower_field: "gpu_h3_group_min_rows",
                upper_field: "gpu_h3_max_chunk_rows",
                ..
            })
        ));

        let mut limits = DeviceLimits::cpu_only();
        limits.gpu_grouped_agg_one_shot_max_rows = GPU_GROUPED_AGG_ONE_SHOT_ABSOLUTE_MAX_ROWS + 1;
        assert!(matches!(
            limits.validate(),
            Err(DeviceLimitsValidationError::InvertedRange {
                lower_field: "gpu_grouped_agg_one_shot_max_rows",
                upper_field: "GPU_GROUPED_AGG_ONE_SHOT_ABSOLUTE_MAX_ROWS",
                ..
            })
        ));

        let mut limits = DeviceLimits::cpu_only();
        limits.gpu_spatial_min_vertices = limits.gpu_spatial_max_vertices_per_row + 1;
        assert!(matches!(
            limits.validate(),
            Err(DeviceLimitsValidationError::InvertedRange {
                lower_field: "gpu_spatial_min_vertices",
                upper_field: "gpu_spatial_max_vertices_per_row",
                ..
            })
        ));

        let mut limits = DeviceLimits::cpu_only();
        limits.gpu_raster_min_pixels = limits.gpu_raster_max_chunk_pixels + 1;
        assert!(matches!(
            limits.validate(),
            Err(DeviceLimitsValidationError::InvertedRange {
                lower_field: "gpu_raster_min_pixels",
                upper_field: "gpu_raster_max_chunk_pixels",
                ..
            })
        ));

        let mut limits = DeviceLimits::cpu_only();
        limits.resident_domain_max_exact_value_bytes = limits.resident_memory_budget_bytes + 1;
        assert!(matches!(
            limits.validate(),
            Err(DeviceLimitsValidationError::InvertedRange {
                lower_field: "resident_domain_max_exact_value_bytes",
                upper_field: "resident_memory_budget_bytes",
                ..
            })
        ));

        let mut limits = DeviceLimits::cpu_only();
        limits.optimal_batch_min = limits.optimal_batch_max + 1;
        assert!(matches!(
            limits.validate(),
            Err(DeviceLimitsValidationError::InvertedRange {
                lower_field: "optimal_batch_min",
                upper_field: "optimal_batch_max",
                ..
            })
        ));
    }

    #[test]
    fn validation_rejects_nonfinite_or_out_of_band_fractions() {
        let mut limits = DeviceLimits::cpu_only();
        limits.gpu_spatial_max_recheck_fraction = f64::NAN;
        assert!(matches!(
            limits.validate(),
            Err(DeviceLimitsValidationError::InvalidFraction {
                field: "gpu_spatial_max_recheck_fraction",
                value,
            }) if value.is_nan()
        ));

        let mut limits = DeviceLimits::cpu_only();
        limits.gpu_spatial_max_output_fraction = 1.01;
        assert_eq!(
            limits.validate(),
            Err(DeviceLimitsValidationError::InvalidFraction {
                field: "gpu_spatial_max_output_fraction",
                value: 1.01,
            })
        );

        let mut limits = DeviceLimits::cpu_only();
        limits.gpu_sort_heap_topk_max_fraction = -0.01;
        assert_eq!(
            limits.validate(),
            Err(DeviceLimitsValidationError::InvalidFraction {
                field: "gpu_sort_heap_topk_max_fraction",
                value: -0.01,
            })
        );
    }

    #[test]
    fn validation_accepts_inclusive_fraction_and_fp64_boundaries() {
        let mut limits = DeviceLimits::cpu_only();
        limits.gpu_sort_heap_topk_max_fraction = 0.0;
        limits.gpu_spatial_max_output_fraction = 1.0;
        limits.gpu_spatial_max_recheck_fraction = 0.0;
        limits.soft_fp64_cost_multiplier = 1.0;
        limits
            .validate()
            .expect("inclusive lower fraction/fp64 bounds must be valid");

        limits.soft_fp64_cost_multiplier = 64.0;
        limits
            .validate()
            .expect("inclusive upper fp64 bound must be valid");
    }

    #[test]
    fn validation_rejects_invalid_fp64_multiplier() {
        for value in [f64::NEG_INFINITY, 0.99, 64.01, f64::NAN] {
            let mut limits = DeviceLimits::cpu_only();
            limits.soft_fp64_cost_multiplier = value;
            assert!(matches!(
                limits.validate(),
                Err(DeviceLimitsValidationError::InvalidSoftFp64Multiplier {
                    value: rejected,
                }) if rejected.is_nan() == value.is_nan() && (rejected == value || value.is_nan())
            ));
        }
    }

    #[test]
    fn validation_rejects_nonpositive_or_nonfinite_costs() {
        let mut limits = DeviceLimits::cpu_only();
        limits.resident_load_scan_per_row_cost = 0.0;
        assert_eq!(
            limits.validate(),
            Err(DeviceLimitsValidationError::InvalidPositiveFloat {
                field: "resident_load_scan_per_row_cost",
                value: 0.0,
            })
        );

        let mut limits = DeviceLimits::cpu_only();
        limits.resident_load_per_byte_cost = f64::NAN;
        assert!(matches!(
            limits.validate(),
            Err(DeviceLimitsValidationError::InvalidPositiveFloat {
                field: "resident_load_per_byte_cost",
                value,
            }) if value.is_nan()
        ));

        let mut limits = DeviceLimits::cpu_only();
        limits.gpu_nlj_per_pair_cost = f64::INFINITY;
        assert_eq!(
            limits.validate(),
            Err(DeviceLimitsValidationError::InvalidPositiveFloat {
                field: "gpu_nlj_per_pair_cost",
                value: f64::INFINITY,
            })
        );

        let mut limits = DeviceLimits::cpu_only();
        limits.gpu_op_cost_h3_parent_resident = 0.0;
        assert_eq!(
            limits.validate(),
            Err(DeviceLimitsValidationError::InvalidPositiveFloat {
                field: "gpu_op_cost_h3_parent_resident",
                value: 0.0,
            })
        );

        let mut limits = DeviceLimits::cpu_only();
        limits.cpu_spatial_recheck_per_row = 0.0;
        assert_eq!(
            limits.validate(),
            Err(DeviceLimitsValidationError::InvalidPositiveFloat {
                field: "cpu_spatial_recheck_per_row",
                value: 0.0,
            })
        );
    }

    #[test]
    fn publication_validation_accepts_valid_limits_and_rejects_invalid_limits() {
        let valid = validate_device_limits_for_publication(DeviceLimits::cpu_only())
            .expect("valid CPU-only limits may be published");
        assert_eq!(valid.gpu_h3_max_chunk_rows, 1_000_000);

        let mut invalid = DeviceLimits::cpu_only();
        invalid.gpu_h3_max_chunk_rows = 0;
        assert!(matches!(
            validate_device_limits_for_publication(invalid),
            Err(DeviceLimitsValidationError::ZeroCount {
                field: "gpu_h3_max_chunk_rows",
            })
        ));
    }

    #[test]
    fn hosted_metal_calibration_is_exact_fail_closed_and_planner_only() {
        let mut hosted = profile(1, 2 * 1024 * 1024 * 1024);
        hosted.cpu_cores = 3;
        hosted.device_name = "Apple Paravirtual device".to_owned();
        hosted.backend_name = "metal".to_owned();

        assert!(
            hosted_metal_planner_profile(&hosted, None, true)
                .expect("absent compatibility mode should be valid")
                .is_none()
        );
        assert!(
            hosted_metal_planner_profile(&hosted, Some(OsStr::new("0")), true)
                .expect("disabled compatibility mode should be valid")
                .is_none()
        );

        let calibrated = hosted_metal_planner_profile(&hosted, Some(OsStr::new("1")), true)
            .expect("the exact hosted profile should calibrate")
            .expect("enabled compatibility mode should return a profile");
        assert_eq!(hosted.compute_units, 1, "the physical profile is immutable");
        assert_eq!(calibrated.compute_units, HOSTED_METAL_PLANNER_COMPUTE_UNITS);
        assert_eq!(calibrated.device_name, hosted.device_name);
        assert_eq!(calibrated.backend_name, hosted.backend_name);
        assert_eq!(calibrated.gpu_max_alloc_bytes, hosted.gpu_max_alloc_bytes);

        let limits = DeviceLimits::from_profile(&calibrated);
        assert_eq!(limits.gpu_hash_agg_min_rows, 250_000);
        assert_eq!(
            limits.gpu_grouped_agg_one_shot_max_rows,
            GPU_GROUPED_AGG_ONE_SHOT_ABSOLUTE_MAX_ROWS
        );
        let physical_limits = DeviceLimits::from_profile(&hosted);
        assert_eq!(physical_limits.gpu_grouped_agg_one_shot_max_rows, 64_000);
        assert!(
            physical_limits.gpu_grouped_agg_one_shot_max_rows
                < limits.gpu_grouped_agg_one_shot_max_rows,
            "planner calibration may not become the physical synchronous-work bound"
        );
    }

    #[test]
    fn hosted_metal_calibration_rejects_malformed_mode_and_profile_drift() {
        let mut hosted = profile(1, 2 * 1024 * 1024 * 1024);
        hosted.cpu_cores = 3;
        hosted.device_name = "Apple Paravirtual device".to_owned();
        hosted.backend_name = "metal".to_owned();

        assert!(matches!(
            hosted_metal_planner_profile(&hosted, Some(OsStr::new("yes")), true),
            Err(HostedMetalCompatibilityError::InvalidMode(value)) if value == "yes"
        ));
        assert_eq!(
            hosted_metal_planner_profile(&hosted, Some(OsStr::new("1")), false),
            Err(HostedMetalCompatibilityError::ProfileMismatch)
        );

        hosted.device_name = "Apple M2 Max".to_owned();
        assert_eq!(
            hosted_metal_planner_profile(&hosted, Some(OsStr::new("1")), true),
            Err(HostedMetalCompatibilityError::ProfileMismatch)
        );
    }
}

fn validate_device_limits_for_publication(
    limits: DeviceLimits,
) -> Result<DeviceLimits, DeviceLimitsValidationError> {
    limits.validate()?;
    Ok(limits)
}

/// Cached device limits, initialised on first access after GPU init.
static DEVICE_LIMITS: std::sync::OnceLock<DeviceLimits> = std::sync::OnceLock::new();

/// Physical executor limits cached alongside [`DEVICE_LIMITS`]. The public
/// limits may use the exact hosted virtual-M1 planner calibration, but a
/// synthetic compute-unit count must never enlarge synchronous kernel work on
/// the real device.
static EXECUTION_DEVICE_LIMITS: std::sync::OnceLock<DeviceLimits> = std::sync::OnceLock::new();

/// Source of the cached [`DeviceLimits`]. `HardwareDerived` is the normal GPU
/// profile, `HostedCompatibilityCalibrated` is the exact virtual-M1
/// compatibility/coverage profile, and `FallbackCpuOnly` is used when no GPU
/// was detected.
///
/// Diagnostic consumers (see `pg_accel_device_limits` SRF) use this to tell
/// users which set of values their session is actually seeing.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum DeviceLimitsSource {
    /// Derived from a detected [`PlatformProfile`] via
    /// [`DeviceLimits::from_profile`].
    HardwareDerived,
    /// Planner-only 32-CU reference calibration on the exact hosted virtual-M1
    /// profile. This source is explicitly ineligible for performance claims.
    HostedCompatibilityCalibrated,
    /// Hard-coded fallback from [`DeviceLimits::cpu_only`] — used when no GPU
    /// was detected at `device_limits()` init time.
    FallbackCpuOnly,
}

impl DeviceLimitsSource {
    /// Short tag suitable for a SQL column (stable, matches CLAUDE.md doc).
    #[must_use]
    pub const fn as_str(self) -> &'static str {
        match self {
            Self::HardwareDerived => "hardware_derived",
            Self::HostedCompatibilityCalibrated => "hosted_compatibility_calibrated",
            Self::FallbackCpuOnly => "fallback_cpu_only",
        }
    }
}

/// Cached source tag for [`device_limits`] — set once alongside
/// `DEVICE_LIMITS` so diagnostics can report which branch produced the
/// effective limits.
static DEVICE_LIMITS_SOURCE: std::sync::OnceLock<DeviceLimitsSource> = std::sync::OnceLock::new();

/// Get the cached device limits, initialising from the current platform
/// profile on first call.
///
/// In `#[cfg(test)]` builds, returns [`DeviceLimits::cpu_only()`] to avoid
/// calling into the GPU runtime (which requires a running PG backend).
#[must_use]
pub fn device_limits() -> &'static DeviceLimits {
    DEVICE_LIMITS.get_or_init(|| {
        #[cfg(test)]
        let (candidate, execution_candidate, source) = (
            DeviceLimits::cpu_only(),
            DeviceLimits::cpu_only(),
            DeviceLimitsSource::FallbackCpuOnly,
        );
        #[cfg(not(test))]
        let (candidate, execution_candidate, source) = {
            let profile = PlatformProfile::detect();
            let physical_limits = if profile.has_gpu {
                DeviceLimits::from_profile(&profile)
            } else {
                DeviceLimits::cpu_only()
            };
            let compatibility_profile = hosted_metal_planner_profile(
                &profile,
                std::env::var_os(HOSTED_METAL_COMPATIBILITY_ENV).as_deref(),
                cfg!(all(target_os = "macos", target_arch = "aarch64")),
            )
            .unwrap_or_else(|error| {
                panic!(
                    "refusing invalid hosted Metal planner calibration: {error}; detected profile: {profile:?}"
                )
            });
            if let Some(compatibility_profile) = compatibility_profile {
                (
                    DeviceLimits::from_profile(&compatibility_profile),
                    physical_limits,
                    DeviceLimitsSource::HostedCompatibilityCalibrated,
                )
            } else if profile.has_gpu {
                (
                    physical_limits.clone(),
                    physical_limits,
                    DeviceLimitsSource::HardwareDerived,
                )
            } else {
                (
                    DeviceLimits::cpu_only(),
                    physical_limits,
                    DeviceLimitsSource::FallbackCpuOnly,
                )
            }
        };
        let execution_limits = validate_device_limits_for_publication(execution_candidate)
            .unwrap_or_else(|error| panic!("refusing invalid physical executor limits: {error}"));
        let limits = validate_device_limits_for_publication(candidate)
            .unwrap_or_else(|error| panic!("refusing to publish invalid device limits: {error}"));
        let _ = EXECUTION_DEVICE_LIMITS.set(execution_limits);
        let _ = DEVICE_LIMITS_SOURCE.set(source);
        limits
    })
}

/// Get limits derived from the physical device for executor chunking and
/// synchronous-work bounds. This differs from [`device_limits`] only on the
/// exact hosted compatibility runner, where planner admission is calibrated
/// to a reference device while execution must remain bounded by the real
/// one-CU virtual GPU.
#[must_use]
pub(crate) fn execution_device_limits() -> &'static DeviceLimits {
    let _ = device_limits();
    EXECUTION_DEVICE_LIMITS
        .get()
        .expect("physical executor limits initialize with public device limits")
}

/// Returns the source of the cached device limits, forcing init if it hasn't
/// run yet. Used by the `pg_accel_device_limits` SRF so callers can tell
/// whether they're looking at hardware-derived values or the zero-profile
/// fallback constants.
#[must_use]
pub fn device_limits_source() -> DeviceLimitsSource {
    // Touch `device_limits()` to guarantee the OnceLock is populated; the
    // initialiser always sets the source.
    let _ = device_limits();
    DEVICE_LIMITS_SOURCE
        .get()
        .copied()
        .unwrap_or(DeviceLimitsSource::FallbackCpuOnly)
}

#[cfg(test)]
mod diagnostic_contract_tests {
    use super::*;

    #[test]
    fn validation_errors_render_stable_actionable_messages() {
        let cases = [
            (
                DeviceLimitsValidationError::ZeroCount {
                    field: "gpu_min_rows",
                },
                "device limit gpu_min_rows must be nonzero",
            ),
            (
                DeviceLimitsValidationError::InvertedRange {
                    lower_field: "minimum",
                    lower: 11,
                    upper_field: "maximum",
                    upper: 10,
                },
                "device limit range is inverted: minimum=11 exceeds maximum=10",
            ),
            (
                DeviceLimitsValidationError::InvalidFraction {
                    field: "fraction",
                    value: 1.5,
                },
                "device limit fraction must be finite and within [0, 1], got 1.5",
            ),
            (
                DeviceLimitsValidationError::InvalidPositiveFloat {
                    field: "cost",
                    value: 0.0,
                },
                "device limit cost must be finite and positive, got 0",
            ),
            (
                DeviceLimitsValidationError::InvalidSoftFp64Multiplier { value: 65.0 },
                "device limit soft_fp64_cost_multiplier must be finite and within [1, 64], got 65",
            ),
            (
                DeviceLimitsValidationError::HistoricalCrashBandExposed {
                    field: "unsafe_rows",
                    value: 100_001,
                    exclusive_upper_bound: 100_000,
                },
                "device limit unsafe_rows=100001 exposes the historical crash band at 100000 rows",
            ),
        ];

        for (error, expected) in cases {
            assert_eq!(error.to_string(), expected);
        }
    }

    #[test]
    fn hosted_compatibility_errors_render_the_control_and_required_profile() {
        assert_eq!(
            HostedMetalCompatibilityError::InvalidMode("yes".to_owned()).to_string(),
            "PGACCEL_HOSTED_METAL_COMPATIBILITY must be 0 or 1, got \"yes\""
        );
        assert_eq!(
            HostedMetalCompatibilityError::ProfileMismatch.to_string(),
            "PGACCEL_HOSTED_METAL_COMPATIBILITY=1 requires the exact hosted virtual-M1 Metal profile"
        );
    }

    #[test]
    fn device_limit_source_labels_are_complete_and_stable() {
        let cases = [
            (DeviceLimitsSource::HardwareDerived, "hardware_derived"),
            (
                DeviceLimitsSource::HostedCompatibilityCalibrated,
                "hosted_compatibility_calibrated",
            ),
            (DeviceLimitsSource::FallbackCpuOnly, "fallback_cpu_only"),
        ];

        for (source, expected) in cases {
            assert_eq!(source.as_str(), expected);
        }
    }

    #[cfg(unix)]
    #[test]
    fn non_utf8_hosted_compatibility_mode_is_rejected_lossily_but_safely() {
        use std::os::unix::ffi::OsStrExt;

        let profile = PlatformProfile {
            cpu_cores: 3,
            has_gpu: true,
            estimated_gpu_gflops: 2.0,
            compute_units: 1,
            device_name: "Apple Paravirtual device".to_owned(),
            backend_name: "metal".to_owned(),
            gpu_max_alloc_bytes: 1024,
            has_native_fp64: false,
        };
        let mode = OsStr::from_bytes(b"\xff");

        assert!(matches!(
            hosted_metal_planner_profile(&profile, Some(mode), true),
            Err(HostedMetalCompatibilityError::InvalidMode(value)) if value == "\u{fffd}"
        ));
    }
}
