//! Tests for `ffi/planner_hooks`.

#![allow(clippy::unwrap_used, dead_code)]

use super::*;

// =====================================================================
// Existing tests (preserved)
// =====================================================================

#[test]
fn has_accelerable_restriction_null_list_returns_false() {
    assert!(!has_accelerable_restriction(std::ptr::null_mut()));
}

#[test]
fn node_has_accel_func_null_node_returns_false() {
    let reg = registry::AdapterRegistry::new();
    assert!(!node_has_accel_func(std::ptr::null_mut(), &reg));
}

#[test]
fn path_node_size_for_known_tags() {
    let known_sizes = [
        (
            NodeTag::T_IndexPath,
            std::mem::size_of::<pg_sys::IndexPath>(),
        ),
        (
            NodeTag::T_BitmapHeapPath,
            std::mem::size_of::<pg_sys::BitmapHeapPath>(),
        ),
        (
            NodeTag::T_CustomPath,
            std::mem::size_of::<pg_sys::CustomPath>(),
        ),
        (NodeTag::T_NestPath, std::mem::size_of::<pg_sys::NestPath>()),
        (
            NodeTag::T_MergePath,
            std::mem::size_of::<pg_sys::MergePath>(),
        ),
        (NodeTag::T_HashPath, std::mem::size_of::<pg_sys::HashPath>()),
        (
            NodeTag::T_AppendPath,
            std::mem::size_of::<pg_sys::AppendPath>(),
        ),
        (NodeTag::T_SortPath, std::mem::size_of::<pg_sys::SortPath>()),
        (NodeTag::T_AggPath, std::mem::size_of::<pg_sys::AggPath>()),
        (
            NodeTag::T_LimitPath,
            std::mem::size_of::<pg_sys::LimitPath>(),
        ),
    ];

    for (tag, expected_size) in known_sizes {
        assert!(expected_size > 0, "size for {tag:?} should be > 0");
    }
}

#[test]
fn path_node_size_unknown_tag_falls_back_to_base_path() {
    let base_size = std::mem::size_of::<pg_sys::Path>();
    assert!(base_size > 0);
}

#[test]
fn path_node_size_all_match_arms_return_positive() {
    let sizes = [
        std::mem::size_of::<pg_sys::IndexPath>(),
        std::mem::size_of::<pg_sys::BitmapHeapPath>(),
        std::mem::size_of::<pg_sys::BitmapAndPath>(),
        std::mem::size_of::<pg_sys::BitmapOrPath>(),
        std::mem::size_of::<pg_sys::TidPath>(),
        std::mem::size_of::<pg_sys::SubqueryScanPath>(),
        std::mem::size_of::<pg_sys::ForeignPath>(),
        std::mem::size_of::<pg_sys::CustomPath>(),
        std::mem::size_of::<pg_sys::NestPath>(),
        std::mem::size_of::<pg_sys::MergePath>(),
        std::mem::size_of::<pg_sys::HashPath>(),
        std::mem::size_of::<pg_sys::AppendPath>(),
        std::mem::size_of::<pg_sys::MergeAppendPath>(),
        std::mem::size_of::<pg_sys::GroupResultPath>(),
        std::mem::size_of::<pg_sys::MaterialPath>(),
        std::mem::size_of::<pg_sys::MemoizePath>(),
        std::mem::size_of::<pg_sys::UniquePath>(),
        std::mem::size_of::<pg_sys::GatherPath>(),
        std::mem::size_of::<pg_sys::GatherMergePath>(),
        std::mem::size_of::<pg_sys::ProjectionPath>(),
        std::mem::size_of::<pg_sys::ProjectSetPath>(),
        std::mem::size_of::<pg_sys::SortPath>(),
        std::mem::size_of::<pg_sys::GroupPath>(),
        #[cfg(feature = "pg18")]
        std::mem::size_of::<pg_sys::UpperUniquePath>(),
        std::mem::size_of::<pg_sys::AggPath>(),
        std::mem::size_of::<pg_sys::GroupingSetsPath>(),
        std::mem::size_of::<pg_sys::WindowAggPath>(),
        std::mem::size_of::<pg_sys::SetOpPath>(),
        std::mem::size_of::<pg_sys::RecursiveUnionPath>(),
        std::mem::size_of::<pg_sys::LockRowsPath>(),
        std::mem::size_of::<pg_sys::ModifyTablePath>(),
        std::mem::size_of::<pg_sys::LimitPath>(),
        std::mem::size_of::<pg_sys::Path>(), // fallback
    ];

    for (i, &size) in sizes.iter().enumerate() {
        assert!(size > 0, "path type index {i} has zero size");
    }
}

#[test]
fn all_path_subtypes_at_least_as_large_as_base_path() {
    let base = std::mem::size_of::<pg_sys::Path>();
    let subtypes = [
        std::mem::size_of::<pg_sys::IndexPath>(),
        std::mem::size_of::<pg_sys::BitmapHeapPath>(),
        std::mem::size_of::<pg_sys::CustomPath>(),
        std::mem::size_of::<pg_sys::NestPath>(),
        std::mem::size_of::<pg_sys::MergePath>(),
        std::mem::size_of::<pg_sys::HashPath>(),
        std::mem::size_of::<pg_sys::SortPath>(),
        std::mem::size_of::<pg_sys::AggPath>(),
        std::mem::size_of::<pg_sys::LimitPath>(),
    ];

    for (i, &size) in subtypes.iter().enumerate() {
        assert!(
            size >= base,
            "subtype index {i} (size {size}) smaller than base Path (size {base})"
        );
    }
}

// =====================================================================
// AccelStrategy round-trip via from_i32
// =====================================================================

#[test]
fn accel_strategy_from_i32_all_variants() {
    assert_eq!(
        registry::AccelStrategy::from_i32(1),
        Some(registry::AccelStrategy::GpuSpatial)
    );
    assert_eq!(
        registry::AccelStrategy::from_i32(2),
        Some(registry::AccelStrategy::GpuRaster)
    );
    assert_eq!(
        registry::AccelStrategy::from_i32(3),
        Some(registry::AccelStrategy::GpuH3)
    );
    assert_eq!(
        registry::AccelStrategy::from_i32(4),
        Some(registry::AccelStrategy::GpuSort)
    );
    assert_eq!(
        registry::AccelStrategy::from_i32(5),
        Some(registry::AccelStrategy::GpuReduce)
    );
    assert_eq!(
        registry::AccelStrategy::from_i32(6),
        Some(registry::AccelStrategy::GpuExpr)
    );
    assert_eq!(
        registry::AccelStrategy::from_i32(7),
        Some(registry::AccelStrategy::GpuHashJoin)
    );
    assert_eq!(
        registry::AccelStrategy::from_i32(8),
        Some(registry::AccelStrategy::GpuWindow)
    );
}

#[test]
fn accel_strategy_from_i32_unknown_is_invalid() {
    assert_eq!(registry::AccelStrategy::from_i32(-1), None);
    assert_eq!(registry::AccelStrategy::from_i32(0), None);
    assert_eq!(registry::AccelStrategy::from_i32(99), None);
    assert_eq!(registry::AccelStrategy::from_i32(i32::MAX), None);
}

#[test]
fn accel_strategy_repr_i32_roundtrip() {
    // The enum is #[repr(i32)], so casting to i32 and back should work.
    let strategies = [
        registry::AccelStrategy::GpuSpatial,
        registry::AccelStrategy::GpuRaster,
        registry::AccelStrategy::GpuH3,
        registry::AccelStrategy::GpuSort,
        registry::AccelStrategy::GpuReduce,
        registry::AccelStrategy::GpuExpr,
        registry::AccelStrategy::GpuHashJoin,
        registry::AccelStrategy::GpuWindow,
    ];
    for s in strategies {
        let i = s as i32;
        assert_eq!(registry::AccelStrategy::from_i32(i), Some(s));
    }
}

// =====================================================================
// WindowFunc round-trip
// =====================================================================

#[test]
fn window_func_to_i32_roundtrip() {
    let funcs = [
        WindowFunc::RowNumber,
        WindowFunc::Rank,
        WindowFunc::DenseRank,
        WindowFunc::Sum,
        WindowFunc::Count,
        WindowFunc::Lag,
        WindowFunc::Lead,
    ];
    for f in funcs {
        assert_eq!(WindowFunc::from_i32(f.to_i32()), Some(f));
    }
}

#[test]
fn window_func_from_i32_unknown_returns_none() {
    assert_eq!(WindowFunc::from_i32(7), None);
    assert_eq!(WindowFunc::from_i32(-1), None);
    assert_eq!(WindowFunc::from_i32(100), None);
}

// =====================================================================
// WindowFuncSpec construction
// =====================================================================

#[test]
fn window_func_spec_construction() {
    let spec = WindowFuncSpec {
        func: WindowFunc::Sum,
        partition_attno: 2,
        order_attno: 3,
        value_attno: 4,
        offset: 1,
        default_val: 0.0,
        result_type_oid: 701, // float8
        uses_fp64: true,
    };
    assert_eq!(spec.func, WindowFunc::Sum);
    assert_eq!(spec.partition_attno, 2);
    assert_eq!(spec.order_attno, 3);
    assert_eq!(spec.value_attno, 4);
    assert_eq!(spec.offset, 1);
    assert!((spec.default_val - 0.0).abs() < f64::EPSILON);
    assert_eq!(spec.result_type_oid, 701);
    assert!(spec.uses_fp64);
}

#[test]
fn window_func_spec_lag_with_offset_and_default() {
    let spec = WindowFuncSpec {
        func: WindowFunc::Lag,
        partition_attno: 0,
        order_attno: 1,
        value_attno: 2,
        offset: 3,
        default_val: -999.0,
        result_type_oid: 701,
        uses_fp64: true,
    };
    assert_eq!(spec.func, WindowFunc::Lag);
    assert_eq!(spec.offset, 3);
    assert!((spec.default_val - (-999.0)).abs() < f64::EPSILON);
}

#[test]
fn window_func_spec_no_partition() {
    let spec = WindowFuncSpec {
        func: WindowFunc::RowNumber,
        partition_attno: 0,
        order_attno: 0,
        value_attno: 0,
        offset: 1,
        default_val: 0.0,
        result_type_oid: 23,
        uses_fp64: false,
    };
    assert_eq!(spec.partition_attno, 0);
    assert_eq!(spec.order_attno, 0);
    assert!(!spec.uses_fp64);
}

// =====================================================================
// SortKeyDesc construction
// =====================================================================

#[test]
fn sort_key_desc_construction() {
    let sk = SortKeyDesc {
        attno: 5,
        sort_op: pg_sys::Oid::from(97u32), // int4lt
        collation: pg_sys::Oid::from(0u32),
        nulls_first: false,
    };
    assert_eq!(sk.attno, 5);
    assert!(!sk.nulls_first);
}

#[test]
fn sort_key_desc_nulls_first() {
    let sk = SortKeyDesc {
        attno: 1,
        sort_op: pg_sys::Oid::from(622u32), // float8lt
        collation: pg_sys::Oid::from(0u32),
        nulls_first: true,
    };
    assert!(sk.nulls_first);
}

#[test]
fn setop_decline_reason_codes_are_stable() {
    assert_eq!(SETOP_NO_GPU_KERNEL_REASON, "setop_no_gpu_kernel");
    assert_eq!(
        RECURSIVEUNION_NO_GPU_KERNEL_REASON,
        "recursiveunion_no_gpu_kernel"
    );
    assert_eq!(
        setop_reason_for_recursive_union(false),
        "setop_no_gpu_kernel"
    );
    assert_eq!(
        setop_reason_for_recursive_union(true),
        "recursiveunion_no_gpu_kernel"
    );
}

// =====================================================================
// Cost model: should_batch with strategy-specific per-row costs
// =====================================================================

#[test]
fn should_batch_gpu_spatial_sufficient_rows() {
    // GPU spatial: per_row_cost = 0.05 (well above 0.01 threshold)
    assert!(cost::should_batch(
        1000,
        cost::GPU_SPATIAL_PER_ROW_COST,
        256
    ));
}

#[test]
fn should_batch_gpu_h3_sufficient_rows() {
    assert!(cost::should_batch(500, cost::GPU_H3_PER_ROW_COST, 256));
}

#[test]
fn should_batch_gpu_raster_sufficient_rows() {
    assert!(cost::should_batch(1000, cost::GPU_RASTER_PER_ROW_COST, 256));
}

#[test]
fn should_batch_gpu_reduce_sufficient_rows() {
    assert!(cost::should_batch(500, cost::GPU_REDUCE_PER_ROW_COST, 256));
}

// =====================================================================
// Cost model: optimal_batch_size clamping
// =====================================================================

#[test]
fn optimal_batch_size_small_input_clamps_to_min() {
    let limits = cost::device_limits();
    let result = cost::optimal_batch_size(1);
    assert_eq!(result, limits.optimal_batch_min);
}

#[test]
fn optimal_batch_size_large_input_clamps_to_max() {
    let limits = cost::device_limits();
    let result = cost::optimal_batch_size(usize::MAX);
    assert_eq!(result, limits.optimal_batch_max);
}

#[test]
fn optimal_batch_size_mid_range_returns_input() {
    let limits = cost::device_limits();
    let mid = usize::midpoint(limits.optimal_batch_min, limits.optimal_batch_max);
    assert_eq!(cost::optimal_batch_size(mid), mid);
}

// =====================================================================
// Cost constant sanity checks
// =====================================================================

#[test]
fn gpu_launch_overhead_is_positive() {
    const { assert!(cost::GPU_LAUNCH_OVERHEAD > 0.0) };
}

#[test]
fn gpu_cost_safety_margin_between_zero_and_one() {
    const { assert!(cost::GPU_COST_SAFETY_MARGIN > 0.0) };
    const { assert!(cost::GPU_COST_SAFETY_MARGIN < 1.0) };
}

#[test]
fn spatial_index_selectivity_threshold_between_zero_and_one() {
    const { assert!(cost::SPATIAL_INDEX_SELECTIVITY_THRESHOLD > 0.0) };
    const { assert!(cost::SPATIAL_INDEX_SELECTIVITY_THRESHOLD < 1.0) };
}

#[test]
fn spatial_index_cost_ratio_threshold_between_zero_and_one() {
    const { assert!(cost::SPATIAL_INDEX_COST_RATIO_THRESHOLD > 0.0) };
    const { assert!(cost::SPATIAL_INDEX_COST_RATIO_THRESHOLD < 1.0) };
}

#[test]
fn gpu_spatial_per_row_cost_is_positive() {
    const { assert!(cost::GPU_SPATIAL_PER_ROW_COST > 0.0) };
}

#[test]
fn gpu_raster_per_row_cost_is_positive() {
    const { assert!(cost::GPU_RASTER_PER_ROW_COST > 0.0) };
}

#[test]
fn gpu_h3_per_row_cost_is_positive() {
    const { assert!(cost::GPU_H3_PER_ROW_COST > 0.0) };
}

#[test]
fn gpu_reduce_per_row_cost_is_positive() {
    const { assert!(cost::GPU_REDUCE_PER_ROW_COST > 0.0) };
}

#[test]
fn per_datum_extract_cost_is_positive() {
    const { assert!(cost::PER_DATUM_EXTRACT_COST > 0.0) };
}

// =====================================================================
// Cost calculation: scan hook cost formula
// =====================================================================

/// Replicate the scan hook's cost formula to verify it produces
/// sane results with known inputs.
///
/// Formula (matches `pgaccel_set_rel_pathlist`):
///   cost_margin = 0.7 for GPU strategies, 1.0 for GpuExpr
///   yield_cost  = rows * 0.005 for GpuExpr, 0.0 for GPU strategies
///   raw_total   = (base_total * cost_margin + batch_overhead
///                  + gpu_overhead + yield_cost) * cost_multiplier
#[test]
fn scan_cost_formula_gpu_spatial_cheaper_than_base() {
    // Simulate: GpuSpatial, high base_total (expensive spatial function).
    // The 30% cost_margin discount should make GPU cheaper.
    let base_rows = 100_000.0_f64;
    let base_total = 5000.0; // expensive spatial predicate
    let cost_multiplier = 1.0;

    let batch_size = cost::optimal_batch_size(base_rows as usize) as f64;
    let num_batches = (base_rows / batch_size).ceil();
    let batch_overhead = num_batches * 2.0;
    let gpu_overhead = cost::GPU_LAUNCH_OVERHEAD;
    let cost_margin = cost::GPU_COST_SAFETY_MARGIN; // 0.7
    let yield_cost = 0.0; // GPU strategies: no yield cost

    let total_cost =
        (base_total * cost_margin + batch_overhead + gpu_overhead + yield_cost) * cost_multiplier;

    // 5000 * 0.7 + ~26 + 5 = 3531 < 5000: GPU wins for expensive functions.
    assert!(
        total_cost < base_total,
        "GPU spatial path ({total_cost:.2}) should be cheaper than \
         base ({base_total:.2}) for expensive spatial predicate"
    );
}

#[test]
fn spatial_output_fraction_rejects_high_output_heap_scans() {
    let limits = cost::DeviceLimits::cpu_only();

    assert!(cost::spatial_output_fraction_allowed(
        79_999.0, 100_000.0, &limits
    ));
    assert!(cost::spatial_output_fraction_allowed(
        80_000.0, 100_000.0, &limits
    ));
    assert!(!cost::spatial_output_fraction_allowed(
        80_001.0, 100_000.0, &limits
    ));
    assert_eq!(cost::spatial_output_fraction(90_000.0, 100_000.0), 0.9);
}

#[test]
fn scan_cost_formula_gpu_expr_not_cheaper_at_100k() {
    // Simulate: GpuExpr at 100K rows, modest base_total.
    // No cost discount (1.0) + yield cost makes GPU more expensive.
    let base_rows = 100_000.0_f64;
    let base_total = 500.0; // simple WHERE clause scan

    let batch_size = cost::optimal_batch_size(base_rows as usize) as f64;
    let num_batches = (base_rows / batch_size).ceil();
    let batch_overhead = num_batches * 2.0;
    let gpu_overhead = 0.0; // GpuExpr: no GPU launch
    let cost_margin = 1.0; // GpuExpr: no discount
    let yield_cost = base_rows * 0.005; // GpuExpr yield

    let total_cost = (base_total * cost_margin + batch_overhead + gpu_overhead + yield_cost) * 1.0;

    // 500 * 1.0 + ~26 + 0 + 500 = 1026 > 500: GPU loses.
    assert!(
        total_cost > base_total,
        "GpuExpr path ({total_cost:.2}) should be more expensive than \
         base ({base_total:.2}) at 100K rows with modest base cost"
    );
}

// =====================================================================
// Cost calculation: safety margin gate
// =====================================================================

#[test]
fn safety_margin_gate_rejects_marginal_improvement() {
    let base_cost = 100.0;
    // If total_cost is 75% of base, it exceeds the 0.7 margin.
    let total_cost = base_cost * 0.75;
    assert!(total_cost > base_cost * cost::GPU_COST_SAFETY_MARGIN);
}

#[test]
fn safety_margin_gate_accepts_clear_improvement() {
    let base_cost = 100.0;
    // If total_cost is 50% of base, it's well under the 0.7 margin.
    let total_cost = base_cost * 0.50;
    assert!(total_cost <= base_cost * cost::GPU_COST_SAFETY_MARGIN);
}

#[test]
fn safety_margin_gate_boundary_exactly_at_margin() {
    let base_cost = 100.0;
    let total_cost = base_cost * cost::GPU_COST_SAFETY_MARGIN;
    // Exactly at margin should NOT pass the `>` check (it's not strictly greater).
    assert!(total_cost <= base_cost * cost::GPU_COST_SAFETY_MARGIN);
}

// =====================================================================
// Per-row cost selection by strategy
// =====================================================================

#[test]
fn per_row_cost_selection_gpu_spatial() {
    let strategy = registry::AccelStrategy::GpuSpatial;
    let per_row = match strategy {
        registry::AccelStrategy::GpuSpatial => cost::GPU_SPATIAL_PER_ROW_COST,
        registry::AccelStrategy::GpuRaster => cost::GPU_RASTER_PER_ROW_COST,
        registry::AccelStrategy::GpuH3 => cost::GPU_H3_PER_ROW_COST,
        _ => cost::GPU_SPATIAL_PER_ROW_COST,
    };
    assert!((per_row - cost::GPU_SPATIAL_PER_ROW_COST).abs() < f64::EPSILON);
}

#[test]
fn per_row_cost_selection_gpu_raster() {
    let strategy = registry::AccelStrategy::GpuRaster;
    let per_row = match strategy {
        registry::AccelStrategy::GpuSpatial => cost::GPU_SPATIAL_PER_ROW_COST,
        registry::AccelStrategy::GpuRaster => cost::GPU_RASTER_PER_ROW_COST,
        registry::AccelStrategy::GpuH3 => cost::GPU_H3_PER_ROW_COST,
        _ => cost::GPU_SPATIAL_PER_ROW_COST,
    };
    assert!((per_row - cost::GPU_RASTER_PER_ROW_COST).abs() < f64::EPSILON);
}

#[test]
fn per_row_cost_selection_gpu_hash_join_falls_to_default() {
    let strategy = registry::AccelStrategy::GpuHashJoin;
    let per_row = match strategy {
        registry::AccelStrategy::GpuSpatial => cost::GPU_SPATIAL_PER_ROW_COST,
        registry::AccelStrategy::GpuRaster => cost::GPU_RASTER_PER_ROW_COST,
        registry::AccelStrategy::GpuH3 => cost::GPU_H3_PER_ROW_COST,
        _ => cost::GPU_SPATIAL_PER_ROW_COST,
    };
    assert!((per_row - cost::GPU_SPATIAL_PER_ROW_COST).abs() < f64::EPSILON);
}

// =====================================================================
// GPU overhead selection by strategy
// =====================================================================

#[test]
fn gpu_overhead_spatial_uses_launch_overhead() {
    let strategies = [
        registry::AccelStrategy::GpuSpatial,
        registry::AccelStrategy::GpuRaster,
        registry::AccelStrategy::GpuH3,
    ];
    for s in strategies {
        let overhead = match s {
            registry::AccelStrategy::GpuSpatial
            | registry::AccelStrategy::GpuRaster
            | registry::AccelStrategy::GpuH3 => cost::GPU_LAUNCH_OVERHEAD,
            _ => 0.0,
        };
        assert!(
            (overhead - cost::GPU_LAUNCH_OVERHEAD).abs() < f64::EPSILON,
            "strategy {s:?} should use GPU_LAUNCH_OVERHEAD"
        );
    }
}

#[test]
fn gpu_overhead_for_gpu_strategies_is_positive() {
    let overhead = match registry::AccelStrategy::GpuSpatial {
        registry::AccelStrategy::GpuSpatial
        | registry::AccelStrategy::GpuRaster
        | registry::AccelStrategy::GpuH3 => cost::GPU_LAUNCH_OVERHEAD,
        _ => 0.0,
    };
    assert!(overhead > 0.0);
}

// =====================================================================
// DeviceLimits::cpu_only thresholds
// =====================================================================

#[test]
fn device_limits_cpu_only_thresholds_are_sane() {
    let limits = cost::DeviceLimits::cpu_only();
    assert_eq!(limits.gpu_min_rows, 10_000);
    assert_eq!(limits.gpu_sort_min_rows, 100_000);
    assert_eq!(limits.gpu_sort_planner_min_rows, 100_000);
    assert_eq!(limits.gpu_window_min_rows, 100_000);
    assert_eq!(limits.gpu_reduce_min_rows, 25_000);
    assert_eq!(limits.gpu_hash_agg_min_rows, 250_000);
    assert_eq!(limits.gpu_hash_agg_unsafe_input_rows, 100_000);
    assert_eq!(limits.gpu_hash_agg_max_groups, 10_000);
    assert_eq!(limits.optimal_batch_min, 256);
    assert_eq!(limits.optimal_batch_max, 8192);
}

#[test]
fn device_limits_cpu_only_batch_min_lte_max() {
    let limits = cost::DeviceLimits::cpu_only();
    assert!(limits.optimal_batch_min <= limits.optimal_batch_max);
}

// =====================================================================
// Equi-join key type mapping (replicate the match from find_equi_join_key)
// =====================================================================

#[test]
fn equi_join_key_type_mapping_int2_is_unsupported_for_hashjoin() {
    let key_type = match 21u32 {
        23 => Some(0),        // Int32
        20 => Some(1),        // Int64
        700 | 701 => Some(2), // Float64
        _ => None,
    };
    assert_eq!(key_type, None);
}

#[test]
fn equi_join_key_type_mapping_int4_to_int32() {
    let key_type = match 23u32 {
        23 => Some(0),
        20 => Some(1),
        700 | 701 => Some(2),
        _ => None,
    };
    assert_eq!(key_type, Some(0));
}

#[test]
fn equi_join_key_type_mapping_int8_to_int64() {
    let key_type = match 20u32 {
        23 => Some(0),
        20 => Some(1),
        700 | 701 => Some(2),
        _ => None,
    };
    assert_eq!(key_type, Some(1));
}

#[test]
fn equi_join_key_type_mapping_float4_to_float64() {
    let key_type = match 700u32 {
        23 => Some(0),
        20 => Some(1),
        700 | 701 => Some(2),
        _ => None,
    };
    assert_eq!(key_type, Some(2));
}

#[test]
fn equi_join_key_type_mapping_float8_to_float64() {
    let key_type = match 701u32 {
        23 => Some(0),
        20 => Some(1),
        700 | 701 => Some(2),
        _ => None,
    };
    assert_eq!(key_type, Some(2));
}

#[test]
fn equi_join_key_type_mapping_text_unsupported() {
    let key_type = match 25u32 {
        23 => Some(0),
        20 => Some(1),
        700 | 701 => Some(2),
        _ => None,
    };
    assert_eq!(key_type, None);
}

// =====================================================================
// All strategies are GPU strategies (no CPU-only paths)
// =====================================================================

#[test]
fn all_strategies_are_gpu() {
    let gpu_strategies = [
        registry::AccelStrategy::GpuSpatial,
        registry::AccelStrategy::GpuRaster,
        registry::AccelStrategy::GpuH3,
        registry::AccelStrategy::GpuSort,
    ];
    for s in gpu_strategies {
        assert!(s as i32 >= 1, "strategy {s:?} should be a GPU strategy");
    }
}

// =====================================================================
// Cost calculation: sort cost formula
// =====================================================================

#[test]
fn sort_cost_formula_produces_positive_total() {
    let base_rows = 500_000.0_f64;
    let base_startup = 10.0;
    let base_total = 200.0;
    let cost_multiplier = 1.0;

    let gpu_overhead = cost::GPU_LAUNCH_OVERHEAD;
    let per_row = cost::GPU_SORT_PER_ROW_COST + cost::PER_DATUM_EXTRACT_COST + 0.03;
    let sort_cost = base_rows * per_row;
    let startup_cost = base_startup + gpu_overhead;
    let total_cost = (base_total + gpu_overhead + sort_cost) * cost_multiplier;

    assert!(total_cost > 0.0);
    assert!(startup_cost > base_startup);
    // Sort cost should dominate for large row counts.
    assert!(sort_cost > gpu_overhead);
}

// =====================================================================
// Cost calculation: join cost formula
// =====================================================================

#[test]
fn join_cost_hash_build_overhead_scales_with_inner_rows() {
    let inner_rows_small = 1000.0_f64;
    let inner_rows_large = 100_000.0_f64;

    let overhead_small = inner_rows_small * 0.001;
    let overhead_large = inner_rows_large * 0.001;

    assert!(overhead_large > overhead_small);
    assert!((overhead_small - 1.0).abs() < f64::EPSILON);
    assert!((overhead_large - 100.0).abs() < f64::EPSILON);
}

// =====================================================================
// Cost calculation: agg cost formula
// =====================================================================

#[test]
fn agg_cost_grouped_adds_hash_overhead() {
    let base_rows = 50_000.0_f64;
    let reduce_per_row = cost::GPU_REDUCE_PER_ROW_COST + 0.02;

    let hash_overhead_plain = 0.0;
    let hash_overhead_grouped = 0.005;

    let cost_plain = base_rows * (reduce_per_row + hash_overhead_plain);
    let cost_grouped = base_rows * (reduce_per_row + hash_overhead_grouped);

    assert!(cost_grouped > cost_plain);
    // The difference should be exactly base_rows * 0.005.
    let expected_diff = base_rows * 0.005;
    assert!((cost_grouped - cost_plain - expected_diff).abs() < 1e-6);
}

#[test]
fn grouped_hashagg_crash_gate_rejects_100k_plus_rows() {
    let limits = cost::DeviceLimits::cpu_only();

    assert!(
        cost::hashagg_input_rows_safe(99_999, &limits),
        "grouped hashagg should stay eligible below the unsafe threshold"
    );
    assert!(
        !cost::hashagg_input_rows_safe(100_000, &limits),
        "grouped hashagg must reject the first known unsafe row count"
    );
    assert!(
        !cost::hashagg_input_rows_safe(250_000, &limits),
        "grouped hashagg must remain rejected at and above planner min rows"
    );
}

#[test]
fn grouped_hashagg_gate_only_applies_to_grouped_agg() {
    let limits = cost::DeviceLimits::cpu_only();
    let rows = 100_000;
    let rejects =
        |has_group_keys: bool| has_group_keys && !cost::hashagg_input_rows_safe(rows, &limits);

    assert!(!cost::hashagg_input_rows_safe(rows, &limits));
    assert!(rejects(true));
    assert!(
        !rejects(false),
        "plain reductions should not inherit the grouped hashagg crash gate"
    );
}

// =====================================================================
// Empty registry fast-reject
// =====================================================================

#[test]
fn empty_registry_is_empty() {
    let reg = registry::AdapterRegistry::new();
    assert!(reg.is_empty());
}

/// Gate: the window cost site must route through the fp64-aware helper —
/// verify that the helper applies the soft-fp64 multiplier on soft devices
/// and is a no-op on native devices. Mirrors the
/// `self_scan_cost_fp64_aware` call in `mod.rs` (window injection site).
#[test]
fn window_cost_helper_applies_multiplier_on_soft_fp64_device() {
    use crate::engine::cost::{DeviceLimits, apply_fp64_penalty, self_scan_cost};

    let mut l_soft = DeviceLimits::cpu_only();
    l_soft.has_native_fp64 = false;
    l_soft.soft_fp64_cost_multiplier = 32.0;
    let mut l_native = DeviceLimits::cpu_only();
    l_native.has_native_fp64 = true;
    l_native.soft_fp64_cost_multiplier = 32.0;

    // Exact shape the planner uses: 1M rows, 3 extract cols (part/ord/val),
    // window per-row op cost × num_specs.
    let rows = 1_000_000.0_f64;
    let num_extract_cols = 3usize;
    let per_row_op = 0.001_f64;

    let soft = self_scan_cost(
        rows,
        num_extract_cols,
        apply_fp64_penalty(per_row_op, true, &l_soft),
    );
    let native = self_scan_cost(
        rows,
        num_extract_cols,
        apply_fp64_penalty(per_row_op, true, &l_native),
    );
    let unpenalised = self_scan_cost(
        rows,
        num_extract_cols,
        apply_fp64_penalty(per_row_op, false, &l_soft),
    );

    // Soft-fp64 path must be strictly costlier than native by at least the
    // GPU-op-delta (which is rows * per_row_op * (32-1) = 31_000 on these
    // inputs). Not strict equality because scan+extract cancel on the diff.
    let delta = soft - native;
    assert!(
        delta > 1_000.0,
        "soft-fp64 multiplier did not raise cost: soft={soft} native={native}"
    );

    // And the uses_fp64=false branch must match native (no penalty when
    // the spec does not touch fp64).
    assert!(
        (unpenalised - native).abs() < 1e-9,
        "penalty leaked onto non-fp64 path: unpenalised={unpenalised} native={native}"
    );
}

// =====================================================================
// IncrementalSort detect-and-decline smoke
// =====================================================================
//
// Multi-key ORDER BY with a presorted prefix is the classic IncrementalSort
// shape. The retired standalone sort surface is not a release deferral:
// pg_accel observes the shape, records a stable rejection, and leaves it
// PostgreSQL-native on every backend.
//
// These pg_tests exist to ensure:
// 1. The decline path does NOT crash the planner on a real multi-key
//    ORDER BY query (the main risk, since we added a new FFI call to
//    `pathkeys_count_contained_in` from the rel_pathlist hook).
// 2. A single-key ORDER BY query also stays native, returns correct rows,
//    and performs no GPU dispatch.
mod incremental_sort_detect {
    #[pgrx::pg_schema]
    mod tests {
        use pgrx::prelude::{Spi, pg_test};

        /// Smoke: a 2-key ORDER BY query runs without the planner crashing
        /// and records an explicit planner decline. The classifier and FFI
        /// call in the resident-only observer must be robust to multiple
        /// pathkeys.
        #[pg_test]
        fn multi_key_order_by_records_planner_decline() {
            Spi::run("DROP TABLE IF EXISTS pgaccel_incsort_smoke").expect("drop prior");
            Spi::run(
                "CREATE TABLE pgaccel_incsort_smoke (a int4, b int4) WITH (autovacuum_enabled=off)",
            )
            .expect("create");
            Spi::run(
                "INSERT INTO pgaccel_incsort_smoke \
             SELECT g % 10, g FROM generate_series(1, 2000) g",
            )
            .expect("seed");
            Spi::run("CREATE INDEX ON pgaccel_incsort_smoke (a)")
                .expect("create presorted-prefix index");
            Spi::run("ANALYZE pgaccel_incsort_smoke").expect("analyze");
            Spi::run("SET pg_accel.enabled = on").expect("enable pg_accel");

            // The first-key index gives the observer a native path with an
            // exact one-key prefix of the two-key ORDER BY. This exercises
            // pathkeys_count_contained_in deterministically without asserting
            // that PostgreSQL must choose IncrementalSort as its final plan.
            Spi::run("SELECT pg_accel_reset_stats()").expect("reset stats");
            let before = crate::engine::stats::read_planner_rejected();
            let row_count = Spi::get_one::<i64>(
                "SELECT count(*) FROM (\
                    SELECT * FROM pgaccel_incsort_smoke ORDER BY a, b LIMIT 10\
                 ) q",
            )
            .expect("select ORDER BY a, b")
            .expect("row_count should be non-NULL");
            let after = crate::engine::stats::read_planner_rejected();
            assert_eq!(
                row_count, 10,
                "multi-key ORDER BY + LIMIT should return 10 rows"
            );
            assert!(
                after > before,
                "multi-key ORDER BY should record an explicit planner rejection \
                 (before={before}, after={after})"
            );
            let incremental_declines = Spi::get_one::<i64>(
                "SELECT pg_accel_planner_rejection_count('sort_incremental_opportunity')",
            )
            .expect("rejection count query should succeed")
            .expect("rejection count should not be NULL");
            assert!(
                incremental_declines > 0,
                "multi-key ORDER BY should expose the incremental-sort opportunity"
            );

            Spi::run("DROP TABLE pgaccel_incsort_smoke").expect("drop");
        }

        /// Single-key ORDER BY regression guard: the retired standalone sort
        /// surface must remain native without losing rows.
        #[pg_test]
        fn single_key_order_by_still_executes() {
            Spi::run("DROP TABLE IF EXISTS pgaccel_incsort_single").expect("drop prior");
            Spi::run("CREATE TABLE pgaccel_incsort_single (a int4) WITH (autovacuum_enabled=off)")
                .expect("create");
            Spi::run(
                "INSERT INTO pgaccel_incsort_single \
             SELECT g FROM generate_series(1, 1000) g",
            )
            .expect("seed");
            crate::gpu::reset_gpu_exec_count();
            let row_count = Spi::get_one::<i64>(
                "SELECT count(*) FROM (SELECT * FROM pgaccel_incsort_single ORDER BY a LIMIT 50) q",
            )
            .expect("select ORDER BY a")
            .expect("row_count should be non-NULL");
            assert_eq!(row_count, 50);
            assert_eq!(
                crate::gpu::gpu_exec_count(),
                0,
                "standalone single-key top-k must stay PostgreSQL-native"
            );
            Spi::run("DROP TABLE pgaccel_incsort_single").expect("drop");
        }
    }
}

// =====================================================================
// MIN/MAX → ORDER BY LIMIT 1 rewrite decline
// =====================================================================
//
// PostgreSQL rewrites `SELECT MIN(col) FROM t` (and MAX) into a subplan
// shaped `SELECT col FROM t ORDER BY col [DESC] LIMIT 1`
// (`preprocess_minmax_aggregates` in
// `src/backend/optimizer/plan/planagg.c`). The base-relation planner hook
// reaches the base-relation observation hook as a sort-shaped path. The hook
// must classify it separately from an ordinary bounded sort while leaving the
// native IndexScan/SeqScan + Limit plan untouched.
//
// The observation-only base hook classifies this via
// `min_max_rewrite_shape(limit_tuples, num_pathkeys)` and records the
// rejection with `RejectionReason::MinMaxRewriteNotASort` (stats key
// `min_max_rewrite_not_a_sort`). No standalone sort path exists.
mod min_max_rewrite_decline {
    #[pgrx::pg_schema]
    mod tests {
        use pgrx::prelude::{Spi, pg_test};

        /// Collect EXPLAIN text for a query into a single string.
        fn explain(query: &str) -> String {
            pgrx::Spi::connect(|client| {
                let mut lines: Vec<String> = Vec::new();
                let table = client
                    .select(&format!("EXPLAIN (FORMAT TEXT) {query}"), None, &[])
                    .expect("EXPLAIN should succeed");
                for row in table {
                    if let Some(line) = row.get::<String>(1).ok().flatten() {
                        lines.push(line);
                    }
                }
                lines.join("\n")
            })
        }

        /// EXPLAIN for `SELECT MIN(x) FROM t` (and MAX, fp64) must not show
        /// `Custom Scan (GpuSort)`. PG's native MIN/MAX → ORDER BY LIMIT 1
        /// rewrite should be left alone — IndexScan/SeqScan + Limit is the
        /// correct shape at LIMIT 1.
        #[pg_test]
        fn min_max_rewrite_does_not_route_to_gpu_sort() {
            Spi::run("DROP TABLE IF EXISTS pgaccel_minmax_rewrite").expect("drop prior");
            Spi::run(
                "CREATE TABLE pgaccel_minmax_rewrite (vf8 float8) \
                 WITH (autovacuum_enabled=off)",
            )
            .expect("create");
            Spi::run(
                "INSERT INTO pgaccel_minmax_rewrite \
                 SELECT random() FROM generate_series(1, 100000) g",
            )
            .expect("seed");
            Spi::run("ANALYZE pgaccel_minmax_rewrite").expect("analyze");
            Spi::run("SET pg_accel.enabled = on").expect("enable");

            let min_plan = explain("SELECT MIN(vf8) FROM pgaccel_minmax_rewrite");
            assert!(
                !min_plan.contains("Strategy: GpuSort"),
                "MIN(vf8) should NOT route through GpuSort; got plan:\n{min_plan}"
            );

            let max_plan = explain("SELECT MAX(vf8) FROM pgaccel_minmax_rewrite");
            assert!(
                !max_plan.contains("Strategy: GpuSort"),
                "MAX(vf8) should NOT route through GpuSort; got plan:\n{max_plan}"
            );

            // Direct LIMIT 1 ORDER BY (the same shape PG emits for the
            // MIN/MAX rewrite) is also native: the standalone sort executor
            // is retired for every output width and LIMIT.
            let limit1_plan =
                explain("SELECT vf8 FROM pgaccel_minmax_rewrite ORDER BY vf8 LIMIT 1");
            assert!(
                !limit1_plan.contains("Strategy: GpuSort"),
                "ORDER BY vf8 LIMIT 1 should NOT route through GpuSort; \
                 got plan:\n{limit1_plan}"
            );

            Spi::run("DROP TABLE pgaccel_minmax_rewrite").expect("drop");
        }

        /// Bounded top-K is also a universal structural decline: verify a
        /// native plan, exact row count, zero GPU dispatch, and the dedicated
        /// rejection reason.
        #[pg_test]
        fn bounded_topk_limit_100_still_executes() {
            Spi::run("DROP TABLE IF EXISTS pgaccel_minmax_topk").expect("drop prior");
            Spi::run(
                "CREATE TABLE pgaccel_minmax_topk (x float8) \
                 WITH (autovacuum_enabled=off)",
            )
            .expect("create");
            Spi::run(
                "INSERT INTO pgaccel_minmax_topk \
                 SELECT random() FROM generate_series(1, 100000) g",
            )
            .expect("seed");
            Spi::run("ANALYZE pgaccel_minmax_topk").expect("analyze");
            Spi::run("SET pg_accel.enabled = on").expect("enable");
            Spi::run("SET pg_accel.gpu_enabled = on").expect("enable GPU planning");
            Spi::run("SELECT pg_accel_reset_stats()").expect("reset stats");

            let plan = explain("SELECT x FROM pgaccel_minmax_topk ORDER BY x LIMIT 100");
            assert!(
                !plan.contains("Strategy: GpuSort") && !plan.contains("Custom Scan (GpuAccelSort)"),
                "bounded top-k must stay PostgreSQL-native:\n{plan}"
            );

            crate::gpu::reset_gpu_exec_count();
            let row_count = Spi::get_one::<i64>(
                "SELECT count(*) FROM (SELECT x FROM pgaccel_minmax_topk \
                 ORDER BY x LIMIT 100) q",
            )
            .expect("select ORDER BY LIMIT 100")
            .expect("row_count should be non-NULL");
            assert_eq!(
                row_count, 100,
                "bounded top-K LIMIT 100 should return 100 rows"
            );
            assert_eq!(
                crate::gpu::gpu_exec_count(),
                0,
                "bounded standalone top-k must not dispatch GPU work"
            );
            let declines = Spi::get_one::<i64>(
                "SELECT pg_accel_planner_rejection_count(\
                 'sort_standalone_topk_no_gpu_kernel')",
            )
            .expect("top-k rejection query should succeed")
            .expect("top-k rejection count should not be NULL");
            assert!(
                declines > 0,
                "bounded top-k must record its structural decline"
            );

            Spi::run("DROP TABLE pgaccel_minmax_topk").expect("drop");
        }
    }
}

// =====================================================================
// MergeJoin detect-and-decline smoke
// =====================================================================
//
// No GPU merge-join kernel exists in `pgaccel-kernels/src/` (verified by
// `rg -n 'merge_join|mergejoin' --type cpp pgaccel-kernels/src/` →
// empty). `observe_mergejoin_opportunity` in `join_pathlist.rs` detects
// `T_MergePath` entries in `joinrel->pathlist`, emits a `debug1` line,
// and bumps the planner-rejected counter with reason
// `mergejoin_no_gpu_kernel`.
//
// This pg_test exists to ensure:
// 1. The detect-and-decline path does NOT crash the planner when PG
//    decides merge-join is a viable plan for a joinrel (the main risk,
//    since we added a new pathlist walk to the join hook).
// 2. The query still executes to completion with correct results. We
//    intentionally do NOT assert "MergeJoin" appears in EXPLAIN because
//    the planner may pick HashJoin or NestLoop depending on cost — the
//    test is about "hook + pathlist walk did not crash", not "PG picked
//    a particular strategy".
mod mergejoin_detect {
    #[pgrx::pg_schema]
    mod tests {
        use pgrx::prelude::{Spi, pg_test};

        /// Smoke: two already-sorted tables joined on an equi-condition give
        /// the planner a favourable shape for merge-join. The hook walks
        /// `joinrel->pathlist`, observes any `T_MergePath` entries, and
        /// emits the `mergejoin_no_gpu_kernel` rejection signal. The query
        /// must still run to completion.
        #[pg_test]
        fn sorted_equijoin_does_not_crash_planner() {
            Spi::run("DROP TABLE IF EXISTS pgaccel_mj_left").expect("drop prior left");
            Spi::run("DROP TABLE IF EXISTS pgaccel_mj_right").expect("drop prior right");
            Spi::run("CREATE TABLE pgaccel_mj_left (k int4, v int4) WITH (autovacuum_enabled=off)")
                .expect("create left");
            Spi::run(
                "CREATE TABLE pgaccel_mj_right (k int4, w int4) WITH (autovacuum_enabled=off)",
            )
            .expect("create right");
            Spi::run(
                "INSERT INTO pgaccel_mj_left \
             SELECT g, g * 2 FROM generate_series(1, 2000) g",
            )
            .expect("seed left");
            Spi::run(
                "INSERT INTO pgaccel_mj_right \
             SELECT g, g * 3 FROM generate_series(1, 2000) g",
            )
            .expect("seed right");
            // BTREE indexes give the planner pre-sorted access paths on the
            // join key — the classic MergeJoin-favourable shape.
            Spi::run("CREATE INDEX ON pgaccel_mj_left (k)").expect("idx left");
            Spi::run("CREATE INDEX ON pgaccel_mj_right (k)").expect("idx right");
            Spi::run("ANALYZE pgaccel_mj_left").expect("analyze left");
            Spi::run("ANALYZE pgaccel_mj_right").expect("analyze right");

            // Encourage the planner to consider merge-join. We do not set
            // `enable_hashjoin=off` globally — that would be a cheat per
            // anti-cheat #3. We only nudge within this session so the path
            // is visible to the classifier; final plan choice is still PG's.
            Spi::run("SET LOCAL enable_hashjoin = off").ok();
            Spi::run("SET LOCAL enable_nestloop = off").ok();

            let row_count = Spi::get_one::<i64>(
                "SELECT count(*) FROM ( \
                 SELECT l.k, l.v, r.w \
                 FROM pgaccel_mj_left l \
                 JOIN pgaccel_mj_right r ON l.k = r.k \
                 ORDER BY l.k \
             ) q",
            )
            .expect("sorted equi-join")
            .expect("row_count should be non-NULL");
            assert_eq!(
                row_count, 2000,
                "sorted equi-join should return all 2000 matches"
            );

            Spi::run("DROP TABLE pgaccel_mj_left").expect("drop left");
            Spi::run("DROP TABLE pgaccel_mj_right").expect("drop right");
        }

        /// Regression guard: `pg_accel_stats()` exposes the planner-rejected
        /// counter. The MergeJoin detect path must increment it over the
        /// course of a forced merge-join-shape query. We measure delta, not
        /// absolute, because other rejections may also fire.
        #[pg_test]
        fn mergejoin_rejection_counter_increments_for_merge_path_shape() {
            Spi::run("DROP TABLE IF EXISTS pgaccel_mj_ctr_l").expect("drop prior l");
            Spi::run("DROP TABLE IF EXISTS pgaccel_mj_ctr_r").expect("drop prior r");
            Spi::run("CREATE TABLE pgaccel_mj_ctr_l (k int4) WITH (autovacuum_enabled=off)")
                .expect("create l");
            Spi::run("CREATE TABLE pgaccel_mj_ctr_r (k int4) WITH (autovacuum_enabled=off)")
                .expect("create r");
            Spi::run(
                "INSERT INTO pgaccel_mj_ctr_l \
             SELECT g FROM generate_series(1, 5000) g",
            )
            .expect("seed l");
            Spi::run(
                "INSERT INTO pgaccel_mj_ctr_r \
             SELECT g FROM generate_series(1, 5000) g",
            )
            .expect("seed r");
            Spi::run("CREATE INDEX ON pgaccel_mj_ctr_l (k)").expect("idx l");
            Spi::run("CREATE INDEX ON pgaccel_mj_ctr_r (k)").expect("idx r");
            Spi::run("ANALYZE pgaccel_mj_ctr_l").expect("analyze l");
            Spi::run("ANALYZE pgaccel_mj_ctr_r").expect("analyze r");

            Spi::run("SET LOCAL enable_hashjoin = off").ok();
            Spi::run("SET LOCAL enable_nestloop = off").ok();

            Spi::run("SELECT pg_accel_reset_stats()").expect("reset stats");
            let before = crate::engine::stats::read_planner_rejected();
            let rows = Spi::get_one::<i64>(
                "SELECT count(*) FROM ( \
                 SELECT l.k FROM pgaccel_mj_ctr_l l JOIN pgaccel_mj_ctr_r r ON l.k = r.k \
             ) q",
            )
            .expect("mergejoin-shaped join")
            .expect("row_count non-NULL");
            assert_eq!(rows, 5000);
            let after = crate::engine::stats::read_planner_rejected();
            assert!(
                after > before,
                "mergejoin-shaped query should record an explicit planner rejection \
                 (before={before}, after={after})"
            );
            let mergejoin_declines = Spi::get_one::<i64>(
                "SELECT pg_accel_planner_rejection_count('mergejoin_no_gpu_kernel')",
            )
            .expect("rejection count query should succeed")
            .expect("rejection count should not be NULL");
            assert!(
                mergejoin_declines > 0,
                "mergejoin-shaped query should expose the exact missing-kernel reason"
            );

            Spi::run("DROP TABLE pgaccel_mj_ctr_l").expect("drop l");
            Spi::run("DROP TABLE pgaccel_mj_ctr_r").expect("drop r");
        }
    }
}

// =====================================================================
// Phase 4: NestedLoop scalar-inequality detect-and-decline
// =====================================================================
//
// No GPU NestedLoop kernel exists in `pgaccel-kernels/src/` (verified by
// `rg -n 'nested_loop|nestloop' --type cpp pgaccel-kernels/src/` →
// empty). `observe_nestloop_scalar_opportunity` in `join_pathlist.rs`
// detects (T_NestPath ∧ cross-rel scalar inequality) in the join's
// pathlist + restrictlist, emits a `debug1` line, and bumps the
// planner-rejected counter with reason `nestloop_scalar_no_gpu_kernel`.
//
// This pg_test exists to ensure:
// 1. The detect-and-decline path does NOT crash the planner when PG
//    decides nested-loop is a viable plan for an inequality join (the
//    main risk, since we added a new pathlist walk + restrictlist walk
//    + `get_op_index_interpretation` call to the join hook).
// 2. The query still executes to completion with correct results. We
//    intentionally do NOT assert "NestLoop" appears in EXPLAIN because
//    the planner may pick HashJoin or MergeJoin depending on cost — the
//    test is about "hook + observability walk did not crash", not "PG
//    picked a particular strategy".
mod nestloop_scalar_detect {
    #[pgrx::pg_schema]
    mod tests {
        use pgrx::prelude::{Spi, pg_test};

        /// Smoke: a correlated BETWEEN inequality join gives the planner a
        /// favourable shape for nested-loop (no equi-key, so hash/merge
        /// cannot help). The hook walks `joinrel->pathlist` for
        /// `T_NestPath`, walks `restrictlist` for cross-rel inequality
        /// quals, and emits the `nestloop_scalar_no_gpu_kernel` rejection
        /// signal. The query must still run to completion.
        #[pg_test]
        fn correlated_between_inequality_does_not_crash_planner() {
            Spi::run("DROP TABLE IF EXISTS pgaccel_nlj_events").expect("drop prior events");
            Spi::run("DROP TABLE IF EXISTS pgaccel_nlj_windows").expect("drop prior windows");
            Spi::run(
                "CREATE TABLE pgaccel_nlj_events (ts int4, payload int4) \
                 WITH (autovacuum_enabled=off)",
            )
            .expect("create events");
            Spi::run(
                "CREATE TABLE pgaccel_nlj_windows (lo int4, hi int4) \
                 WITH (autovacuum_enabled=off)",
            )
            .expect("create windows");
            Spi::run(
                "INSERT INTO pgaccel_nlj_events \
             SELECT g, g * 7 FROM generate_series(1, 1000) g",
            )
            .expect("seed events");
            // 50 non-overlapping windows of width 20 covering ts [1, 1000].
            Spi::run(
                "INSERT INTO pgaccel_nlj_windows \
             SELECT 1 + (g-1)*20, g*20 FROM generate_series(1, 50) g",
            )
            .expect("seed windows");
            Spi::run("ANALYZE pgaccel_nlj_events").expect("analyze events");
            Spi::run("ANALYZE pgaccel_nlj_windows").expect("analyze windows");

            // Encourage the planner to consider the nest-loop shape. There is
            // no equi key, so HashJoin and MergeJoin are not applicable
            // anyway — disabling them is a no-op for plan choice but
            // documents intent.
            Spi::run("SET LOCAL enable_hashjoin = off").ok();
            Spi::run("SET LOCAL enable_mergejoin = off").ok();

            // Correlated BETWEEN: PG expands this to `(e.ts >= w.lo) AND
            // (e.ts <= w.hi)` — two cross-rel btree inequalities, which is
            // exactly the shape `observe_nestloop_scalar_opportunity`
            // looks for. Each event matches exactly one window so the
            // output count equals the event count.
            let row_count = Spi::get_one::<i64>(
                "SELECT count(*) FROM ( \
                 SELECT e.ts, e.payload, w.lo, w.hi \
                 FROM pgaccel_nlj_events e \
                 JOIN pgaccel_nlj_windows w \
                   ON e.ts BETWEEN w.lo AND w.hi \
             ) q",
            )
            .expect("correlated BETWEEN join")
            .expect("row_count should be non-NULL");
            assert_eq!(
                row_count, 1000,
                "correlated BETWEEN join should return all 1000 events (one window each)"
            );

            Spi::run("DROP TABLE pgaccel_nlj_events").expect("drop events");
            Spi::run("DROP TABLE pgaccel_nlj_windows").expect("drop windows");
        }

        /// Regression guard: `pg_accel_stats()` exposes the planner-rejected
        /// counter. The NestedLoop scalar-inequality detect path must
        /// increment it (or at least not decrement it) over the course of
        /// the join query above. We measure delta, not absolute, because
        /// other rejections may also fire.
        #[pg_test]
        fn nestloop_scalar_rejection_counter_is_non_decreasing() {
            Spi::run("DROP TABLE IF EXISTS pgaccel_nlj_ctr_a").expect("drop prior a");
            Spi::run("DROP TABLE IF EXISTS pgaccel_nlj_ctr_b").expect("drop prior b");
            Spi::run("CREATE TABLE pgaccel_nlj_ctr_a (x int4) WITH (autovacuum_enabled=off)")
                .expect("create a");
            Spi::run(
                "CREATE TABLE pgaccel_nlj_ctr_b (lo int4, hi int4) WITH (autovacuum_enabled=off)",
            )
            .expect("create b");
            Spi::run(
                "INSERT INTO pgaccel_nlj_ctr_a \
             SELECT g FROM generate_series(1, 200) g",
            )
            .expect("seed a");
            // Overlapping ranges — every a.x can match multiple b rows; the
            // output is small (200 events × ~10 windows = ~2000 rows) so the
            // early gpu_join_max_output_rows gate doesn't filter the row,
            // but the NLJ observer runs BEFORE that gate anyway (see the
            // placement comment in join_pathlist.rs).
            Spi::run(
                "INSERT INTO pgaccel_nlj_ctr_b \
             SELECT g, g + 10 FROM generate_series(1, 200) g",
            )
            .expect("seed b");
            Spi::run("ANALYZE pgaccel_nlj_ctr_a").expect("analyze a");
            Spi::run("ANALYZE pgaccel_nlj_ctr_b").expect("analyze b");

            Spi::run("SET LOCAL enable_hashjoin = off").ok();
            Spi::run("SET LOCAL enable_mergejoin = off").ok();

            let before = crate::engine::stats::read_planner_rejected();
            let rows = Spi::get_one::<i64>(
                "SELECT count(*) FROM ( \
                 SELECT a.x FROM pgaccel_nlj_ctr_a a \
                 JOIN pgaccel_nlj_ctr_b b ON a.x BETWEEN b.lo AND b.hi \
             ) q",
            )
            .expect("inequality-shaped nlj")
            .expect("row_count non-NULL");
            assert!(
                rows > 0,
                "correlated BETWEEN join must return non-zero rows (got {rows})"
            );
            let after = crate::engine::stats::read_planner_rejected();
            // Must be non-decreasing. We cannot assert strict-greater
            // because the planner may not pick this hook codepath for
            // very small inputs (the hook is invoked per-joinrel, but
            // tiny inputs may skip earlier gates).
            assert!(
                after >= before,
                "planner_rejected counter must be non-decreasing across query execution"
            );

            Spi::run("DROP TABLE pgaccel_nlj_ctr_a").expect("drop a");
            Spi::run("DROP TABLE pgaccel_nlj_ctr_b").expect("drop b");
        }
    }
}

// =====================================================================
// Phase 4: BitmapHeapScan injection smoke
// =====================================================================
//
// `pgaccel_set_rel_pathlist` previously bailed when PG had pruned the
// seq scan because a bitmap-driven path dominates. The fallback added in
// `rel_pathlist.rs` (Gate 5) instead wraps the cheapest
// `T_BitmapHeapPath` as the CustomScan child for non-GpuExpr strategies.
//
// We exercise the unit-level helper directly (`find_cheapest_bitmap_heap_path`
// returns null on a null pathlist) and run an integration smoke that
// ensures the planner does not crash when the bitmap-fallback branch is
// reachable on a real table.
mod bitmap_heap_inject {
    #[pgrx::pg_schema]
    mod tests {
        use pgrx::prelude::{Spi, pg_test};

        /// Smoke: planner does not crash on a table where a bitmap-eligible
        /// path is in scope. We seed enough rows to clear `min_batch_size`
        /// and create a btree index so the planner has a `T_BitmapHeapPath`
        /// candidate. The bitmap fallback branch may or may not fire (PG
        /// will pick whatever it costs cheapest), but the planner walking
        /// `find_cheapest_bitmap_heap_path` over the pathlist must not
        /// crash.
        #[pg_test]
        fn bitmap_eligible_query_does_not_crash_planner() {
            Spi::run("DROP TABLE IF EXISTS pgaccel_bmp_smoke").expect("drop prior");
            Spi::run(
                "CREATE TABLE pgaccel_bmp_smoke (a int4, b int4) WITH (autovacuum_enabled=off)",
            )
            .expect("create");
            Spi::run(
                "INSERT INTO pgaccel_bmp_smoke \
             SELECT g, g % 1000 FROM generate_series(1, 200000) g",
            )
            .expect("seed");
            Spi::run("CREATE INDEX ON pgaccel_bmp_smoke (b)").expect("idx");
            Spi::run("ANALYZE pgaccel_bmp_smoke").expect("analyze");

            // Bias the planner toward bitmap by disabling pure index scan.
            // We do NOT touch parallel settings — that is forbidden by
            // anti-cheat rule #3 and benchmark rule #11.
            Spi::run("SET LOCAL enable_seqscan = off").ok();
            Spi::run("SET LOCAL enable_indexscan = off").ok();

            let row_count = Spi::get_one::<i64>(
                "SELECT count(*) FROM pgaccel_bmp_smoke WHERE b BETWEEN 100 AND 200",
            )
            .expect("bitmap-eligible select")
            .expect("row_count non-NULL");
            assert!(
                row_count > 0,
                "bitmap-eligible select should return non-zero rows"
            );

            Spi::run("DROP TABLE pgaccel_bmp_smoke").expect("drop");
        }

        /// Smoke: bitmap-prefiltered scalar expression shapes have an
        /// explicit planner decline while standalone GpuExpr remains disabled.
        #[pg_test]
        fn bitmap_gpuexpr_candidate_records_planner_decline() {
            Spi::run("DROP TABLE IF EXISTS pgaccel_bmp_expr_decline").expect("drop prior");
            Spi::run(
                "CREATE TABLE pgaccel_bmp_expr_decline ( \
                    bucket int4 NOT NULL, \
                    score float4 NOT NULL, \
                    qty int4 NOT NULL \
                 ) WITH (autovacuum_enabled=off)",
            )
            .expect("create");
            Spi::run(
                "INSERT INTO pgaccel_bmp_expr_decline \
                 SELECT \
                   (g % 1000)::int4, \
                   ((g * 37) % 1000)::float4, \
                   ((g * 13) % 100)::int4 \
                 FROM generate_series(1, 200000) g",
            )
            .expect("seed");
            Spi::run("CREATE INDEX ON pgaccel_bmp_expr_decline (bucket)").expect("idx");
            Spi::run("ANALYZE pgaccel_bmp_expr_decline").expect("analyze");

            Spi::run("SET LOCAL pg_accel.enabled = on").ok();
            Spi::run("SET LOCAL enable_seqscan = off").ok();
            Spi::run("SET LOCAL enable_indexscan = off").ok();

            Spi::run("SELECT pg_accel_reset_stats()").expect("reset stats");
            let before = crate::engine::stats::read_planner_rejected();
            let row_count = Spi::get_one::<i64>(
                "SELECT count(*) \
                 FROM pgaccel_bmp_expr_decline \
                 WHERE bucket BETWEEN 100 AND 300 \
                   AND score > 500.0::float4 \
                   AND qty < 50",
            )
            .expect("bitmap GpuExpr decline select")
            .expect("row_count non-NULL");
            assert!(
                row_count > 0,
                "bitmap GpuExpr decline query should return non-zero rows"
            );
            let after = crate::engine::stats::read_planner_rejected();
            assert!(
                after > before,
                "bitmap + GpuExpr candidate should record a planner decline \
                 (before={before}, after={after})"
            );
            let bitmap_declines = Spi::get_one::<i64>(
                "SELECT pg_accel_planner_rejection_count(\
                    'no_gpu_resident_pipeline'\
                 )",
            )
            .expect("rejection count query should succeed")
            .expect("rejection count should not be NULL");
            assert!(
                bitmap_declines > 0,
                "bitmap + GpuExpr candidate should expose the resident-only gate"
            );

            Spi::run("DROP TABLE pgaccel_bmp_expr_decline").expect("drop");
        }
    }
}

// =====================================================================
// Phase 4: Append / MergeAppend injection smoke
// =====================================================================
//
// `pgaccel_set_rel_pathlist` previously bailed when invoked on a
// `RELOPT_OTHER_MEMBER_REL` (a partition child of a partitioned
// table). Gate 2 in `rel_pathlist.rs` now allows both BASEREL and
// OTHER_MEMBER_REL, so PG's `add_paths_to_append_rel` collects any
// CustomPath we inject into the child's pathlist and wraps the set
// in an Append / MergeAppend.
mod append_inject {
    #[pgrx::pg_schema]
    mod tests {
        use pgrx::prelude::{Spi, pg_test};

        /// Smoke: a 4-partition range-partitioned table with a numeric
        /// WHERE predicate runs to completion. The planner walking each
        /// partition child via the relaxed `set_rel_pathlist_hook` must
        /// not crash.
        #[pg_test]
        fn partitioned_table_select_does_not_crash_planner() {
            Spi::run("DROP TABLE IF EXISTS pgaccel_part_smoke").expect("drop prior");
            Spi::run(
                "CREATE TABLE pgaccel_part_smoke (a int4, b int4) \
             PARTITION BY RANGE (a)",
            )
            .expect("create parent");
            Spi::run(
                "CREATE TABLE pgaccel_part_smoke_p1 PARTITION OF pgaccel_part_smoke \
             FOR VALUES FROM (0) TO (50000)",
            )
            .expect("p1");
            Spi::run(
                "CREATE TABLE pgaccel_part_smoke_p2 PARTITION OF pgaccel_part_smoke \
             FOR VALUES FROM (50000) TO (100000)",
            )
            .expect("p2");
            Spi::run(
                "CREATE TABLE pgaccel_part_smoke_p3 PARTITION OF pgaccel_part_smoke \
             FOR VALUES FROM (100000) TO (150000)",
            )
            .expect("p3");
            Spi::run(
                "CREATE TABLE pgaccel_part_smoke_p4 PARTITION OF pgaccel_part_smoke \
             FOR VALUES FROM (150000) TO (200000)",
            )
            .expect("p4");
            Spi::run(
                "INSERT INTO pgaccel_part_smoke \
             SELECT g, g % 1000 FROM generate_series(0, 199999) g",
            )
            .expect("seed");
            Spi::run("ANALYZE pgaccel_part_smoke").expect("analyze");

            let row_count =
                Spi::get_one::<i64>("SELECT count(*) FROM pgaccel_part_smoke WHERE b > 100")
                    .expect("partitioned select")
                    .expect("row_count non-NULL");
            assert!(
                row_count > 0,
                "partitioned select with predicate should return non-zero rows"
            );

            Spi::run("DROP TABLE pgaccel_part_smoke").expect("drop");
        }
    }
}

// =====================================================================
// Planner-hook overhead audit
// =====================================================================
//
// A 2026-05-14 four-way star-schema diagnosis found planning time inflated to
// 37-40 ms with pg_accel hooks installed versus ~0.2 ms with
// `pg_accel.enabled=off`, even though the query selected no pg_accel
// path and dispatched zero GPU kernels. Immutable planner-stage gates must
// produce a measurable fast-decline signal, while shape/catalog/residency/cost
// admission failures remain ordinary reason-coded planner rejections.
// Join-pathlist now has an INT32/INT64 hash-join kernel and must inspect
// equi-join key shape before declining.
mod phase0_overhead_audit {
    #[pgrx::pg_schema]
    mod tests {
        use pgrx::prelude::{Spi, pg_test};

        #[pg_test]
        fn plain_base_scan_uses_catalog_free_rel_decline() {
            Spi::run("DROP TABLE IF EXISTS pgaccel_p0_plain_scan").expect("drop prior");
            Spi::run("CREATE TABLE pgaccel_p0_plain_scan (v int4 NOT NULL)")
                .expect("create plain scan table");
            Spi::run("INSERT INTO pgaccel_p0_plain_scan VALUES (42)")
                .expect("seed plain scan table");

            let before = crate::engine::stats::read_planner_stage(
                crate::engine::stats::PlannerHookStage::RelPathlist,
            );
            let value = Spi::get_one::<i32>("SELECT v FROM pgaccel_p0_plain_scan LIMIT 1")
                .expect("plain scan should execute")
                .expect("plain scan result should be non-NULL");
            let after = crate::engine::stats::read_planner_stage(
                crate::engine::stats::PlannerHookStage::RelPathlist,
            );

            assert_eq!(value, 42);
            assert!(
                after.0 > before.0,
                "rel_pathlist stage must observe the scan"
            );
            assert!(
                after.2 > before.2,
                "direct Var target must take the catalog-free immutable decline"
            );

            Spi::run("DROP TABLE pgaccel_p0_plain_scan").expect("drop plain scan table");
        }

        /// Generic star-schema regression. A 4-way join with GROUP BY on a
        /// text column (`p_brand1`) is the canonical no-dispatch shape:
        ///
        /// - join hook fires once per join order considered and key-shape /
        ///   cost/cardinality gates decide whether the narrow integer
        ///   hash-join path is legal;
        /// - upper-paths hook performs exact aggregate admission and records
        ///   its first precise shape/residency/cost blocker without
        ///   misclassifying that analysis as an O(1) fast decline.
        ///
        /// We measure the fast-decline counter delta — a positive number
        /// means the audit is wired correctly. We deliberately do NOT
        /// assert on `Planning Time:` from EXPLAIN ANALYZE because it
        /// varies too much with test-host noise to be a stable signal.
        #[pg_test]
        fn star_schema_query_fast_declines_in_planner_hooks() {
            // Build a small star schema: 4-way join, text GROUP BY.
            Spi::run("DROP TABLE IF EXISTS pgaccel_p0_lineorder").expect("drop l");
            Spi::run("DROP TABLE IF EXISTS pgaccel_p0_part").expect("drop p");
            Spi::run("DROP TABLE IF EXISTS pgaccel_p0_supplier").expect("drop s");
            Spi::run("DROP TABLE IF EXISTS pgaccel_p0_date").expect("drop d");

            Spi::run(
                "CREATE TABLE pgaccel_p0_date (d_datekey int4 PRIMARY KEY, d_year int4) \
                 WITH (autovacuum_enabled=off)",
            )
            .expect("create date");
            Spi::run(
                "CREATE TABLE pgaccel_p0_part (\
                    p_partkey int4 PRIMARY KEY, \
                    p_brand1 text NOT NULL\
                 ) WITH (autovacuum_enabled=off)",
            )
            .expect("create part");
            Spi::run(
                "CREATE TABLE pgaccel_p0_supplier (\
                    s_suppkey int4 PRIMARY KEY, \
                    s_region text NOT NULL\
                 ) WITH (autovacuum_enabled=off)",
            )
            .expect("create supplier");
            Spi::run(
                "CREATE TABLE pgaccel_p0_lineorder (\
                    lo_orderdate int4 NOT NULL, \
                    lo_partkey int4 NOT NULL, \
                    lo_suppkey int4 NOT NULL, \
                    lo_revenue int8 NOT NULL\
                 ) WITH (autovacuum_enabled=off)",
            )
            .expect("create lineorder");

            Spi::run(
                "INSERT INTO pgaccel_p0_date \
                 SELECT g + 19920000, 1992 + g % 7 FROM generate_series(1, 200) g",
            )
            .expect("seed date");
            Spi::run(
                "INSERT INTO pgaccel_p0_part \
                 SELECT g, 'MFGR#' || (g % 40) FROM generate_series(1, 200) g",
            )
            .expect("seed part");
            Spi::run(
                "INSERT INTO pgaccel_p0_supplier \
                 SELECT g, (ARRAY['AMERICA','ASIA','EUROPE'])[(g % 3) + 1] \
                 FROM generate_series(1, 50) g",
            )
            .expect("seed supplier");
            Spi::run(
                "INSERT INTO pgaccel_p0_lineorder \
                 SELECT 19920001 + (g % 200), \
                        (g % 200) + 1, (g % 50) + 1, (g * 13)::int8 \
                 FROM generate_series(1, 5000) g",
            )
            .expect("seed lineorder");
            Spi::run("ANALYZE pgaccel_p0_date").expect("analyze d");
            Spi::run("ANALYZE pgaccel_p0_part").expect("analyze p");
            Spi::run("ANALYZE pgaccel_p0_supplier").expect("analyze s");
            Spi::run("ANALYZE pgaccel_p0_lineorder").expect("analyze l");

            // Reset stats counters that the audit increments so the delta
            // is unambiguous. `pg_accel_reset_stats()` clears the
            // thread-local counters; the atomic process-wide counters
            // (which include planner_fast_decline) are NOT reset, so we
            // take a `before` snapshot instead.
            let before_fast = crate::engine::stats::read_planner_fast_decline();
            let before_rejected = crate::engine::stats::read_planner_rejected();
            let before_total_us = crate::engine::stats::read_planner_hook_total_us();

            // Run the star-schema query. Join-pathlist may inspect integer
            // equi-joins now that a narrow hash-join kernel exists.
            let row_count = Spi::get_one::<i64>(
                "SELECT count(*) FROM ( \
                   SELECT SUM(lo_revenue), d_year, p_brand1 \
                   FROM pgaccel_p0_lineorder \
                   JOIN pgaccel_p0_date     ON lo_orderdate = d_datekey \
                   JOIN pgaccel_p0_part     ON lo_partkey   = p_partkey \
                   JOIN pgaccel_p0_supplier ON lo_suppkey   = s_suppkey \
                   WHERE p_brand1 = 'MFGR#3' \
                     AND s_region = 'EUROPE' \
                   GROUP BY d_year, p_brand1 \
                 ) q",
            )
            .expect("star-schema select")
            .expect("row_count non-NULL");
            // Result correctness — count is small but the query must run
            // to completion without crashing the planner.
            assert!(
                row_count >= 0,
                "star-schema 4-way join + grouped agg should return a row count"
            );

            let after_fast = crate::engine::stats::read_planner_fast_decline();
            let after_rejected = crate::engine::stats::read_planner_rejected();
            let after_total_us = crate::engine::stats::read_planner_hook_total_us();

            // Cheap immutable rel/upper-stage gates must still fire somewhere
            // in this no-dispatch query. Aggregate admission is counted as an
            // ordinary reason-coded rejection because it requires shape work.
            assert!(
                after_fast > before_fast,
                "Phase 0 audit: planner_fast_decline counter must \
                 increase after a no-dispatch star-schema query \
                 (before={before_fast}, after={after_fast})"
            );
            assert!(
                after_rejected > before_rejected,
                "star-schema text GROUP BY should record a precise \
                 planner_rejected blocker for the PreAgg/GpuAgg hashagg path \
                 (before={before_rejected}, after={after_rejected})"
            );
            // Total planner-hook microseconds must increase by a finite
            // amount. This proves the elapsed-time guard fires on every
            // invocation. We deliberately do NOT assert an upper bound
            // here because that varies with test host CPU; the bench
            // harness owns that check via comparing accel-on vs accel-off
            // planning time.
            assert!(
                after_total_us >= before_total_us,
                "planner_hook_total_us must be non-decreasing"
            );

            Spi::run("DROP TABLE pgaccel_p0_lineorder").expect("drop l");
            Spi::run("DROP TABLE pgaccel_p0_part").expect("drop p");
            Spi::run("DROP TABLE pgaccel_p0_supplier").expect("drop s");
            Spi::run("DROP TABLE pgaccel_p0_date").expect("drop d");
        }

        /// Regression guard for grouped-aggregate admission. A query that
        /// groups by `INT4` must neither record the unsupported group-key
        /// reason nor classify a later resident/cost rejection as an O(1)
        /// `UpperGroupAgg` fast decline.
        ///
        /// This guards against over-decline: if the gate accidentally
        /// rejects a supported group key type, the upper_paths arm
        /// would never call `agg::inject` and we'd lose all grouped
        /// aggregation acceleration. The test is small enough that the
        /// GPU dispatch thresholds are not met, but the planner walks
        /// the same gates regardless.
        #[pg_test]
        fn numeric_group_by_does_not_take_upper_paths_fast_decline() {
            Spi::run("DROP TABLE IF EXISTS pgaccel_p0_num_grp").expect("drop prior");
            Spi::run(
                "CREATE TABLE pgaccel_p0_num_grp (g int4, v int8) \
                 WITH (autovacuum_enabled=off)",
            )
            .expect("create");
            Spi::run(
                "INSERT INTO pgaccel_p0_num_grp \
                 SELECT g % 10, g FROM generate_series(1, 1000) g",
            )
            .expect("seed");
            Spi::run("ANALYZE pgaccel_p0_num_grp").expect("analyze");

            let before_group_stage = crate::engine::stats::read_planner_stage(
                crate::engine::stats::PlannerHookStage::UpperGroupAgg,
            );
            let before_unsupported_group =
                crate::engine::stats::read_planner_rejection_reason_count(
                    "shape_unsupported_group_key_type",
                );

            let row_count = Spi::get_one::<i64>(
                "SELECT count(*) FROM ( \
                   SELECT g, SUM(v) FROM pgaccel_p0_num_grp GROUP BY g \
                 ) q",
            )
            .expect("numeric-group-by select")
            .expect("row_count non-NULL");
            assert_eq!(
                row_count, 10,
                "numeric GROUP BY should produce 10 groups (g % 10)"
            );

            let after_group_stage = crate::engine::stats::read_planner_stage(
                crate::engine::stats::PlannerHookStage::UpperGroupAgg,
            );
            let after_unsupported_group = crate::engine::stats::read_planner_rejection_reason_count(
                "shape_unsupported_group_key_type",
            );
            assert!(
                after_group_stage.0 > before_group_stage.0,
                "numeric GROUP BY must reach the UpperGroupAgg hook"
            );
            assert_eq!(
                after_group_stage.2, before_group_stage.2,
                "post-shape grouped-aggregate rejection must not be counted as an O(1) fast decline"
            );
            assert_eq!(
                after_unsupported_group, before_unsupported_group,
                "INT4 GROUP BY must not record shape_unsupported_group_key_type"
            );

            Spi::run("DROP TABLE pgaccel_p0_num_grp").expect("drop");
        }
    }
}

// The pg_test integration above covers reason-specific behavior for a
// supported group-key type using planner-populated query structures.
