use std::collections::{BTreeMap, BTreeSet};
use std::fmt::Write as _;
use std::fs;
use std::path::Path;

use serde::{Deserialize, Serialize};

use crate::bench_model::{CachePurgeState, CacheState};
use crate::stats;

const NO_DISPATCH_TIMING_SKEW_THRESHOLD: f64 = 0.10;
const WARMUP_JIT_POST_FIRST_WARN_MS: f64 = 1_000.0;
const WARMUP_JIT_RELATIVE_WARN_RATIO: f64 = 8.0;
pub const NO_DISPATCH_AUDIT_SCHEMA_VERSION: u32 = 1;
pub const RESIDENT_BOUNDARY_AUDIT_SCHEMA_VERSION: u32 = 2;
pub const BENCHMARK_FAILURE_LEDGER_SCHEMA_VERSION: u32 = 1;
const FUNCTION_SRF_GPU_FUNCTIONS: &[&str] = &[
    "h3_latlng_to_cell",
    "h3_grid_disk",
    "h3_grid_ring_unsafe",
    "h3_polyfill",
    "h3_cell_to_children",
    "h3_cell_to_boundary",
    "h3_cells_to_multi_polygon",
];

fn deserialize_stat_f64<'de, D>(deserializer: D) -> Result<f64, D::Error>
where
    D: serde::Deserializer<'de>,
{
    Ok(Option::<f64>::deserialize(deserializer)?.unwrap_or(f64::NAN))
}

fn deserialize_stat_f64_pair<'de, D>(deserializer: D) -> Result<(f64, f64), D::Error>
where
    D: serde::Deserializer<'de>,
{
    let (lower, upper) = <(Option<f64>, Option<f64>)>::deserialize(deserializer)?;
    match (lower, upper) {
        (Some(lower), Some(upper)) => Ok((lower, upper)),
        (None, None) => Ok((f64::NAN, f64::NAN)),
        _ => Err(serde::de::Error::custom(
            "statistical interval endpoints must both be numbers or both be null",
        )),
    }
}

/// Where a native-decline reason came from. Distinguishes a real planner
/// decision from an unconfirmed static-matrix expectation so the report can
/// never launder an *expected* decline into *verified* evidence.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum DeclineReasonSource {
    /// Sourced from a positive reset-session
    /// `pg_accel_planner_rejection_count(reason)` value. This is confirmed
    /// planner evidence.
    PlannerReported,
    /// The static benchmark-threshold matrix expected a decline (no Custom
    /// Scan appeared) but the planner surfaced no reason. Unconfirmed: the
    /// report must render it as "expected, unconfirmed" and never treat it as
    /// verified.
    ExpectedUnconfirmed,
}

/// Native-decline evidence for a benchmark row, tagged with its source. The
/// runner only populates the `reason` from a real planner rejection or an
/// unconfirmed static expectation — it never synthesizes plan text.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct NativeDeclineEvidence {
    /// The decline reason string.
    pub reason: String,
    /// Whether the reason was reported by the planner or is an unconfirmed
    /// static-matrix expectation.
    pub source: DeclineReasonSource,
}

/// Planner-hook work attributed to one stage during a single accelerated
/// benchmark query. These are deltas from the backend-local cumulative stage
/// counters, not snapshots.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct PlannerStageDelta {
    pub stage: String,
    pub calls: u64,
    pub elapsed_us: u64,
    pub fast_declines: u64,
}

/// Planner work attributed to one opt-in aggregate-decline substage.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct PlannerSubstageDelta {
    pub substage: String,
    pub calls: u64,
    pub elapsed_us: u64,
}

/// Off-clock planner-stage evidence for one measured accel/baseline pair.
///
/// `pair_index` indexes [`WorkloadResult::iterations`]. The snapshot query is
/// prepared once before both snapshots, so its own planning is excluded from
/// these deltas and the snapshots execute outside the timed query interval.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct PlannerStageCapture {
    pub pair_index: usize,
    pub cache_state: CacheState,
    pub stages: Vec<PlannerStageDelta>,
    /// Immediate second execution of the prepared observer statement. Every
    /// delta must be zero; non-zero values mean observer planning may have
    /// contaminated the target interval and make the capture invalid.
    #[serde(default, skip_serializing_if = "Vec::is_empty")]
    pub observer_probe: Vec<PlannerStageDelta>,
    /// Fine-grained aggregate-decline timing captured over the same target
    /// interval. These counters are active only while planner profiling is on.
    #[serde(default, skip_serializing_if = "Vec::is_empty")]
    pub substages: Vec<PlannerSubstageDelta>,
    /// Immediate prepared-observer probe for the substage counters. Every
    /// delta must be zero for valid attribution.
    #[serde(default, skip_serializing_if = "Vec::is_empty")]
    pub substage_observer_probe: Vec<PlannerSubstageDelta>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub error: Option<String>,
}

/// Raw executions retained for one mirrored native-parity crossover block.
/// The corresponding [`IterationResult`] contains the arithmetic mean for
/// each arm; these vectors prove that no component sample was discarded.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct NativeParityPairCapture {
    pub pair_index: usize,
    pub accel_first: bool,
    pub sequence: Vec<String>,
    pub accel_ms: Vec<f64>,
    pub parallel_ms: Vec<f64>,
    pub accel_average_ms: f64,
    pub parallel_average_ms: f64,
}

/// Exact counter delta for dependency-stamped artifact preparation during one
/// accelerated query execution.
#[derive(Debug, Clone, Copy, Default, PartialEq, Eq, Serialize, Deserialize)]
pub struct ArtifactLifecycleDelta {
    pub hits: u64,
    pub builds: u64,
    pub rebuilds: u64,
    pub artifact_bytes_observed: u64,
    pub construction_bytes: u64,
    pub construction_us: u64,
    pub preparation_us: u64,
    pub raw_load_us: u64,
}

impl ArtifactLifecycleDelta {
    #[must_use]
    pub const fn ensures(self) -> u64 {
        self.hits
            .saturating_add(self.builds)
            .saturating_add(self.rebuilds)
    }
}

/// Generation identity that the resident store used to validate a derived
/// artifact before and after one query.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct ResidentDependencyIdentity {
    pub relid: u32,
    pub generation: u64,
    pub global_generation: u64,
    pub relfilenode: u32,
    pub row_count: u64,
    pub raw_bytes: u64,
    pub derived_bytes: u64,
}

/// Separately sealed lifecycle or steady-state artifact evidence. The timing
/// pair is never mixed into the regular warm sample vector unless explicitly
/// summarized by `combined_warm_summary`.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ResidentLifecycleCapture {
    pub phase: String,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub pair_index: Option<usize>,
    pub iteration: IterationResult,
    pub artifact: ArtifactLifecycleDelta,
    /// Ownership policy observed after this exact artifact ensure.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub artifact_policy: Option<String>,
    /// Explicit raw-relation refresh cost included in lifecycle `accel_ms`.
    /// Always zero for steady-state captures.
    pub refresh_us: u64,
    /// Number of resident relations explicitly refreshed before this query.
    /// Always zero for steady-state captures.
    #[serde(default)]
    pub refreshed_relations: u64,
    /// Total source rows reloaded by the explicit refresh operation.
    /// Always zero for steady-state captures.
    #[serde(default)]
    pub refreshed_rows: u64,
    pub dependencies_before: Vec<ResidentDependencyIdentity>,
    pub dependencies_after: Vec<ResidentDependencyIdentity>,
    pub queries_accelerated: u64,
    pub rows_dispatched: u64,
    pub batches_executed: u64,
    pub stock_exec_count: u64,
    pub gpu_rows_processed: u64,
    pub gpu_kernel_executions: u64,
    pub output_rows_consumed: u64,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub error: Option<String>,
}

/// Summary statistics for one cache state (warm or cold) of a workload.
///
/// Populated by [`WorkloadResult::from_iterations`] by partitioning the
/// iteration vector on [`IterationResult::cache_state`]. In `CacheMode::Both`
/// both `warm` and `cold` summaries are populated so the report renders
/// medians / p-values / speedups computed over homogeneous subsamples rather
/// than the pooled bimodal mixture.
#[derive(Debug, Clone, Copy, PartialEq, Serialize, Deserialize)]
pub struct CacheModeSummary {
    /// Which cache state this summary describes.
    pub cache_state: CacheState,
    /// Number of measured iterations in this subsample.
    pub n: usize,
    pub accel_mean_ms: f64,
    pub accel_median_ms: f64,
    pub accel_stddev_ms: f64,
    pub accel_p95_ms: f64,
    pub accel_cv_pct: f64,
    #[serde(deserialize_with = "deserialize_stat_f64_pair")]
    pub accel_ci_95: (f64, f64),
    pub parallel_mean_ms: f64,
    pub parallel_median_ms: f64,
    pub parallel_stddev_ms: f64,
    pub parallel_p95_ms: f64,
    pub parallel_cv_pct: f64,
    #[serde(deserialize_with = "deserialize_stat_f64_pair")]
    pub parallel_ci_95: (f64, f64),
    /// `parallel_mean / accel_mean` over this subsample.
    pub speedup_mean_vs_parallel: f64,
    /// `parallel_median / accel_median` over this subsample.
    pub speedup_median_vs_parallel: f64,
    /// Paired t-test p-value over this subsample.
    #[serde(deserialize_with = "deserialize_stat_f64")]
    pub p_value_vs_parallel: f64,
    /// Cohen's d over this subsample.
    #[serde(deserialize_with = "deserialize_stat_f64")]
    pub cohens_d_vs_parallel: f64,
    /// `|d| >= 0.5` over this subsample.
    pub effect_size_meaningful: bool,
}

impl CacheModeSummary {
    /// Build a summary from a homogeneous slice of iterations (all one cache
    /// state). Returns `None` for an empty slice.
    pub(crate) fn from_iterations(
        cache_state: CacheState,
        iterations: &[IterationResult],
    ) -> Option<Self> {
        if iterations.is_empty() {
            return None;
        }
        let accel: Vec<f64> = iterations.iter().map(|i| i.accel_ms).collect();
        let parallel: Vec<f64> = iterations.iter().map(|i| i.parallel_ms).collect();
        let accel_mean = stats::mean(&accel);
        let parallel_mean = stats::mean(&parallel);
        let accel_median = stats::median(&accel);
        let parallel_median = stats::median(&parallel);
        let cohens_d = stats::cohens_d(&parallel, &accel);
        Some(Self {
            cache_state,
            n: iterations.len(),
            accel_mean_ms: accel_mean,
            accel_median_ms: accel_median,
            accel_stddev_ms: stats::stddev(&accel),
            accel_p95_ms: stats::percentile(&accel, 95.0),
            accel_cv_pct: stats::cv_percent(&accel),
            accel_ci_95: stats::confidence_interval_95(&accel),
            parallel_mean_ms: parallel_mean,
            parallel_median_ms: parallel_median,
            parallel_stddev_ms: stats::stddev(&parallel),
            parallel_p95_ms: stats::percentile(&parallel, 95.0),
            parallel_cv_pct: stats::cv_percent(&parallel),
            parallel_ci_95: stats::confidence_interval_95(&parallel),
            speedup_mean_vs_parallel: if accel_mean > 0.0 {
                parallel_mean / accel_mean
            } else {
                f64::NAN
            },
            speedup_median_vs_parallel: if accel_median > 0.0 {
                parallel_median / accel_median
            } else {
                f64::NAN
            },
            p_value_vs_parallel: stats::paired_t_test_p(&accel, &parallel),
            cohens_d_vs_parallel: cohens_d,
            effect_size_meaningful: cohens_d.is_finite() && cohens_d.abs() >= 0.5,
        })
    }
}

/// Timing results for a single iteration (two-way: accel vs PG parallel).
#[derive(Debug, Clone, Serialize, Deserialize)]
#[allow(clippy::struct_field_names)]
pub struct IterationResult {
    /// Execution time in milliseconds with pg_accel enabled.
    pub accel_ms: f64,
    /// Execution time in milliseconds with PG parallel workers (pg_accel off).
    pub parallel_ms: f64,
    /// Whether the pg_accel-enabled arm ran before the disabled PostgreSQL
    /// arm for this pair. Older reports deserialize this as `false`; release
    /// analyzers require an explicitly balanced order in newly sealed runs.
    #[serde(default)]
    pub accel_first: bool,
    /// Outcome of the OS page-cache purge requested for this iteration.
    #[serde(default)]
    pub cache_purge: CachePurgeState,
    /// Cache state this iteration measured under (warm vs cold). Set from the
    /// run's [`CacheMode`](crate::runner::CacheMode). In `CacheMode::Both` this
    /// is the key that separates the cold and warm subsamples so summary stats
    /// are never computed over the bimodal mixture.
    #[serde(default)]
    pub cache_state: CacheState,
}

/// Successful grouped-aggregate native calls by stable physical branch.
#[derive(Debug, Clone, Copy, Default, PartialEq, Eq, Serialize, Deserialize)]
pub struct PhysicalKernelModeCounts {
    pub parallel_hash: u64,
    pub parallel_dense_count: u64,
    pub parallel_dense_integer: u64,
    #[serde(default)]
    pub parallel_dense_numeric: u64,
    pub serial_generic: u64,
}

impl PhysicalKernelModeCounts {
    #[must_use]
    pub fn unique_mode(self) -> Option<&'static str> {
        let mut nonzero = [
            ("parallel_hash", self.parallel_hash),
            ("parallel_dense_count", self.parallel_dense_count),
            ("parallel_dense_integer", self.parallel_dense_integer),
            ("parallel_dense_numeric", self.parallel_dense_numeric),
            ("serial_generic", self.serial_generic),
        ]
        .into_iter()
        .filter_map(|(mode, calls)| (calls != 0).then_some(mode));
        let mode = nonzero.next()?;
        nonzero.next().is_none().then_some(mode)
    }
}

/// Aggregated results for one workload at one row scale (two-way: accel vs PG parallel).
#[derive(Debug, Clone, Serialize, Deserialize)]
#[allow(clippy::struct_excessive_bools)]
pub struct WorkloadResult {
    pub name: String,
    pub description: String,
    /// Workload category (`gpu_spatial`, `gpu_h3`, `ssbm`, etc.). Used for
    /// rollup / geomean grouping in the report.
    pub category: String,
    /// Kernel class this workload exercises (`point_in_ring`, `reduce_f32`,
    /// `hashagg`, `h3_latlng`, etc.). Used by the Kernel Coverage table
    /// (action_items W11) to show that 127 workloads exercise only ~9
    /// distinct kernels.
    pub kernel_class: String,
    /// Row count this result was measured at.
    pub rows: usize,
    pub iterations: Vec<IterationResult>,
    /// Per-pair, off-clock planner-stage deltas for native-decline benchmark
    /// cells. Entries index `iterations`; absent for non-native cells.
    #[serde(default, skip_serializing_if = "Vec::is_empty")]
    pub planner_stage_captures: Vec<PlannerStageCapture>,
    /// Mirrored ABBA/BAAB raw components for same-backend native-parity runs.
    #[serde(default, skip_serializing_if = "Vec::is_empty")]
    pub native_parity_pair_captures: Vec<NativeParityPairCapture>,
    /// One explicit refresh/build/dispatch pair, excluded from steady-state
    /// warm ratchets and retained as lifecycle evidence.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub artifact_lifecycle_probe: Option<ResidentLifecycleCapture>,
    /// Per-pair proof that regular warm samples used existing artifacts.
    #[serde(default, skip_serializing_if = "Vec::is_empty")]
    pub artifact_steady_state_captures: Vec<ResidentLifecycleCapture>,
    /// Whether PostgreSQL selected a pg_accel Custom Scan plan node.
    ///
    /// This is intentionally separate from runtime GPU dispatch: aggregate
    /// wrappers can be selected and still report `GPU Dispatched: false`.
    #[serde(default)]
    pub plan_selected: bool,
    /// Whether a GPU kernel is credited as dispatched for this benchmark row.
    ///
    /// This is true for Custom Scan runtime dispatch and for recognized
    /// function/SRF GPU kernels such as H3 bulk operations. A typed
    /// derived-output lane can also receive credit when a separate sealed
    /// lifecycle probe proves GPU construction and every measured execution
    /// proves exact artifact reuse without fresh kernel work.
    #[serde(default)]
    pub gpu_kernel_dispatched: bool,
    /// Whether the dispatch came from a function/SRF GPU kernel rather than a
    /// Custom Scan plan node.
    #[serde(default)]
    pub function_srf_kernel_dispatched: bool,
    /// Derived release-gate flag: no pg_accel Custom Scan was selected and no
    /// function/SRF GPU dispatch was credited for this measured row.
    #[serde(default)]
    pub planner_declined: bool,
    /// Derived release-gate flag: PostgreSQL selected a pg_accel Custom Scan
    /// node, but runtime counters did not prove GPU kernel dispatch.
    #[serde(default)]
    pub custom_scan_selected_not_dispatched: bool,
    /// Derived release-gate count for credited function/SRF kernel executions.
    ///
    /// The harness currently has one kernel counter surface, so this is the
    /// total kernel delta only for rows classified as function/SRF dispatch.
    #[serde(default)]
    pub function_kernel_count: u64,
    /// Derived release-gate alias for accel-side rows returned to PostgreSQL
    /// or the client.
    #[serde(default)]
    pub rows_returned_to_cpu: u64,
    /// Derived release-gate status for GPU-resident pipeline evidence when the
    /// plan artifact exposes it.
    #[serde(default)]
    pub gpu_resident_pipeline: GpuResidentPipelineStatus,
    /// CPU/PostgreSQL boundary that prevents the selected pg_accel plan from
    /// being treated as a GPU-resident pipeline.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub gpu_resident_boundary_reason: Option<String>,
    /// Native filtering after GPU aggregate output materialization, not a
    /// host-staged input or an intermediate inside the resident GPU pipeline.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub native_post_aggregate_filter: Option<String>,
    /// Warmup timings are excluded from statistics but retained in artifacts
    /// so one-time JIT/runtime latency cannot disappear from report evidence.
    #[serde(default, skip_serializing_if = "Vec::is_empty")]
    pub warmup_iterations: Vec<IterationResult>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub warmup_accel_first_ms: Option<f64>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub warmup_accel_max_ms: Option<f64>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub warmup_accel_post_first_max_ms: Option<f64>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub warmup_parallel_first_ms: Option<f64>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub warmup_parallel_max_ms: Option<f64>,
    /// Whether the harness successfully captured pg_accel runtime counters
    /// around the measured accel-side executions.
    #[serde(default)]
    pub dispatch_counter_captured: bool,
    /// Delta of `pg_accel_kernel_executions()`/`pg_accel_stats()` for the
    /// accel backend across the measured workload. This is the ordinary
    /// source of truth for GPU-dispatched wins; the strictly typed
    /// derived-output exception keeps its construction kernel in
    /// `artifact_lifecycle_probe` instead of mixing it into this delta.
    #[serde(default)]
    pub gpu_kernel_execution_delta: u64,
    /// Delta of `pg_accel_stats().queries_accelerated` captured on the same
    /// backend around measured accel executions. Selected Custom Scan credit
    /// requires this to cover every measured pair.
    #[serde(default)]
    pub pg_accel_queries_accelerated_delta: u64,
    /// Delta of `pg_accel_stats().rows_dispatched`.
    #[serde(default)]
    pub pg_accel_rows_dispatched_delta: u64,
    /// Delta of `pg_accel_stats().batches_executed`.
    #[serde(default)]
    pub pg_accel_batches_executed_delta: u64,
    /// Delta of `pg_accel_stats().gpu_rows_processed`.
    #[serde(default)]
    pub pg_accel_gpu_rows_processed_delta: u64,
    /// Delta of `pg_accel_stats().stock_exec_count`; non-zero values are a
    /// red flag for CPU-backed pg_accel plans.
    #[serde(default)]
    pub pg_accel_stock_exec_delta: u64,
    /// Successful native grouped-aggregate calls split by the physical branch
    /// that the C++ validator selected immediately before dispatch.
    #[serde(default)]
    pub physical_kernel_mode_counts: PhysicalKernelModeCounts,
    /// The unique physical mode observed for this benchmark row, when exactly
    /// one grouped branch dispatched.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub physical_kernel_mode: Option<String>,
    /// Whether the native counter mode matches the planned EXPLAIN mode.
    #[serde(default)]
    pub physical_kernel_mode_verified: bool,
    /// Rows returned to the client or reported by EXPLAIN ANALYZE for the
    /// accel-side measured executions. Function/SRF kernel wins require this
    /// to be non-zero so a launched kernel is not counted without output
    /// consumption.
    #[serde(default)]
    pub accel_output_rows_consumed: u64,
    /// Counter-capture failure, when the SQL stats surface was unavailable.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub dispatch_counter_error: Option<String>,
    // -- pg_accel stats --
    pub accel_mean_ms: f64,
    pub accel_stddev_ms: f64,
    pub accel_median_ms: f64,
    pub accel_p25_ms: f64,
    pub accel_p75_ms: f64,
    pub accel_p95_ms: f64,
    pub accel_cv_pct: f64,
    #[serde(deserialize_with = "deserialize_stat_f64_pair")]
    pub accel_ci_95: (f64, f64),
    pub accel_outliers: Vec<usize>,
    pub accel_min_ms: f64,
    pub accel_max_ms: f64,
    // -- PG parallel stats --
    pub parallel_mean_ms: f64,
    pub parallel_stddev_ms: f64,
    pub parallel_median_ms: f64,
    pub parallel_p25_ms: f64,
    pub parallel_p75_ms: f64,
    pub parallel_p95_ms: f64,
    pub parallel_cv_pct: f64,
    #[serde(deserialize_with = "deserialize_stat_f64_pair")]
    pub parallel_ci_95: (f64, f64),
    pub parallel_outliers: Vec<usize>,
    pub parallel_min_ms: f64,
    pub parallel_max_ms: f64,
    // -- Derived --
    /// `parallel_mean / accel_mean`. Values > 1 mean pg_accel is faster than PG parallel.
    pub speedup_vs_parallel: f64,
    /// `parallel_median / accel_median`. Preferred over `speedup_vs_parallel`
    /// for the headline (action_items M12 / Reviewer 1 Sin #19) — median is
    /// robust to the 22% CV cold-start contamination that inflates the mean.
    pub speedup_median_vs_parallel: f64,
    /// Paired t-test p-value: accel vs parallel.
    #[serde(deserialize_with = "deserialize_stat_f64")]
    pub p_value_vs_parallel: f64,
    /// Cohen's d: accel vs parallel. Positive values mean parallel is larger
    /// (i.e. pg_accel is faster). See `stats::cohens_d` for the pooled-sd
    /// formula.
    #[serde(deserialize_with = "deserialize_stat_f64")]
    pub cohens_d_vs_parallel: f64,
    /// `|d| >= 0.5`, i.e. effect size at least "medium" (action_items C9 /
    /// Reviewer 1 Sin #16). The significance gate uses BOTH this AND
    /// Bonferroni-adjusted p, so a row with a 1.2% speedup that is "p = 0"
    /// because of tiny variance is correctly reported as not meaningfully
    /// different.
    pub effect_size_meaningful: bool,
    /// Asymmetric variance ratio = max(cv_accel, cv_baseline) /
    /// min(cv_accel, cv_baseline). Values > 3 indicate the two samples
    /// have very different jitter characteristics and should be reported
    /// with an asymmetric-variance note.
    #[serde(deserialize_with = "deserialize_stat_f64")]
    pub cv_ratio: f64,
    /// Plan diagnostic text captured once per (workload, scale) by the
    /// runner with `pg_accel.enabled = on`. Contains the first few lines of
    /// `EXPLAIN (VERBOSE, COSTS OFF)` — the portion with the Custom Scan
    /// node / GPU Dispatched tags. Used for dispatch classification and
    /// debugging.
    #[serde(default)]
    pub plan_snippet: Option<String>,
    /// Comparable plan diagnostic text captured once per (workload, scale)
    /// with `pg_accel.enabled = off` on the PG-parallel side. Used to flag
    /// no-dispatch rows whose native PostgreSQL plan shape differs from the
    /// accel-mode no-dispatch plan.
    #[serde(default)]
    pub baseline_plan_snippet: Option<String>,
    /// Relative path to the accel-vs-baseline correctness diff artifact for
    /// this workload/scale, when artifact capture was enabled.
    #[serde(default)]
    pub correctness_diff_artifact: Option<String>,
    /// Fail-closed proof that bulk fixture setup was forced through a
    /// completed PostgreSQL checkpoint and that the checkpointer stayed idle
    /// throughout the measured interval. This prevents asynchronous setup
    /// writes from contaminating low-latency native-parity tails.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub setup_quiescence: Option<SetupQuiescenceAudit>,
    /// Thermal state captured immediately before this workload ran.
    /// `None` on platforms where capture is unavailable.
    #[serde(default)]
    pub thermal: Option<ThermalState>,
    /// `pg_class`/`pg_stats` diagnostics captured after VACUUM ANALYZE
    /// (action_items C6 / Reviewer 2 §3(iii)). Proves the parallel
    /// baseline's planner had fresh statistics.
    #[serde(default)]
    pub table_stats: Vec<TableStats>,
    /// Benchmark sanity checks captured after setup and before timing.
    /// SSBM uses these to prove dimension filters are non-empty before
    /// no-dispatch rows are interpreted as missing GPU PreAgg work.
    #[serde(default)]
    pub sanity_checks: Vec<SanityCheck>,
    /// Wall-clock time (ms) the accel side spent loading GPU-resident caches
    /// **off** the timed region for this workload, when a resident-cache
    /// loader ran. `None` for workloads with no resident-cache prerequisite.
    /// First-class evidence: the resident lanes pre-load caches outside the
    /// clock while the PG baseline pays scan I/O on the clock, so the report
    /// must be able to surface what the accel side got for free.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub resident_load_ms: Option<f64>,
    /// True when this workload requires a GPU-resident cache preload
    /// (`ssbm_*` / `resident_*` lanes). Marks resident-lane rows distinctly so
    /// the report never folds an off-clock-preloaded win into the headline
    /// geomean without a marker.
    #[serde(default)]
    pub resident_lane: bool,
    /// Native-decline evidence tagged with its source. Populated only from a
    /// real planner rejection (`PlannerReported`) or an unconfirmed static
    /// expectation (`ExpectedUnconfirmed`). Replaces the deleted fabricated
    /// plan-text injection: the report reads this instead of grepping the plan
    /// snippet for a synthetic reason line.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub native_decline_evidence: Option<NativeDeclineEvidence>,
    /// Warm-only summary statistics, populated when the run measured any warm
    /// iterations. In `CacheMode::Both` this is computed over the warm
    /// subsample only.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub warm_summary: Option<CacheModeSummary>,
    /// End-to-end warm view with the lifecycle probe prepended to the regular
    /// steady-state samples. Cost calibration may use this; latency gates use
    /// `warm_summary` only.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub combined_warm_summary: Option<CacheModeSummary>,
    /// Cold-only summary statistics, populated when the run measured any cold
    /// iterations. In `CacheMode::Both` this is computed over the cold
    /// subsample only.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub cold_summary: Option<CacheModeSummary>,
    /// For cold / both runs: whether the workload fixture fits within
    /// `shared_buffers` (`Some(true)` = data stays resident in shared_buffers
    /// even after the OS page-cache purge, so the "cold" label overstates the
    /// eviction) or exceeds it (`Some(false)` = genuinely cold). `None` when
    /// not a cold run or the comparison could not be made. Recorded so reports
    /// cannot call a run cold when shared_buffers stayed resident.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub cold_shared_buffers_resident: Option<bool>,
}

/// Hardware and software profile for reproducibility.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct HardwareProfile {
    pub os: String,
    pub os_version: String,
    pub arch: String,
    pub cpu: String,
    pub cpu_cores: usize,
    pub memory_gb: String,
}

/// PostgreSQL GUC settings relevant to benchmarks.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct GucSettings {
    pub settings: Vec<(String, String)>,
}

/// A workload+scale that crashed during benchmarking.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct CrashedScale {
    pub workload: String,
    pub rows: usize,
    pub error: String,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub repro_command: Option<String>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub plan_snippet_artifact: Option<String>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub correctness_diff_artifact: Option<String>,
    #[serde(default, skip_serializing_if = "Vec::is_empty")]
    pub log_tail_artifacts: Vec<String>,
}

/// Full benchmark report containing results for all workloads at all scales.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct BenchReport {
    pub hardware: Option<HardwareProfile>,
    pub gucs: Option<GucSettings>,
    pub methodology: Methodology,
    pub workloads: Vec<WorkloadResult>,
    /// False for broad characterization runs that intentionally publish only
    /// per-cell evidence, not an aggregate system-level speedup claim.
    #[serde(default = "default_true")]
    pub headline_speedup_allowed: bool,
    /// Directory where report JSON/Markdown/CSV, crash lists, log tails,
    /// plan snippets, and GUC snapshots were persisted.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub artifact_dir: Option<String>,
    /// Scales that crashed and were skipped (not included in workloads).
    #[serde(default)]
    pub crashes: Vec<CrashedScale>,
    /// Timestamp from `pg_postmaster_start_time()` at the time the run
    /// started. Proves the observed settings match a specific running
    /// postmaster (action_items C4).
    #[serde(default)]
    pub postmaster_start_time: Option<String>,
}

const fn default_true() -> bool {
    true
}

/// Machine-readable audit for selected pg_accel Custom Scan resident-pipeline
/// evidence in a saved benchmark report.
#[derive(Debug, Clone, Serialize, PartialEq, Eq)]
pub struct ResidentBoundaryAudit {
    pub schema_version: u32,
    pub selected_custom_scan_rows: usize,
    pub passed_rows: usize,
    pub failed_rows: usize,
    pub ignored_non_custom_scan_rows: usize,
    pub rows: Vec<ResidentBoundaryAuditRow>,
}

#[derive(Debug, Clone, Serialize, PartialEq, Eq)]
pub struct ResidentBoundaryAuditRow {
    pub workload: String,
    pub rows: usize,
    pub gpu_kernel_dispatched: bool,
    pub gpu_resident_pipeline: String,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub boundary_reason: Option<String>,
    pub status: ResidentBoundaryAuditStatus,
    pub detail: String,
}

#[derive(Debug, Clone, Copy, Serialize, PartialEq, Eq)]
#[serde(rename_all = "snake_case")]
pub enum ResidentBoundaryAuditStatus {
    ReportedResidentPipeline,
    LifecycleProducedArtifactReuse,
    NonResidentPipeline,
    MissingResidentPipelineEvidence,
}

impl ResidentBoundaryAuditStatus {
    const fn is_failure(self) -> bool {
        !matches!(
            self,
            Self::ReportedResidentPipeline | Self::LifecycleProducedArtifactReuse
        )
    }

    const fn as_str(self) -> &'static str {
        match self {
            Self::ReportedResidentPipeline => "reported_resident_pipeline",
            Self::LifecycleProducedArtifactReuse => "lifecycle_produced_artifact_reuse",
            Self::NonResidentPipeline => "non_resident_pipeline",
            Self::MissingResidentPipelineEvidence => "missing_resident_pipeline_evidence",
        }
    }
}

impl ResidentBoundaryAudit {
    #[must_use]
    pub const fn has_failures(&self) -> bool {
        self.failed_rows > 0
    }

    #[must_use]
    pub fn to_markdown(&self) -> String {
        let mut out = String::new();
        out.push_str("# Resident Boundary Audit\n\n");
        let _ = writeln!(
            out,
            "| Selected Custom Scan rows | Passed | Failed | Ignored non-Custom-Scan rows |"
        );
        let _ = writeln!(out, "|---:|---:|---:|---:|");
        let _ = writeln!(
            out,
            "| {} | {} | {} | {} |",
            self.selected_custom_scan_rows,
            self.passed_rows,
            self.failed_rows,
            self.ignored_non_custom_scan_rows
        );
        out.push('\n');
        out.push_str(
            "Every selected pg_accel Custom Scan must carry explicit \
             `GPU Resident Pipeline: true` proof. A typed derived-output lane may also \
             prove that one sealed lifecycle GPU kernel constructed the exact final \
             artifact and that every measured warm query consumed a dependency-stable \
             hit without fresh GPU work. CPU/PostgreSQL boundary reasons are preserved \
             as diagnostics, but they are failures for SQL-plan admission.\n\n",
        );
        let _ = writeln!(
            out,
            "| Workload | Scale | GPU dispatched | GPU-resident pipeline | Status | Boundary | Detail |"
        );
        let _ = writeln!(out, "|---|---:|---|---|---|---|---|");
        for row in &self.rows {
            let boundary = row.boundary_reason.as_deref().unwrap_or("-");
            let _ = writeln!(
                out,
                "| {} | {} | {} | {} | {} | {} | {} |",
                markdown_cell(&row.workload),
                format_rows(row.rows),
                row.gpu_kernel_dispatched,
                row.gpu_resident_pipeline,
                row.status.as_str(),
                markdown_cell(boundary),
                markdown_cell(&row.detail),
            );
        }
        out
    }
}

/// Machine-readable audit for benchmark rows where pg_accel did not dispatch
/// GPU work and any timing difference is therefore not GPU performance credit.
#[derive(Debug, Clone, Serialize, PartialEq)]
pub struct NoDispatchAudit {
    pub schema_version: u32,
    pub timing_skew_threshold_fraction: f64,
    pub evaluated_no_dispatch_rows: usize,
    pub clean_rows: usize,
    pub warning_rows: usize,
    pub timing_skew_rows: usize,
    pub plan_mismatch_rows: usize,
    pub selected_custom_scan_not_dispatched_rows: usize,
    pub missing_plan_evidence_rows: usize,
    pub ignored_dispatching_rows: usize,
    pub rows: Vec<NoDispatchAuditRow>,
}

#[derive(Debug, Clone, Serialize, PartialEq)]
pub struct NoDispatchAuditRow {
    pub workload: String,
    pub rows: usize,
    pub speedup_median_vs_parallel: f64,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub timing_skew_fraction: Option<f64>,
    pub timing_skew: bool,
    pub plan_mismatch: bool,
    pub missing_plan_evidence: bool,
    pub accel_plan_signature: String,
    pub baseline_plan_signature: String,
    pub status: NoDispatchAuditStatus,
    pub action: String,
}

/// Machine-readable work queue for every benchmark row that blocks release or
/// still loses to PG-parallel. This intentionally merges multiple failure
/// sources for the same workload/scale into one row so the next engineering
/// task is visible without scraping markdown sections.
#[derive(Debug, Clone, Serialize, PartialEq)]
pub struct BenchmarkFailureLedger {
    pub schema_version: u32,
    pub total_measured_rows: usize,
    pub ship_gate_failure_count: usize,
    pub h3_lane_gate_failure_count: usize,
    pub crash_count: usize,
    pub rows_below_parity_count: usize,
    pub gpu_dispatched_below_parity_count: usize,
    pub native_below_parity_count: usize,
    pub planner_declined_below_parity_count: usize,
    pub stock_fallback_rows: usize,
    pub custom_scan_selected_not_dispatched_rows: usize,
    pub unique_work_items: usize,
    pub rows: Vec<BenchmarkFailureLedgerRow>,
}

#[derive(Debug, Clone, Serialize, PartialEq)]
pub struct BenchmarkFailureLedgerRow {
    pub workload: String,
    pub rows: usize,
    pub category: String,
    pub kernel_class: String,
    pub classification: String,
    pub priority: String,
    pub next_track: String,
    pub sources: Vec<String>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub speedup_median_vs_parallel: Option<f64>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub gate_floor: Option<f64>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub accel_median_ms: Option<f64>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub parallel_median_ms: Option<f64>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub repro_command: Option<String>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub plan_snippet_artifact: Option<String>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub correctness_diff_artifact: Option<String>,
    #[serde(skip_serializing_if = "Vec::is_empty")]
    pub log_tail_artifacts: Vec<String>,
    pub details: Vec<String>,
}

impl BenchmarkFailureLedger {
    #[must_use]
    pub fn to_markdown(&self) -> String {
        let mut out = String::new();
        out.push_str("# Benchmark Failure Ledger\n\n");
        out.push_str(
            "Release-blocking gate failures and every measured row still below \
             PostgreSQL-parallel parity. Rows are merged by workload/scale so one \
             benchmark cell has one owner even when it trips multiple checks.\n\n",
        );
        let _ = writeln!(
            out,
            "| Total rows | Ship-gate failures | H3 gate failures | Crashes | Rows below parity | GPU-dispatched below parity | Native below parity | Planner-declined below parity | Stock fallback rows | Custom Scan no-dispatch | Work items |"
        );
        let _ = writeln!(
            out,
            "|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|"
        );
        let _ = writeln!(
            out,
            "| {} | {} | {} | {} | {} | {} | {} | {} | {} | {} | {} |",
            self.total_measured_rows,
            self.ship_gate_failure_count,
            self.h3_lane_gate_failure_count,
            self.crash_count,
            self.rows_below_parity_count,
            self.gpu_dispatched_below_parity_count,
            self.native_below_parity_count,
            self.planner_declined_below_parity_count,
            self.stock_fallback_rows,
            self.custom_scan_selected_not_dispatched_rows,
            self.unique_work_items
        );
        out.push('\n');

        let _ = writeln!(
            out,
            "| Priority | Track | Workload | Scale | Sources | Classification | Speedup | Gate | Accel ms | PG ms | Crash artifacts | Detail |"
        );
        let _ = writeln!(
            out,
            "|---|---|---|---:|---|---|---:|---:|---:|---:|---|---|"
        );
        for row in &self.rows {
            let speedup = row
                .speedup_median_vs_parallel
                .map_or_else(|| "-".to_owned(), |value| format!("{value:.2}x"));
            let gate = row
                .gate_floor
                .map_or_else(|| "-".to_owned(), |value| format!("{value:.2}x"));
            let accel = row
                .accel_median_ms
                .map_or_else(|| "-".to_owned(), |value| format!("{value:.2}"));
            let parallel = row
                .parallel_median_ms
                .map_or_else(|| "-".to_owned(), |value| format!("{value:.2}"));
            let sources = row.sources.join(", ");
            let crash_artifacts = ledger_crash_artifact_summary(row);
            let details = row.details.join("<br>");
            let _ = writeln!(
                out,
                "| {} | {} | {} | {} | {} | {} | {} | {} | {} | {} | {} | {} |",
                markdown_cell(&row.priority),
                markdown_cell(&row.next_track),
                markdown_cell(&row.workload),
                format_rows(row.rows),
                markdown_cell(&sources),
                markdown_cell(&row.classification),
                speedup,
                gate,
                accel,
                parallel,
                markdown_cell(&crash_artifacts),
                markdown_cell(&details),
            );
        }
        out
    }
}

#[derive(Debug, Clone, Copy, Serialize, PartialEq, Eq)]
#[serde(rename_all = "snake_case")]
pub enum NoDispatchAuditStatus {
    ComparableNative,
    TimingSkew,
    PlanMismatch,
    TimingSkewAndPlanMismatch,
    SelectedCustomScanNotDispatched,
    MissingPlanEvidence,
}

impl NoDispatchAuditStatus {
    const fn is_warning(self) -> bool {
        !matches!(self, Self::ComparableNative)
    }

    const fn as_str(self) -> &'static str {
        match self {
            Self::ComparableNative => "comparable_native",
            Self::TimingSkew => "timing_skew",
            Self::PlanMismatch => "plan_mismatch",
            Self::TimingSkewAndPlanMismatch => "timing_skew_and_plan_mismatch",
            Self::SelectedCustomScanNotDispatched => "selected_custom_scan_not_dispatched",
            Self::MissingPlanEvidence => "missing_plan_evidence",
        }
    }
}

impl NoDispatchAudit {
    #[must_use]
    pub fn to_markdown(&self) -> String {
        let mut out = String::new();
        out.push_str("# No-Dispatch Audit\n\n");
        let _ = writeln!(
            out,
            "| Evaluated no-dispatch rows | Clean | Warnings | Timing skew | Plan mismatch | Selected Custom Scan no-dispatch | Missing plan evidence | Ignored dispatching rows |"
        );
        let _ = writeln!(out, "|---:|---:|---:|---:|---:|---:|---:|---:|");
        let _ = writeln!(
            out,
            "| {} | {} | {} | {} | {} | {} | {} | {} |",
            self.evaluated_no_dispatch_rows,
            self.clean_rows,
            self.warning_rows,
            self.timing_skew_rows,
            self.plan_mismatch_rows,
            self.selected_custom_scan_not_dispatched_rows,
            self.missing_plan_evidence_rows,
            self.ignored_dispatching_rows
        );
        out.push('\n');
        let _ = writeln!(
            out,
            "Rows in this audit did not prove pg_accel GPU kernel dispatch. Timing gaps \
             here are harness, planner, cache, or native plan differences until the row is \
             re-run with matching plan evidence and dispatch counters."
        );
        out.push('\n');
        let _ = writeln!(
            out,
            "| Workload | Scale | Median speedup | Timing skew | Plan shape | Missing plan evidence | Accel plan | PG plan | Status | Action |"
        );
        let _ = writeln!(out, "|---|---:|---:|---|---|---|---|---|---|---|");
        for row in &self.rows {
            let timing = row
                .timing_skew_fraction
                .map_or_else(|| "-".to_owned(), |skew| format!("{:.1}%", skew * 100.0));
            let plan_shape = if row.plan_mismatch {
                "DIFF"
            } else if row.accel_plan_signature == "-" || row.baseline_plan_signature == "-" {
                "not captured"
            } else {
                "same"
            };
            let _ = writeln!(
                out,
                "| {} | {} | {:.2}x | {} | {} | {} | `{}` | `{}` | {} | {} |",
                markdown_cell(&row.workload),
                format_rows(row.rows),
                row.speedup_median_vs_parallel,
                timing,
                plan_shape,
                row.missing_plan_evidence,
                markdown_cell(&row.accel_plan_signature),
                markdown_cell(&row.baseline_plan_signature),
                row.status.as_str(),
                markdown_cell(&row.action),
            );
        }
        out
    }
}

/// Methodology metadata for reproducibility.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Methodology {
    pub iterations: usize,
    pub warmup: usize,
    pub row_scales: Vec<usize>,
    pub ordering: String,
    pub statistical_tests: Vec<String>,
    /// Short label for the timing mode (e.g. `raw-wallclock`,
    /// `explain-analyze`, `both`). Reviewers can see at a glance which
    /// mechanism produced the reported numbers.
    #[serde(default)]
    pub timing_mode: String,
    /// Short label for the cache mode (`warm`, `cold`, `both`).
    #[serde(default)]
    pub cache_mode: String,
    /// Build profile of the benchmark harness itself. Raw wall-clock timing
    /// includes client-side row draining, so debug harness binaries can
    /// materially inflate timings for high-output workloads.
    #[serde(default)]
    pub harness_profile: String,
    /// Whether each logical accel/baseline pair used one PostgreSQL backend.
    /// This is restricted to planner-native non-inferiority measurements.
    #[serde(default)]
    pub native_parity_pairing: bool,
    /// Raw executions of each arm contributing to one native-parity pair.
    #[serde(default)]
    pub native_parity_repetitions_per_arm: usize,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
#[allow(clippy::struct_excessive_bools)]
pub struct DispatchClassification {
    pub plan_selected: bool,
    pub gpu_kernel_dispatched: bool,
    pub function_srf_kernel_dispatched: bool,
    pub planner_declined: bool,
    pub custom_scan_selected_not_dispatched: bool,
    pub function_kernel_count: u64,
    pub rows_returned_to_cpu: u64,
    pub gpu_resident_pipeline: GpuResidentPipelineStatus,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize, Default)]
#[serde(rename_all = "snake_case")]
pub enum GpuResidentPipelineStatus {
    /// No explicit GPU-resident pipeline evidence was available in the
    /// captured plan artifacts.
    #[default]
    NotReported,
    /// Captured plan text explicitly reported that the selected path still
    /// crosses a CPU/PostgreSQL boundary before final output.
    NotResident,
    /// Captured plan text exposed explicit fused/PreAgg pipeline evidence.
    Reported,
    /// The row was credited through a function/SRF kernel rather than a
    /// Custom Scan pipeline.
    NotApplicableFunctionSrf,
    /// PostgreSQL planned the query natively, so no pg_accel pipeline exists.
    PlannerDeclined,
    /// A pg_accel Custom Scan was selected but runtime dispatch was not
    /// proven.
    SelectedNotDispatched,
}

impl GpuResidentPipelineStatus {
    const fn as_str(self) -> &'static str {
        match self {
            Self::NotReported => "not_reported",
            Self::NotResident => "not_resident",
            Self::Reported => "reported",
            Self::NotApplicableFunctionSrf => "not_applicable_function_srf",
            Self::PlannerDeclined => "planner_declined",
            Self::SelectedNotDispatched => "selected_not_dispatched",
        }
    }
}

/// Thermal state captured before a workload runs (action_items M13 /
/// Reviewer 1 Sin #18). Used to flag workloads that ran under thermal
/// throttling.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ThermalState {
    /// `CPU_Scheduler_Limit` from `pmset -g therm` on macOS (percentage;
    /// < 100 means throttled).
    pub cpu_scheduler_limit: Option<u32>,
    /// `CPU_Speed_Limit` from `pmset -g therm` on macOS (percentage;
    /// < 100 means throttled).
    pub cpu_speed_limit: Option<u32>,
    /// Raw tool output (truncated to ~400 bytes) for archival purposes.
    pub raw: String,
    /// True if either scheduler or speed limit was below 100 at capture.
    pub pressure: bool,
}

/// Post-`VACUUM (ANALYZE)` statistics for a benchmark table.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct TableStats {
    pub relname: String,
    pub relpages: i64,
    pub reltuples: f64,
    /// Max `n_distinct` across all columns in the table. Handy summary of
    /// whether the stats collector thinks the columns are selective.
    pub max_n_distinct: f64,
}

/// Cumulative counters from PostgreSQL's `pg_stat_checkpointer` view.
/// Exact equality across a measured interval proves that no timed or
/// requested checkpoint started or completed while timings were collected.
#[derive(Debug, Clone, Default, PartialEq, Serialize, Deserialize)]
pub struct CheckpointerSnapshot {
    pub num_timed: u64,
    pub num_requested: u64,
    pub num_done: u64,
    pub restartpoints_timed: u64,
    pub restartpoints_requested: u64,
    pub restartpoints_done: u64,
    pub write_time_ms: f64,
    pub sync_time_ms: f64,
    pub buffers_written: u64,
    pub slru_written: u64,
}

/// Database-I/O quiescence proof surrounding one workload's timed interval.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct SetupQuiescenceAudit {
    pub schema_version: u32,
    pub checkpoint_completed: bool,
    pub checkpoint_completed_at: String,
    pub checkpoint_wal_lsn: String,
    pub measurement_completed_at: String,
    pub measurement_completed_wal_lsn: String,
    pub checkpointer_before: CheckpointerSnapshot,
    pub checkpointer_after: CheckpointerSnapshot,
    pub checkpointer_unchanged: bool,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SanityCheck {
    pub label: String,
    pub count: i64,
    pub passed: bool,
}

impl WorkloadResult {
    /// Build aggregated result from raw iterations (two-way: accel vs parallel),
    /// populating kernel class, dispatch status, and per-percentile statistics.
    /// dispatch status, and all per-percentile statistics.
    #[allow(clippy::too_many_arguments)]
    pub fn from_iterations(
        name: String,
        description: String,
        category: String,
        kernel_class: String,
        rows: usize,
        iterations: Vec<IterationResult>,
        gpu_kernel_dispatched: bool,
    ) -> Self {
        // Partition by cache state so summary stats are never computed over a
        // bimodal warm+cold mixture (CacheMode::Both). Each subsample gets its
        // own summary; when both are present the flat top-level fields below
        // describe the WARM subsample (the steady-state headline) rather than
        // the pooled mixture, so nothing downstream can cite a mixed median.
        let warm_iters: Vec<IterationResult> = iterations
            .iter()
            .filter(|i| i.cache_state == CacheState::Warm)
            .cloned()
            .collect();
        let cold_iters: Vec<IterationResult> = iterations
            .iter()
            .filter(|i| i.cache_state == CacheState::Cold)
            .cloned()
            .collect();
        let warm_summary = CacheModeSummary::from_iterations(CacheState::Warm, &warm_iters);
        let cold_summary = CacheModeSummary::from_iterations(CacheState::Cold, &cold_iters);

        // Primary subsample for the flat top-level statistics: when the run
        // mixed warm and cold (Both), use warm only; otherwise use everything
        // (a homogeneous single-mode run).
        let primary: &[IterationResult] = if !warm_iters.is_empty() && !cold_iters.is_empty() {
            &warm_iters
        } else {
            &iterations
        };

        let accel_times: Vec<f64> = primary.iter().map(|i| i.accel_ms).collect();
        let parallel_times: Vec<f64> = primary.iter().map(|i| i.parallel_ms).collect();

        let accel_mean = stats::mean(&accel_times);
        let parallel_mean = stats::mean(&parallel_times);
        let accel_median = stats::median(&accel_times);
        let parallel_median = stats::median(&parallel_times);

        let speedup_vs_parallel = if accel_mean > 0.0 {
            parallel_mean / accel_mean
        } else {
            f64::NAN
        };
        let speedup_median_vs_parallel = if accel_median > 0.0 {
            parallel_median / accel_median
        } else {
            f64::NAN
        };

        let cohens_d = stats::cohens_d(&parallel_times, &accel_times);
        let effect_size_meaningful = cohens_d.is_finite() && cohens_d.abs() >= 0.5;

        let cv_a = stats::cv_percent(&accel_times);
        let cv_p = stats::cv_percent(&parallel_times);
        let cv_ratio = if cv_a.is_finite() && cv_p.is_finite() && cv_a > 0.0 && cv_p > 0.0 {
            cv_a.max(cv_p) / cv_a.min(cv_p)
        } else {
            f64::NAN
        };

        Self {
            name,
            description,
            category,
            kernel_class,
            rows,
            plan_selected: gpu_kernel_dispatched,
            gpu_kernel_dispatched,
            function_srf_kernel_dispatched: false,
            planner_declined: false,
            custom_scan_selected_not_dispatched: false,
            function_kernel_count: 0,
            rows_returned_to_cpu: 0,
            gpu_resident_pipeline: GpuResidentPipelineStatus::NotReported,
            gpu_resident_boundary_reason: None,
            native_post_aggregate_filter: None,
            warmup_iterations: Vec::new(),
            warmup_accel_first_ms: None,
            warmup_accel_max_ms: None,
            warmup_accel_post_first_max_ms: None,
            warmup_parallel_first_ms: None,
            warmup_parallel_max_ms: None,
            dispatch_counter_captured: false,
            gpu_kernel_execution_delta: 0,
            pg_accel_queries_accelerated_delta: 0,
            pg_accel_rows_dispatched_delta: 0,
            pg_accel_batches_executed_delta: 0,
            pg_accel_gpu_rows_processed_delta: 0,
            pg_accel_stock_exec_delta: 0,
            physical_kernel_mode_counts: PhysicalKernelModeCounts::default(),
            physical_kernel_mode: None,
            physical_kernel_mode_verified: false,
            accel_output_rows_consumed: 0,
            dispatch_counter_error: None,
            accel_mean_ms: accel_mean,
            accel_stddev_ms: stats::stddev(&accel_times),
            accel_median_ms: accel_median,
            accel_p25_ms: stats::percentile(&accel_times, 25.0),
            accel_p75_ms: stats::percentile(&accel_times, 75.0),
            accel_p95_ms: stats::percentile(&accel_times, 95.0),
            accel_cv_pct: cv_a,
            accel_ci_95: stats::confidence_interval_95(&accel_times),
            accel_outliers: stats::detect_outliers(&accel_times, 3.0),
            accel_min_ms: stats::min(&accel_times),
            accel_max_ms: stats::max(&accel_times),
            parallel_mean_ms: parallel_mean,
            parallel_stddev_ms: stats::stddev(&parallel_times),
            parallel_median_ms: parallel_median,
            parallel_p25_ms: stats::percentile(&parallel_times, 25.0),
            parallel_p75_ms: stats::percentile(&parallel_times, 75.0),
            parallel_p95_ms: stats::percentile(&parallel_times, 95.0),
            parallel_cv_pct: cv_p,
            parallel_ci_95: stats::confidence_interval_95(&parallel_times),
            parallel_outliers: stats::detect_outliers(&parallel_times, 3.0),
            parallel_min_ms: stats::min(&parallel_times),
            parallel_max_ms: stats::max(&parallel_times),
            speedup_vs_parallel,
            speedup_median_vs_parallel,
            p_value_vs_parallel: stats::paired_t_test_p(&accel_times, &parallel_times),
            cohens_d_vs_parallel: cohens_d,
            effect_size_meaningful,
            cv_ratio,
            plan_snippet: None,
            baseline_plan_snippet: None,
            correctness_diff_artifact: None,
            setup_quiescence: None,
            thermal: None,
            table_stats: Vec::new(),
            sanity_checks: Vec::new(),
            resident_load_ms: None,
            resident_lane: false,
            native_decline_evidence: None,
            warm_summary,
            combined_warm_summary: warm_summary,
            cold_summary,
            cold_shared_buffers_resident: None,
            iterations,
            planner_stage_captures: Vec::new(),
            native_parity_pair_captures: Vec::new(),
            artifact_lifecycle_probe: None,
            artifact_steady_state_captures: Vec::new(),
        }
    }

    pub fn set_warmup_iterations(&mut self, warmup_iterations: Vec<IterationResult>) {
        self.warmup_accel_first_ms = warmup_iterations
            .first()
            .map(|iteration| iteration.accel_ms);
        self.warmup_accel_max_ms = max_iteration_value(&warmup_iterations, |i| i.accel_ms);
        self.warmup_accel_post_first_max_ms =
            max_iteration_value(warmup_iterations.get(1..).unwrap_or(&[]), |i| i.accel_ms);
        self.warmup_parallel_first_ms = warmup_iterations
            .first()
            .map(|iteration| iteration.parallel_ms);
        self.warmup_parallel_max_ms = max_iteration_value(&warmup_iterations, |i| i.parallel_ms);
        self.warmup_iterations = warmup_iterations;
    }

    #[must_use]
    pub fn dispatch_classification(&self) -> DispatchClassification {
        infer_dispatch_classification(self, None)
    }

    fn dispatch_classification_with_plan_artifact(
        &self,
        full_plan: Option<&str>,
    ) -> DispatchClassification {
        infer_dispatch_classification(self, full_plan)
    }

    fn apply_dispatch_classification(&mut self, classification: DispatchClassification) {
        self.plan_selected = classification.plan_selected;
        self.gpu_kernel_dispatched = classification.gpu_kernel_dispatched;
        self.function_srf_kernel_dispatched = classification.function_srf_kernel_dispatched;
        self.planner_declined = classification.planner_declined;
        self.custom_scan_selected_not_dispatched =
            classification.custom_scan_selected_not_dispatched;
        self.function_kernel_count = classification.function_kernel_count;
        self.rows_returned_to_cpu = classification.rows_returned_to_cpu;
        self.gpu_resident_pipeline = classification.gpu_resident_pipeline;
    }
}

/// Map an exact workload name to its declarative kernel class.
#[must_use]
pub fn classify_kernel(name: &str) -> String {
    crate::workloads::workload_metadata(name).map_or_else(
        || "unclassified".to_owned(),
        |metadata| metadata.kernel_class.as_str().to_owned(),
    )
}

impl HardwareProfile {
    /// Auto-detect the current hardware profile.
    #[must_use]
    pub fn detect() -> Self {
        Self {
            os: detect_os(),
            os_version: detect_os_version(),
            arch: std::env::consts::ARCH.to_owned(),
            cpu: detect_cpu(),
            cpu_cores: detect_cpu_cores(),
            memory_gb: detect_memory(),
        }
    }
}

impl GucSettings {
    /// Query PostgreSQL for benchmark-relevant GUC settings.
    ///
    /// # Errors
    ///
    /// Returns an error if the connection or query fails.
    pub fn from_connection(connection: &str) -> Result<Self, Box<dyn std::error::Error>> {
        let mut client = postgres::Client::connect(connection, postgres::NoTls)?;
        let guc_names = [
            "pg_accel.enabled",
            "pg_accel.gpu_enabled",
            "pg_accel.min_batch_size",
            "pg_accel.kernel_timeout_ms",
            "max_parallel_workers_per_gather",
            "max_parallel_workers",
            "parallel_setup_cost",
            "parallel_tuple_cost",
            "work_mem",
            "shared_buffers",
            "effective_cache_size",
            "server_version",
        ];

        let mut settings = Vec::new();
        for name in &guc_names {
            let query = format!("SHOW {name}");
            if let Ok(Some(row)) = client.query_opt(&query, &[]) {
                let val: String = row.get(0);
                settings.push(((*name).to_owned(), val));
            }
        }
        Ok(Self { settings })
    }
}

/// Format row count for display: 1000 → "1K", 1000000 → "1M".
fn format_rows(rows: usize) -> String {
    match rows {
        r if r >= 1_000_000 && r % 1_000_000 == 0 => format!("{}M", r / 1_000_000),
        r if r >= 1_000 && r % 1_000 == 0 => format!("{}K", r / 1_000),
        r => r.to_string(),
    }
}

/// Format a p-value for the detail table.
///
/// Action_items C10 / Reviewer 1 Sin #20: print ≥6 significant figures in
/// scientific notation (`2.34e-08`, not `0.0000`). For numerical
/// underflow (raw p ≤ 1e-300), print `<1e-300`.
#[must_use]
pub fn format_pvalue(p: f64) -> String {
    if p.is_nan() {
        return "NaN".to_owned();
    }
    if p >= 1.0 {
        return "1.00".to_owned();
    }
    if p <= 1e-300 {
        return "<1e-300".to_owned();
    }
    format!("{p:.6e}")
}

/// Short wins/losses/ties decomposition of the workload set.
#[derive(Debug, Clone, Copy, Default)]
struct SignificanceCounts {
    sig_wins: usize,
    sig_losses: usize,
    total_sig: usize,
    not_significant: usize,
    effect_rejected: usize,
}

/// Compute wins/losses/ties over a slice of workloads, using
/// Bonferroni-corrected p and the |d| >= 0.5 effect-size gate. Crashed
/// scales are accounted for by the caller (they feed the family size but
/// are NOT in this slice).
fn classify_significance(
    workloads: &[&WorkloadResult],
    family_size: usize,
    alpha: f64,
) -> SignificanceCounts {
    let mut c = SignificanceCounts::default();
    for w in workloads {
        let adj = stats::bonferroni_adjusted_p(w.p_value_vs_parallel, family_size);
        let cohens_abs = w.cohens_d_vs_parallel.abs();
        let sig = adj.is_finite() && adj < alpha;
        if !sig {
            c.not_significant += 1;
            continue;
        }
        if cohens_abs < 0.5 {
            // action_items C9: Bonferroni-significant but the effect is
            // not meaningful. Report it but do NOT count it as a win or
            // loss.
            c.effect_rejected += 1;
            continue;
        }
        c.total_sig += 1;
        if w.speedup_vs_parallel > 1.0 {
            c.sig_wins += 1;
        } else {
            c.sig_losses += 1;
        }
    }
    c
}

fn infer_dispatch_classification(
    w: &WorkloadResult,
    full_plan: Option<&str>,
) -> DispatchClassification {
    let snippet = w.plan_snippet.as_deref().unwrap_or_default();
    let plan_selected = w.plan_selected
        || plan_contains_custom_scan_marker(snippet)
        || full_plan.is_some_and(plan_contains_custom_scan_marker);
    let explicit_gpu_dispatch_disabled = plan_explicit_gpu_dispatched(snippet) == Some(false)
        || full_plan.and_then(plan_explicit_gpu_dispatched) == Some(false);
    let counter_capture_known = w.dispatch_counter_captured;
    let counter_proves_kernel = w.gpu_kernel_execution_delta > 0;
    let function_candidate = known_function_srf_kernel_workload(w);
    let output_consumed = w.accel_output_rows_consumed > 0;
    let selected_queries_consumed = usize::try_from(w.pg_accel_queries_accelerated_delta)
        .is_ok_and(|queries| queries >= w.iterations.len());
    let lifecycle_artifact_reuse_credited = plan_selected
        && !explicit_gpu_dispatch_disabled
        && !counter_proves_kernel
        && derived_output_artifact_reuse_evidence_error(w).is_none();
    let function_srf_kernel_dispatched = function_candidate
        && !explicit_gpu_dispatch_disabled
        && !plan_selected
        && counter_capture_known
        && counter_proves_kernel
        && output_consumed
        && w.pg_accel_stock_exec_delta == 0;

    let custom_scan_gpu_dispatched = plan_selected
        && counter_capture_known
        && !explicit_gpu_dispatch_disabled
        && counter_proves_kernel
        && selected_queries_consumed
        && output_consumed
        && w.pg_accel_stock_exec_delta == 0;

    let gpu_kernel_dispatched = custom_scan_gpu_dispatched
        || function_srf_kernel_dispatched
        || lifecycle_artifact_reuse_credited;
    let custom_scan_selected_not_dispatched = plan_selected && !gpu_kernel_dispatched;
    let planner_declined = !plan_selected && !function_srf_kernel_dispatched;
    let function_kernel_count = if function_srf_kernel_dispatched {
        w.gpu_kernel_execution_delta
    } else {
        0
    };
    let rows_returned_to_cpu = w.accel_output_rows_consumed;
    let gpu_resident_pipeline = classify_gpu_resident_pipeline_status(
        w,
        full_plan,
        plan_selected,
        gpu_kernel_dispatched,
        function_srf_kernel_dispatched,
        planner_declined,
        custom_scan_selected_not_dispatched,
    );

    DispatchClassification {
        plan_selected,
        gpu_kernel_dispatched,
        function_srf_kernel_dispatched,
        planner_declined,
        custom_scan_selected_not_dispatched,
        function_kernel_count,
        rows_returned_to_cpu,
        gpu_resident_pipeline,
    }
}

#[allow(clippy::fn_params_excessive_bools)]
fn classify_gpu_resident_pipeline_status(
    w: &WorkloadResult,
    full_plan: Option<&str>,
    plan_selected: bool,
    gpu_kernel_dispatched: bool,
    function_srf_kernel_dispatched: bool,
    planner_declined: bool,
    custom_scan_selected_not_dispatched: bool,
) -> GpuResidentPipelineStatus {
    if function_srf_kernel_dispatched {
        return GpuResidentPipelineStatus::NotApplicableFunctionSrf;
    }
    if planner_declined {
        return GpuResidentPipelineStatus::PlannerDeclined;
    }
    if custom_scan_selected_not_dispatched {
        return GpuResidentPipelineStatus::SelectedNotDispatched;
    }
    if !plan_selected || !gpu_kernel_dispatched {
        return GpuResidentPipelineStatus::NotReported;
    }
    let snippet = w.plan_snippet.as_deref().unwrap_or_default();
    let resident_scan_evidence = full_plan
        .map(plan_custom_scan_resident_evidence)
        .filter(|status| *status != CustomScanResidentEvidence::NoCustomScan)
        .unwrap_or_else(|| plan_custom_scan_resident_evidence(snippet));
    match resident_scan_evidence {
        CustomScanResidentEvidence::AllResident => return GpuResidentPipelineStatus::Reported,
        CustomScanResidentEvidence::NonResident => return GpuResidentPipelineStatus::NotResident,
        CustomScanResidentEvidence::MissingEvidence => {}
        CustomScanResidentEvidence::NoCustomScan => {
            if plan_contains_gpu_resident_pipeline_evidence(snippet)
                || full_plan.is_some_and(plan_contains_gpu_resident_pipeline_evidence)
            {
                return GpuResidentPipelineStatus::Reported;
            }
        }
    }
    if plan_gpu_resident_pipeline_value(snippet) == Some(false)
        || full_plan.and_then(plan_gpu_resident_pipeline_value) == Some(false)
        || extract_gpu_resident_boundary_reason(snippet).is_some()
        || full_plan
            .and_then(extract_gpu_resident_boundary_reason)
            .is_some()
        || infer_gpu_resident_boundary_reason_from_plan(snippet).is_some()
        || full_plan
            .and_then(infer_gpu_resident_boundary_reason_from_plan)
            .is_some()
        || infer_gpu_resident_boundary_reason_from_workload(w).is_some()
    {
        return GpuResidentPipelineStatus::NotResident;
    }
    GpuResidentPipelineStatus::NotReported
}

fn known_function_srf_kernel_workload(w: &WorkloadResult) -> bool {
    is_function_kernel_candidate(&w.name, &w.category, &w.kernel_class, &w.description)
}

#[must_use]
pub fn is_function_kernel_candidate(
    name: &str,
    category: &str,
    kernel_class: &str,
    description: &str,
) -> bool {
    if let Some(metadata) = crate::workloads::workload_metadata(name) {
        return metadata.evidence.function_kernel();
    }

    // Preserve classification for reports produced by older binaries whose
    // workload is no longer present in the current exact-name registry.
    let name = name.to_ascii_lowercase();
    let category = category.to_ascii_lowercase();
    let kernel = kernel_class.to_ascii_lowercase();
    name.starts_with("h3_")
        || name.contains("_h3_")
        || name.starts_with("raster_")
        || category == "gpu_h3"
        || category == "gpu_raster"
        || kernel.starts_with("h3")
        || kernel.starts_with("raster")
        || description.to_ascii_lowercase().contains("h3_")
        || description.to_ascii_lowercase().contains("st_mapalgebra")
        || description.to_ascii_lowercase().contains("st_slope")
        || description.to_ascii_lowercase().contains("st_reclass")
}

#[allow(dead_code)]
fn workload_or_plan_mentions_accel_function(w: &WorkloadResult, text: &str) -> bool {
    let haystack = format!(
        "{}\n{}\n{}",
        w.name.to_ascii_lowercase(),
        w.description.to_ascii_lowercase(),
        text.to_ascii_lowercase()
    );
    FUNCTION_SRF_GPU_FUNCTIONS
        .iter()
        .any(|function| haystack.contains(function))
}

fn extract_full_plan_block(plans: &str, workload: &str, rows: usize) -> Option<String> {
    let header = format!("=== {workload} @ rows={rows} ===");
    let start = plans.find(&header)?;
    let body = plans.get(start + header.len()..)?;
    let end = body.find("\n=== ").unwrap_or(body.len());
    let block = body.get(..end)?.trim();
    (!block.is_empty()).then(|| block.to_owned())
}

fn no_dispatch_anomaly(w: &WorkloadResult) -> bool {
    both_modes_appear_non_dispatching(w)
        && (no_dispatch_timing_skew(w) || no_dispatch_plan_mismatch(w))
}

fn both_modes_appear_non_dispatching(w: &WorkloadResult) -> bool {
    !w.dispatch_classification().gpu_kernel_dispatched && !baseline_plan_dispatches(w)
}

fn baseline_plan_dispatches(w: &WorkloadResult) -> bool {
    w.baseline_plan_snippet
        .as_deref()
        .is_some_and(plan_contains_custom_scan_marker)
}

fn no_dispatch_timing_skew(w: &WorkloadResult) -> bool {
    if !both_modes_appear_non_dispatching(w) {
        return false;
    }
    timing_skew_fraction(no_dispatch_speedup(w))
        .is_some_and(|skew| skew >= NO_DISPATCH_TIMING_SKEW_THRESHOLD)
}

fn no_dispatch_plan_mismatch(w: &WorkloadResult) -> bool {
    if !both_modes_appear_non_dispatching(w) {
        return false;
    }
    let Some(accel_plan) = w.plan_snippet.as_deref() else {
        return false;
    };
    let Some(baseline_plan) = w.baseline_plan_snippet.as_deref() else {
        return false;
    };
    let accel_sig = plan_shape_signature(accel_plan);
    let baseline_sig = plan_shape_signature(baseline_plan);
    !accel_sig.is_empty() && !baseline_sig.is_empty() && accel_sig != baseline_sig
}

fn no_dispatch_speedup(w: &WorkloadResult) -> f64 {
    if w.speedup_median_vs_parallel.is_finite() && w.speedup_median_vs_parallel > 0.0 {
        w.speedup_median_vs_parallel
    } else {
        w.speedup_vs_parallel
    }
}

fn timing_skew_fraction(speedup: f64) -> Option<f64> {
    if !speedup.is_finite() || speedup <= 0.0 {
        return None;
    }
    Some(if speedup >= 1.0 {
        speedup - 1.0
    } else {
        (1.0 / speedup) - 1.0
    })
}

fn plan_contains_custom_scan_marker(plan: &str) -> bool {
    plan.contains("Custom Scan")
}

fn plan_explicit_gpu_dispatched(plan: &str) -> Option<bool> {
    let lower = plan.to_ascii_lowercase();
    if lower.contains("gpu dispatched: false")
        || lower.contains("gpu kernel dispatched: false")
        || lower.contains("\"gpu dispatched\": false")
        || lower.contains("\"gpu dispatched\":false")
        || lower.contains("\"gpu dispatched\":\"false\"")
        || lower.contains("\"gpu dispatched\": \"false\"")
        || lower.contains("\"gpu kernel dispatched\": false")
        || lower.contains("\"gpu kernel dispatched\":false")
        || lower.contains("\"gpu kernel dispatched\":\"false\"")
        || lower.contains("\"gpu kernel dispatched\": \"false\"")
    {
        Some(false)
    } else if lower.contains("gpu dispatched: true")
        || lower.contains("gpu kernel dispatched: true")
        || lower.contains("\"gpu dispatched\": true")
        || lower.contains("\"gpu dispatched\":true")
        || lower.contains("\"gpu dispatched\":\"true\"")
        || lower.contains("\"gpu dispatched\": \"true\"")
        || lower.contains("\"gpu kernel dispatched\": true")
        || lower.contains("\"gpu kernel dispatched\":true")
        || lower.contains("\"gpu kernel dispatched\":\"true\"")
        || lower.contains("\"gpu kernel dispatched\": \"true\"")
    {
        Some(true)
    } else {
        None
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
enum CustomScanResidentEvidence {
    NoCustomScan,
    AllResident,
    NonResident,
    MissingEvidence,
}

fn plan_custom_scan_resident_evidence(plan: &str) -> CustomScanResidentEvidence {
    let blocks = pg_accel_custom_scan_blocks(plan);
    if blocks.is_empty() {
        return CustomScanResidentEvidence::NoCustomScan;
    }

    let mut missing = false;
    for block in blocks {
        let direct_lines = direct_custom_scan_property_lines(&block);
        let direct_text = direct_lines.join("\n");
        if plan_contains_gpu_resident_pipeline_evidence(&direct_text) {
            continue;
        }
        if plan_gpu_resident_pipeline_value(&direct_text) == Some(false)
            || extract_gpu_resident_boundary_reason(&direct_text).is_some()
            || infer_gpu_resident_boundary_reason_from_plan(&direct_text).is_some()
        {
            return CustomScanResidentEvidence::NonResident;
        }
        missing = true;
    }

    if missing {
        CustomScanResidentEvidence::MissingEvidence
    } else {
        CustomScanResidentEvidence::AllResident
    }
}

fn pg_accel_custom_scan_blocks(plan: &str) -> Vec<Vec<&str>> {
    let lines: Vec<&str> = plan.lines().collect();
    let mut blocks = Vec::new();
    for (idx, line) in lines.iter().enumerate() {
        let trimmed = line.trim_start_matches([' ', '-', '>']).trim_start();
        if !(trimmed.starts_with("Custom Scan (") && trimmed.contains("GpuAccel")) {
            continue;
        }
        let depth = custom_scan_leading_indent(line);
        let mut block = vec![*line];
        for next in lines.iter().skip(idx + 1) {
            if next.trim().is_empty() {
                continue;
            }
            let next_depth = custom_scan_leading_indent(next);
            if next_depth <= depth {
                break;
            }
            block.push(*next);
        }
        blocks.push(block);
    }
    blocks
}

fn direct_custom_scan_property_lines<'a>(block: &[&'a str]) -> Vec<&'a str> {
    let Some(parent_depth) = block.first().map(|line| custom_scan_leading_indent(line)) else {
        return Vec::new();
    };
    let direct_depth = block
        .iter()
        .skip(1)
        .filter(|line| !line.trim().is_empty())
        .map(|line| custom_scan_leading_indent(line))
        .filter(|depth| *depth > parent_depth)
        .min();
    let Some(direct_depth) = direct_depth else {
        return Vec::new();
    };
    block
        .iter()
        .skip(1)
        .copied()
        .filter(|line| custom_scan_leading_indent(line) == direct_depth)
        .collect()
}

fn custom_scan_leading_indent(line: &str) -> usize {
    line.chars()
        .take_while(|ch| matches!(ch, ' ' | '-' | '>'))
        .count()
}

fn plan_contains_gpu_resident_pipeline_evidence(plan: &str) -> bool {
    if plan_gpu_resident_pipeline_value(plan) == Some(true) {
        return plan_contains_resident_proof_evidence(plan);
    }
    if plan_gpu_resident_pipeline_value(plan) == Some(false) {
        return false;
    }
    let lower = plan.to_ascii_lowercase();
    (lower.contains("gpu resident pipeline: true")
        || lower.contains("gpu-resident pipeline: true")
        || lower.contains("gpu_resident_pipeline: true")
        || lower.contains("\"gpu resident pipeline\": true")
        || lower.contains("\"gpu resident pipeline\":true")
        || lower.contains("\"gpu_resident_pipeline\": true")
        || lower.contains("\"gpu_resident_pipeline\":true")
        || lower.contains("pipeline fusion: true"))
        && plan_contains_resident_proof_evidence(plan)
}

fn plan_contains_resident_proof_evidence(plan: &str) -> bool {
    let version = plan_integer_property(
        plan,
        &["gpu resident proof version", "gpu_resident_proof_version"],
    );
    let stage_mask = plan_integer_property(
        plan,
        &["gpu resident stage mask", "gpu_resident_stage_mask"],
    );
    let device_columns = plan_integer_property(
        plan,
        &["gpu resident device columns", "gpu_resident_device_columns"],
    );
    let operator_class = plan_text_property(
        plan,
        &["gpu resident operator class", "gpu_resident_operator_class"],
    );
    version.is_some_and(|version| version >= 2)
        && operator_class.is_some_and(|class| !class.eq_ignore_ascii_case("unspecified"))
        && stage_mask.is_some_and(|mask| mask > 0)
        && device_columns.is_some_and(|cols| cols > 0)
}

fn threshold_lane_requires_resident_groupagg_logical_spec(lane: &str) -> bool {
    lane.starts_with("resident_dense_groupagg")
        || lane.starts_with("resident_dictionary_groupagg")
        || lane.starts_with("resident_f64_reduce")
        || lane.starts_with("ssbm_q")
        || lane.starts_with("h3_latlng_to_cell_grouped_")
        || lane.starts_with("h3_cell_to_parent_grouped_count_")
        || lane == "hashjoin_filter_groupagg"
        || lane == "hashjoin_groupagg_exact_sum_count"
        || lane == "ssbm_resident_int4_year_size_revenue"
}

fn plan_contains_resident_groupagg_logical_evidence(plan: &str) -> bool {
    let operator_class = plan_text_property(
        plan,
        &["gpu resident operator class", "gpu_resident_operator_class"],
    );
    let key = plan_text_property(
        plan,
        &["gpu resident groupagg key", "gpu_resident_groupagg_key"],
    );
    let measure = plan_text_property(
        plan,
        &[
            "gpu resident groupagg measure",
            "gpu_resident_groupagg_measure",
        ],
    );
    let filter = plan_text_property(
        plan,
        &[
            "gpu resident groupagg filter",
            "gpu_resident_groupagg_filter",
        ],
    );
    let predicate_guard = plan_text_property(
        plan,
        &[
            "gpu resident groupagg predicate guard",
            "gpu_resident_groupagg_predicate_guard",
        ],
    );
    let value_predicate = plan_text_property(
        plan,
        &[
            "gpu resident groupagg value predicate",
            "gpu_resident_groupagg_value_predicate",
        ],
    );
    let predicate_ir = plan_text_property(
        plan,
        &[
            "gpu resident groupagg predicate ir",
            "gpu_resident_groupagg_predicate_ir",
        ],
    );
    let aggregate_mask = plan_integer_property(
        plan,
        &[
            "gpu resident groupagg aggregate mask",
            "gpu_resident_groupagg_aggregate_mask",
        ],
    );
    let resident_groupagg =
        operator_class.is_some_and(|class| class.eq_ignore_ascii_case("resident_groupagg"));
    let legacy_logical_spec = key.is_some_and(|key| !key.eq_ignore_ascii_case("unspecified"))
        && measure.is_some_and(|measure| !measure.eq_ignore_ascii_case("unspecified"))
        && filter.is_some_and(|filter| !filter.eq_ignore_ascii_case("unspecified"))
        && predicate_guard.is_some_and(|guard| !guard.eq_ignore_ascii_case("unspecified"))
        && value_predicate.is_some_and(|predicate| !predicate.eq_ignore_ascii_case("unspecified"))
        && predicate_ir.is_some_and(|ir| !ir.eq_ignore_ascii_case("unspecified"))
        && aggregate_mask.is_some_and(|mask| mask > 0);

    let descriptor_strategy = plan_text_property(
        plan,
        &["gpu descriptor strategy", "gpu_descriptor_strategy"],
    );
    let descriptor_group_keys = plan_text_property(
        plan,
        &["gpu descriptor group keys", "gpu_descriptor_group_keys"],
    );
    let descriptor_aggregates = plan_text_property(
        plan,
        &["gpu descriptor aggregates", "gpu_descriptor_aggregates"],
    );
    let descriptor_filter =
        plan_text_property(plan, &["gpu descriptor filter", "gpu_descriptor_filter"]);
    let descriptor_output =
        plan_text_property(plan, &["gpu descriptor output", "gpu_descriptor_output"]);
    let descriptor_logical_spec = descriptor_strategy
        .is_some_and(|strategy| strategy.eq_ignore_ascii_case("descriptor_grouped_aggregate"))
        && descriptor_property_is_concrete(descriptor_group_keys, false)
        && descriptor_property_is_concrete(descriptor_aggregates, false)
        && descriptor_property_is_concrete(descriptor_filter, true)
        && descriptor_property_is_concrete(descriptor_output, false);

    resident_groupagg && (legacy_logical_spec || descriptor_logical_spec)
}

fn plan_contains_required_groupagg_logical_evidence(plan: &str, lane: &str) -> bool {
    if lane == "ssbm_resident_int4_year_size_revenue" {
        plan_contains_exact_ssbm_two_dimension_descriptor(plan)
    } else {
        plan_contains_resident_groupagg_logical_evidence(plan)
    }
}

fn plan_contains_exact_ssbm_two_dimension_descriptor(plan: &str) -> bool {
    let operator_class = plan_text_property(
        plan,
        &["gpu resident operator class", "gpu_resident_operator_class"],
    );
    let strategy = plan_text_property(
        plan,
        &["gpu descriptor strategy", "gpu_descriptor_strategy"],
    );
    let Some(group_keys) = plan_text_property(
        plan,
        &["gpu descriptor group keys", "gpu_descriptor_group_keys"],
    ) else {
        return false;
    };
    let Some(aggregates) = plan_text_property(
        plan,
        &["gpu descriptor aggregates", "gpu_descriptor_aggregates"],
    ) else {
        return false;
    };
    let Some(filter) =
        plan_text_property(plan, &["gpu descriptor filter", "gpu_descriptor_filter"])
    else {
        return false;
    };
    let Some(dimensions) = plan_text_property(
        plan,
        &[
            "gpu descriptor star dimensions",
            "gpu_descriptor_star_dimensions",
        ],
    ) else {
        return false;
    };
    let Some(output) =
        plan_text_property(plan, &["gpu descriptor output", "gpu_descriptor_output"])
    else {
        return false;
    };

    let Some(keys) = exact_indexed_descriptor_entries(&group_keys, "k", 2) else {
        return false;
    };
    let Some(measures) = exact_indexed_descriptor_entries(&aggregates, "m", 2) else {
        return false;
    };
    let Some(dims) = exact_indexed_descriptor_entries(&dimensions, "d", 2) else {
        return false;
    };
    let Some(slots) = exact_indexed_descriptor_entries(&output, "slot", 4) else {
        return false;
    };

    let keys = keys
        .into_iter()
        .map(str::to_ascii_lowercase)
        .collect::<Vec<_>>();
    let measures = measures
        .into_iter()
        .map(str::to_ascii_lowercase)
        .collect::<Vec<_>>();
    let dims = dims
        .into_iter()
        .map(str::to_ascii_lowercase)
        .collect::<Vec<_>>();
    let slots = slots
        .into_iter()
        .map(str::to_ascii_lowercase)
        .collect::<Vec<_>>();
    let filter = filter.to_ascii_lowercase();

    let Some(date_group) = parse_descriptor_dimension_group_key(&keys[0]) else {
        return false;
    };
    let Some(part_group) = parse_descriptor_dimension_group_key(&keys[1]) else {
        return false;
    };
    let parsed_dims = dims
        .iter()
        .map(|entry| parse_descriptor_star_dimension(entry))
        .collect::<Option<Vec<_>>>();
    let Some(parsed_dims) = parsed_dims else {
        return false;
    };
    let Some(date_dim) = parsed_dims.iter().find(|dimension| {
        dimension.fact_key.attno == 6
            && dimension.dim_key.attno == 1
            && dimension.fact_key.type_oid == 23
            && dimension.dim_key.type_oid == 23
    }) else {
        return false;
    };
    let Some(part_dim) = parsed_dims.iter().find(|dimension| {
        dimension.fact_key.attno == 4
            && dimension.dim_key.attno == 1
            && dimension.fact_key.type_oid == 23
            && dimension.dim_key.type_oid == 23
    }) else {
        return false;
    };
    let Some(sum_column) = parse_descriptor_column_measure(&measures[0]) else {
        return false;
    };
    let fact_oid = date_dim.fact_key.relation_oid;
    let date_oid = date_dim.relation_oid;
    let part_oid = part_dim.relation_oid;

    operator_class.is_some_and(|value| value.eq_ignore_ascii_case("resident_groupagg"))
        && strategy.is_some_and(|value| value.eq_ignore_ascii_case("descriptor_grouped_aggregate"))
        && date_group.dim_index == date_dim.dim_index
        && date_group.column.relation_oid == date_oid
        && date_group.column.attno == 5
        && date_group.column.type_oid == 23
        && date_group.type_oid == 23
        && date_group.collation_oid == 0
        && descriptor_i32_group_key_encoding_is_concrete(&date_group.encoding)
        && part_group.dim_index == part_dim.dim_index
        && part_group.column.relation_oid == part_oid
        && part_group.column.attno == 8
        && part_group.column.type_oid == 23
        && part_group.type_oid == 23
        && part_group.collation_oid == 0
        && descriptor_i32_group_key_encoding_is_concrete(&part_group.encoding)
        && fact_oid == part_dim.fact_key.relation_oid
        && date_oid == date_dim.dim_key.relation_oid
        && part_oid == part_dim.dim_key.relation_oid
        && fact_oid != date_oid
        && fact_oid != part_oid
        && date_oid != part_oid
        && sum_column.relation_oid == fact_oid
        && sum_column.attno == 13
        && sum_column.type_oid == 23
        && measures[0] == format!("m0:column({fact_oid}.13:type=23) -> value.sum")
        && measures[1] == "m1:count_star -> value.count"
        && filter == "fact=none; measures=[m0=none; m1=none]; dimensions=[d0=none; d1=none]"
        && slots[0]
            == "slot0:group[k0] source_type=23 result_type=23 typmod=-1 collation=0 nullable=false"
        && slots[1]
            == "slot1:group[k1] source_type=23 result_type=23 typmod=-1 collation=0 nullable=false"
        && slots[2]
            == "slot2:aggregate[m0].value.sum source_type=23 result_type=20 typmod=-1 collation=0 nullable=true"
        && slots[3]
            == "slot3:aggregate[m1].value.count source_type=0 result_type=20 typmod=-1 collation=0 nullable=false"
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
struct DescriptorColumnRef {
    relation_oid: u32,
    attno: i32,
    type_oid: u32,
}

#[derive(Debug, Clone, PartialEq, Eq)]
struct DescriptorDimensionGroupKey {
    dim_index: usize,
    column: DescriptorColumnRef,
    type_oid: u32,
    collation_oid: u32,
    encoding: String,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
struct DescriptorStarDimension {
    dim_index: usize,
    relation_oid: u32,
    fact_key: DescriptorColumnRef,
    dim_key: DescriptorColumnRef,
}

fn parse_descriptor_column(value: &str) -> Option<DescriptorColumnRef> {
    let (relation_and_attno, type_oid) = value.split_once(":type=")?;
    let (relation_oid, attno) = relation_and_attno.rsplit_once('.')?;
    Some(DescriptorColumnRef {
        relation_oid: relation_oid.parse().ok()?,
        attno: attno.parse().ok()?,
        type_oid: type_oid.parse().ok()?,
    })
}

fn parse_descriptor_dimension_group_key(entry: &str) -> Option<DescriptorDimensionGroupKey> {
    let (_, source) = entry.split_once(':')?;
    let source = source.strip_prefix("dimension[")?;
    let (dim_index, column) = source.split_once("](")?;
    let (column, fields) = column.split_once(") ")?;
    let fields = fields.strip_prefix("type=")?;
    let (type_oid, fields) = fields.split_once(" collation=")?;
    let (collation_oid, encoding) = fields.split_once(" encoding=")?;
    if encoding.is_empty() {
        return None;
    }
    Some(DescriptorDimensionGroupKey {
        dim_index: dim_index.parse().ok()?,
        column: parse_descriptor_column(column)?,
        type_oid: type_oid.parse().ok()?,
        collation_oid: collation_oid.parse().ok()?,
        encoding: encoding.to_owned(),
    })
}

fn parse_descriptor_star_dimension(entry: &str) -> Option<DescriptorStarDimension> {
    let (indexed, fields) = entry.split_once(':')?;
    let dim_index = indexed.strip_prefix('d')?.parse().ok()?;
    let mut fields = fields.split_whitespace();
    let relation_oid = fields.next()?.strip_prefix("rel=")?.parse().ok()?;
    let join = fields.next()?.strip_prefix("join=")?;
    let collation_oid = fields
        .next()?
        .strip_prefix("collation=")?
        .parse::<u32>()
        .ok()?;
    let multiplicity = fields.next()?.strip_prefix("multiplicity=")?;
    let filter = fields.next()?.strip_prefix("filter=")?;
    if fields.next().is_some() || collation_oid != 0 || multiplicity != "unique" || filter != "none"
    {
        return None;
    }
    let (fact_key, dim_key) = join.split_once("<->")?;
    Some(DescriptorStarDimension {
        dim_index,
        relation_oid,
        fact_key: parse_descriptor_column(fact_key)?,
        dim_key: parse_descriptor_column(dim_key)?,
    })
}

fn descriptor_i32_group_key_encoding_is_concrete(encoding: &str) -> bool {
    if encoding == "hash" {
        return true;
    }
    let Some((kind, fields)) = encoding.split_once('(') else {
        return false;
    };
    let Some(fields) = fields.strip_suffix(')') else {
        return false;
    };
    let fields = fields.split(", ").collect::<Vec<_>>();
    let valid_cardinality = |field: &str| {
        field
            .strip_prefix("cardinality=")
            .and_then(|value| value.parse::<usize>().ok())
            .is_some_and(|value| value > 0)
    };
    let valid_null = |field: &str| {
        field
            .strip_prefix("null=")
            .is_some_and(|value| value == "none" || value.parse::<i32>().is_ok())
    };
    match (kind, fields.as_slice()) {
        ("dense_i32", [minimum, cardinality, null]) => {
            minimum
                .strip_prefix("min=")
                .is_some_and(|value| value.parse::<i32>().is_ok())
                && valid_cardinality(cardinality)
                && valid_null(null)
        }
        ("dictionary_i32", [cardinality, null]) => {
            valid_cardinality(cardinality) && valid_null(null)
        }
        _ => false,
    }
}

fn parse_descriptor_column_measure(entry: &str) -> Option<DescriptorColumnRef> {
    let measure = entry.strip_prefix("m0:column(")?;
    let (column, _) = measure.split_once(')')?;
    parse_descriptor_column(column)
}

fn exact_indexed_descriptor_entries<'a>(
    value: &'a str,
    prefix: &str,
    expected: usize,
) -> Option<Vec<&'a str>> {
    let entries = value.split(';').map(str::trim).collect::<Vec<_>>();
    (entries.len() == expected
        && entries
            .iter()
            .enumerate()
            .all(|(index, entry)| entry.starts_with(&format!("{prefix}{index}:"))))
    .then_some(entries)
}

fn descriptor_property_is_concrete(value: Option<String>, allow_none: bool) -> bool {
    value.is_some_and(|value| {
        let value = value.trim();
        let lower = value.to_ascii_lowercase();
        !value.is_empty()
            && !value.eq_ignore_ascii_case("unspecified")
            && !lower.starts_with("not initialized")
            && (allow_none || !value.eq_ignore_ascii_case("none"))
    })
}

fn plan_integer_property(plan: &str, keys: &[&str]) -> Option<i64> {
    for line in plan.lines() {
        let trimmed = line.trim().trim_end_matches(',');
        let lower = trimmed.to_ascii_lowercase();
        for key in keys {
            let quoted_key = format!("\"{key}\"");
            let value = if lower.starts_with(key) {
                trimmed.split_once(':').map(|(_, value)| value)
            } else if lower.starts_with(&quoted_key) {
                trimmed.split_once(':').map(|(_, value)| value)
            } else {
                None
            };
            if let Some(value) = value.and_then(parse_plan_integer_value) {
                return Some(value);
            }
        }
    }
    json_integer_property(plan, keys)
}

fn plan_text_property(plan: &str, keys: &[&str]) -> Option<String> {
    for line in plan.lines() {
        let trimmed = line.trim().trim_end_matches(',');
        let lower = trimmed.to_ascii_lowercase();
        for key in keys {
            let quoted_key = format!("\"{key}\"");
            let value = if lower.starts_with(key) {
                trimmed.split_once(':').map(|(_, value)| value)
            } else if lower.starts_with(&quoted_key) {
                trimmed.split_once(':').map(|(_, value)| value)
            } else {
                None
            };
            if let Some(value) = value.and_then(parse_plan_text_value) {
                return Some(value);
            }
        }
    }
    json_string_property(plan, keys)
}

fn parse_plan_integer_value(value: &str) -> Option<i64> {
    value
        .trim()
        .trim_matches('"')
        .trim_end_matches('"')
        .trim()
        .parse()
        .ok()
}

fn parse_plan_text_value(value: &str) -> Option<String> {
    let value = value
        .trim()
        .trim_matches('"')
        .trim_end_matches('"')
        .trim()
        .to_owned();
    (!value.is_empty()).then_some(value)
}

fn json_bool_property(plan: &str, keys: &[&str]) -> Option<bool> {
    let value: serde_json::Value = serde_json::from_str(plan).ok()?;
    match json_find_property(&value, keys)? {
        serde_json::Value::Bool(value) => Some(*value),
        serde_json::Value::String(value) if value.eq_ignore_ascii_case("true") => Some(true),
        serde_json::Value::String(value) if value.eq_ignore_ascii_case("false") => Some(false),
        _ => None,
    }
}

fn json_integer_property(plan: &str, keys: &[&str]) -> Option<i64> {
    let value: serde_json::Value = serde_json::from_str(plan).ok()?;
    match json_find_property(&value, keys)? {
        serde_json::Value::Number(value) => value
            .as_i64()
            .or_else(|| value.as_u64().and_then(|value| i64::try_from(value).ok())),
        serde_json::Value::String(value) => value.parse().ok(),
        _ => None,
    }
}

fn json_string_property(plan: &str, keys: &[&str]) -> Option<String> {
    let value: serde_json::Value = serde_json::from_str(plan).ok()?;
    match json_find_property(&value, keys)? {
        serde_json::Value::String(value) => Some(value.clone()),
        other => Some(other.to_string()),
    }
}

fn json_find_property<'a>(
    value: &'a serde_json::Value,
    keys: &[&str],
) -> Option<&'a serde_json::Value> {
    match value {
        serde_json::Value::Object(map) => {
            for (key, child) in map {
                let key = key.to_ascii_lowercase();
                if keys.iter().any(|expected| key == *expected) {
                    return Some(child);
                }
            }
            map.values()
                .find_map(|child| json_find_property(child, keys))
        }
        serde_json::Value::Array(values) => values
            .iter()
            .find_map(|child| json_find_property(child, keys)),
        _ => None,
    }
}

fn plan_gpu_resident_pipeline_value(plan: &str) -> Option<bool> {
    if let Some(value) =
        json_bool_property(plan, &["gpu resident pipeline", "gpu_resident_pipeline"])
    {
        return Some(value);
    }
    let lower = plan.to_ascii_lowercase();
    if lower.contains("gpu resident pipeline: false")
        || lower.contains("gpu-resident pipeline: false")
        || lower.contains("gpu_resident_pipeline: false")
        || lower.contains("\"gpu resident pipeline\": false")
        || lower.contains("\"gpu resident pipeline\":false")
        || lower.contains("\"gpu resident pipeline\":\"false\"")
        || lower.contains("\"gpu resident pipeline\": \"false\"")
        || lower.contains("\"gpu_resident_pipeline\": false")
        || lower.contains("\"gpu_resident_pipeline\":false")
        || lower.contains("\"gpu_resident_pipeline\":\"false\"")
        || lower.contains("\"gpu_resident_pipeline\": \"false\"")
    {
        Some(false)
    } else if lower.contains("gpu resident pipeline: true")
        || lower.contains("gpu-resident pipeline: true")
        || lower.contains("gpu_resident_pipeline: true")
        || lower.contains("\"gpu resident pipeline\": true")
        || lower.contains("\"gpu resident pipeline\":true")
        || lower.contains("\"gpu resident pipeline\":\"true\"")
        || lower.contains("\"gpu resident pipeline\": \"true\"")
        || lower.contains("\"gpu_resident_pipeline\": true")
        || lower.contains("\"gpu_resident_pipeline\":true")
        || lower.contains("\"gpu_resident_pipeline\":\"true\"")
        || lower.contains("\"gpu_resident_pipeline\": \"true\"")
    {
        Some(true)
    } else {
        None
    }
}

fn extract_gpu_resident_boundary_reason(plan: &str) -> Option<String> {
    if let Some(value) = json_string_property(
        plan,
        &[
            "gpu resident boundary",
            "gpu_resident_boundary",
            "gpu_resident_boundary_reason",
        ],
    ) {
        return Some(value.trim_matches('"').to_owned());
    }
    for line in plan.lines() {
        let trimmed = line.trim().trim_end_matches(',');
        let lower = trimmed.to_ascii_lowercase();
        let value = if lower.starts_with("gpu resident boundary:") {
            trimmed.split_once(':').map(|(_, value)| value)
        } else if lower.starts_with("\"gpu resident boundary\":") {
            trimmed.split_once(':').map(|(_, value)| value)
        } else if lower.starts_with("\"gpu_resident_boundary_reason\":") {
            trimmed.split_once(':').map(|(_, value)| value)
        } else {
            None
        };
        if let Some(value) = value {
            let reason = value
                .trim()
                .trim_matches('"')
                .trim_end_matches('"')
                .trim()
                .to_owned();
            if !reason.is_empty() {
                return Some(reason);
            }
        }
    }
    None
}

fn classify_gpu_resident_boundary_reason(
    w: &WorkloadResult,
    full_plan: Option<&str>,
) -> Option<String> {
    if matches!(
        w.gpu_resident_pipeline,
        GpuResidentPipelineStatus::Reported
            | GpuResidentPipelineStatus::PlannerDeclined
            | GpuResidentPipelineStatus::NotApplicableFunctionSrf
    ) {
        return None;
    }
    w.plan_snippet
        .as_deref()
        .and_then(extract_gpu_resident_boundary_reason)
        .or_else(|| full_plan.and_then(extract_gpu_resident_boundary_reason))
        .or_else(|| {
            w.plan_snippet
                .as_deref()
                .and_then(infer_gpu_resident_boundary_reason_from_plan)
        })
        .or_else(|| full_plan.and_then(infer_gpu_resident_boundary_reason_from_plan))
        .or_else(|| infer_gpu_resident_boundary_reason_from_workload(w).map(str::to_owned))
}

fn infer_gpu_resident_boundary_reason_from_plan(plan: &str) -> Option<String> {
    let lower = plan.to_ascii_lowercase();
    let strategy = if lower.contains("strategy: gpuscan")
        || lower.contains("\"strategy\": \"gpuscan\"")
        || lower.contains("\"strategy\":\"gpuscan\"")
    {
        "GpuScan"
    } else if lower.contains("strategy: gpujoin")
        || lower.contains("\"strategy\": \"gpujoin\"")
        || lower.contains("\"strategy\":\"gpujoin\"")
    {
        "GpuJoin"
    } else if lower.contains("strategy: gpuagg")
        || lower.contains("\"strategy\": \"gpuagg\"")
        || lower.contains("\"strategy\":\"gpuagg\"")
    {
        "GpuAgg"
    } else if lower.contains("strategy: gpusort")
        || lower.contains("\"strategy\": \"gpusort\"")
        || lower.contains("\"strategy\":\"gpusort\"")
    {
        "GpuSort"
    } else if lower.contains("strategy: gpuwindow")
        || lower.contains("\"strategy\": \"gpuwindow\"")
        || lower.contains("\"strategy\":\"gpuwindow\"")
    {
        "GpuWindow"
    } else if lower.contains("strategy: gpupreagg")
        || lower.contains("\"strategy\": \"gpupreagg\"")
        || lower.contains("\"strategy\":\"gpupreagg\"")
    {
        "GpuPreAgg"
    } else if lower.contains("strategy: gpufunctionscan")
        || lower.contains("\"strategy\": \"gpufunctionscan\"")
        || lower.contains("\"strategy\":\"gpufunctionscan\"")
    {
        "GpuFunctionScan"
    } else if lower.contains("strategy: gpuaccelsrftargetlist")
        || lower.contains("\"strategy\": \"gpuaccelsrftargetlist\"")
        || lower.contains("\"strategy\":\"gpuaccelsrftargetlist\"")
    {
        "GpuAccelSrfTargetList"
    } else {
        return None;
    };
    gpu_resident_boundary_reason_for_strategy(strategy).map(str::to_owned)
}

fn infer_gpu_resident_boundary_reason_from_workload(w: &WorkloadResult) -> Option<&'static str> {
    let name = w.name.as_str();
    let category = w.category.as_str();
    let kernel = w.kernel_class.as_str();
    if kernel == "sort" || name.contains("sort") || name.contains("topk") {
        gpu_resident_boundary_reason_for_strategy("GpuSort")
    } else if kernel.contains("join") || name.contains("join") || name.contains("nlj") {
        gpu_resident_boundary_reason_for_strategy("GpuJoin")
    } else if kernel == "hash_agg"
        || kernel == "reduce"
        || name.contains("agg")
        || name.contains("reduce")
    {
        gpu_resident_boundary_reason_for_strategy("GpuAgg")
    } else if kernel == "window" || name.contains("window") {
        gpu_resident_boundary_reason_for_strategy("GpuWindow")
    } else if category == "gpu_spatial"
        || category == "gpu_raster"
        || category == "gpu_h3"
        || category == "gpu_expr"
    {
        gpu_resident_boundary_reason_for_strategy("GpuScan")
    } else {
        None
    }
}

pub fn gpu_resident_boundary_reason_for_strategy(strategy: &str) -> Option<&'static str> {
    Some(match strategy {
        "GpuScan" => {
            "GpuScan consumes heap or child tuples on CPU via table_scan_getnextslot/ExecProcNode/MinimalTuple staging and emits PostgreSQL slots"
        }
        "GpuJoin" => {
            "GpuJoin collects child rows through ExecProcNode into host MinimalTuple/key buffers and reconstructs joined PostgreSQL slots"
        }
        "GpuAgg" => {
            "GpuAgg drains heap or child tuples on CPU and stages host input/key/value buffers before GPU reduce or grouped aggregation"
        }
        "GpuSort" => {
            "GpuSort is a retired wire identity; standalone sort must stay PostgreSQL-native because no sort kernel/executor is registered"
        }
        "GpuWindow" => {
            "GpuWindow is a retired wire identity; standalone window must stay PostgreSQL-native because no window kernel/executor is registered"
        }
        "GpuPreAgg" => {
            "GpuPreAgg materializes dimensions in host HashMap state and scans/probes fact rows through ExecProcNode/materialized slots"
        }
        "GpuFunctionScan" => {
            "GpuFunctionScan dispatches constant arguments once, buffers host Datums, and drains output through PostgreSQL slots"
        }
        "GpuAccelSrfTargetList" => {
            "GpuAccelSrfTargetList drives ProjectSet input through ExecProcNode, buffers per-row SRF output, and emits expanded PostgreSQL tuples"
        }
        _ => return None,
    })
}

fn plan_shape_signature(plan: &str) -> Vec<String> {
    plan.lines().filter_map(normalize_plan_line).collect()
}

fn first_plan_signature_line(plan: Option<&str>) -> String {
    plan.and_then(|p| plan_shape_signature(p).into_iter().next())
        .unwrap_or_else(|| "-".to_owned())
}

fn normalize_plan_line(line: &str) -> Option<String> {
    let mut trimmed = line.trim();
    if let Some(rest) = trimmed.strip_prefix("->") {
        trimmed = rest.trim_start();
    }
    if trimmed.is_empty() {
        return None;
    }

    let mut lower = trimmed.to_ascii_lowercase();
    if lower.starts_with("planning time:")
        || lower.starts_with("execution time:")
        || lower.starts_with("buffers:")
        || lower.starts_with("pg_accel planner rejection reason:")
    {
        return None;
    }

    let mut truncate_at = lower.len();
    for marker in ["  (cost=", " (cost=", "  (actual", " (actual"] {
        if let Some(idx) = lower.find(marker) {
            truncate_at = truncate_at.min(idx);
        }
    }
    lower.truncate(truncate_at);

    let normalized = lower.split_whitespace().collect::<Vec<_>>().join(" ");
    (!normalized.is_empty()).then_some(normalized)
}

fn markdown_cell(input: &str) -> String {
    input.replace('|', "\\|").replace('\n', "<br>")
}

fn max_iteration_value(
    iterations: &[IterationResult],
    value: impl Fn(&IterationResult) -> f64,
) -> Option<f64> {
    iterations
        .iter()
        .map(value)
        .filter(|v| v.is_finite())
        .reduce(f64::max)
}

fn format_optional_ms(value: Option<f64>) -> String {
    value.map_or_else(|| "-".to_owned(), |v| format!("{v:.2}ms"))
}

/// Maximum number of plan-snippet lines shown in a rendered report. This is
/// a display-only cap: `WorkloadResult::plan_snippet` itself always holds
/// the FULL captured `EXPLAIN (VERBOSE, COSTS OFF)` text, and every
/// classification helper (dispatch detection, decline-reason extraction,
/// plan-shape comparison, etc.) reads that full text directly. Only the
/// markdown renderer truncates, so a deep plan tree cannot blow up the
/// rendered report while a Custom Scan node past line 30 is still correctly
/// classified.
const PLAN_SNIPPET_DISPLAY_MAX_LINES: usize = 30;

/// Truncate a full plan snippet for markdown display only. See
/// `PLAN_SNIPPET_DISPLAY_MAX_LINES`. Never call this before classification —
/// classification helpers must keep reading `WorkloadResult::plan_snippet`
/// untouched.
fn truncate_plan_for_display(plan: &str) -> String {
    let total = plan.lines().count();
    if total <= PLAN_SNIPPET_DISPLAY_MAX_LINES {
        return plan.to_owned();
    }
    let mut truncated = plan
        .lines()
        .take(PLAN_SNIPPET_DISPLAY_MAX_LINES)
        .collect::<Vec<_>>()
        .join("\n");
    let _ = write!(
        truncated,
        "\n… ({} more lines)",
        total - PLAN_SNIPPET_DISPLAY_MAX_LINES
    );
    truncated
}

/// Render the per-row evidence appendix for the Detailed Results section:
/// warm/cold summaries (never a pooled median), the resident-cache preload
/// note, the cold-cache `shared_buffers`-resident warning, native-decline
/// evidence tagged with its source, and a truncated plan-snippet preview.
/// Emits nothing when none of these apply to the row.
fn render_workload_evidence_notes(w: &WorkloadResult, scale_label: &str, out: &mut String) {
    let mut notes: Vec<String> = Vec::new();

    if let Some(filter) = w.native_post_aggregate_filter.clone().or_else(|| {
        w.plan_snippet.as_deref().and_then(|plan| {
            plan_text_property(
                plan,
                &["gpu post-aggregate filter", "gpu_post_aggregate_filter"],
            )
        })
    }) {
        notes.push(format!(
            "Native post-aggregate filter: {filter}; CPU evaluation is included in query timings."
        ));
    }

    if w.physical_kernel_mode.is_some()
        || w.physical_kernel_mode_counts != PhysicalKernelModeCounts::default()
    {
        notes.push(format!(
            "Physical grouped kernel: mode={}, EXPLAIN/native verified={}; calls hash={}, dense-count={}, dense-integer={}, dense-numeric={}, serial-generic={}.",
            w.physical_kernel_mode.as_deref().unwrap_or("ambiguous"),
            w.physical_kernel_mode_verified,
            w.physical_kernel_mode_counts.parallel_hash,
            w.physical_kernel_mode_counts.parallel_dense_count,
            w.physical_kernel_mode_counts.parallel_dense_integer,
            w.physical_kernel_mode_counts.parallel_dense_numeric,
            w.physical_kernel_mode_counts.serial_generic,
        ));
    }

    if let (Some(warm), Some(cold)) = (&w.warm_summary, &w.cold_summary) {
        notes.push(format!(
            "Warm (n={}): accel median {:.2}ms, PG parallel median {:.2}ms, speedup {:.2}x.",
            warm.n, warm.accel_median_ms, warm.parallel_median_ms, warm.speedup_median_vs_parallel
        ));
        notes.push(format!(
            "Cold (n={}): accel median {:.2}ms, PG parallel median {:.2}ms, speedup {:.2}x.",
            cold.n, cold.accel_median_ms, cold.parallel_median_ms, cold.speedup_median_vs_parallel
        ));
    }

    if w.resident_lane {
        notes.push(w.resident_load_ms.map_or_else(
            || {
                "Resident-cache preload: required for this lane but not captured for this row."
                    .to_owned()
            },
            |ms| {
                format!(
                    "Resident-cache preload: {ms:.2}ms, paid once off the timed clock and \
                     amortized across repeated queries against the resident cache."
                )
            },
        ));
        if let Some(probe) = &w.artifact_lifecycle_probe {
            notes.push(format!(
                "Artifact lifecycle probe: refreshed {} relation(s) / {} rows in {:.3}ms; accel \
                 end-to-end {:.2}ms; PG parallel \
                 {:.2}ms; policy={}; outcomes built={} rebuilt={} hit={}; construction bytes={}; \
                 construction {:.3}ms; preparation {:.3}ms; dependency identities {}→{}; \
                 kernels={}; batches={}; output rows={}; fallback={}; error={}.",
                probe.refreshed_relations,
                probe.refreshed_rows,
                probe.refresh_us as f64 / 1_000.0,
                probe.iteration.accel_ms,
                probe.iteration.parallel_ms,
                probe.artifact_policy.as_deref().unwrap_or("unavailable"),
                probe.artifact.builds,
                probe.artifact.rebuilds,
                probe.artifact.hits,
                probe.artifact.construction_bytes,
                probe.artifact.construction_us as f64 / 1_000.0,
                probe.artifact.preparation_us as f64 / 1_000.0,
                probe.dependencies_before.len(),
                probe.dependencies_after.len(),
                probe.gpu_kernel_executions,
                probe.batches_executed,
                probe.output_rows_consumed,
                probe.stock_exec_count,
                probe.error.as_deref().unwrap_or("none"),
            ));
        } else {
            notes.push("Artifact lifecycle probe: missing.".to_owned());
        }
        if !w.artifact_steady_state_captures.is_empty() {
            let hits = w
                .artifact_steady_state_captures
                .iter()
                .fold(0_u64, |total, capture| {
                    total.saturating_add(capture.artifact.hits)
                });
            notes.push(format!(
                "Artifact steady state: {} independently captured warm pairs, {hits} hits, \
                 {} build/rebuild outcomes.",
                w.artifact_steady_state_captures.len(),
                w.artifact_steady_state_captures
                    .iter()
                    .fold(0_u64, |total, capture| total
                        .saturating_add(capture.artifact.builds)
                        .saturating_add(capture.artifact.rebuilds)),
            ));
        }
        if let Some(combined) = &w.combined_warm_summary {
            notes.push(format!(
                "Combined lifecycle + steady calibration (n={}): accel median {:.2}ms, PG \
                 parallel median {:.2}ms, speedup {:.2}x; warm latency ratchets remain bound to \
                 the separate steady-state summary.",
                combined.n,
                combined.accel_median_ms,
                combined.parallel_median_ms,
                combined.speedup_median_vs_parallel,
            ));
        }
    }

    if w.cold_shared_buffers_resident == Some(true) {
        notes.push(
            "WARNING: this cold-cache fixture fit inside `shared_buffers`; PostgreSQL's buffer \
             cache stayed resident after the OS page-cache purge, so these \"cold\" numbers \
             reflect a shared_buffers-resident fixture, not genuine cold I/O."
                .to_owned(),
        );
    }

    if let Some(evidence) = &w.native_decline_evidence {
        let confirmation = match evidence.source {
            DeclineReasonSource::PlannerReported => "planner-reported, verified",
            DeclineReasonSource::ExpectedUnconfirmed => "expected, unconfirmed",
        };
        notes.push(format!(
            "Native-decline evidence: `{}` ({confirmation}).",
            evidence.reason
        ));
    }

    // Nothing noteworthy for this row (no cache split, no resident lane, no
    // cold-buffer warning, no decline evidence) — skip. The full plan
    // snippet is only worth dumping alongside evidence that needs it; the
    // Dispatch Evidence By Row table already carries a one-line plan
    // signature for every row.
    if notes.is_empty() {
        return;
    }

    if w.plan_snippet.is_some() {
        notes.push(format!(
            "Plan snippet (accel, display-truncated to {PLAN_SNIPPET_DISPLAY_MAX_LINES} lines):"
        ));
    }

    let _ = writeln!(out, "- **{scale_label}:**");
    for note in &notes {
        let _ = writeln!(out, "  - {note}");
    }
    if let Some(plan) = &w.plan_snippet {
        let _ = writeln!(out, "\n```\n{}\n```\n", truncate_plan_for_display(plan));
    }
}

fn csv_optional_f64(value: Option<f64>) -> String {
    value.map_or_else(String::new, |v| format!("{v:.4}"))
}

fn iteration_indexes_with_cache_purge(
    iterations: &[IterationResult],
    state: CachePurgeState,
) -> Vec<usize> {
    iterations
        .iter()
        .enumerate()
        .filter_map(|(idx, iteration)| (iteration.cache_purge == state).then_some(idx + 1))
        .collect()
}

fn format_iteration_indexes(indexes: &[usize]) -> String {
    if indexes.is_empty() {
        "-".to_owned()
    } else {
        indexes
            .iter()
            .map(std::string::ToString::to_string)
            .collect::<Vec<_>>()
            .join(", ")
    }
}

fn dispatch_evidence_label(w: &WorkloadResult) -> &'static str {
    if w.function_srf_kernel_dispatched {
        "function_srf_dispatch"
    } else if derived_output_artifact_reuse_evidence_verified(w) {
        "custom_scan_lifecycle_artifact_reuse"
    } else if w.custom_scan_selected_not_dispatched {
        "custom_scan_selected_not_dispatched"
    } else if w.planner_declined {
        "planner_declined"
    } else if w.gpu_kernel_dispatched {
        "custom_scan_dispatch"
    } else {
        "uncredited_gpu_counter_or_unknown"
    }
}

fn threshold_matrix_expectation_label(
    expectation: crate::workloads::BenchmarkLaneExpectation,
) -> String {
    match expectation {
        crate::workloads::BenchmarkLaneExpectation::GpuWinner { min_warm_speedup } => {
            format!("{} >= {min_warm_speedup:.2}x", expectation.label())
        }
        crate::workloads::BenchmarkLaneExpectation::NativeDecline { reason } => {
            let reason = expectation.decline_reason().unwrap_or(reason);
            format!("{} ({reason})", expectation.label())
        }
    }
}

fn threshold_matrix_status(
    w: &WorkloadResult,
    lane: &str,
    expectation: crate::workloads::BenchmarkLaneExpectation,
) -> &'static str {
    match expectation {
        crate::workloads::BenchmarkLaneExpectation::GpuWinner { min_warm_speedup } => {
            if gpu_winner_evidence_verified(w, lane, min_warm_speedup) {
                "pass"
            } else {
                "FAIL"
            }
        }
        crate::workloads::BenchmarkLaneExpectation::NativeDecline { reason } => {
            if !w.plan_selected
                && !w.gpu_kernel_dispatched
                && native_decline_reason_verified(w, reason)
            {
                "pass"
            } else {
                "FAIL"
            }
        }
    }
}

fn warmup_jit_audit_reason(w: &WorkloadResult) -> Option<String> {
    let post_first_max = w.warmup_accel_post_first_max_ms?;
    let mut reasons = Vec::new();
    if post_first_max >= WARMUP_JIT_POST_FIRST_WARN_MS {
        reasons.push(format!(
            "post-first warmup max {post_first_max:.2}ms >= {WARMUP_JIT_POST_FIRST_WARN_MS:.0}ms"
        ));
    }
    if w.accel_median_ms.is_finite() && w.accel_median_ms > 0.0 {
        let ratio = post_first_max / w.accel_median_ms;
        if ratio >= WARMUP_JIT_RELATIVE_WARN_RATIO && post_first_max >= 100.0 {
            reasons.push(format!(
                "post-first warmup max is {ratio:.1}x measured accel median"
            ));
        }
    }
    (!reasons.is_empty()).then(|| reasons.join("; "))
}

/// Warm-subsample speedup used by the ship gates below. Reads
/// `WorkloadResult::warm_summary` directly when the run measured a cache
/// split (`CacheMode::Both`); falls back to the flat top-level
/// `speedup_median_vs_parallel` for warm-only runs, where the flat field
/// already describes the same (only) subsample. This is deliberately
/// explicit rather than relying on the flat field's documented "describes
/// the warm subsample" invariant — the gate should read the warm evidence
/// directly, not through an implicit contract on an unrelated field.
fn warm_speedup_for_gate(w: &WorkloadResult) -> f64 {
    w.warm_summary
        .as_ref()
        .map_or(w.speedup_median_vs_parallel, |s| {
            s.speedup_median_vs_parallel
        })
}

fn gpu_winner_evidence_verified(w: &WorkloadResult, lane: &str, min_warm_speedup: f64) -> bool {
    let classification = w.dispatch_classification();
    let threshold = min_warm_speedup.max(BENCHMARK_SHIP_GATE_MIN_SPEEDUP);
    let warm_speedup = warm_speedup_for_gate(w);
    let dispatch_proven =
        w.gpu_kernel_execution_delta > 0 || derived_output_artifact_reuse_evidence_verified(w);
    classification.gpu_kernel_dispatched
        && w.dispatch_counter_captured
        && dispatch_proven
        && classification.rows_returned_to_cpu > 0
        && warm_speedup.is_finite()
        && warm_speedup >= threshold
        && (!threshold_lane_requires_resident_groupagg_logical_spec(lane)
            || w.plan_snippet
                .as_deref()
                .is_some_and(|plan| plan_contains_required_groupagg_logical_evidence(plan, lane)))
}

/// Whether native-decline evidence for this row is *verified* — i.e. safe to
/// pass a ship gate. Reads `WorkloadResult::native_decline_evidence` only:
/// only `DeclineReasonSource::PlannerReported` (a real planner decline backed
/// by a positive reset-session per-reason counter captured by the runner)
/// counts as verified. `DeclineReasonSource::ExpectedUnconfirmed`
/// (the static benchmark-threshold matrix expected a decline but the
/// planner surfaced no reason) must never pass — the report renders it as
/// "expected, unconfirmed" instead (see `native_decline_evidence_label`).
///
/// This deliberately does not grep `plan_snippet` for any decline-reason
/// text. The runner never synthesizes plan text for an unconfirmed
/// expectation (see `runner::native_decline_evidence`), so grepping the
/// plan snippet can no longer distinguish a real decline from an assumed
/// one — the tagged evidence field is the only source of truth.
fn native_decline_reason_verified(w: &WorkloadResult, reason: &str) -> bool {
    matches!(
        &w.native_decline_evidence,
        Some(NativeDeclineEvidence {
            reason: actual,
            source: DeclineReasonSource::PlannerReported,
        }) if actual == reason
    )
}

/// Render the native-decline evidence for a row, tagged with its
/// confirmation status, for markdown display. `ExpectedUnconfirmed` renders
/// as "expected, unconfirmed" so a reader never mistakes a static-matrix
/// assumption for a proven planner decision.
fn native_decline_evidence_label(w: &WorkloadResult) -> String {
    match &w.native_decline_evidence {
        Some(NativeDeclineEvidence {
            reason,
            source: DeclineReasonSource::PlannerReported,
        }) => format!("{reason} (planner-reported, verified)"),
        Some(NativeDeclineEvidence {
            reason,
            source: DeclineReasonSource::ExpectedUnconfirmed,
        }) => format!("{reason} (expected, unconfirmed)"),
        None => "-".to_owned(),
    }
}

fn operation_cache_gate_required(name: &str) -> bool {
    crate::workloads::workload_metadata(name).map_or_else(
        || name.starts_with("h3_") || name.starts_with("raster_"),
        |metadata| metadata.evidence.requires_cache_mode_both(),
    )
}

/// Verifies the h3_/raster_ cache-mode-both requirement. The methodology label
/// is not evidence by itself: the row must carry non-empty warm and cold
/// summaries, and every cold iteration must prove that both measurements in
/// the pair completed their requested OS page-cache purge. Shared-buffer
/// residency remains visible report evidence, not a ship failure: the fixed
/// 1M fixture can legitimately fit inside the qualified profile's buffers.
fn operation_cache_gate_verified(
    w: &WorkloadResult,
    cache_mode: &str,
    expected_iterations: usize,
) -> bool {
    if !operation_cache_gate_required(&w.name) {
        return true;
    }

    let Some(warm) = &w.warm_summary else {
        return false;
    };
    let Some(cold) = &w.cold_summary else {
        return false;
    };
    let warm_count = w
        .iterations
        .iter()
        .filter(|iteration| iteration.cache_state == CacheState::Warm)
        .count();
    let cold_iterations = w
        .iterations
        .iter()
        .filter(|iteration| iteration.cache_state == CacheState::Cold)
        .collect::<Vec<_>>();

    cache_mode.trim().eq_ignore_ascii_case("both")
        && warm.cache_state == CacheState::Warm
        && expected_iterations > 0
        && warm.n == expected_iterations
        && warm_count == expected_iterations
        && cold.cache_state == CacheState::Cold
        && cold.n == expected_iterations
        && cold_iterations.len() == expected_iterations
        && cold_iterations
            .iter()
            .all(|iteration| iteration.cache_purge == CachePurgeState::Completed)
}

fn no_dispatch_audit_action(w: &WorkloadResult) -> &'static str {
    let classification = w.dispatch_classification();
    if classification.custom_scan_selected_not_dispatched {
        "quarantine CPU fallback / planner-decline"
    } else if no_dispatch_plan_mismatch(w) {
        "align native plan/GUCs before comparing"
    } else if no_dispatch_timing_skew(w) {
        "same native plan timing skew; rerun/inspect harness"
    } else if w.plan_snippet.is_none() || w.baseline_plan_snippet.is_none() {
        "capture accel and baseline plan evidence before comparing"
    } else {
        "no GPU credit; use only as native-decline/stability evidence"
    }
}

fn no_dispatch_audit_row(w: &WorkloadResult) -> Option<NoDispatchAuditRow> {
    if !both_modes_appear_non_dispatching(w) {
        return None;
    }

    let skew_fraction = timing_skew_fraction(no_dispatch_speedup(w));
    let timing_skew = skew_fraction.is_some_and(|skew| skew >= NO_DISPATCH_TIMING_SKEW_THRESHOLD);
    let plan_mismatch = no_dispatch_plan_mismatch(w);
    let missing_plan_evidence = w.plan_snippet.is_none() || w.baseline_plan_snippet.is_none();
    let classification = w.dispatch_classification();
    let status = if classification.custom_scan_selected_not_dispatched {
        NoDispatchAuditStatus::SelectedCustomScanNotDispatched
    } else if timing_skew && plan_mismatch {
        NoDispatchAuditStatus::TimingSkewAndPlanMismatch
    } else if plan_mismatch {
        NoDispatchAuditStatus::PlanMismatch
    } else if timing_skew {
        NoDispatchAuditStatus::TimingSkew
    } else if missing_plan_evidence {
        NoDispatchAuditStatus::MissingPlanEvidence
    } else {
        NoDispatchAuditStatus::ComparableNative
    };

    Some(NoDispatchAuditRow {
        workload: w.name.clone(),
        rows: w.rows,
        speedup_median_vs_parallel: no_dispatch_speedup(w),
        timing_skew_fraction: skew_fraction,
        timing_skew,
        plan_mismatch,
        missing_plan_evidence,
        accel_plan_signature: first_plan_signature_line(w.plan_snippet.as_deref()),
        baseline_plan_signature: first_plan_signature_line(w.baseline_plan_snippet.as_deref()),
        status,
        action: no_dispatch_audit_action(w).to_owned(),
    })
}

fn resident_boundary_audit_row(w: &WorkloadResult) -> ResidentBoundaryAuditRow {
    let lifecycle_artifact_reuse = derived_output_artifact_reuse_evidence_error(w).is_none();
    let (status, detail) = if lifecycle_artifact_reuse
        && w.gpu_resident_pipeline == GpuResidentPipelineStatus::Reported
    {
        (
            ResidentBoundaryAuditStatus::LifecycleProducedArtifactReuse,
            "sealed lifecycle evidence proves GPU construction of the exact final artifact and complete dependency-stable warm-hit reuse"
                .to_owned(),
        )
    } else if w.gpu_resident_pipeline == GpuResidentPipelineStatus::Reported {
        (
            ResidentBoundaryAuditStatus::ReportedResidentPipeline,
            "selected Custom Scan reported a GPU-resident pipeline".to_owned(),
        )
    } else if w.gpu_resident_boundary_reason.is_some() {
        (
            ResidentBoundaryAuditStatus::NonResidentPipeline,
            "selected Custom Scan recorded a CPU/PostgreSQL boundary; the hard GPU-only gate should have declined it"
                .to_owned(),
        )
    } else {
        (
            ResidentBoundaryAuditStatus::MissingResidentPipelineEvidence,
            "selected Custom Scan lacks `GPU Resident Pipeline: true` proof".to_owned(),
        )
    };
    ResidentBoundaryAuditRow {
        workload: w.name.clone(),
        rows: w.rows,
        gpu_kernel_dispatched: w.gpu_kernel_dispatched,
        gpu_resident_pipeline: w.gpu_resident_pipeline.as_str().to_owned(),
        boundary_reason: w.gpu_resident_boundary_reason.clone(),
        status,
        detail,
    }
}

impl BenchReport {
    #[must_use]
    pub fn no_dispatch_audit(&self) -> NoDispatchAudit {
        let report = self.with_normalized_dispatch();
        let ignored_dispatching_rows = report
            .workloads
            .iter()
            .filter(|w| !both_modes_appear_non_dispatching(w))
            .count();
        let rows: Vec<_> = report
            .workloads
            .iter()
            .filter_map(no_dispatch_audit_row)
            .collect();
        let warning_rows = rows.iter().filter(|row| row.status.is_warning()).count();
        let timing_skew_rows = rows.iter().filter(|row| row.timing_skew).count();
        let plan_mismatch_rows = rows.iter().filter(|row| row.plan_mismatch).count();
        let selected_custom_scan_not_dispatched_rows = rows
            .iter()
            .filter(|row| row.status == NoDispatchAuditStatus::SelectedCustomScanNotDispatched)
            .count();
        let missing_plan_evidence_rows =
            rows.iter().filter(|row| row.missing_plan_evidence).count();
        NoDispatchAudit {
            schema_version: NO_DISPATCH_AUDIT_SCHEMA_VERSION,
            timing_skew_threshold_fraction: NO_DISPATCH_TIMING_SKEW_THRESHOLD,
            evaluated_no_dispatch_rows: rows.len(),
            clean_rows: rows.len().saturating_sub(warning_rows),
            warning_rows,
            timing_skew_rows,
            plan_mismatch_rows,
            selected_custom_scan_not_dispatched_rows,
            missing_plan_evidence_rows,
            ignored_dispatching_rows,
            rows,
        }
    }

    #[must_use]
    pub fn resident_boundary_audit(&self) -> ResidentBoundaryAudit {
        let report = self.with_normalized_dispatch();
        let ignored_non_custom_scan_rows =
            report.workloads.iter().filter(|w| !w.plan_selected).count();
        let rows: Vec<_> = report
            .workloads
            .iter()
            .filter(|w| w.plan_selected)
            .map(resident_boundary_audit_row)
            .collect();
        let failed_rows = rows.iter().filter(|row| row.status.is_failure()).count();
        ResidentBoundaryAudit {
            schema_version: RESIDENT_BOUNDARY_AUDIT_SCHEMA_VERSION,
            selected_custom_scan_rows: rows.len(),
            passed_rows: rows.len().saturating_sub(failed_rows),
            failed_rows,
            ignored_non_custom_scan_rows,
            rows,
        }
    }

    #[must_use]
    pub fn benchmark_failure_ledger(&self) -> BenchmarkFailureLedger {
        let report = self.with_normalized_dispatch();
        let ship_gate_failures = report.evaluate_benchmark_ship_gate();
        let h3_lane_gate_failures = report.evaluate_h3_lane_gate();
        let mut rows: BTreeMap<(String, usize), BenchmarkFailureLedgerRow> = BTreeMap::new();

        for failure in &ship_gate_failures {
            let workload = report.workload_result(&failure.workload, failure.rows);
            merge_ledger_item(
                &mut rows,
                LedgerMergeItem {
                    workload,
                    workload_name: &failure.workload,
                    row_count: failure.rows,
                    source: "benchmark_ship_gate",
                    priority: "p1_release_blocker",
                    next_track: ledger_track(
                        &failure.workload,
                        workload.map_or("", |w| w.category.as_str()),
                        workload.map_or("", |w| w.kernel_class.as_str()),
                        Some(failure.kind.label()),
                    ),
                    speedup: Some(failure.speedup_median),
                    gate_floor: Some(failure.gate_floor),
                    detail: format!("{}: {}", failure.kind.label(), failure.detail),
                },
            );
        }
        for crash in &report.crashes {
            merge_crash_ledger_item(&mut rows, crash);
        }

        for failure in &h3_lane_gate_failures {
            let workload = report.workload_result(&failure.workload, failure.rows);
            merge_ledger_item(
                &mut rows,
                LedgerMergeItem {
                    workload,
                    workload_name: &failure.workload,
                    row_count: failure.rows,
                    source: "h3_lane_gate",
                    priority: "p1_release_blocker",
                    next_track: "h3_cache_evidence_and_lane_policy",
                    speedup: Some(failure.speedup_median),
                    gate_floor: Some(failure.gate_floor),
                    detail: format!(
                        "{}: advisory warm threshold {:.2}x",
                        failure.kind.label(),
                        failure.advisory_min_warm_speedup
                    ),
                },
            );
        }

        for workload in &report.workloads {
            if workload.pg_accel_stock_exec_delta > 0 {
                merge_ledger_item(
                    &mut rows,
                    LedgerMergeItem {
                        workload: Some(workload),
                        workload_name: &workload.name,
                        row_count: workload.rows,
                        source: "stock_executor_fallback",
                        priority: "p1_release_blocker",
                        next_track: ledger_track(
                            &workload.name,
                            &workload.category,
                            &workload.kernel_class,
                            Some("stock_executor_fallback"),
                        ),
                        speedup: Some(workload.speedup_median_vs_parallel),
                        gate_floor: Some(BENCHMARK_SHIP_GATE_MIN_SPEEDUP),
                        detail: format!(
                            "pg_accel stock executor fallback count was {}",
                            workload.pg_accel_stock_exec_delta
                        ),
                    },
                );
            }

            if workload.custom_scan_selected_not_dispatched {
                merge_ledger_item(
                    &mut rows,
                    LedgerMergeItem {
                        workload: Some(workload),
                        workload_name: &workload.name,
                        row_count: workload.rows,
                        source: "custom_scan_selected_not_dispatched",
                        priority: "p1_release_blocker",
                        next_track: ledger_track(
                            &workload.name,
                            &workload.category,
                            &workload.kernel_class,
                            Some("custom_scan_selected_not_dispatched"),
                        ),
                        speedup: Some(workload.speedup_median_vs_parallel),
                        gate_floor: Some(BENCHMARK_SHIP_GATE_MIN_SPEEDUP),
                        detail: "pg_accel Custom Scan selected without credited GPU dispatch"
                            .to_owned(),
                    },
                );
            }

            if workload.speedup_median_vs_parallel.is_finite()
                && workload.speedup_median_vs_parallel < BENCHMARK_SHIP_GATE_MIN_SPEEDUP
            {
                let (source, priority, detail) = if workload.gpu_kernel_dispatched {
                    (
                        "gpu_dispatched_below_parity",
                        "p1_release_blocker",
                        "credited GPU dispatch below PG-parallel parity",
                    )
                } else if workload.speedup_median_vs_parallel < 0.98 {
                    (
                        "native_below_parity",
                        "p2_architecture_gap",
                        "native/planner-declined row below 0.98x parity",
                    )
                } else {
                    (
                        "native_below_parity",
                        "p3_parity_noise",
                        "native/planner-declined row below 1.00x parity",
                    )
                };
                merge_ledger_item(
                    &mut rows,
                    LedgerMergeItem {
                        workload: Some(workload),
                        workload_name: &workload.name,
                        row_count: workload.rows,
                        source,
                        priority,
                        next_track: ledger_track(
                            &workload.name,
                            &workload.category,
                            &workload.kernel_class,
                            Some(source),
                        ),
                        speedup: Some(workload.speedup_median_vs_parallel),
                        gate_floor: None,
                        detail: detail.to_owned(),
                    },
                );
            }
        }

        let rows_below_parity_count = report
            .workloads
            .iter()
            .filter(|w| {
                w.speedup_median_vs_parallel.is_finite()
                    && w.speedup_median_vs_parallel < BENCHMARK_SHIP_GATE_MIN_SPEEDUP
            })
            .count();
        let gpu_dispatched_below_parity_count = report
            .workloads
            .iter()
            .filter(|w| {
                w.gpu_kernel_dispatched
                    && w.speedup_median_vs_parallel.is_finite()
                    && w.speedup_median_vs_parallel < BENCHMARK_SHIP_GATE_MIN_SPEEDUP
            })
            .count();
        let native_below_parity_count = report
            .workloads
            .iter()
            .filter(|w| {
                !w.gpu_kernel_dispatched
                    && w.speedup_median_vs_parallel.is_finite()
                    && w.speedup_median_vs_parallel < BENCHMARK_SHIP_GATE_MIN_SPEEDUP
            })
            .count();
        let planner_declined_below_parity_count = report
            .workloads
            .iter()
            .filter(|w| {
                w.planner_declined
                    && w.speedup_median_vs_parallel.is_finite()
                    && w.speedup_median_vs_parallel < BENCHMARK_SHIP_GATE_MIN_SPEEDUP
            })
            .count();
        let stock_fallback_rows = report
            .workloads
            .iter()
            .filter(|w| w.pg_accel_stock_exec_delta > 0)
            .count();
        let custom_scan_selected_not_dispatched_rows = report
            .workloads
            .iter()
            .filter(|w| w.custom_scan_selected_not_dispatched)
            .count();

        let mut rows: Vec<_> = rows.into_values().collect();
        rows.sort_by(|a, b| {
            ledger_priority_rank(&a.priority)
                .cmp(&ledger_priority_rank(&b.priority))
                .then_with(|| a.next_track.cmp(&b.next_track))
                .then_with(|| a.workload.cmp(&b.workload))
                .then_with(|| a.rows.cmp(&b.rows))
        });

        BenchmarkFailureLedger {
            schema_version: BENCHMARK_FAILURE_LEDGER_SCHEMA_VERSION,
            total_measured_rows: report.workloads.len(),
            ship_gate_failure_count: ship_gate_failures.len(),
            h3_lane_gate_failure_count: h3_lane_gate_failures.len(),
            crash_count: report.crashes.len(),
            rows_below_parity_count,
            gpu_dispatched_below_parity_count,
            native_below_parity_count,
            planner_declined_below_parity_count,
            stock_fallback_rows,
            custom_scan_selected_not_dispatched_rows,
            unique_work_items: rows.len(),
            rows,
        }
    }

    fn workload_result(&self, name: &str, rows: usize) -> Option<&WorkloadResult> {
        self.workloads
            .iter()
            .find(|workload| workload.name == name && workload.rows == rows)
    }

    fn with_normalized_dispatch(&self) -> Self {
        let mut report = self.clone();
        let full_plans = report.full_plan_artifact_text();
        for w in &mut report.workloads {
            let full_plan = full_plans
                .as_deref()
                .and_then(|plans| extract_full_plan_block(plans, &w.name, w.rows));
            let classification = w.dispatch_classification_with_plan_artifact(full_plan.as_deref());
            w.apply_dispatch_classification(classification);
            w.gpu_resident_boundary_reason =
                classify_gpu_resident_boundary_reason(w, full_plan.as_deref());
            let filter_keys = ["gpu post-aggregate filter", "gpu_post_aggregate_filter"];
            w.native_post_aggregate_filter = w
                .plan_snippet
                .as_deref()
                .and_then(|plan| plan_text_property(plan, &filter_keys))
                .or_else(|| {
                    full_plan
                        .as_deref()
                        .and_then(|plan| plan_text_property(plan, &filter_keys))
                });
        }
        report
    }

    fn full_plan_artifact_text(&self) -> Option<String> {
        let dir = self.artifact_dir.as_deref()?;
        fs::read_to_string(Path::new(dir).join("plans.txt")).ok()
    }

    /// Render the report as a Markdown document.
    ///
    /// The summary table shows speedup at each row scale. Detailed sections
    /// follow with per-scale statistics for every workload.
    #[must_use]
    #[allow(clippy::too_many_lines)]
    pub fn to_markdown(&self) -> String {
        let mut out = String::new();
        out.push_str("# pg_accel Benchmark Report\n\n");

        // Hardware profile
        if let Some(hw) = &self.hardware {
            out.push_str("## Hardware Profile\n\n");
            let _ = writeln!(out, "| Property | Value |");
            let _ = writeln!(out, "|----------|-------|");
            let _ = writeln!(out, "| OS | {} {} |", hw.os, hw.os_version);
            let _ = writeln!(out, "| Architecture | {} |", hw.arch);
            let _ = writeln!(out, "| CPU | {} |", hw.cpu);
            let _ = writeln!(out, "| CPU Cores | {} |", hw.cpu_cores);
            let _ = writeln!(out, "| Memory | {} |", hw.memory_gb);
            out.push('\n');
        }

        // -------------------------------------------------------------------
        // Headline geomean callout (action_items M7 / K / Reviewer 1 Sin #1)
        // -------------------------------------------------------------------
        //
        // The geomean table sits IMMEDIATELY after the hardware profile —
        // before settings, methodology, detailed results — so reviewers do
        // not have to scroll to find the lede. The callout line labels
        // sub-1.0x runs as "net regression" and sub-1.0x categories as
        // losers. The non-h3 geomean is printed in its own row so the reader
        // can see the trig-kernel artifact (Reviewer 1 Sin #9) isolated.
        if self.headline_speedup_allowed {
            self.render_geomean_headline(&mut out);
        } else {
            out.push_str("## Characterization Scope\n\n");
            out.push_str(
                "This broad-system artifact intentionally does not calculate or publish an \
                 aggregate speedup headline. Per-cell timings below are diagnostic evidence \
                 for correctness, planner selection, dispatch, and lifecycle behavior; they \
                 are not a certified TPC-H, ClickBench, or whole-system score.\n\n",
            );
        }
        self.render_dispatch_classification(&mut out);
        self.render_dispatch_evidence(&mut out);
        self.render_planner_threshold_matrix(&mut out);
        self.render_sanity_checks(&mut out);

        // -------------------------------------------------------------------
        // Kernel coverage table (action_items W11 / Reviewer 1 Sin #17)
        // -------------------------------------------------------------------
        //
        // Reviewer 1 counts at most 9 distinct GPU kernels across the
        // entire suite; the category table inflates the count because the
        // same `point_in_ring` kernel appears under 4 different category
        // labels. This table collapses everything to kernel class.
        self.render_no_dispatch_audit(&mut out);

        self.render_kernel_coverage(&mut out);

        // -------------------------------------------------------------------
        // Benchmark ship gate
        // -------------------------------------------------------------------
        //
        // Renders when any selected pg_accel row crashes, misses GPU dispatch,
        // or dispatches below PostgreSQL-parallel parity. The CLI turns this
        // same predicate into a non-zero process exit for CI.
        self.render_benchmark_ship_gate(&mut out);

        // -------------------------------------------------------------------
        // H3 winning-lane gate
        // -------------------------------------------------------------------
        //
        // Renders the `### H3 Lane Gate Failures` section when any H3 Winner
        // regressed below the uniform 1.0x floor (or failed to dispatch) or
        // any H3 Parity workload dispatched a GPU kernel. When the gate is
        // green this is a no-op; when it fails, the bench process is expected
        // to exit non-zero (see `main::cmd_run`).
        self.render_h3_lane_gate(&mut out);
        self.render_warmup_jit_audit(&mut out);
        self.render_cache_purge_audit(&mut out);

        // GUC settings
        if let Some(gucs) = &self.gucs
            && !gucs.settings.is_empty()
        {
            out.push_str("## PostgreSQL Settings\n\n");
            if let Some(ts) = &self.postmaster_start_time {
                let _ = writeln!(
                    out,
                    "_Observed from inside the benchmarked session via `SHOW`. Postmaster start: \
                     `{ts}`. Settings listed here are guaranteed to match the running postmaster \
                     — any `PGC_POSTMASTER` mismatch would have aborted the run (action_items \
                     C4)._"
                );
                out.push('\n');
            }
            let _ = writeln!(out, "| GUC | Value |");
            let _ = writeln!(out, "|-----|-------|");
            for (name, val) in &gucs.settings {
                let _ = writeln!(out, "| `{name}` | `{val}` |");
            }
            out.push('\n');
        }

        // Methodology
        out.push_str("## Methodology\n\n");
        let _ = writeln!(out, "| Parameter | Value |");
        let _ = writeln!(out, "|-----------|-------|");
        let _ = writeln!(out, "| Iterations | {} |", self.methodology.iterations);
        let _ = writeln!(out, "| Warmup iterations | {} |", self.methodology.warmup);
        if let Some(dir) = &self.artifact_dir {
            let _ = writeln!(out, "| Artifact directory | `{dir}` |");
        }
        if !self.methodology.harness_profile.is_empty() {
            let _ = writeln!(
                out,
                "| Harness build profile | `{}` |",
                self.methodology.harness_profile
            );
        }
        let scales_str: Vec<String> = self
            .methodology
            .row_scales
            .iter()
            .map(|r| format_rows(*r))
            .collect();
        let _ = writeln!(out, "| Row scales | {} |", scales_str.join(", "));
        let _ = writeln!(
            out,
            "| Measurement ordering | {} |",
            self.methodology.ordering
        );
        let _ = writeln!(
            out,
            "| Native-parity same-backend crossover | {} |",
            self.methodology.native_parity_pairing
        );
        let _ = writeln!(
            out,
            "| Native-parity raw executions per arm/pair | {} |",
            self.methodology.native_parity_repetitions_per_arm
        );
        for test in &self.methodology.statistical_tests {
            let _ = writeln!(out, "| Statistical test | {test} |");
        }
        out.push_str("\n**Ordering note:** Measurement order (accel-first vs baseline-first) ");
        out.push_str("uses an exactly balanced randomized AB/BA schedule. ");
        if self.methodology.native_parity_pairing {
            let total_raw = self
                .methodology
                .native_parity_repetitions_per_arm
                .saturating_mul(2);
            let _ = writeln!(
                out,
                "Each measured pair contains replicated mirrored ABBA/BAAB motifs on one persistent PostgreSQL backend; all {total_raw} raw executions are retained, and `DISCARD ALL` runs before each execution."
            );
        } else {
            out.push_str(
                "The arms use distinct persistent PostgreSQL backends, with `DISCARD ALL` before every arm.\n",
            );
        }
        if !self.crashes.is_empty() {
            let _ = writeln!(
                out,
                "\n**Crashes:** {} scale(s) crashed and were excluded from results.",
                self.crashes.len()
            );
        }
        out.push('\n');

        // Collect unique scales and workload names (preserving order).
        let scales = &self.methodology.row_scales;
        let mut workload_names: Vec<String> = Vec::new();
        for w in &self.workloads {
            if !workload_names.contains(&w.name) {
                workload_names.push(w.name.clone());
            }
        }

        // Build lookup: (name, rows) -> &WorkloadResult
        let mut lookup: BTreeMap<(&str, usize), &WorkloadResult> = BTreeMap::new();
        for w in &self.workloads {
            lookup.insert((&w.name, w.rows), w);
        }
        let normalized_detail_report = self.with_normalized_dispatch();
        let mut normalized_lookup: BTreeMap<(&str, usize), &WorkloadResult> = BTreeMap::new();
        for w in &normalized_detail_report.workloads {
            normalized_lookup.insert((&w.name, w.rows), w);
        }

        // Build crash lookup: (name, rows) -> true
        let mut crash_lookup: std::collections::HashSet<(String, usize)> =
            std::collections::HashSet::new();
        for c in &self.crashes {
            crash_lookup.insert((c.workload.clone(), c.rows));
            // Ensure crashed workloads appear in the name list.
            if !workload_names.contains(&c.workload) {
                workload_names.push(c.workload.clone());
            }
        }

        // (The headline geomean is now rendered at the top of the report by
        // `render_geomean_headline`. We retain `n_tests` here for the
        // per-workload Bonferroni-adjusted p in the detail tables.)
        let n_tests = self.workloads.len() + self.crashes.len();

        // Summary table: workload × scale → speedup
        out.push_str("## Results\n\n");
        out.push_str(
            "All comparisons are against PostgreSQL with parallel workers enabled \
             (the default production configuration). Speedup > 1.00x means pg_accel \
             is faster.\n\n",
        );

        // Header
        out.push_str("| Workload |");
        for &s in scales {
            let _ = write!(out, " {} |", format_rows(s));
        }
        out.push('\n');
        out.push_str("|----------|");
        for _ in scales {
            out.push_str("------|");
        }
        out.push('\n');

        // Data rows. action_items L: crash cells render as `CRASH` so they
        // are visually distinct from "no result". Workloads with one or more
        // crashes get an asterisk in the row name and a `(N/M kernels stable)`
        // annotation reflecting how many of the attempted scales actually
        // produced a result. The headline rate uses median speedup.
        for name in &workload_names {
            // Count crashed scales for this workload across the requested
            // scale list. attempted = scales that have either a result or a
            // crash. stable = scales with a non-crash result.
            let mut attempted = 0usize;
            let mut stable = 0usize;
            for &s in scales {
                let has_result = lookup.contains_key(&(name.as_str(), s));
                let has_crash = crash_lookup.contains(&(name.clone(), s));
                if has_result || has_crash {
                    attempted += 1;
                }
                if has_result {
                    stable += 1;
                }
            }
            let any_crash = stable < attempted && attempted > 0;
            let display_name = if any_crash {
                format!("{name}* ({stable}/{attempted} kernels stable)")
            } else {
                name.clone()
            };
            let _ = write!(out, "| {display_name} |");
            for &s in scales {
                if let Some(w) = lookup.get(&(name.as_str(), s)) {
                    let sp = w.speedup_median_vs_parallel;
                    // Significance gate: |d| ≥ 0.5 AND Bonferroni p < 0.05.
                    let adj = stats::bonferroni_adjusted_p(w.p_value_vs_parallel, n_tests);
                    let sig = adj.is_finite() && adj < 0.05 && w.effect_size_meaningful;
                    if sig && sp > 1.005 {
                        let _ = write!(out, " **{sp:.2}x** |");
                    } else {
                        let _ = write!(out, " {sp:.2}x |");
                    }
                } else if crash_lookup.contains(&(name.clone(), s)) {
                    out.push_str(" CRASH |");
                } else {
                    out.push_str(" — |");
                }
            }
            out.push('\n');
        }
        out.push('\n');

        // Detailed per-workload sections
        out.push_str("## Detailed Results\n\n");
        for name in &workload_names {
            let _ = writeln!(out, "### {name}\n");

            // Get description from first result
            if let Some(w) = self.workloads.iter().find(|w| w.name == *name) {
                let _ = writeln!(out, "**Query:** {}\n", w.description);
            }

            // Per-scale detail table. action_items F+G+I:
            //   - median (with p25/p75/p95) is the headline timing column,
            //     mean is supplementary
            //   - Cohen's d is shown alongside Bonferroni p
            //   - the significance verdict requires BOTH |d|≥0.5 AND Bonferroni
            //   - p-values are formatted to ≥6 sig figs scientific notation
            //   - rows where cv_ratio > 3 are flagged "(asymmetric variance)"
            let _ = writeln!(
                out,
                "| Scale | Accel median (ms) | Accel p25–p75 | PG Parallel median (ms) | \
                 PG p25–p75 | Speedup (median) | Cohen's d | p (Bonferroni) | Verdict | \
                 Resident Load (ms) |"
            );
            let _ = writeln!(out, "|---|---|---|---|---|---|---|---|---|---|");
            for &s in scales {
                if let Some(w) = lookup.get(&(name.as_str(), s)) {
                    let dispatch_view = normalized_lookup
                        .get(&(name.as_str(), s))
                        .copied()
                        .unwrap_or(*w);
                    let adj_p = stats::bonferroni_adjusted_p(w.p_value_vs_parallel, n_tests);
                    let bonf_sig = adj_p.is_finite() && adj_p < 0.05;
                    let verdict = if !dispatch_view.gpu_kernel_dispatched {
                        dispatch_evidence_label(dispatch_view)
                    } else if bonf_sig && w.effect_size_meaningful {
                        if w.speedup_median_vs_parallel > 1.0 {
                            "WIN"
                        } else {
                            "LOSS"
                        }
                    } else if bonf_sig {
                        // Bonferroni passed but effect size below 0.5.
                        "p-only"
                    } else {
                        "ns"
                    };
                    let asym = if w.cv_ratio.is_finite() && w.cv_ratio > 3.0 {
                        " (asym var)"
                    } else {
                        ""
                    };
                    // Resident-cache preload cost, when this row required one
                    // (`ssbm_*` / `resident_*` lanes). Paid once, off the
                    // timed clock, and amortized across repeated queries
                    // against the same resident cache — surfaced here so the
                    // report never hides what the accel side got for free.
                    let resident_load = if w.resident_lane {
                        format_optional_ms(w.resident_load_ms)
                    } else {
                        "-".to_owned()
                    };
                    let _ = writeln!(
                        out,
                        "| {} | {:.2}{} | {:.2}–{:.2} (p95 {:.2}) | {:.2}{} | \
                         {:.2}–{:.2} (p95 {:.2}) | **{:.2}x** | {:.2} | {} | {} | {} |",
                        format_rows(s),
                        w.accel_median_ms,
                        asym,
                        w.accel_p25_ms,
                        w.accel_p75_ms,
                        w.accel_p95_ms,
                        w.parallel_median_ms,
                        asym,
                        w.parallel_p25_ms,
                        w.parallel_p75_ms,
                        w.parallel_p95_ms,
                        w.speedup_median_vs_parallel,
                        w.cohens_d_vs_parallel,
                        format_pvalue(adj_p),
                        verdict,
                        resident_load,
                    );
                }
            }
            out.push('\n');

            // Evidence appendix: warm/cold split (never pooled), cold-cache
            // shared_buffers warning, native-decline evidence source, and a
            // truncated plan-snippet preview. Rendered as notes rather than
            // extra columns on the primary table above so the headline shape
            // stays stable while the honesty-critical evidence is still
            // visible per row.
            for &s in scales {
                if let Some(w) = lookup.get(&(name.as_str(), s)) {
                    render_workload_evidence_notes(w, &format_rows(s), &mut out);
                }
            }
        }

        // -------------------------------------------------------------------
        // Regressions: workloads significantly slower than PG parallel.
        // -------------------------------------------------------------------
        //
        // A workload makes the list only if it's BOTH slower by >10% AND
        // statistically significant after Bonferroni correction. Sorted by
        // absolute slowdown (worst first).
        let normalized_for_regressions = self.with_normalized_dispatch();
        let mut regressions: Vec<&WorkloadResult> = normalized_for_regressions
            .workloads
            .iter()
            .filter(|w| {
                let adj_p = stats::bonferroni_adjusted_p(w.p_value_vs_parallel, n_tests);
                w.gpu_kernel_dispatched
                    && w.speedup_vs_parallel < 0.90
                    && adj_p.is_finite()
                    && adj_p < 0.05
                    && w.effect_size_meaningful
            })
            .collect();
        regressions.sort_by(|a, b| {
            a.speedup_vs_parallel
                .partial_cmp(&b.speedup_vs_parallel)
                .unwrap_or(std::cmp::Ordering::Equal)
        });
        if !regressions.is_empty() {
            out.push_str("## Regressions\n\n");
            out.push_str(
                "Workloads where pg_accel is **statistically significantly slower** than PG \
                 parallel with credited GPU dispatch (>10% slowdown, Bonferroni-corrected \
                 p < 0.05). Planner-declined/no-dispatch rows are reported in the \
                 no-dispatch audit instead of here.\n\n",
            );
            let _ = writeln!(
                out,
                "| Workload | Scale | Speedup (median) | Cohen's d | Accel median (ms) | \
                 PG median (ms) | p (Bonferroni) |"
            );
            let _ = writeln!(out, "|---|---|---|---|---|---|---|");
            for w in &regressions {
                let adj_p = stats::bonferroni_adjusted_p(w.p_value_vs_parallel, n_tests);
                let _ = writeln!(
                    out,
                    "| {} | {} | {:.2}x | {:.2} | {:.2} | {:.2} | {} |",
                    w.name,
                    format_rows(w.rows),
                    w.speedup_median_vs_parallel,
                    w.cohens_d_vs_parallel,
                    w.accel_median_ms,
                    w.parallel_median_ms,
                    format_pvalue(adj_p),
                );
            }
            out.push('\n');
        }

        // -------------------------------------------------------------------
        // Non-Dispatching: workloads where speedup ≈ 1.0, meaning pg_accel
        // almost certainly did not dispatch to the GPU (no custom scan, or
        // dispatch rejected). These are the most informative diagnostic rows
        // — they tell us which workloads never even got off the starting line.
        // -------------------------------------------------------------------
        let normalized_dispatch = self.with_normalized_dispatch();
        let non_dispatch: Vec<&WorkloadResult> = normalized_dispatch
            .workloads
            .iter()
            .filter(|w| !w.gpu_kernel_dispatched)
            .collect();
        if !non_dispatch.is_empty() {
            out.push_str("## Non-Dispatching Workloads\n\n");
            out.push_str(
                "Workloads where runtime counters did not prove GPU dispatch. These are not GPU \
                 performance conclusions. If the no-dispatch audit flags a row, treat it as \
                 harness/planner skew until the pg_accel-side plan either dispatches to GPU or \
                 normal PostgreSQL planning cleanly declines the pg_accel path.\n\n",
            );
            let _ = writeln!(
                out,
                "| Workload | Scale | Classification | Speedup | Accel (ms) | PG Parallel (ms) |"
            );
            let _ = writeln!(out, "|---|---|---|---|---|---|");
            for w in &non_dispatch {
                let _ = writeln!(
                    out,
                    "| {} | {} | {} | {:.2}x | {:.2} | {:.2} |",
                    w.name,
                    format_rows(w.rows),
                    dispatch_evidence_label(w),
                    w.speedup_vs_parallel,
                    w.accel_mean_ms,
                    w.parallel_mean_ms,
                );
            }
            out.push('\n');
        }

        // Crashed scales section
        if !self.crashes.is_empty() {
            out.push_str("## Crashed Scales\n\n");
            out.push_str(
                "The following workload/scale combinations crashed the PostgreSQL \
                 backend and were excluded from results. Artifact paths are relative \
                 to the artifact directory when one was configured.\n\n",
            );
            let _ = writeln!(
                out,
                "| Workload | Scale | Error | Plan Snippet | Correctness Diff | Log Tails | Repro |"
            );
            let _ = writeln!(
                out,
                "|----------|-------|-------|--------------|------------------|-----------|-------|"
            );
            for c in &self.crashes {
                // Char-boundary-safe truncation: byte-slicing at a fixed
                // offset panics if the cut falls inside a multibyte UTF-8
                // sequence.
                let short_err = if c.error.chars().count() > 80 {
                    let truncated: String = c.error.chars().take(77).collect();
                    format!("{truncated}...")
                } else {
                    c.error.clone()
                };
                let plan = c.plan_snippet_artifact.as_deref().unwrap_or("-");
                let correctness = c.correctness_diff_artifact.as_deref().unwrap_or("-");
                let logs = if c.log_tail_artifacts.is_empty() {
                    "-".to_owned()
                } else {
                    c.log_tail_artifacts.join("<br>")
                };
                let repro = c.repro_command.as_deref().unwrap_or("-");
                let _ = writeln!(
                    out,
                    "| {} | {} | {} | {} | {} | {} | `{}` |",
                    c.workload,
                    format_rows(c.rows),
                    short_err,
                    plan,
                    correctness,
                    logs,
                    repro,
                );
            }
            out.push('\n');
        }

        out
    }

    /// Render the report as JSON.
    ///
    /// # Errors
    ///
    /// Returns an error if serialization fails (should not happen in practice).
    pub fn to_json(&self) -> Result<String, serde_json::Error> {
        serde_json::to_string_pretty(&self.with_normalized_dispatch())
    }

    /// Render the report as CSV (one row per workload per scale, two-way).
    #[must_use]
    pub fn to_csv(&self) -> String {
        let report = self.with_normalized_dispatch();
        let mut out = String::new();
        out.push_str(
            "workload,category,kernel_class,plan_selected,gpu_kernel_dispatched,\
             function_srf_kernel_dispatched,planner_declined,\
             custom_scan_selected_not_dispatched,function_kernel_count,\
             rows_returned_to_cpu,gpu_resident_pipeline,dispatch_counter_captured,\
             gpu_kernel_execution_delta,pg_accel_queries_accelerated_delta,pg_accel_rows_dispatched_delta,\
             pg_accel_batches_executed_delta,pg_accel_gpu_rows_processed_delta,\
             pg_accel_stock_exec_delta,\
             accel_output_rows_consumed,rows,correctness_diff_artifact,\
             warmup_count,warmup_accel_first_ms,warmup_accel_max_ms,\
             warmup_accel_post_first_max_ms,warmup_parallel_first_ms,warmup_parallel_max_ms,\
             baseline_dispatched,no_dispatch_timing_skew,no_dispatch_plan_mismatch,\
             accel_mean_ms,accel_stddev_ms,accel_median_ms,accel_p25_ms,accel_p75_ms,accel_p95_ms,\
             accel_cv_pct,accel_min_ms,accel_max_ms,\
             parallel_mean_ms,parallel_stddev_ms,parallel_median_ms,parallel_p25_ms,parallel_p75_ms,\
             parallel_p95_ms,parallel_cv_pct,parallel_min_ms,parallel_max_ms,\
             sanity_check_count,sanity_check_failed,\
             speedup_vs_parallel,speedup_median_vs_parallel,p_value_vs_parallel,\
             cohens_d_vs_parallel,effect_size_meaningful,cv_ratio,significant\n",
        );
        for w in &report.workloads {
            let baseline_dispatched = baseline_plan_dispatches(w);
            let timing_skew = no_dispatch_timing_skew(w);
            let plan_mismatch = no_dispatch_plan_mismatch(w);
            let sig = if w.p_value_vs_parallel < 0.01 {
                "yes"
            } else if w.p_value_vs_parallel < 0.05 {
                "marginal"
            } else {
                "no"
            };
            let warmup_accel_first = csv_optional_f64(w.warmup_accel_first_ms);
            let warmup_accel_max = csv_optional_f64(w.warmup_accel_max_ms);
            let warmup_accel_post_first_max = csv_optional_f64(w.warmup_accel_post_first_max_ms);
            let warmup_parallel_first = csv_optional_f64(w.warmup_parallel_first_ms);
            let warmup_parallel_max = csv_optional_f64(w.warmup_parallel_max_ms);
            let sanity_check_count = w.sanity_checks.len();
            let sanity_check_failed = w.sanity_checks.iter().filter(|check| !check.passed).count();
            let _ = writeln!(
                out,
                "{},{},{},{},{},{},{},{},{},{},{},{},{},{},{},\
                 {},{},{},{},{},{},{},{},{},{},{},{},{},{},{},\
                 {:.4},{:.4},{:.4},{:.4},{:.4},{:.4},\
                 {:.4},{:.4},{:.4},\
                 {:.4},{:.4},{:.4},{:.4},{:.4},\
                 {:.4},{:.4},{:.4},{:.4},{},{},\
                 {:.4},{:.4},{:.6e},\
                 {:.4},{},{:.4},{}",
                w.name,
                w.category,
                w.kernel_class,
                w.plan_selected,
                w.gpu_kernel_dispatched,
                w.function_srf_kernel_dispatched,
                w.planner_declined,
                w.custom_scan_selected_not_dispatched,
                w.function_kernel_count,
                w.rows_returned_to_cpu,
                w.gpu_resident_pipeline.as_str(),
                w.dispatch_counter_captured,
                w.gpu_kernel_execution_delta,
                w.pg_accel_queries_accelerated_delta,
                w.pg_accel_rows_dispatched_delta,
                w.pg_accel_batches_executed_delta,
                w.pg_accel_gpu_rows_processed_delta,
                w.pg_accel_stock_exec_delta,
                w.accel_output_rows_consumed,
                w.rows,
                w.correctness_diff_artifact.as_deref().unwrap_or(""),
                w.warmup_iterations.len(),
                warmup_accel_first,
                warmup_accel_max,
                warmup_accel_post_first_max,
                warmup_parallel_first,
                warmup_parallel_max,
                baseline_dispatched,
                timing_skew,
                plan_mismatch,
                w.accel_mean_ms,
                w.accel_stddev_ms,
                w.accel_median_ms,
                w.accel_p25_ms,
                w.accel_p75_ms,
                w.accel_p95_ms,
                w.accel_cv_pct,
                w.accel_min_ms,
                w.accel_max_ms,
                w.parallel_mean_ms,
                w.parallel_stddev_ms,
                w.parallel_median_ms,
                w.parallel_p25_ms,
                w.parallel_p75_ms,
                w.parallel_p95_ms,
                w.parallel_cv_pct,
                w.parallel_min_ms,
                w.parallel_max_ms,
                sanity_check_count,
                sanity_check_failed,
                w.speedup_vs_parallel,
                w.speedup_median_vs_parallel,
                w.p_value_vs_parallel,
                w.cohens_d_vs_parallel,
                w.effect_size_meaningful,
                w.cv_ratio,
                sig,
            );
        }
        out
    }

    /// Render the headline geomean callout banner that sits at the top of
    /// the markdown report.
    ///
    /// action_items K + M7 + H + L + M:
    ///   - The geomean is the lede; reviewers should not have to scroll
    ///   - Sub-1.0x runs are labeled "net regression"
    ///   - Each category row shows sig wins / sig losses / total sig
    ///     using the |d| ≥ 0.5 AND Bonferroni gate
    ///   - "overall wins outside h3" appears as a separate row so the
    ///     trig-kernel artifact (Reviewer 1 Sin #9) is visible
    ///   - Crashed scales count toward the family size for Bonferroni
    ///     so adding more crashes does NOT make the surviving rows
    ///     accidentally pass significance
    ///   - Workloads where `gpu_kernel_dispatched == false` are excluded
    ///     from per-category geomeans (action_items M)
    fn render_geomean_headline(&self, out: &mut String) {
        let report = self.with_normalized_dispatch();
        // Family size for Bonferroni = attempted scales = workloads + crashes.
        // This is the same value used by the detail tables so the two views
        // never disagree.
        let family_size = report.workloads.len() + report.crashes.len();
        let speedup_label = "median speedup";
        let speedup_of = |w: &WorkloadResult| -> f64 { w.speedup_median_vs_parallel };

        // ----- Overall (dispatched only) -----
        let dispatched: Vec<&WorkloadResult> = report
            .workloads
            .iter()
            .filter(|w| w.gpu_kernel_dispatched)
            .collect();
        let dispatched_speedups: Vec<f64> = dispatched.iter().map(|w| speedup_of(w)).collect();
        let overall_gm = stats::geomean(&dispatched_speedups);
        let overall_counts = classify_significance(&dispatched, family_size, 0.05);

        let label = if overall_gm < 1.0 {
            "**NET REGRESSION**"
        } else if overall_gm < 1.05 {
            "**NEUTRAL** (within noise)"
        } else {
            "**NET SPEEDUP**"
        };
        out.push_str("## Headline\n\n");
        let _ = writeln!(
            out,
            "> {label}: overall {speedup_label} = **{overall_gm:.2}x** \
             (geomean across {n} GPU-dispatched workloads, family size = {family_size}).",
            n = dispatched.len(),
        );
        let _ = writeln!(
            out,
            ">\n> Significant wins: **{}** · Significant losses: **{}** · \
             Not significant: **{}** · Effect-size rejected: **{}**",
            overall_counts.sig_wins,
            overall_counts.sig_losses,
            overall_counts.not_significant,
            overall_counts.effect_rejected,
        );
        if !report.crashes.is_empty() {
            let _ = writeln!(
                out,
                ">\n> {n_crash} scale(s) crashed and are counted in the Bonferroni \
                 family size but not in the geomean.",
                n_crash = report.crashes.len(),
            );
        }
        out.push('\n');

        // ----- Per-category table -----
        // Group dispatched workloads by category for the breakdown.
        let mut by_cat: BTreeMap<String, Vec<&WorkloadResult>> = BTreeMap::new();
        for w in &dispatched {
            by_cat.entry(w.category.clone()).or_default().push(*w);
        }

        out.push_str("### Geomean by Category\n\n");
        out.push_str(
            "Sub-1.0x categories are losers. The `outside_h3` row excludes \
             `gpu_h3` workloads — the h3 trig kernels dominate the wall-clock \
             aggregate so this row is the more honest non-h3 picture.\n\n",
        );
        let _ = writeln!(
            out,
            "| Category | Workloads | Geomean ({speedup_label}) | Sig Wins | \
             Sig Losses | Total Sig | Not Sig |"
        );
        let _ = writeln!(out, "|---|---|---|---|---|---|---|");
        for (cat, ws) in &by_cat {
            let speedups: Vec<f64> = ws.iter().map(|w| speedup_of(w)).collect();
            let gm = stats::geomean(&speedups);
            let counts = classify_significance(ws, family_size, 0.05);
            let _ = writeln!(
                out,
                "| {cat} | {} | {gm:.2}x | {} | {} | {} | {} |",
                ws.len(),
                counts.sig_wins,
                counts.sig_losses,
                counts.total_sig,
                counts.not_significant,
            );
        }

        // outside_h3 row.
        let outside_h3: Vec<&WorkloadResult> = dispatched
            .iter()
            .copied()
            .filter(|w| w.category != "gpu_h3")
            .collect();
        let outside_speedups: Vec<f64> = outside_h3.iter().map(|w| speedup_of(w)).collect();
        let outside_gm = stats::geomean(&outside_speedups);
        let outside_counts = classify_significance(&outside_h3, family_size, 0.05);
        let _ = writeln!(
            out,
            "| **outside_h3** | **{}** | **{outside_gm:.2}x** | **{}** | **{}** | **{}** | **{}** |",
            outside_h3.len(),
            outside_counts.sig_wins,
            outside_counts.sig_losses,
            outside_counts.total_sig,
            outside_counts.not_significant,
        );

        // overall row.
        let _ = writeln!(
            out,
            "| **overall (GPU-dispatched)** | **{}** | **{overall_gm:.2}x** | **{}** | **{}** | **{}** | **{}** |",
            dispatched.len(),
            overall_counts.sig_wins,
            overall_counts.sig_losses,
            overall_counts.total_sig,
            overall_counts.not_significant,
        );
        out.push('\n');

        // ----- Per-dispatch-source split ------------------------------------
        //
        // Custom Scan dispatch and Function/SRF kernel dispatch share the
        // headline geomean, but a single combined number hides which path
        // earned the win. This sub-table prints the geomean / wins / losses
        // for each dispatch source separately so reviewers can see at a
        // glance whether the headline is being carried by Custom Scan
        // execution, the function/SRF kernel hook, or both.
        let custom_scan_dispatched: Vec<&WorkloadResult> = dispatched
            .iter()
            .copied()
            .filter(|w| !w.function_srf_kernel_dispatched)
            .collect();
        let function_srf_dispatched: Vec<&WorkloadResult> = dispatched
            .iter()
            .copied()
            .filter(|w| w.function_srf_kernel_dispatched)
            .collect();

        out.push_str("### Geomean by Dispatch Source\n\n");
        out.push_str(
            "Splits the `overall (GPU-dispatched)` row into two buckets: \
             pg_accel Custom Scan execution and function/SRF kernel dispatch. \
             Custom Scan rows have a `Custom Scan` plan node; function/SRF \
             rows have non-zero `function_kernel_count` without a Custom \
             Scan node. Either bucket counts as a GPU-dispatched win, but \
             they exercise different code paths and the report must not \
             collapse them into a single bar.\n\n",
        );
        let _ = writeln!(
            out,
            "| Dispatch Source | Workloads | Geomean ({speedup_label}) | Sig Wins | \
             Sig Losses | Total Sig | Not Sig |"
        );
        let _ = writeln!(out, "|---|---|---|---|---|---|---|");

        let cs_speedups: Vec<f64> = custom_scan_dispatched
            .iter()
            .map(|w| speedup_of(w))
            .collect();
        let cs_gm = stats::geomean(&cs_speedups);
        let cs_counts = classify_significance(&custom_scan_dispatched, family_size, 0.05);
        let _ = writeln!(
            out,
            "| Custom Scan dispatch | {} | {cs_gm:.2}x | {} | {} | {} | {} |",
            custom_scan_dispatched.len(),
            cs_counts.sig_wins,
            cs_counts.sig_losses,
            cs_counts.total_sig,
            cs_counts.not_significant,
        );

        let fn_speedups: Vec<f64> = function_srf_dispatched
            .iter()
            .map(|w| speedup_of(w))
            .collect();
        let fn_gm = stats::geomean(&fn_speedups);
        let fn_counts = classify_significance(&function_srf_dispatched, family_size, 0.05);
        let _ = writeln!(
            out,
            "| Function/SRF kernel dispatch | {} | {fn_gm:.2}x | {} | {} | {} | {} |",
            function_srf_dispatched.len(),
            fn_counts.sig_wins,
            fn_counts.sig_losses,
            fn_counts.total_sig,
            fn_counts.not_significant,
        );
        out.push('\n');

        // ----- Resident-cache lane split -----
        //
        // Resident lanes (`ssbm_*` / `resident_*`) pre-load GPU-resident
        // caches OFF the timed clock, while the PG-parallel baseline pays
        // scan I/O ON the clock for the same query. That is a real and
        // legitimate difference, but it must never hide inside one combined
        // geomean bar — a reviewer needs to be able to tell "this win
        // includes off-clock preload" from "this win did not". See
        // `resident_load_ms` in Detailed Results for the per-row preload
        // cost.
        let resident_dispatched: Vec<&WorkloadResult> = dispatched
            .iter()
            .copied()
            .filter(|w| w.resident_lane)
            .collect();
        let non_resident_dispatched: Vec<&WorkloadResult> = dispatched
            .iter()
            .copied()
            .filter(|w| !w.resident_lane)
            .collect();

        out.push_str("### Geomean by Resident-Cache Lane\n\n");
        out.push_str(
            "Splits the `overall (GPU-dispatched)` row into resident-cache lanes \
             (pre-load caches off the timed clock; see `resident_load_ms` per row in \
             Detailed Results) and non-resident lanes (no off-clock preload). Both \
             buckets count as GPU-dispatched wins, but only the non-resident bucket is \
             directly comparable to a PG-parallel baseline that pays scan I/O on the \
             clock.\n\n",
        );
        let _ = writeln!(
            out,
            "| Lane | Workloads | Geomean ({speedup_label}) | Sig Wins | \
             Sig Losses | Total Sig | Not Sig |"
        );
        let _ = writeln!(out, "|---|---|---|---|---|---|---|");

        let resident_speedups: Vec<f64> =
            resident_dispatched.iter().map(|w| speedup_of(w)).collect();
        let resident_gm = stats::geomean(&resident_speedups);
        let resident_counts = classify_significance(&resident_dispatched, family_size, 0.05);
        let _ = writeln!(
            out,
            "| Resident-cache lane | {} | {resident_gm:.2}x | {} | {} | {} | {} |",
            resident_dispatched.len(),
            resident_counts.sig_wins,
            resident_counts.sig_losses,
            resident_counts.total_sig,
            resident_counts.not_significant,
        );

        let non_resident_speedups: Vec<f64> = non_resident_dispatched
            .iter()
            .map(|w| speedup_of(w))
            .collect();
        let non_resident_gm = stats::geomean(&non_resident_speedups);
        let non_resident_counts =
            classify_significance(&non_resident_dispatched, family_size, 0.05);
        let _ = writeln!(
            out,
            "| Non-resident lane | {} | {non_resident_gm:.2}x | {} | {} | {} | {} |",
            non_resident_dispatched.len(),
            non_resident_counts.sig_wins,
            non_resident_counts.sig_losses,
            non_resident_counts.total_sig,
            non_resident_counts.not_significant,
        );
        out.push('\n');

        // ----- CRASH summary rows (action_items L) -----
        if !report.crashes.is_empty() {
            out.push_str("### Crashed scales\n\n");
            let _ = writeln!(
                out,
                "| Workload | Scale | Error | Plan Snippet | Log Tails | Repro |"
            );
            let _ = writeln!(out, "|---|---|---|---|---|---|");
            for c in &report.crashes {
                // Char-boundary-safe truncation: byte-slicing at a fixed
                // offset panics if the cut falls inside a multibyte UTF-8
                // sequence (e.g. an error message containing non-ASCII
                // identifiers or copy-pasted terminal output).
                let short = if c.error.chars().count() > 80 {
                    let truncated: String = c.error.chars().take(77).collect();
                    format!("{truncated}...")
                } else {
                    c.error.clone()
                };
                let plan = c.plan_snippet_artifact.as_deref().unwrap_or("-");
                let logs = if c.log_tail_artifacts.is_empty() {
                    "-".to_owned()
                } else {
                    c.log_tail_artifacts.join("<br>")
                };
                let repro = c.repro_command.as_deref().unwrap_or("-");
                let _ = writeln!(
                    out,
                    "| {} | {} | CRASH: {} | {} | {} | `{}` |",
                    c.workload,
                    format_rows(c.rows),
                    short,
                    plan,
                    logs,
                    repro,
                );
            }
            out.push('\n');
        }
    }

    fn render_planner_threshold_matrix(&self, out: &mut String) {
        let report = self.with_normalized_dispatch();
        let mut rows: Vec<(
            &WorkloadResult,
            crate::workloads::BenchmarkThresholdMatrixEntry,
        )> = report
            .workloads
            .iter()
            .filter_map(|w| {
                crate::workloads::benchmark_threshold_matrix_entry(&w.name, w.rows)
                    .map(|entry| (w, entry))
            })
            .collect();
        rows.sort_by(|(a, left), (b, right)| {
            left.lane
                .cmp(right.lane)
                .then_with(|| a.name.cmp(&b.name))
                .then_with(|| a.rows.cmp(&b.rows))
        });
        if rows.is_empty() {
            return;
        }

        out.push_str("## Planner Threshold Matrix\n\n");
        out.push_str(
            "Each row ties planner admission to a concrete release-lane matrix cell: \
             row count, type, cardinality, selectivity, result count, index/pruning \
             shape, retained prepared geometry, batch count, row width, output size, \
             dispatch/output proof, correctness proof, cache policy, warm-run proof, and \
             measured break-even basis. Expected GPU winners must dispatch, consume \
             output, and meet their warm-run threshold; native-decline cells must not \
             select pg_accel. Privileged OS-cold certification is evaluated by \
             the separate operation-cache gate.\n\n",
        );
        let _ = writeln!(
            out,
            "| Lane | Workload | Scale | Type | Cardinality | Selectivity | Result Count | \
             Index/Pruning | Prepared Geometry | Batches | Row Width | Output | \
             Dispatch/Output Evidence | Correctness Evidence | Cache Gate | \
             Threshold Basis | Expected | Observed | Decline Evidence | Speedup | Status |"
        );
        let _ = writeln!(
            out,
            "|---|---|---:|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---:|---|"
        );
        for (workload, entry) in rows {
            let status = threshold_matrix_status(workload, entry.lane, entry.expectation);
            let expected = threshold_matrix_expectation_label(entry.expectation);
            let observed = dispatch_evidence_label(workload);
            let decline_evidence = native_decline_evidence_label(workload);
            let _ = writeln!(
                out,
                "| {} | {} | {} | {} | {} | {} | {} | {} | {} | {} | {} | {} | {} | {} | {} | {} | {} | {} | {} | {:.2}x | {} |",
                markdown_cell(entry.lane),
                markdown_cell(entry.workload),
                format_rows(entry.rows),
                markdown_cell(entry.data_type),
                markdown_cell(entry.cardinality),
                markdown_cell(entry.selectivity),
                markdown_cell(&entry.result_count),
                markdown_cell(entry.index_pruning_shape),
                markdown_cell(entry.prepared_geometry),
                markdown_cell(&entry.batch_count),
                markdown_cell(entry.row_width),
                markdown_cell(entry.output_size),
                markdown_cell(entry.dispatch_evidence),
                markdown_cell(entry.correctness_evidence),
                markdown_cell(entry.cache_gate),
                markdown_cell(entry.threshold_basis),
                markdown_cell(&expected),
                observed,
                markdown_cell(&decline_evidence),
                workload.speedup_median_vs_parallel,
                status,
            );
        }
        out.push('\n');
    }

    fn render_cache_purge_audit(&self, out: &mut String) {
        let mut rows: Vec<(&WorkloadResult, Vec<usize>, Vec<usize>)> = Vec::new();
        for workload in &self.workloads {
            let unavailable = iteration_indexes_with_cache_purge(
                &workload.iterations,
                CachePurgeState::Unavailable,
            );
            let failed =
                iteration_indexes_with_cache_purge(&workload.iterations, CachePurgeState::Failed);
            if !unavailable.is_empty() || !failed.is_empty() {
                rows.push((workload, unavailable, failed));
            }
        }
        if rows.is_empty() {
            return;
        }

        out.push_str("## Cache Purge Audit\n\n");
        out.push_str(
            "Cold-cache iterations whose OS page-cache purge could not be proven are \
             marked here and in `report.json` so skips/failures do not depend on \
             terminal scrollback.\n\n",
        );
        let _ = writeln!(
            out,
            "| Workload | Scale | Unavailable purge iterations | Failed purge iterations |"
        );
        let _ = writeln!(out, "|---|---:|---|---|");
        for (workload, unavailable, failed) in rows {
            let _ = writeln!(
                out,
                "| {} | {} | {} | {} |",
                markdown_cell(&workload.name),
                format_rows(workload.rows),
                markdown_cell(&format_iteration_indexes(&unavailable)),
                markdown_cell(&format_iteration_indexes(&failed)),
            );
        }
        out.push('\n');
    }

    fn render_warmup_jit_audit(&self, out: &mut String) {
        let mut rows: Vec<(&WorkloadResult, String)> = self
            .workloads
            .iter()
            .filter_map(|workload| {
                warmup_jit_audit_reason(workload).map(|reason| (workload, reason))
            })
            .collect();
        rows.sort_by(|(left, _), (right, _)| {
            right
                .warmup_accel_post_first_max_ms
                .partial_cmp(&left.warmup_accel_post_first_max_ms)
                .unwrap_or(std::cmp::Ordering::Equal)
        });
        if rows.is_empty() {
            return;
        }

        out.push_str("## Warmup/JIT Audit\n\n");
        out.push_str(
            "Warmup timings are excluded from published statistics, but retained in \
             `report.json`. Rows here had post-first warmup spikes large enough to \
             suggest recurring JIT/runtime latency rather than a single cold compile.\n\n",
        );
        let _ = writeln!(
            out,
            "| Workload | Scale | Warmups | First accel | Max accel | Post-first max accel | Measured accel median | Reason |"
        );
        let _ = writeln!(out, "|---|---:|---:|---:|---:|---:|---:|---|");
        for (workload, reason) in rows {
            let _ = writeln!(
                out,
                "| {} | {} | {} | {} | {} | {} | {} | {} |",
                markdown_cell(&workload.name),
                format_rows(workload.rows),
                workload.warmup_iterations.len(),
                format_optional_ms(workload.warmup_accel_first_ms),
                format_optional_ms(workload.warmup_accel_max_ms),
                format_optional_ms(workload.warmup_accel_post_first_max_ms),
                format_optional_ms(Some(workload.accel_median_ms)),
                markdown_cell(&reason),
            );
        }
        out.push('\n');
    }

    fn render_sanity_checks(&self, out: &mut String) {
        let rows: Vec<(&WorkloadResult, &SanityCheck)> = self
            .workloads
            .iter()
            .flat_map(|workload| {
                workload
                    .sanity_checks
                    .iter()
                    .map(move |check| (workload, check))
            })
            .collect();
        if rows.is_empty() {
            return;
        }

        let failed = rows.iter().filter(|(_, check)| !check.passed).count();
        out.push_str("## Benchmark Sanity Checks\n\n");
        let _ = writeln!(
            out,
            "Captured after setup and before timing. Zero-row dimension filters are release-blocking \
             because they can make no-dispatch SSBM rows look like GPU performance results. \
             Failed checks: **{failed}**.\n"
        );
        let _ = writeln!(out, "| Workload | Scale | Check | Count | Status |");
        let _ = writeln!(out, "|---|---|---|---:|---|");
        for (workload, check) in rows {
            let status = if check.passed { "pass" } else { "FAIL" };
            let _ = writeln!(
                out,
                "| {} | {} | {} | {} | {} |",
                workload.name,
                format_rows(workload.rows),
                markdown_cell(&check.label),
                check.count,
                status,
            );
        }
        out.push('\n');
    }

    fn render_dispatch_classification(&self, out: &mut String) {
        let report = self.with_normalized_dispatch();
        let total = report.workloads.len();
        let plan_selected = report.workloads.iter().filter(|w| w.plan_selected).count();
        let gpu_kernel_dispatched = report
            .workloads
            .iter()
            .filter(|w| w.gpu_kernel_dispatched)
            .count();
        let function_srf_kernel_dispatched = report
            .workloads
            .iter()
            .filter(|w| w.function_srf_kernel_dispatched)
            .count();
        let lifecycle_artifact_reuse_credited = report
            .workloads
            .iter()
            .filter(|w| derived_output_artifact_reuse_evidence_verified(w))
            .count();
        let counter_capture = report
            .workloads
            .iter()
            .filter(|w| w.dispatch_counter_captured)
            .count();
        let kernel_counter_positive = report
            .workloads
            .iter()
            .filter(|w| w.gpu_kernel_execution_delta > 0)
            .count();
        let accelerated_query_coverage = report
            .workloads
            .iter()
            .filter(|w| {
                usize::try_from(w.pg_accel_queries_accelerated_delta)
                    .is_ok_and(|queries| queries >= w.iterations.len())
            })
            .count();
        let stock_exec_positive = report
            .workloads
            .iter()
            .filter(|w| w.pg_accel_stock_exec_delta > 0)
            .count();
        let plan_only = report
            .workloads
            .iter()
            .filter(|w| w.custom_scan_selected_not_dispatched)
            .count();
        let planner_declined = report
            .workloads
            .iter()
            .filter(|w| w.planner_declined)
            .count();
        let function_kernel_count: u64 = report
            .workloads
            .iter()
            .map(|w| w.function_kernel_count)
            .sum();
        let rows_returned_to_cpu: u64 = report
            .workloads
            .iter()
            .map(|w| w.rows_returned_to_cpu)
            .sum();
        let gpu_resident_reported = report
            .workloads
            .iter()
            .filter(|w| w.gpu_resident_pipeline == GpuResidentPipelineStatus::Reported)
            .count();
        let gpu_resident_not_reported = report
            .workloads
            .iter()
            .filter(|w| w.plan_selected && w.gpu_kernel_dispatched)
            .filter(|w| w.gpu_resident_pipeline != GpuResidentPipelineStatus::Reported)
            .count();
        let gpu_resident_boundary_recorded = report
            .workloads
            .iter()
            .filter(|w| w.plan_selected && w.gpu_resident_boundary_reason.is_some())
            .count();
        let native_output_filter_rows = report
            .workloads
            .iter()
            .filter(|w| w.plan_selected && w.native_post_aggregate_filter.is_some())
            .count();

        out.push_str("## Dispatch Classification\n\n");
        out.push_str(
            "Plan selection and runtime GPU work are counted separately. Runtime counter deltas \
             are the source of truth for ordinary GPU-dispatched geomeans. A typed \
             derived-output lane may instead use a sealed lifecycle kernel plus complete \
             dependency-stable artifact-hit evidence; plan-only pg_accel rows and rows with \
             stock executor fallback are excluded. Release-gate fields in this section are \
             derived from workload counters, lifecycle captures, and captured plan text.\n\n",
        );
        let _ = writeln!(out, "| Classification | Workloads |");
        let _ = writeln!(out, "|---|---:|");
        let _ = writeln!(out, "| Total measured rows | {total} |");
        let _ = writeln!(
            out,
            "| pg_accel Custom Scan plan selected | {plan_selected} |"
        );
        let _ = writeln!(out, "| GPU kernel dispatched | {gpu_kernel_dispatched} |");
        let _ = writeln!(
            out,
            "| Lifecycle-produced artifact reuse credited | {lifecycle_artifact_reuse_credited} |"
        );
        let _ = writeln!(
            out,
            "| Function/SRF kernel dispatched | {function_srf_kernel_dispatched} |"
        );
        let _ = writeln!(
            out,
            "| Runtime counter capture available | {counter_capture} |"
        );
        let _ = writeln!(
            out,
            "| Kernel counter delta > 0 | {kernel_counter_positive} |"
        );
        let _ = writeln!(
            out,
            "| Accelerated-query counter covers measured pairs | {accelerated_query_coverage} |"
        );
        let _ = writeln!(
            out,
            "| pg_accel stock executor fallback delta > 0 | {stock_exec_positive} |"
        );
        let _ = writeln!(
            out,
            "| Custom Scan selected but no GPU dispatch | {plan_only} |"
        );
        let _ = writeln!(
            out,
            "| Planner declined/no credited pg_accel path | {planner_declined} |"
        );
        let _ = writeln!(
            out,
            "| Function/SRF kernel count | {function_kernel_count} |"
        );
        let _ = writeln!(out, "| Rows returned to CPU | {rows_returned_to_cpu} |");
        let _ = writeln!(
            out,
            "| GPU-resident pipeline reported | {gpu_resident_reported} |"
        );
        let _ = writeln!(
            out,
            "| GPU-dispatched Custom Scan without resident-pipeline proof | \
             {gpu_resident_not_reported} |"
        );
        let _ = writeln!(
            out,
            "| Custom Scan rows with recorded CPU boundary | \
             {gpu_resident_boundary_recorded} |"
        );
        let _ = writeln!(
            out,
            "| Custom Scan rows with native post-aggregate filtering | {native_output_filter_rows} |"
        );
        out.push('\n');
    }

    fn render_dispatch_evidence(&self, out: &mut String) {
        let report = self.with_normalized_dispatch();
        if report.workloads.is_empty() {
            return;
        }

        out.push_str("### Dispatch Evidence By Row\n\n");
        out.push_str(
            "Each measured row is assigned one explicit release-gate classification. \
             `rows_returned_to_cpu` is the accel-side output consumption count; \
             `function_kernel_count` is populated only for credited function/SRF dispatch, \
             and `custom_scan_lifecycle_artifact_reuse` means the fresh kernel is retained in \
             the separate lifecycle evidence rather than the warm timing series.\n\n",
        );
        let _ = writeln!(
            out,
            "| Workload | Scale | Classification | Function kernel count | Rows returned to CPU | \
             Correctness diff | GPU-resident pipeline | Resident boundary | Kernel delta | Accelerated queries | Rows dispatched | GPU rows processed | Stock fallback |"
        );
        let _ = writeln!(
            out,
            "|---|---|---|---:|---:|---|---|---|---:|---:|---:|---:|---:|"
        );
        for w in &report.workloads {
            let classification = dispatch_evidence_label(w);
            let resident_boundary = w.gpu_resident_boundary_reason.as_deref().unwrap_or("-");
            let correctness_diff = w.correctness_diff_artifact.as_deref().unwrap_or("-");
            let _ = writeln!(
                out,
                "| {} | {} | {} | {} | {} | {} | {} | {} | {} | {} | {} | {} | {} |",
                markdown_cell(&w.name),
                format_rows(w.rows),
                classification,
                w.function_kernel_count,
                w.rows_returned_to_cpu,
                markdown_cell(correctness_diff),
                w.gpu_resident_pipeline.as_str(),
                markdown_cell(resident_boundary),
                w.gpu_kernel_execution_delta,
                w.pg_accel_queries_accelerated_delta,
                w.pg_accel_rows_dispatched_delta,
                w.pg_accel_gpu_rows_processed_delta,
                w.pg_accel_stock_exec_delta,
            );
        }
        out.push('\n');
    }

    /// Render warnings for rows where both benchmark modes appear to have
    /// stayed on PostgreSQL-native plans, but the comparison is still not
    /// trustworthy because timing or plan shape diverged materially.
    fn render_no_dispatch_audit(&self, out: &mut String) {
        let report = self.with_normalized_dispatch();
        let mut anomalies: Vec<&WorkloadResult> = report
            .workloads
            .iter()
            .filter(|w| no_dispatch_anomaly(w))
            .collect();
        anomalies.sort_by(|a, b| {
            timing_skew_fraction(no_dispatch_speedup(b))
                .unwrap_or(0.0)
                .partial_cmp(&timing_skew_fraction(no_dispatch_speedup(a)).unwrap_or(0.0))
                .unwrap_or(std::cmp::Ordering::Equal)
        });

        if anomalies.is_empty() {
            return;
        }

        out.push_str("## No-Dispatch Timing Audit\n\n");
        let _ = writeln!(
            out,
            "> WARNING: {} no-dispatch comparison(s) have >= {:.0}% timing skew or \
             materially different native plan shapes. Do not use these rows as GPU \
             performance conclusions.",
            anomalies.len(),
            NO_DISPATCH_TIMING_SKEW_THRESHOLD * 100.0,
        );
        out.push_str(
            ">\n> Action item: for Custom Scan rows, delete or quarantine any pg_accel CPU \
             fallback. For planner-declined rows with matching native plan shape, treat the \
             row as harness timing skew and rerun before drawing conclusions.\n\n",
        );
        let _ = writeln!(
            out,
            "| Workload | Scale | Median speedup | Timing skew | Plan shape | Accel plan | \
             PG plan | Action |"
        );
        let _ = writeln!(out, "|---|---|---|---|---|---|---|---|");
        for w in anomalies {
            let speedup = no_dispatch_speedup(w);
            let skew = timing_skew_fraction(speedup).unwrap_or(f64::NAN) * 100.0;
            let timing = if no_dispatch_timing_skew(w) {
                format!("{skew:.1}%")
            } else {
                "<threshold".to_owned()
            };
            let plan_shape = if no_dispatch_plan_mismatch(w) {
                "DIFF"
            } else if w.plan_snippet.is_some() && w.baseline_plan_snippet.is_some() {
                "same"
            } else {
                "not captured"
            };
            let _ = writeln!(
                out,
                "| {} | {} | {:.2}x | {} | {} | `{}` | `{}` | {} |",
                markdown_cell(&w.name),
                format_rows(w.rows),
                speedup,
                timing,
                plan_shape,
                markdown_cell(&first_plan_signature_line(w.plan_snippet.as_deref())),
                markdown_cell(&first_plan_signature_line(
                    w.baseline_plan_snippet.as_deref(),
                )),
                no_dispatch_audit_action(w),
            );
        }
        out.push('\n');
    }

    /// Render the kernel coverage table — collapses workloads by the
    /// kernel class they exercise. action_items O / W11.
    ///
    /// Reviewer 1 Sin #17: the suite has ~127 workloads but only ~9 GPU
    /// kernels actually under test. The category table inflates this
    /// because the same `point_in_ring` kernel shows up under several
    /// category labels. Grouping by `kernel_class` makes the real
    /// coverage matrix obvious.
    fn render_kernel_coverage(&self, out: &mut String) {
        let report = self.with_normalized_dispatch();
        out.push_str("## Kernel Coverage\n\n");
        out.push_str(
            "Workloads grouped by the GPU kernel class they exercise. \
             A high workload count under a single kernel class means lots \
             of redundant variations of the same code path. Use this table \
             when adding new tests — prefer kernels with low coverage.\n\n",
        );
        let family_size = report.workloads.len() + report.crashes.len();
        let speedup_of = |w: &WorkloadResult| -> f64 { w.speedup_median_vs_parallel };

        // Group dispatched workloads by kernel_class.
        let mut by_kernel: BTreeMap<String, Vec<&WorkloadResult>> = BTreeMap::new();
        for w in &report.workloads {
            if !w.gpu_kernel_dispatched {
                continue;
            }
            by_kernel.entry(w.kernel_class.clone()).or_default().push(w);
        }

        let _ = writeln!(
            out,
            "| Kernel Class | Workloads | Distinct Scales | Geomean | \
             Sig Wins | Sig Losses |"
        );
        let _ = writeln!(out, "|---|---|---|---|---|---|");
        for (kernel, ws) in &by_kernel {
            let speedups: Vec<f64> = ws.iter().map(|w| speedup_of(w)).collect();
            let gm = stats::geomean(&speedups);
            let counts = classify_significance(ws, family_size, 0.05);
            let mut scales: std::collections::BTreeSet<usize> = std::collections::BTreeSet::new();
            for w in ws {
                scales.insert(w.rows);
            }
            let _ = writeln!(
                out,
                "| `{kernel}` | {} | {} | {gm:.2}x | {} | {} |",
                ws.len(),
                scales.len(),
                counts.sig_wins,
                counts.sig_losses,
            );
        }
        out.push('\n');
    }

    /// Evaluate the H3 lane gate against the report's workloads.
    ///
    /// The gate enforces three contracts derived from
    /// [`crate::workloads::benchmark_threshold_matrix_entry`] for the measured
    /// row scale, falling back to [`crate::workloads::h3_lane_class`] only when
    /// a matrix entry is unavailable:
    ///
    /// 1. **Winner below floor**: every H3 [`Winning`](crate::workloads::H3LaneClass::Winning)
    ///    row that DID dispatch a GPU kernel must have a median speedup of at
    ///    least [`H3_LANE_GATE_MIN_WARM_SPEEDUP`]. This is the minimum ship bar
    ///    — a Winner that drops below PG-parallel parity is, by definition,
    ///    not winning.
    /// 2. **Winner missed dispatch**: every H3 Winner row that did NOT dispatch
    ///    a GPU kernel fails the gate. A Winner that silently routes to the
    ///    PG-native plan is a release failure for a selected winner; the
    ///    report-level gate makes that loss of dispatch a CI failure.
    /// 3. **Parity dispatched unexpectedly**: every H3 [`Parity`](crate::workloads::H3LaneClass::Parity)
    ///    row that DID dispatch a GPU kernel fails the gate. Parity ops are
    ///    deliberately not registered for normal planner exposure; an
    ///    accidental re-registration is a quarantine breach.
    ///
    /// Returns an empty vector when every H3 row passes (or when no H3 rows
    /// are present — the gate is a release-time tool, not a unit-test tool).
    #[must_use]
    pub fn evaluate_h3_lane_gate(&self) -> Vec<H3LaneGateFailure> {
        let report = self.with_normalized_dispatch();
        let mut failures = Vec::new();
        for w in &report.workloads {
            let Some(class) = crate::workloads::h3_lane_class(&w.name) else {
                continue;
            };
            let matrix_expectation =
                crate::workloads::benchmark_threshold_matrix_entry(&w.name, w.rows)
                    .map(|entry| entry.expectation);
            let advisory_min_warm_speedup =
                crate::workloads::h3_winner_min_warm_speedup(&w.name).unwrap_or(1.0);
            match matrix_expectation {
                Some(crate::workloads::BenchmarkLaneExpectation::GpuWinner {
                    min_warm_speedup,
                }) => {
                    if !w.gpu_kernel_dispatched {
                        failures.push(H3LaneGateFailure {
                            workload: w.name.clone(),
                            rows: w.rows,
                            kind: H3LaneGateFailureKind::WinnerMissedDispatch,
                            speedup_median: w.speedup_median_vs_parallel,
                            gate_floor: H3_LANE_GATE_MIN_WARM_SPEEDUP,
                            advisory_min_warm_speedup: min_warm_speedup,
                        });
                    } else if !w.speedup_median_vs_parallel.is_finite()
                        || w.speedup_median_vs_parallel < H3_LANE_GATE_MIN_WARM_SPEEDUP
                    {
                        failures.push(H3LaneGateFailure {
                            workload: w.name.clone(),
                            rows: w.rows,
                            kind: H3LaneGateFailureKind::WinnerBelowFloor,
                            speedup_median: w.speedup_median_vs_parallel,
                            gate_floor: H3_LANE_GATE_MIN_WARM_SPEEDUP,
                            advisory_min_warm_speedup: min_warm_speedup,
                        });
                    }
                }
                Some(crate::workloads::BenchmarkLaneExpectation::NativeDecline { .. }) => {
                    if w.gpu_kernel_dispatched {
                        failures.push(H3LaneGateFailure {
                            workload: w.name.clone(),
                            rows: w.rows,
                            kind: H3LaneGateFailureKind::ParityUnexpectedlyDispatched,
                            speedup_median: w.speedup_median_vs_parallel,
                            gate_floor: H3_LANE_GATE_MIN_WARM_SPEEDUP,
                            advisory_min_warm_speedup,
                        });
                    }
                }
                None => match class {
                    crate::workloads::H3LaneClass::Winning { min_warm_speedup } => {
                        if !w.gpu_kernel_dispatched {
                            failures.push(H3LaneGateFailure {
                                workload: w.name.clone(),
                                rows: w.rows,
                                kind: H3LaneGateFailureKind::WinnerMissedDispatch,
                                speedup_median: w.speedup_median_vs_parallel,
                                gate_floor: H3_LANE_GATE_MIN_WARM_SPEEDUP,
                                advisory_min_warm_speedup: min_warm_speedup,
                            });
                        } else if !w.speedup_median_vs_parallel.is_finite()
                            || w.speedup_median_vs_parallel < H3_LANE_GATE_MIN_WARM_SPEEDUP
                        {
                            failures.push(H3LaneGateFailure {
                                workload: w.name.clone(),
                                rows: w.rows,
                                kind: H3LaneGateFailureKind::WinnerBelowFloor,
                                speedup_median: w.speedup_median_vs_parallel,
                                gate_floor: H3_LANE_GATE_MIN_WARM_SPEEDUP,
                                advisory_min_warm_speedup: min_warm_speedup,
                            });
                        }
                    }
                    crate::workloads::H3LaneClass::Parity => {
                        if w.gpu_kernel_dispatched {
                            failures.push(H3LaneGateFailure {
                                workload: w.name.clone(),
                                rows: w.rows,
                                kind: H3LaneGateFailureKind::ParityUnexpectedlyDispatched,
                                speedup_median: w.speedup_median_vs_parallel,
                                gate_floor: H3_LANE_GATE_MIN_WARM_SPEEDUP,
                                advisory_min_warm_speedup,
                            });
                        }
                    }
                },
            }
        }
        failures
    }

    /// Evaluate the optional privileged OS page-cache certification gate.
    ///
    /// The mandatory benchmark ship gate is intentionally warm-only. This
    /// separate evaluator verifies the additional warm/cold evidence required
    /// by operation families whose metadata calls for `cache-mode both`.
    /// Keeping the checks separate prevents an unprivileged warm release run
    /// from masquerading as cold-cache evidence or being blocked by a purge it
    /// cannot perform.
    #[must_use]
    pub fn evaluate_operation_cache_gate(&self) -> Vec<BenchmarkShipGateFailure> {
        let report = self.with_normalized_dispatch();
        let mut failures = Vec::new();

        for w in &report.workloads {
            let Some(entry) = crate::workloads::benchmark_threshold_matrix_entry(&w.name, w.rows)
            else {
                continue;
            };
            let crate::workloads::BenchmarkLaneExpectation::GpuWinner { min_warm_speedup } =
                entry.expectation
            else {
                continue;
            };
            if !operation_cache_gate_required(&w.name)
                || operation_cache_gate_verified(
                    w,
                    &report.methodology.cache_mode,
                    report.methodology.iterations,
                )
            {
                continue;
            }

            failures.push(BenchmarkShipGateFailure {
                workload: w.name.clone(),
                rows: w.rows,
                kind: BenchmarkShipGateFailureKind::ExpectedWinnerMissingCacheEvidence,
                speedup_median: warm_speedup_for_gate(w),
                gate_floor: min_warm_speedup.max(BENCHMARK_SHIP_GATE_MIN_SPEEDUP),
                detail: format!(
                    "expected GPU winner in lane `{}` requires cache-mode both evidence for \
                     bounded cold-start cost ({})",
                    entry.lane, entry.cache_gate
                ),
            });
        }

        failures
    }

    /// Evaluate the benchmark-wide ship gate.
    ///
    /// This is the generic selected-row ratchet: any selected pg_accel row that
    /// crashes, fails to prove GPU dispatch, or dispatches below PostgreSQL
    /// parallel parity is a release-blocking failure. Expected-lane selection
    /// requirements that are workload-family-specific, such as H3 Winners,
    /// remain in their dedicated lane gates.
    #[must_use]
    pub fn evaluate_benchmark_ship_gate(&self) -> Vec<BenchmarkShipGateFailure> {
        let report = self.with_normalized_dispatch();
        let mut failures = Vec::new();

        for c in &report.crashes {
            failures.push(BenchmarkShipGateFailure {
                workload: c.workload.clone(),
                rows: c.rows,
                kind: BenchmarkShipGateFailureKind::Crash,
                speedup_median: f64::NAN,
                gate_floor: BENCHMARK_SHIP_GATE_MIN_SPEEDUP,
                detail: c.error.clone(),
            });
        }

        for w in &report.workloads {
            let threshold_entry =
                crate::workloads::benchmark_threshold_matrix_entry(&w.name, w.rows);
            let is_native_decline =
                crate::workloads::workload_metadata(&w.name).is_some_and(|metadata| {
                    metadata.evidence.threshold
                        == crate::workloads::ThresholdEvidenceEligibility::NativeDeclineOnly
                });
            if w.custom_scan_selected_not_dispatched && !is_native_decline {
                let detail = if crate::workloads::workload_metadata(&w.name)
                    .is_some_and(|metadata| metadata.evidence.derived_output_artifact_reuse())
                {
                    let evidence_error = derived_output_artifact_reuse_evidence_error(w);
                    format!(
                        "typed derived-output Custom Scan lacked admissible lifecycle artifact reuse evidence: {}",
                        evidence_error
                            .as_deref()
                            .unwrap_or("evidence classifier mismatch")
                    )
                } else {
                    "pg_accel Custom Scan selected without credited GPU kernel dispatch".to_owned()
                };
                failures.push(BenchmarkShipGateFailure {
                    workload: w.name.clone(),
                    rows: w.rows,
                    kind: BenchmarkShipGateFailureKind::SelectedPlanMissedDispatch,
                    speedup_median: w.speedup_median_vs_parallel,
                    gate_floor: BENCHMARK_SHIP_GATE_MIN_SPEEDUP,
                    detail,
                });
                continue;
            }

            if w.resident_lane
                && w.plan_selected
                && w.gpu_kernel_dispatched
                && w.warm_summary.is_some()
                && let Some(detail) = selected_resident_lifecycle_evidence_error(w)
            {
                failures.push(BenchmarkShipGateFailure {
                    workload: w.name.clone(),
                    rows: w.rows,
                    kind: BenchmarkShipGateFailureKind::ResidentLifecycleEvidenceMissing,
                    speedup_median: w.speedup_median_vs_parallel,
                    gate_floor: BENCHMARK_SHIP_GATE_MIN_SPEEDUP,
                    detail,
                });
                continue;
            }

            if let Some(entry) = threshold_entry {
                match entry.expectation {
                    crate::workloads::BenchmarkLaneExpectation::GpuWinner { min_warm_speedup } => {
                        let classification = w.dispatch_classification();
                        if !w.gpu_kernel_dispatched {
                            failures.push(BenchmarkShipGateFailure {
                                workload: w.name.clone(),
                                rows: w.rows,
                                kind: BenchmarkShipGateFailureKind::ExpectedWinnerMissedSelection,
                                speedup_median: w.speedup_median_vs_parallel,
                                gate_floor: BENCHMARK_SHIP_GATE_MIN_SPEEDUP,
                                detail: format!(
                                    "expected GPU winner missed dispatch/selection in lane `{}` \
                                     ({})",
                                    entry.lane, entry.threshold_basis
                                ),
                            });
                            continue;
                        }
                        if !w.dispatch_counter_captured
                            || (w.gpu_kernel_execution_delta == 0
                                && !derived_output_artifact_reuse_evidence_verified(w))
                            || classification.rows_returned_to_cpu == 0
                        {
                            failures.push(BenchmarkShipGateFailure {
                                workload: w.name.clone(),
                                rows: w.rows,
                                kind: BenchmarkShipGateFailureKind::ExpectedWinnerMissingEvidence,
                                speedup_median: w.speedup_median_vs_parallel,
                                gate_floor: min_warm_speedup.max(BENCHMARK_SHIP_GATE_MIN_SPEEDUP),
                                detail: format!(
                                    "expected GPU winner in lane `{}` lacks dispatch-counter or \
                                     output-consumption evidence ({})",
                                    entry.lane, entry.dispatch_evidence
                                ),
                            });
                            continue;
                        }
                        if threshold_lane_requires_resident_groupagg_logical_spec(entry.lane)
                            && !w.plan_snippet.as_deref().is_some_and(|plan| {
                                plan_contains_required_groupagg_logical_evidence(plan, entry.lane)
                            })
                        {
                            failures.push(BenchmarkShipGateFailure {
                                workload: w.name.clone(),
                                rows: w.rows,
                                kind: BenchmarkShipGateFailureKind::ExpectedWinnerMissingGroupAggLogicalSpec,
                                speedup_median: w.speedup_median_vs_parallel,
                                gate_floor: min_warm_speedup.max(BENCHMARK_SHIP_GATE_MIN_SPEEDUP),
                                detail: format!(
                                    "resident grouped winner in lane `{}` did not prove the shared \
                                     ResidentGroupAgg logical spec in EXPLAIN",
                                    entry.lane
                                ),
                            });
                            continue;
                        }
                        if threshold_lane_requires_resident_groupagg_logical_spec(entry.lane)
                            && (!w.physical_kernel_mode_verified
                                || w.physical_kernel_mode.is_none()
                                || w.physical_kernel_mode_counts.serial_generic != 0)
                        {
                            failures.push(BenchmarkShipGateFailure {
                                workload: w.name.clone(),
                                rows: w.rows,
                                kind: BenchmarkShipGateFailureKind::ExpectedWinnerPhysicalKernelModeUnverified,
                                speedup_median: w.speedup_median_vs_parallel,
                                gate_floor: min_warm_speedup.max(BENCHMARK_SHIP_GATE_MIN_SPEEDUP),
                                detail: format!(
                                    "resident grouped winner in lane `{}` did not prove one non-serial native physical mode matching EXPLAIN (mode={}, verified={}, serial_calls={})",
                                    entry.lane,
                                    w.physical_kernel_mode.as_deref().unwrap_or("-"),
                                    w.physical_kernel_mode_verified,
                                    w.physical_kernel_mode_counts.serial_generic,
                                ),
                            });
                            continue;
                        }
                        let winner_threshold =
                            min_warm_speedup.max(BENCHMARK_SHIP_GATE_MIN_SPEEDUP);
                        if !w.speedup_median_vs_parallel.is_finite()
                            || w.speedup_median_vs_parallel < winner_threshold
                        {
                            failures.push(BenchmarkShipGateFailure {
                                workload: w.name.clone(),
                                rows: w.rows,
                                kind: BenchmarkShipGateFailureKind::ExpectedWinnerBelowThreshold,
                                speedup_median: w.speedup_median_vs_parallel,
                                gate_floor: winner_threshold,
                                detail: format!(
                                    "expected GPU winner in lane `{}` below warm-run threshold \
                                     ({})",
                                    entry.lane, entry.cache_gate
                                ),
                            });
                            continue;
                        }
                    }
                    crate::workloads::BenchmarkLaneExpectation::NativeDecline { reason } => {
                        if !w.dispatch_counter_captured {
                            failures.push(BenchmarkShipGateFailure {
                                workload: w.name.clone(),
                                rows: w.rows,
                                kind: BenchmarkShipGateFailureKind::NativeDeclineDispatchCounterUnavailable,
                                speedup_median: w.speedup_median_vs_parallel,
                                gate_floor: BENCHMARK_SHIP_GATE_MIN_SPEEDUP,
                                detail: format!(
                                    "native-decline lane `{}` did not capture the GPU dispatch \
                                     counter, so a zero kernel delta cannot prove absence of GPU \
                                     work (counter_error={})",
                                    entry.lane,
                                    w.dispatch_counter_error.as_deref().unwrap_or("-")
                                ),
                            });
                            continue;
                        }
                        if w.plan_selected
                            || w.gpu_kernel_dispatched
                            || w.gpu_kernel_execution_delta > 0
                        {
                            failures.push(BenchmarkShipGateFailure {
                                workload: w.name.clone(),
                                rows: w.rows,
                                kind: BenchmarkShipGateFailureKind::NativeDeclineUnexpectedDispatch,
                                speedup_median: w.speedup_median_vs_parallel,
                                gate_floor: BENCHMARK_SHIP_GATE_MIN_SPEEDUP,
                                detail: format!(
                                    "native-decline lane `{}` unexpectedly selected a pg_accel \
                                     Custom Scan or dispatched GPU work (plan_selected={}, \
                                     gpu_kernel_dispatched={}, kernel_delta={}); expected decline \
                                     reason `{reason}`",
                                    entry.lane,
                                    w.plan_selected,
                                    w.gpu_kernel_dispatched,
                                    w.gpu_kernel_execution_delta
                                ),
                            });
                            continue;
                        }
                        if !native_decline_reason_verified(w, reason) {
                            failures.push(BenchmarkShipGateFailure {
                                workload: w.name.clone(),
                                rows: w.rows,
                                kind: BenchmarkShipGateFailureKind::NativeDeclineReasonMissing,
                                speedup_median: w.speedup_median_vs_parallel,
                                gate_floor: BENCHMARK_SHIP_GATE_MIN_SPEEDUP,
                                detail: format!(
                                    "native-decline lane `{}` did not prove expected planner \
                                     rejection reason `{reason}`",
                                    entry.lane
                                ),
                            });
                            continue;
                        }
                    }
                }
            }

            if w.plan_selected
                && w.gpu_kernel_dispatched
                && w.gpu_resident_pipeline != GpuResidentPipelineStatus::Reported
            {
                failures.push(BenchmarkShipGateFailure {
                    workload: w.name.clone(),
                    rows: w.rows,
                    kind: BenchmarkShipGateFailureKind::SelectedPlanNotGpuResident,
                    speedup_median: w.speedup_median_vs_parallel,
                    gate_floor: BENCHMARK_SHIP_GATE_MIN_SPEEDUP,
                    detail: "selected GPU-dispatched Custom Scan did not report \
                             `GPU Resident Pipeline: true`"
                        .to_owned(),
                });
                continue;
            }

            if w.gpu_kernel_dispatched
                && (!w.speedup_median_vs_parallel.is_finite()
                    || w.speedup_median_vs_parallel < BENCHMARK_SHIP_GATE_MIN_SPEEDUP)
            {
                failures.push(BenchmarkShipGateFailure {
                    workload: w.name.clone(),
                    rows: w.rows,
                    kind: BenchmarkShipGateFailureKind::DispatchedBelowParity,
                    speedup_median: w.speedup_median_vs_parallel,
                    gate_floor: BENCHMARK_SHIP_GATE_MIN_SPEEDUP,
                    detail: "credited GPU dispatch below PostgreSQL parallel parity".to_owned(),
                });
            }
        }

        failures
    }

    /// Append the `### Benchmark Ship Gate Failures` section to `out` when the
    /// generic release gate produced any failures.
    fn render_benchmark_ship_gate(&self, out: &mut String) {
        let failures = self.evaluate_benchmark_ship_gate();
        if failures.is_empty() {
            return;
        }
        out.push_str("### Benchmark Ship Gate Failures\n\n");
        out.push_str(
            "Hard release gate for selected pg_accel benchmark rows. Any crash, \
             selected Custom Scan without credited GPU dispatch, expected GPU \
             winner that stays native, expected winner missing dispatch/output \
             evidence or threshold evidence, \
             native-decline lane that dispatches, selected GPU-dispatched Custom \
             Scan without `GPU Resident Pipeline: true`, or credited GPU dispatch \
             below PostgreSQL-parallel parity exits non-zero in the CLI.\n\n",
        );
        let _ = writeln!(
            out,
            "Gate floor: **{BENCHMARK_SHIP_GATE_MIN_SPEEDUP:.2}x** median speedup."
        );
        out.push('\n');
        let _ = writeln!(
            out,
            "| Workload | Scale | Failure | Observed Speedup | Gate Floor | Detail |"
        );
        let _ = writeln!(out, "|---|---|---|---|---|---|");
        for f in &failures {
            let observed = if f.speedup_median.is_finite() {
                format!("{:.2}x", f.speedup_median)
            } else {
                "n/a".to_owned()
            };
            let detail = f.detail.replace('|', "\\|");
            let _ = writeln!(
                out,
                "| {} | {} | {} | {} | {:.2}x | {} |",
                f.workload,
                format_rows(f.rows),
                f.kind.label(),
                observed,
                f.gate_floor,
                detail,
            );
        }
        out.push('\n');
    }

    /// Append the `### H3 Lane Gate Failures` section to `out` when the gate
    /// produced any failures. Renders nothing when the gate passes.
    fn render_h3_lane_gate(&self, out: &mut String) {
        let failures = self.evaluate_h3_lane_gate();
        if failures.is_empty() {
            return;
        }
        out.push_str("### H3 Lane Gate Failures\n\n");
        out.push_str(
            "Hard gate against the H3 row-scale threshold matrix, with \
             `pg_accel_bench/src/workloads/mod.rs::h3_lane_class` as the \
             fallback classifier. Expected Winning rows must dispatch a GPU \
             kernel and beat PG-parallel parity; native-decline rows must stay \
             native. A failure here means the bench process exits non-zero — \
             CI will fail.\n\n",
        );
        let _ = writeln!(
            out,
            "Gate floor: **{H3_LANE_GATE_MIN_WARM_SPEEDUP:.2}x** (uniform across \
             all H3 Winners; per-Winner advisory thresholds shown below)."
        );
        out.push('\n');
        let _ = writeln!(
            out,
            "| Workload | Scale | Failure | Observed Speedup | Gate Floor | Per-Winner Advisory |"
        );
        let _ = writeln!(out, "|---|---|---|---|---|---|");
        for f in &failures {
            let observed = if f.speedup_median.is_finite() {
                format!("{:.2}x", f.speedup_median)
            } else {
                "n/a".to_owned()
            };
            let _ = writeln!(
                out,
                "| {} | {} | {} | {} | {:.2}x | {:.2}x |",
                f.workload,
                format_rows(f.rows),
                f.kind.label(),
                observed,
                f.gate_floor,
                f.advisory_min_warm_speedup,
            );
        }
        out.push('\n');
    }
}

/// Uniform floor enforced by the H3 lane gate.
///
/// Set to `1.0x` so a Winner that drops below PG-parallel parity always
/// fails. Per-Winner advisory thresholds (from
/// [`crate::workloads::h3_winner_min_warm_speedup`]) are reported next to
/// each failing row but do NOT participate in the pass/fail decision —
/// the gate boundary stays at the minimum ship bar.
pub const H3_LANE_GATE_MIN_WARM_SPEEDUP: f64 = 1.0;

/// Generic release gate floor for selected GPU benchmark rows.
///
/// Any credited GPU dispatch below PostgreSQL parallel parity fails the
/// benchmark process. Workloads that intentionally stay native are excluded
/// because they do not dispatch a GPU kernel and are handled by planner
/// decline evidence instead.
pub const BENCHMARK_SHIP_GATE_MIN_SPEEDUP: f64 = 1.0;

/// Whether this row carries the complete alternate dispatch proof used by a
/// typed derived-output lane. The lifecycle probe must build the exact final
/// output with GPU work; every measured warm execution must then prove a
/// dependency-stable artifact hit with no fresh kernel or stock fallback.
///
/// This is deliberately stricter than the general resident lifecycle gate.
/// It is the only evidence allowed to credit a selected Custom Scan whose
/// measured kernel delta is zero.
#[must_use]
pub fn derived_output_artifact_reuse_evidence_verified(workload: &WorkloadResult) -> bool {
    derived_output_artifact_reuse_evidence_error(workload).is_none()
}

fn derived_output_artifact_reuse_evidence_error(workload: &WorkloadResult) -> Option<String> {
    let eligible = crate::workloads::workload_metadata(&workload.name)
        .is_some_and(|metadata| metadata.evidence.derived_output_artifact_reuse());
    if !eligible {
        return Some(
            "workload metadata does not authorize derived-output artifact reuse".to_owned(),
        );
    }
    if !workload.resident_lane
        || workload
            .resident_load_ms
            .is_none_or(|milliseconds| !milliseconds.is_finite() || milliseconds <= 0.0)
    {
        return Some("derived-output reuse lacks a positive off-clock resident load".to_owned());
    }

    let rows = u64::try_from(workload.rows).unwrap_or(u64::MAX);
    let Some(probe) = workload.artifact_lifecycle_probe.as_ref() else {
        return Some("derived-output lifecycle probe is missing".to_owned());
    };
    if probe.phase != "lifecycle"
        || probe.pair_index.is_some()
        || probe.error.is_some()
        || probe.artifact.hits != 0
        || probe
            .artifact
            .builds
            .saturating_add(probe.artifact.rebuilds)
            != 1
        || probe.artifact.ensures() != 1
        || probe.artifact.artifact_bytes_observed == 0
        || probe.artifact.construction_bytes != probe.artifact.artifact_bytes_observed
        || probe.artifact.construction_us == 0
        || probe.artifact.preparation_us < probe.artifact.construction_us
        || probe.refresh_us == 0
        || probe.refreshed_relations != 1
        || probe.refreshed_rows != rows
        || probe.queries_accelerated != 1
        || probe.gpu_kernel_executions == 0
        || probe.stock_exec_count != 0
        || probe.output_rows_consumed != rows
        || probe.rows_dispatched != 0
        || probe.batches_executed != 0
        || probe.gpu_rows_processed != 0
    {
        return Some(
            "derived-output lifecycle probe did not prove one exact GPU-built final artifact, full output consumption, and zero fallback"
                .to_owned(),
        );
    }
    if probe.dependencies_before.len() != 1
        || probe.dependencies_before != probe.dependencies_after
        || probe.dependencies_after[0].row_count != rows
        || probe.dependencies_after[0].raw_bytes == 0
        || probe.dependencies_after[0].derived_bytes != probe.artifact.artifact_bytes_observed
    {
        return Some(
            "derived-output lifecycle dependency identity or retained-byte accounting is invalid"
                .to_owned(),
        );
    }

    let warm_count = workload
        .iterations
        .iter()
        .filter(|iteration| iteration.cache_state == CacheState::Warm)
        .count();
    if warm_count == 0 || workload.artifact_steady_state_captures.len() != warm_count {
        return Some(format!(
            "derived-output steady-state evidence covers {} of {warm_count} warm pairs",
            workload.artifact_steady_state_captures.len()
        ));
    }

    let mut pair_indexes = BTreeSet::new();
    for capture in &workload.artifact_steady_state_captures {
        let pair_index_valid = capture.pair_index.is_some_and(|index| {
            pair_indexes.insert(index)
                && workload
                    .iterations
                    .get(index)
                    .is_some_and(|iteration| iteration.cache_state == CacheState::Warm)
        });
        if capture.phase != "steady_state"
            || !pair_index_valid
            || capture.iteration.cache_state != CacheState::Warm
            || capture.error.is_some()
            || capture.artifact.hits != 1
            || capture.artifact.builds != 0
            || capture.artifact.rebuilds != 0
            || capture.artifact.ensures() != 1
            || capture.artifact.artifact_bytes_observed != probe.artifact.artifact_bytes_observed
            || capture.artifact.construction_bytes != 0
            || capture.artifact.construction_us != 0
            || capture.artifact.preparation_us == 0
            || capture.artifact_policy != probe.artifact_policy
            || capture.refresh_us != 0
            || capture.refreshed_relations != 0
            || capture.refreshed_rows != 0
            || capture.dependencies_before != probe.dependencies_after
            || capture.dependencies_after != probe.dependencies_after
            || capture.queries_accelerated != 1
            || capture.gpu_kernel_executions != 0
            || capture.stock_exec_count != 0
            || capture.output_rows_consumed != rows
            || capture.rows_dispatched != 0
            || capture.batches_executed != 0
            || capture.gpu_rows_processed != 0
        {
            return Some(format!(
                "derived-output steady-state pair {} did not prove one exact dependency-stable artifact hit with zero fresh GPU work and zero fallback",
                capture
                    .pair_index
                    .map_or_else(|| "?".to_owned(), |index| index.to_string())
            ));
        }
    }

    if workload
        .combined_warm_summary
        .as_ref()
        .is_none_or(|summary| summary.n != warm_count.saturating_add(1))
    {
        return Some(
            "derived-output evidence has no combined lifecycle plus warm-hit calibration summary"
                .to_owned(),
        );
    }

    let measured_pairs = u64::try_from(workload.iterations.len()).unwrap_or(u64::MAX);
    let expected_output_rows = rows.saturating_mul(measured_pairs);
    if !workload.dispatch_counter_captured
        || workload.dispatch_counter_error.is_some()
        || workload.pg_accel_queries_accelerated_delta != measured_pairs
        || workload.pg_accel_stock_exec_delta != 0
        || workload.accel_output_rows_consumed != expected_output_rows
    {
        return Some(
            "aggregate counters do not cover every measured derived-output query and output row"
                .to_owned(),
        );
    }
    None
}

fn selected_resident_lifecycle_evidence_error(workload: &WorkloadResult) -> Option<String> {
    if crate::workloads::workload_metadata(&workload.name)
        .is_some_and(|metadata| metadata.evidence.derived_output_artifact_reuse())
    {
        derived_output_artifact_reuse_evidence_error(workload)
    } else {
        resident_lifecycle_evidence_error(workload)
    }
}

fn resident_lifecycle_evidence_error(workload: &WorkloadResult) -> Option<String> {
    let Some(probe) = workload.artifact_lifecycle_probe.as_ref() else {
        return Some("resident lifecycle probe is missing".to_owned());
    };
    if probe.phase != "lifecycle" || probe.error.is_some() {
        return Some(format!(
            "resident lifecycle probe is invalid (phase={}, error={})",
            probe.phase,
            probe.error.as_deref().unwrap_or("-")
        ));
    }
    if probe
        .artifact
        .builds
        .saturating_add(probe.artifact.rebuilds)
        == 0
        || probe.artifact.ensures() == 0
        || probe.refresh_us == 0
        || probe.refreshed_relations == 0
        || probe.refreshed_rows == 0
        || probe.queries_accelerated == 0
        || probe.gpu_kernel_executions == 0
        || probe.stock_exec_count != 0
        || probe.output_rows_consumed == 0
        || probe.dependencies_before.is_empty()
        || probe.dependencies_after.is_empty()
    {
        return Some(
            "resident lifecycle probe did not prove an explicit non-empty refresh, \
             build/rebuild, recorded dependency identity, GPU dispatch, consumed output, and \
             zero fallback"
                .to_owned(),
        );
    }

    let expected = workload
        .iterations
        .iter()
        .filter(|iteration| iteration.cache_state == CacheState::Warm)
        .count();
    if workload.artifact_steady_state_captures.len() != expected {
        return Some(format!(
            "resident steady-state evidence covers {} of {expected} warm pairs",
            workload.artifact_steady_state_captures.len()
        ));
    }
    for capture in &workload.artifact_steady_state_captures {
        // A global raw-column aggregate has no dictionary or derived buffer to
        // retain. Its ephemeral preparation builds metadata only; require zero
        // allocated bytes rather than claiming a cache hit that cannot exist.
        let artifact_valid = if capture.artifact_policy.as_deref() == Some("ephemeral_fused") {
            probe.artifact_policy == capture.artifact_policy
                && probe.artifact.builds == 1
                && probe.artifact.hits == 0
                && probe.artifact.rebuilds == 0
                && probe.artifact.artifact_bytes_observed == 0
                && probe.artifact.construction_bytes == 0
                && capture.artifact.builds == 1
                && capture.artifact.hits == 0
                && capture.artifact.rebuilds == 0
                && capture.artifact.artifact_bytes_observed == 0
                && capture.artifact.construction_bytes == 0
        } else {
            capture.artifact.ensures() != 0
                && capture.artifact.hits == capture.artifact.ensures()
                && capture.artifact.builds == 0
                && capture.artifact.rebuilds == 0
        };
        if capture.phase != "steady_state"
            || capture.error.is_some()
            || !artifact_valid
            || capture.artifact.raw_load_us != 0
            || capture.refresh_us != 0
            || capture.refreshed_relations != 0
            || capture.refreshed_rows != 0
            || capture.dependencies_before != capture.dependencies_after
            || capture.queries_accelerated == 0
            || capture.gpu_kernel_executions == 0
            || capture.stock_exec_count != 0
            || capture.output_rows_consumed == 0
        {
            return Some(format!(
                "resident steady-state pair {} did not prove artifact hit or zero-buffer preparation, stable dependency \
                 identity, GPU dispatch, consumed output, and zero fallback (error={})",
                capture
                    .pair_index
                    .map_or_else(|| "?".to_owned(), |index| index.to_string()),
                capture.error.as_deref().unwrap_or("-")
            ));
        }
    }
    if workload
        .combined_warm_summary
        .is_none_or(|summary| summary.n != expected.saturating_add(1))
    {
        return Some(
            "resident lifecycle evidence has no combined end-to-end warm calibration summary"
                .to_owned(),
        );
    }
    None
}

/// Kind of failure observed by the benchmark and operation-cache ship gates.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum BenchmarkShipGateFailureKind {
    /// The benchmark harness recorded a crash for this workload/scale.
    Crash,
    /// A pg_accel Custom Scan was selected but no GPU kernel dispatch was
    /// credited by plan/counter evidence.
    SelectedPlanMissedDispatch,
    /// A selected GPU-dispatched Custom Scan did not report
    /// `GPU Resident Pipeline: true`.
    SelectedPlanNotGpuResident,
    /// A GPU-dispatched row fell below the PostgreSQL-parallel parity floor.
    DispatchedBelowParity,
    /// A benchmark matrix cell declared as a GPU winner stayed native or did
    /// not prove credited GPU dispatch.
    ExpectedWinnerMissedSelection,
    /// A benchmark matrix cell declared as a GPU winner dispatched but did not
    /// show the required dispatch counter and consumed-output evidence.
    ExpectedWinnerMissingEvidence,
    /// A benchmark matrix cell declared as a GPU winner dispatched but missed
    /// its operation-specific warm-run threshold.
    ExpectedWinnerBelowThreshold,
    /// A resident grouped-aggregate winner did not prove the shared logical
    /// groupagg spec in its plan artifact.
    ExpectedWinnerMissingGroupAggLogicalSpec,
    /// A resident grouped winner did not prove that its EXPLAIN mode matched
    /// the successful native physical branch counter.
    ExpectedWinnerPhysicalKernelModeUnverified,
    /// An operation-cache certification row did not prove bounded cold-start
    /// cost with complete warm/cold samples and successful OS page-cache purge.
    ExpectedWinnerMissingCacheEvidence,
    /// A selected resident winner did not provide separate construction and
    /// artifact-hit evidence plus the combined calibration view.
    ResidentLifecycleEvidenceMissing,
    /// A benchmark matrix cell declared as native-decline dispatched GPU work.
    NativeDeclineUnexpectedDispatch,
    /// A native-decline matrix cell did not capture the dispatch counter, so
    /// its zero dispatch delta is not admissible evidence.
    NativeDeclineDispatchCounterUnavailable,
    /// A native-decline matrix cell did not prove its expected planner reason.
    NativeDeclineReasonMissing,
}

impl BenchmarkShipGateFailureKind {
    #[must_use]
    pub const fn label(self) -> &'static str {
        match self {
            Self::Crash => "crash",
            Self::SelectedPlanMissedDispatch => "selected_plan_missed_dispatch",
            Self::SelectedPlanNotGpuResident => "selected_plan_not_gpu_resident",
            Self::DispatchedBelowParity => "dispatched_below_parity",
            Self::ExpectedWinnerMissedSelection => "expected_winner_missed_selection",
            Self::ExpectedWinnerMissingEvidence => "expected_winner_missing_evidence",
            Self::ExpectedWinnerBelowThreshold => "expected_winner_below_threshold",
            Self::ExpectedWinnerMissingGroupAggLogicalSpec => {
                "expected_winner_missing_groupagg_logical_spec"
            }
            Self::ExpectedWinnerPhysicalKernelModeUnverified => {
                "expected_winner_physical_kernel_mode_unverified"
            }
            Self::ExpectedWinnerMissingCacheEvidence => "expected_winner_missing_cache_evidence",
            Self::ResidentLifecycleEvidenceMissing => "resident_lifecycle_evidence_missing",
            Self::NativeDeclineUnexpectedDispatch => "native_decline_unexpected_dispatch",
            Self::NativeDeclineDispatchCounterUnavailable => {
                "native_decline_dispatch_counter_unavailable"
            }
            Self::NativeDeclineReasonMissing => "native_decline_reason_missing",
        }
    }
}

/// One benchmark ship-gate failure record.
#[derive(Debug, Clone, PartialEq)]
pub struct BenchmarkShipGateFailure {
    pub workload: String,
    pub rows: usize,
    pub kind: BenchmarkShipGateFailureKind,
    pub speedup_median: f64,
    pub gate_floor: f64,
    pub detail: String,
}

/// Kind of failure observed by [`BenchReport::evaluate_h3_lane_gate`].
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum H3LaneGateFailureKind {
    /// An H3 Winner dispatched a GPU kernel but its median speedup is below
    /// the gate floor (or non-finite).
    WinnerBelowFloor,
    /// An H3 Winner did NOT dispatch a GPU kernel at all.
    WinnerMissedDispatch,
    /// An H3 Parity workload dispatched a GPU kernel under normal planner
    /// exposure (a quarantine breach).
    ParityUnexpectedlyDispatched,
}

impl H3LaneGateFailureKind {
    #[must_use]
    pub const fn label(self) -> &'static str {
        match self {
            Self::WinnerBelowFloor => "winner_below_floor",
            Self::WinnerMissedDispatch => "winner_missed_dispatch",
            Self::ParityUnexpectedlyDispatched => "parity_unexpectedly_dispatched",
        }
    }
}

/// One H3 lane gate failure record.
#[derive(Debug, Clone, PartialEq)]
pub struct H3LaneGateFailure {
    pub workload: String,
    pub rows: usize,
    pub kind: H3LaneGateFailureKind,
    pub speedup_median: f64,
    pub gate_floor: f64,
    pub advisory_min_warm_speedup: f64,
}

struct LedgerMergeItem<'a> {
    workload: Option<&'a WorkloadResult>,
    workload_name: &'a str,
    row_count: usize,
    source: &'a str,
    priority: &'a str,
    next_track: &'a str,
    speedup: Option<f64>,
    gate_floor: Option<f64>,
    detail: String,
}

fn merge_ledger_item(
    rows: &mut BTreeMap<(String, usize), BenchmarkFailureLedgerRow>,
    item: LedgerMergeItem<'_>,
) {
    let LedgerMergeItem {
        workload,
        workload_name,
        row_count,
        source,
        priority,
        next_track,
        speedup,
        gate_floor,
        detail,
    } = item;
    let key = (workload_name.to_owned(), row_count);
    let entry = rows
        .entry(key)
        .or_insert_with(|| BenchmarkFailureLedgerRow {
            workload: workload_name.to_owned(),
            rows: row_count,
            category: workload.map_or_else(|| "unknown".to_owned(), |w| w.category.clone()),
            kernel_class: workload.map_or_else(|| "unknown".to_owned(), |w| w.kernel_class.clone()),
            classification: workload.map_or_else(
                || "crash_or_missing_result".to_owned(),
                ledger_classification,
            ),
            priority: priority.to_owned(),
            next_track: next_track.to_owned(),
            sources: Vec::new(),
            speedup_median_vs_parallel: workload
                .and_then(|w| finite_option(w.speedup_median_vs_parallel))
                .or_else(|| speedup.and_then(finite_option)),
            gate_floor: gate_floor.and_then(finite_option),
            accel_median_ms: workload.and_then(|w| finite_option(w.accel_median_ms)),
            parallel_median_ms: workload.and_then(|w| finite_option(w.parallel_median_ms)),
            repro_command: None,
            plan_snippet_artifact: None,
            correctness_diff_artifact: None,
            log_tail_artifacts: Vec::new(),
            details: Vec::new(),
        });

    push_unique(&mut entry.sources, source);
    push_unique_string(&mut entry.details, detail);
    if ledger_priority_rank(priority) < ledger_priority_rank(&entry.priority) {
        priority.clone_into(&mut entry.priority);
        next_track.clone_into(&mut entry.next_track);
    }
    if entry.speedup_median_vs_parallel.is_none() {
        entry.speedup_median_vs_parallel = speedup.and_then(finite_option);
    }
    if let Some(gate_floor) = gate_floor.and_then(finite_option) {
        entry.gate_floor = Some(
            entry
                .gate_floor
                .map_or(gate_floor, |old| old.max(gate_floor)),
        );
    }
}

fn merge_crash_ledger_item(
    rows: &mut BTreeMap<(String, usize), BenchmarkFailureLedgerRow>,
    crash: &CrashedScale,
) {
    merge_ledger_item(
        rows,
        LedgerMergeItem {
            workload: None,
            workload_name: &crash.workload,
            row_count: crash.rows,
            source: "crash_inventory",
            priority: "p1_release_blocker",
            next_track: ledger_track(&crash.workload, "", "", Some("crash")),
            speedup: None,
            gate_floor: Some(BENCHMARK_SHIP_GATE_MIN_SPEEDUP),
            detail: crash_ledger_detail(crash),
        },
    );

    if let Some(entry) = rows.get_mut(&(crash.workload.clone(), crash.rows)) {
        entry.repro_command.clone_from(&crash.repro_command);
        entry
            .plan_snippet_artifact
            .clone_from(&crash.plan_snippet_artifact);
        entry
            .correctness_diff_artifact
            .clone_from(&crash.correctness_diff_artifact);
        entry
            .log_tail_artifacts
            .clone_from(&crash.log_tail_artifacts);
    }
}

fn crash_ledger_detail(crash: &CrashedScale) -> String {
    let mut parts = Vec::new();
    if let Some(plan) = &crash.plan_snippet_artifact {
        parts.push(format!("plan={plan}"));
    }
    if let Some(correctness) = &crash.correctness_diff_artifact {
        parts.push(format!("correctness={correctness}"));
    }
    if !crash.log_tail_artifacts.is_empty() {
        parts.push(format!("logs={}", crash.log_tail_artifacts.join(",")));
    }
    if let Some(repro) = &crash.repro_command {
        parts.push(format!("repro={repro}"));
    }

    if parts.is_empty() {
        "crash inventory has no attached artifacts".to_owned()
    } else {
        format!("crash inventory artifacts: {}", parts.join("; "))
    }
}

fn ledger_crash_artifact_summary(row: &BenchmarkFailureLedgerRow) -> String {
    let mut parts = Vec::new();
    if let Some(plan) = &row.plan_snippet_artifact {
        parts.push(format!("plan: {plan}"));
    }
    if let Some(correctness) = &row.correctness_diff_artifact {
        parts.push(format!("correctness: {correctness}"));
    }
    if !row.log_tail_artifacts.is_empty() {
        parts.push(format!("logs: {}", row.log_tail_artifacts.join(", ")));
    }
    if let Some(repro) = &row.repro_command {
        parts.push(format!("repro: `{repro}`"));
    }

    if parts.is_empty() {
        "-".to_owned()
    } else {
        parts.join("<br>")
    }
}

fn push_unique(items: &mut Vec<String>, item: &str) {
    if !items.iter().any(|existing| existing == item) {
        items.push(item.to_owned());
    }
}

fn push_unique_string(items: &mut Vec<String>, item: String) {
    if !items.iter().any(|existing| existing == &item) {
        items.push(item);
    }
}

fn finite_option(value: f64) -> Option<f64> {
    value.is_finite().then_some(value)
}

fn ledger_classification(workload: &WorkloadResult) -> String {
    if workload.gpu_kernel_dispatched {
        if workload.function_srf_kernel_dispatched {
            "function_srf_gpu_dispatch".to_owned()
        } else {
            "custom_scan_gpu_dispatch".to_owned()
        }
    } else if workload.custom_scan_selected_not_dispatched {
        "custom_scan_selected_not_dispatched".to_owned()
    } else if workload.planner_declined {
        "planner_declined_native".to_owned()
    } else if workload.plan_selected {
        "custom_scan_selected_without_gpu_credit".to_owned()
    } else {
        "native_or_unclassified".to_owned()
    }
}

fn ledger_priority_rank(priority: &str) -> u8 {
    match priority {
        "p1_release_blocker" => 0,
        "p2_architecture_gap" => 1,
        "p3_parity_noise" => 2,
        _ => 3,
    }
}

fn ledger_track(
    workload: &str,
    category: &str,
    kernel_class: &str,
    failure_hint: Option<&str>,
) -> &'static str {
    if failure_hint.is_some_and(|hint| hint.contains("cache"))
        || workload.starts_with("h3_")
        || category == "gpu_h3"
    {
        return "h3_cache_evidence_and_lane_policy";
    }
    if failure_hint.is_some_and(|hint| hint.contains("hashjoin"))
        || category == "gpu_hashjoin"
        || kernel_class == "hash_join"
        || workload.contains("hashjoin")
        || workload.contains("hash_join")
        || workload.starts_with("mixed_join_agg")
    {
        return "resident_hashjoin_and_join_aggregate";
    }
    if workload == "filtered_grouped_agg" && failure_hint == Some("gpu_dispatched_below_parity") {
        return "resident_groupagg_small_input_overhead";
    }
    if category == "gpu_hashagg"
        || kernel_class == "hash_agg"
        || workload.contains("grouped_agg")
        || workload.starts_with("hashagg_")
        || workload == "timeseries_sensor_rollup"
        || workload == "dictionary_grouped_agg"
    {
        return "resident_groupagg_small_input_overhead";
    }
    if category == "gpu_reduce" || category == "gpu_expr" || kernel_class == "reduce" {
        return "resident_scan_reduce_expression_fusion";
    }
    if category == "gpu_window" || kernel_class == "window" {
        return "resident_segmented_window";
    }
    if category == "gpu_sort" || kernel_class == "sort" || workload.contains("topk") {
        return "resident_sort_topk";
    }
    if category == "gpu_spatial" || kernel_class == "point_in_ring" {
        return "geo_spatial_resident_pipeline";
    }
    if category == "gpu_raster" || kernel_class == "raster" {
        return "raster_resident_pipeline";
    }
    if category == "mixed" {
        return "mixed_workload_resident_fusion";
    }
    "benchmark_gate_policy_or_parity_noise"
}

/// Build a benchmark report, carrying the observed-GUC snapshot, timing mode,
/// and cache mode through so renderers can label columns correctly.
#[allow(
    clippy::too_many_arguments,
    clippy::needless_pass_by_value,
    clippy::option_if_let_else
)]
pub fn generate_report(
    workloads: Vec<WorkloadResult>,
    crashes: Vec<CrashedScale>,
    connection: Option<&str>,
    iterations: usize,
    warmup: usize,
    observed: Option<crate::runner::ObservedGucs>,
    timing_mode: crate::runner::TimingMode,
    cache_mode: crate::runner::CacheMode,
) -> BenchReport {
    let hardware = Some(HardwareProfile::detect());

    // Prefer the observed snapshot (from inside the benchmarked session)
    // over the fallback settings-table query, because the observed
    // snapshot was already validated against the requested profile.
    let gucs = if let Some(snapshot) = &observed {
        Some(GucSettings {
            settings: snapshot.settings.clone(),
        })
    } else {
        connection.and_then(|c| GucSettings::from_connection(c).ok())
    };
    let postmaster_start_time = observed
        .as_ref()
        .and_then(|s| s.postmaster_start_time.clone());

    // Collect unique row scales from results (preserving order).
    let mut row_scales: Vec<usize> = Vec::new();
    for w in &workloads {
        if !row_scales.contains(&w.rows) {
            row_scales.push(w.rows);
        }
    }
    row_scales.sort_unstable();

    let timing_label = match timing_mode {
        crate::runner::TimingMode::RawWallClock => "raw-wallclock",
        crate::runner::TimingMode::ExplainAnalyze => "explain-analyze",
        crate::runner::TimingMode::Both => "both",
    };
    let cache_label = match cache_mode {
        crate::runner::CacheMode::Warm => "warm",
        crate::runner::CacheMode::Cold => "cold",
        crate::runner::CacheMode::Both => "both",
    };
    let harness_profile = if cfg!(debug_assertions) {
        "debug"
    } else {
        "release"
    };
    let methodology = Methodology {
        iterations,
        warmup,
        row_scales,
        ordering: "randomized per iteration (accel-first vs baseline-first)".to_owned(),
        statistical_tests: vec![
            "Paired t-test (two-tailed, p < 0.05)".to_owned(),
            "Bonferroni correction (family-wise alpha)".to_owned(),
            "Cohen's d effect size (|d| >= 0.5 gate, action_items C9)".to_owned(),
            "95% CI via t-distribution".to_owned(),
            "Outlier detection (> 3 sigma)".to_owned(),
        ],
        timing_mode: timing_label.to_owned(),
        cache_mode: cache_label.to_owned(),
        harness_profile: harness_profile.to_owned(),
        native_parity_pairing: false,
        native_parity_repetitions_per_arm: 1,
    };
    let report = BenchReport {
        hardware,
        gucs,
        methodology,
        workloads,
        headline_speedup_allowed: true,
        artifact_dir: None,
        crashes,
        postmaster_start_time,
    };
    report.with_normalized_dispatch()
}

// ---------------------------------------------------------------------------
// Platform detection helpers
// ---------------------------------------------------------------------------

fn detect_os() -> String {
    std::env::consts::OS.to_owned()
}

fn detect_os_version() -> String {
    #[cfg(target_os = "macos")]
    {
        std::process::Command::new("sw_vers")
            .arg("-productVersion")
            .output()
            .ok()
            .and_then(|o| String::from_utf8(o.stdout).ok())
            .map_or_else(|| "unknown".to_owned(), |s| s.trim().to_owned())
    }
    #[cfg(target_os = "linux")]
    {
        std::fs::read_to_string("/etc/os-release")
            .ok()
            .and_then(|content| {
                content
                    .lines()
                    .find(|l| l.starts_with("PRETTY_NAME="))
                    .map(|l| {
                        l.trim_start_matches("PRETTY_NAME=")
                            .trim_matches('"')
                            .to_owned()
                    })
            })
            .unwrap_or_else(|| "unknown".to_owned())
    }
    #[cfg(not(any(target_os = "macos", target_os = "linux")))]
    {
        "unknown".to_owned()
    }
}

fn detect_cpu() -> String {
    #[cfg(target_os = "macos")]
    {
        std::process::Command::new("sysctl")
            .args(["-n", "machdep.cpu.brand_string"])
            .output()
            .ok()
            .and_then(|o| String::from_utf8(o.stdout).ok())
            .map_or_else(|| "unknown".to_owned(), |s| s.trim().to_owned())
    }
    #[cfg(target_os = "linux")]
    {
        std::fs::read_to_string("/proc/cpuinfo")
            .ok()
            .and_then(|content| {
                content
                    .lines()
                    .find(|l| l.starts_with("model name"))
                    .and_then(|l| l.split(':').nth(1))
                    .map(|s| s.trim().to_owned())
            })
            .unwrap_or_else(|| "unknown".to_owned())
    }
    #[cfg(not(any(target_os = "macos", target_os = "linux")))]
    {
        "unknown".to_owned()
    }
}

fn detect_cpu_cores() -> usize {
    std::thread::available_parallelism().map_or(1, std::num::NonZero::get)
}

fn detect_memory() -> String {
    #[cfg(target_os = "macos")]
    {
        std::process::Command::new("sysctl")
            .args(["-n", "hw.memsize"])
            .output()
            .ok()
            .and_then(|o| String::from_utf8(o.stdout).ok())
            .and_then(|s| s.trim().parse::<u64>().ok())
            .map_or_else(
                || "unknown".to_owned(),
                |bytes| format!("{} GB", bytes / (1024 * 1024 * 1024)),
            )
    }
    #[cfg(target_os = "linux")]
    {
        std::fs::read_to_string("/proc/meminfo")
            .ok()
            .and_then(|content| {
                content
                    .lines()
                    .find(|l| l.starts_with("MemTotal:"))
                    .and_then(|l| {
                        l.split_whitespace()
                            .nth(1)
                            .and_then(|s| s.parse::<u64>().ok())
                    })
                    .map(|kb| format!("{} GB", kb / (1024 * 1024)))
            })
            .unwrap_or_else(|| "unknown".to_owned())
    }
    #[cfg(not(any(target_os = "macos", target_os = "linux")))]
    {
        "unknown".to_owned()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn mock_workload_result(
        name: &str,
        rows: usize,
        accel_ms: f64,
        baseline_ms: f64,
    ) -> WorkloadResult {
        let iterations: Vec<IterationResult> = (0..10)
            .map(|i| {
                let jitter = f64::from(i) * 0.1;
                IterationResult {
                    accel_ms: accel_ms + jitter,
                    parallel_ms: baseline_ms + jitter,
                    accel_first: i % 2 == 0,
                    cache_purge: CachePurgeState::NotRequested,
                    cache_state: CacheState::Warm,
                }
            })
            .collect();
        let mut result = WorkloadResult::from_iterations(
            name.to_owned(),
            format!("Mock workload: {name}"),
            "gpu".to_owned(),
            classify_kernel("unclassified"),
            rows,
            iterations,
            true,
        );
        result.pg_accel_queries_accelerated_delta = 10;
        result.physical_kernel_mode_counts.parallel_dense_integer = 10;
        result.physical_kernel_mode = Some("parallel_dense_integer".to_owned());
        result.physical_kernel_mode_verified = true;
        result
    }

    #[test]
    fn test_classify_kernel_separates_h3_parent_count() {
        assert_eq!(classify_kernel("h3_cell_to_parent"), "h3_cell_to_parent");
        assert_eq!(classify_kernel("h3_bulk"), "h3_latlng");
        assert_eq!(classify_kernel("reduce_f64_sum"), "resident_f64_reduce");
        assert_eq!(classify_kernel("reduce_f64_minmax"), "resident_f64_reduce");
        assert_eq!(classify_kernel("reduce_f64_stats"), "resident_f64_reduce");
        assert_eq!(
            classify_kernel("hashagg_f64_aggs"),
            "resident_f64_grouped_stats"
        );
        assert_eq!(
            classify_kernel("case_when_expression_grouped_agg"),
            "hash_agg"
        );
        assert_eq!(
            classify_kernel("case_when_range_expression_grouped_agg"),
            "hash_agg"
        );
        assert_eq!(
            classify_kernel("case_when_value_predicate_expression_grouped_agg"),
            "hash_agg"
        );
        assert_eq!(
            classify_kernel("case_when_null_predicate_expression_grouped_agg"),
            "hash_agg"
        );
        assert_eq!(
            classify_kernel("case_when_or_expression_grouped_agg"),
            "hash_agg"
        );
        assert_eq!(
            classify_kernel("case_when_in_expression_grouped_agg"),
            "hash_agg"
        );
        assert_eq!(
            classify_kernel("case_when_not_expression_grouped_agg"),
            "hash_agg"
        );
        assert_eq!(classify_kernel("ssbm_q4_3"), "resident_star_groupagg");
        assert_eq!(classify_kernel("mixed_join_agg"), "resident_star_groupagg");
        assert_eq!(
            classify_kernel("gpu_hashjoin_filter"),
            "resident_star_groupagg"
        );
    }

    fn mock_report(workloads: Vec<WorkloadResult>) -> BenchReport {
        BenchReport {
            hardware: Some(HardwareProfile {
                os: "linux".to_owned(),
                os_version: "6.1".to_owned(),
                arch: "x86_64".to_owned(),
                cpu: "Test CPU".to_owned(),
                cpu_cores: 8,
                memory_gb: "32 GB".to_owned(),
            }),
            gucs: Some(GucSettings {
                settings: vec![
                    ("work_mem".to_owned(), "256MB".to_owned()),
                    ("shared_buffers".to_owned(), "4GB".to_owned()),
                ],
            }),
            postmaster_start_time: None,
            methodology: Methodology {
                iterations: 30,
                warmup: 5,
                row_scales: vec![1_000, 10_000, 100_000, 1_000_000, 10_000_000],
                ordering: "randomized".to_owned(),
                statistical_tests: vec!["Paired t-test".to_owned()],
                timing_mode: "raw".to_owned(),
                cache_mode: "warm".to_owned(),
                harness_profile: "test".to_owned(),
                native_parity_pairing: false,
                native_parity_repetitions_per_arm: 1,
            },
            workloads,
            headline_speedup_allowed: true,
            artifact_dir: None,
            crashes: Vec::new(),
        }
    }

    #[test]
    fn characterization_report_suppresses_aggregate_speedup_headline() {
        let mut report = mock_report(Vec::new());
        report.headline_speedup_allowed = false;

        let markdown = report.to_markdown();
        assert!(markdown.contains("## Characterization Scope"));
        assert!(!markdown.contains("## Headline"));
        assert!(!markdown.contains("**NET SPEEDUP**"));
        assert!(!markdown.contains("**NET REGRESSION**"));
    }

    #[test]
    fn native_parity_report_declares_every_retained_raw_execution() {
        let mut report = mock_report(Vec::new());
        report.methodology.native_parity_pairing = true;
        report.methodology.native_parity_repetitions_per_arm = 4;

        let markdown = report.to_markdown();

        assert!(markdown.contains("all 8 raw executions are retained"));
        assert!(markdown.contains("replicated mirrored ABBA/BAAB motifs"));
    }

    #[test]
    fn markdown_binds_settings_to_the_observed_postmaster_start() {
        let mut report = mock_report(Vec::new());
        report.postmaster_start_time = Some("2026-08-11 12:34:56+00".to_owned());

        let markdown = report.to_markdown();

        assert!(markdown.contains("Postmaster start: `2026-08-11 12:34:56+00`"));
        assert!(markdown.contains("guaranteed to match the running postmaster"));
    }

    #[test]
    fn report_edge_helpers_cover_zero_timings_and_unclassified_plans() {
        let zero_iteration = IterationResult {
            accel_ms: 0.0,
            parallel_ms: 1.0,
            accel_first: true,
            cache_purge: CachePurgeState::NotRequested,
            cache_state: CacheState::Warm,
        };
        let mut workload = WorkloadResult::from_iterations(
            "edge_helpers".to_owned(),
            "edge helpers".to_owned(),
            "test".to_owned(),
            "unclassified".to_owned(),
            1,
            vec![zero_iteration],
            false,
        );
        assert!(workload.speedup_vs_parallel.is_nan());
        assert!(workload.speedup_median_vs_parallel.is_nan());
        let warm = workload.warm_summary.expect("warm summary");
        assert!(warm.speedup_mean_vs_parallel.is_nan());
        assert!(warm.speedup_median_vs_parallel.is_nan());

        assert_eq!(
            classify_gpu_resident_pipeline_status(
                &workload, None, false, false, false, false, false,
            ),
            GpuResidentPipelineStatus::NotReported
        );
        assert!(workload_or_plan_mentions_accel_function(
            &workload,
            "Aggregate over h3_grid_disk(cell, 1)"
        ));

        workload.speedup_vs_parallel = 1.25;
        workload.speedup_median_vs_parallel = f64::NAN;
        assert!((no_dispatch_speedup(&workload) - 1.25).abs() < f64::EPSILON);
        assert_eq!(timing_skew_fraction(f64::NAN), None);
        assert_eq!(
            NoDispatchAuditStatus::TimingSkewAndPlanMismatch.as_str(),
            "timing_skew_and_plan_mismatch"
        );

        let blocks = pg_accel_custom_scan_blocks(
            "Custom Scan (GpuAccelAgg)\n\n  GPU Resident Pipeline: true\nSeq Scan on t",
        );
        assert_eq!(blocks.len(), 1);
        assert!(direct_custom_scan_property_lines(&[]).is_empty());

        workload.p_value_vs_parallel = 0.0;
        workload.cohens_d_vs_parallel = 0.1;
        let counts = classify_significance(&[&workload], 1, 0.05);
        assert_eq!(counts.effect_rejected, 1);
        assert_eq!(counts.total_sig, 0);
    }

    #[test]
    fn legacy_report_json_defaults_to_allowing_headline() {
        let report = mock_report(Vec::new());
        let mut value = serde_json::to_value(report).expect("serialize report");
        value
            .as_object_mut()
            .expect("report object")
            .remove("headline_speedup_allowed");

        let decoded: BenchReport = serde_json::from_value(value).expect("deserialize report");
        assert!(decoded.headline_speedup_allowed);
    }

    fn with_valid_resident_lifecycle(mut workload: WorkloadResult) -> WorkloadResult {
        let before = ResidentDependencyIdentity {
            relid: 42,
            generation: 1,
            global_generation: 1,
            relfilenode: 7,
            row_count: 1_000_000,
            raw_bytes: 8_000_000,
            derived_bytes: 0,
        };
        let after = ResidentDependencyIdentity {
            generation: 2,
            global_generation: 2,
            derived_bytes: 64_000,
            ..before
        };
        let lifecycle_iteration = IterationResult {
            accel_ms: 25.0,
            parallel_ms: 20.0,
            accel_first: true,
            cache_purge: CachePurgeState::NotRequested,
            cache_state: CacheState::Warm,
        };
        workload.artifact_lifecycle_probe = Some(ResidentLifecycleCapture {
            phase: "lifecycle".to_owned(),
            pair_index: None,
            iteration: lifecycle_iteration.clone(),
            artifact: ArtifactLifecycleDelta {
                builds: 1,
                artifact_bytes_observed: 64_000,
                construction_bytes: 64_000,
                construction_us: 500,
                preparation_us: 700,
                raw_load_us: 200,
                ..ArtifactLifecycleDelta::default()
            },
            artifact_policy: Some("cached_reusable".to_owned()),
            refresh_us: 250,
            refreshed_relations: 1,
            refreshed_rows: 1_000_000,
            dependencies_before: vec![before],
            dependencies_after: vec![after.clone()],
            queries_accelerated: 1,
            rows_dispatched: 1_000_000,
            batches_executed: 1,
            stock_exec_count: 0,
            gpu_rows_processed: 1_000_000,
            gpu_kernel_executions: 1,
            output_rows_consumed: 1,
            error: None,
        });
        workload.artifact_steady_state_captures = workload
            .iterations
            .iter()
            .enumerate()
            .filter(|(_, iteration)| iteration.cache_state == CacheState::Warm)
            .map(|(pair_index, iteration)| ResidentLifecycleCapture {
                phase: "steady_state".to_owned(),
                pair_index: Some(pair_index),
                iteration: iteration.clone(),
                artifact: ArtifactLifecycleDelta {
                    hits: 1,
                    artifact_bytes_observed: 64_000,
                    preparation_us: 5,
                    ..ArtifactLifecycleDelta::default()
                },
                artifact_policy: Some("cached_reusable".to_owned()),
                refresh_us: 0,
                refreshed_relations: 0,
                refreshed_rows: 0,
                dependencies_before: vec![after.clone()],
                dependencies_after: vec![after.clone()],
                queries_accelerated: 1,
                rows_dispatched: 1_000_000,
                batches_executed: 1,
                stock_exec_count: 0,
                gpu_rows_processed: 1_000_000,
                gpu_kernel_executions: 1,
                output_rows_consumed: 1,
                error: None,
            })
            .collect();
        let mut combined = Vec::with_capacity(workload.iterations.len() + 1);
        combined.push(lifecycle_iteration);
        combined.extend(workload.iterations.iter().cloned());
        workload.combined_warm_summary =
            CacheModeSummary::from_iterations(CacheState::Warm, &combined);
        workload
    }

    fn valid_derived_output_artifact_reuse() -> WorkloadResult {
        let mut workload =
            mock_workload_result("raster_resident_exact_reclass", 10_000, 10.0, 20.0);
        workload.category = "gpu_raster".to_owned();
        workload.kernel_class = "raster".to_owned();
        workload.plan_selected = true;
        workload.dispatch_counter_captured = true;
        workload.gpu_kernel_execution_delta = 0;
        workload.pg_accel_queries_accelerated_delta = 10;
        workload.pg_accel_rows_dispatched_delta = 0;
        workload.pg_accel_batches_executed_delta = 0;
        workload.pg_accel_gpu_rows_processed_delta = 0;
        workload.pg_accel_stock_exec_delta = 0;
        workload.accel_output_rows_consumed = 100_000;
        workload.resident_lane = true;
        workload.resident_load_ms = Some(25.0);
        workload.plan_snippet = Some(
            "Custom Scan (GpuAccelRaster)\n  Strategy: GpuRaster\n  \
             GPU Resident Pipeline: true\n  GPU Resident Proof Version: 2\n  \
             GPU Resident Operator Class: resident_expression\n  \
             GPU Resident Stage Mask: 28673\n  GPU Resident Device Columns: 1\n  \
             GPU Resident Boundary: none: no CPU boundary\n"
                .to_owned(),
        );

        let dependency = ResidentDependencyIdentity {
            relid: 42,
            generation: 2,
            global_generation: 2,
            relfilenode: 7,
            row_count: 10_000,
            raw_bytes: 2_000_000,
            derived_bytes: 1_000_000,
        };
        let lifecycle_iteration = workload.iterations[0].clone();
        workload.artifact_lifecycle_probe = Some(ResidentLifecycleCapture {
            phase: "lifecycle".to_owned(),
            pair_index: None,
            iteration: lifecycle_iteration.clone(),
            artifact: ArtifactLifecycleDelta {
                builds: 1,
                artifact_bytes_observed: 1_000_000,
                construction_bytes: 1_000_000,
                construction_us: 500,
                preparation_us: 700,
                ..ArtifactLifecycleDelta::default()
            },
            artifact_policy: None,
            refresh_us: 250,
            refreshed_relations: 1,
            refreshed_rows: 10_000,
            dependencies_before: vec![dependency.clone()],
            dependencies_after: vec![dependency.clone()],
            queries_accelerated: 1,
            rows_dispatched: 0,
            batches_executed: 0,
            stock_exec_count: 0,
            gpu_rows_processed: 0,
            gpu_kernel_executions: 1,
            output_rows_consumed: 10_000,
            error: None,
        });
        workload.artifact_steady_state_captures = workload
            .iterations
            .iter()
            .cloned()
            .enumerate()
            .map(|(pair_index, iteration)| ResidentLifecycleCapture {
                phase: "steady_state".to_owned(),
                pair_index: Some(pair_index),
                iteration,
                artifact: ArtifactLifecycleDelta {
                    hits: 1,
                    artifact_bytes_observed: 1_000_000,
                    preparation_us: 5,
                    ..ArtifactLifecycleDelta::default()
                },
                artifact_policy: None,
                refresh_us: 0,
                refreshed_relations: 0,
                refreshed_rows: 0,
                dependencies_before: vec![dependency.clone()],
                dependencies_after: vec![dependency.clone()],
                queries_accelerated: 1,
                rows_dispatched: 0,
                batches_executed: 0,
                stock_exec_count: 0,
                gpu_rows_processed: 0,
                gpu_kernel_executions: 0,
                output_rows_consumed: 10_000,
                error: None,
            })
            .collect();
        let mut combined = vec![lifecycle_iteration];
        combined.extend(workload.iterations.iter().cloned());
        workload.combined_warm_summary =
            CacheModeSummary::from_iterations(CacheState::Warm, &combined);
        workload
    }

    #[test]
    fn derived_output_artifact_reuse_is_strict_alternate_dispatch_evidence() {
        let workload = valid_derived_output_artifact_reuse();
        assert!(derived_output_artifact_reuse_evidence_verified(&workload));

        let classification = workload.dispatch_classification();
        assert!(classification.plan_selected);
        assert!(classification.gpu_kernel_dispatched);
        assert!(!classification.custom_scan_selected_not_dispatched);
        assert_eq!(
            classification.gpu_resident_pipeline,
            GpuResidentPipelineStatus::Reported
        );
        let report = mock_report(vec![workload]);
        assert!(report.evaluate_benchmark_ship_gate().is_empty());
        let markdown = report.to_markdown();
        assert!(markdown.contains("| Lifecycle-produced artifact reuse credited | 1 |"));
        assert!(markdown.contains("custom_scan_lifecycle_artifact_reuse"));
    }

    #[test]
    fn derived_output_artifact_reuse_rejects_every_incomplete_evidence_layer() {
        let valid = valid_derived_output_artifact_reuse();

        let mut wrong_workload = valid.clone();
        wrong_workload.name = "generic_gpu_dispatch".to_owned();
        assert!(
            derived_output_artifact_reuse_evidence_error(&wrong_workload)
                .is_some_and(|error| error.contains("metadata does not authorize"))
        );

        let mut missing_load = valid.clone();
        missing_load.resident_load_ms = None;
        assert!(
            derived_output_artifact_reuse_evidence_error(&missing_load)
                .is_some_and(|error| error.contains("resident load"))
        );

        let mut missing_probe = valid.clone();
        missing_probe.artifact_lifecycle_probe = None;
        assert!(
            derived_output_artifact_reuse_evidence_error(&missing_probe)
                .is_some_and(|error| error.contains("probe is missing"))
        );

        let mut missing_lifecycle_kernel = valid.clone();
        missing_lifecycle_kernel
            .artifact_lifecycle_probe
            .as_mut()
            .expect("valid probe")
            .gpu_kernel_executions = 0;
        assert!(
            derived_output_artifact_reuse_evidence_error(&missing_lifecycle_kernel)
                .is_some_and(|error| error.contains("one exact GPU-built"))
        );
        let failures = mock_report(vec![missing_lifecycle_kernel]).evaluate_benchmark_ship_gate();
        assert!(failures.iter().any(|failure| {
            failure.kind == BenchmarkShipGateFailureKind::SelectedPlanMissedDispatch
                && failure
                    .detail
                    .contains("lacked admissible lifecycle artifact reuse")
        }));

        let mut invalid_dependency = valid.clone();
        invalid_dependency
            .artifact_lifecycle_probe
            .as_mut()
            .expect("valid probe")
            .dependencies_after[0]
            .derived_bytes = 1;
        assert!(
            derived_output_artifact_reuse_evidence_error(&invalid_dependency)
                .is_some_and(|error| error.contains("dependency identity"))
        );

        let mut incomplete_hits = valid.clone();
        incomplete_hits.artifact_steady_state_captures.pop();
        assert!(
            derived_output_artifact_reuse_evidence_error(&incomplete_hits)
                .is_some_and(|error| error.contains("covers 9 of 10"))
        );

        let mut fresh_steady_kernel = valid.clone();
        fresh_steady_kernel.artifact_steady_state_captures[0].gpu_kernel_executions = 1;
        assert!(
            derived_output_artifact_reuse_evidence_error(&fresh_steady_kernel)
                .is_some_and(|error| error.contains("zero fresh GPU work"))
        );

        let mut missing_combined = valid.clone();
        missing_combined.combined_warm_summary = None;
        assert!(
            derived_output_artifact_reuse_evidence_error(&missing_combined)
                .is_some_and(|error| error.contains("combined lifecycle"))
        );

        let mut incomplete_aggregate_counters = valid;
        incomplete_aggregate_counters.accel_output_rows_consumed -= 1;
        assert!(
            derived_output_artifact_reuse_evidence_error(&incomplete_aggregate_counters)
                .is_some_and(|error| error.contains("aggregate counters"))
        );
    }

    #[test]
    fn resident_lifecycle_gate_requires_separate_build_and_hit_series() {
        let workload = with_valid_resident_lifecycle(mock_workload_result(
            "resident_lifecycle_contract",
            1_000_000,
            10.0,
            20.0,
        ));
        assert_eq!(resident_lifecycle_evidence_error(&workload), None);
        assert_eq!(
            workload
                .artifact_lifecycle_probe
                .as_ref()
                .and_then(|capture| capture.artifact_policy.as_deref()),
            Some("cached_reusable")
        );
        assert!(
            serde_json::to_string(&workload)
                .expect("lifecycle workload serializes")
                .contains("\"artifact_policy\":\"cached_reusable\"")
        );

        let mut missing_probe = workload.clone();
        missing_probe.artifact_lifecycle_probe = None;
        assert!(
            resident_lifecycle_evidence_error(&missing_probe)
                .expect("missing probe must fail")
                .contains("probe is missing")
        );

        let mut invalid_probe = workload.clone();
        let invalid = invalid_probe
            .artifact_lifecycle_probe
            .as_mut()
            .expect("fixture has lifecycle probe");
        invalid.phase = "steady_state".to_owned();
        invalid.error = Some("probe failed".to_owned());
        let detail = resident_lifecycle_evidence_error(&invalid_probe)
            .expect("invalid lifecycle probe must fail");
        assert!(detail.contains("phase=steady_state"));
        assert!(detail.contains("error=probe failed"));

        let mut empty_build = workload.clone();
        let lifecycle = empty_build
            .artifact_lifecycle_probe
            .as_mut()
            .expect("fixture has lifecycle probe");
        lifecycle.artifact.builds = 0;
        lifecycle.artifact.rebuilds = 0;
        assert!(
            resident_lifecycle_evidence_error(&empty_build)
                .expect("lifecycle without a build must fail")
                .contains("did not prove an explicit non-empty refresh")
        );

        let mut short_steady = workload.clone();
        short_steady.artifact_steady_state_captures.pop();
        assert!(
            resident_lifecycle_evidence_error(&short_steady)
                .expect("incomplete steady evidence must fail")
                .contains("steady-state evidence covers 9 of 10 warm pairs")
        );

        let mut rebuilt_steady = workload.clone();
        rebuilt_steady.artifact_steady_state_captures[0]
            .artifact
            .rebuilds = 1;
        assert!(
            resident_lifecycle_evidence_error(&rebuilt_steady)
                .expect("steady-state rebuild must fail")
                .contains("did not prove artifact hit")
        );

        let mut missing_combined = workload;
        missing_combined.combined_warm_summary = None;
        assert!(
            resident_lifecycle_evidence_error(&missing_combined)
                .expect("missing combined calibration must fail")
                .contains("combined end-to-end")
        );
    }

    #[test]
    fn resident_global_metadata_preparation_requires_zero_buffers_and_real_dispatch() {
        let mut workload = with_valid_resident_lifecycle(mock_workload_result(
            "numeric_global_sum_avg",
            1_000_000,
            10.0,
            20.0,
        ));
        let probe = workload.artifact_lifecycle_probe.as_mut().expect("probe");
        probe.artifact_policy = Some("ephemeral_fused".to_owned());
        probe.artifact.artifact_bytes_observed = 0;
        probe.artifact.construction_bytes = 0;
        for capture in &mut workload.artifact_steady_state_captures {
            capture.artifact_policy = Some("ephemeral_fused".to_owned());
            capture.artifact.hits = 0;
            capture.artifact.builds = 1;
            capture.artifact.artifact_bytes_observed = 0;
            capture.artifact.construction_bytes = 0;
        }
        assert_eq!(resident_lifecycle_evidence_error(&workload), None);
        for mutation in 0..6 {
            let mut invalid = workload.clone();
            let capture = &mut invalid.artifact_steady_state_captures[0];
            match mutation {
                0 => capture.artifact.construction_bytes = 1,
                1 => capture.artifact.artifact_bytes_observed = 1,
                2 => capture.artifact.raw_load_us = 1,
                3 => capture.gpu_kernel_executions = 0,
                4 => capture.artifact_policy = Some("cached_reusable".to_owned()),
                _ => capture.artifact.builds = 0,
            }
            assert!(resident_lifecycle_evidence_error(&invalid).is_some());
        }
        for mutation in 0..3 {
            let mut invalid = workload.clone();
            let probe = invalid.artifact_lifecycle_probe.as_mut().expect("probe");
            match mutation {
                0 => probe.artifact.construction_bytes = 1,
                1 => probe.artifact.artifact_bytes_observed = 1,
                _ => probe.artifact.rebuilds = 1,
            }
            assert!(resident_lifecycle_evidence_error(&invalid).is_some());
        }
    }

    #[test]
    fn benchmark_ship_gate_surfaces_missing_resident_lifecycle_evidence() {
        let mut workload = with_valid_resident_lifecycle(mock_workload_result(
            "grouped_agg_int4",
            1_000_000,
            10.0,
            20.0,
        ));
        workload.resident_lane = true;
        workload.plan_selected = true;
        workload.dispatch_counter_captured = true;
        workload.gpu_kernel_execution_delta = 10;
        workload.accel_output_rows_consumed = 101;
        workload.pg_accel_stock_exec_delta = 0;
        workload.plan_snippet = Some("Custom Scan (pg_accel)\n".to_owned());
        workload.artifact_lifecycle_probe = None;

        let failures = mock_report(vec![workload]).evaluate_benchmark_ship_gate();

        assert!(failures.iter().any(|failure| {
            failure.kind == BenchmarkShipGateFailureKind::ResidentLifecycleEvidenceMissing
                && failure.detail.contains("lifecycle probe is missing")
        }));
    }

    fn with_cache_mode(mut report: BenchReport, mode: &str) -> BenchReport {
        report.methodology.cache_mode = mode.to_owned();
        report
    }

    fn mark_no_dispatch(
        mut result: WorkloadResult,
        accel_plan: &str,
        baseline_plan: &str,
    ) -> WorkloadResult {
        result.plan_selected = false;
        result.gpu_kernel_dispatched = false;
        result.function_srf_kernel_dispatched = false;
        result.dispatch_counter_captured = true;
        result.plan_snippet = Some(accel_plan.to_owned());
        result.baseline_plan_snippet = Some(baseline_plan.to_owned());
        result
    }

    #[test]
    fn test_workload_result_from_iterations_basic() {
        let result = mock_workload_result("test_wl", 100_000, 10.0, 20.0);
        assert_eq!(result.name, "test_wl");
        assert_eq!(result.rows, 100_000);
        assert!(result.speedup_vs_parallel > 1.0);
        assert_eq!(result.iterations.len(), 10);
    }

    #[test]
    fn test_workload_result_single_iteration() {
        let iters = vec![IterationResult {
            accel_ms: 5.0,
            parallel_ms: 10.0,
            accel_first: false,
            cache_purge: CachePurgeState::NotRequested,
            cache_state: CacheState::Warm,
        }];
        let result = WorkloadResult::from_iterations(
            "one".to_owned(),
            "desc".to_owned(),
            "gpu".to_owned(),
            classify_kernel("unclassified"),
            1000,
            iters,
            true,
        );
        assert!((result.accel_mean_ms - 5.0).abs() < f64::EPSILON);
        assert!((result.speedup_vs_parallel - 2.0).abs() < f64::EPSILON);
    }

    #[test]
    fn iteration_result_defaults_missing_arm_order_for_old_reports() {
        let decoded: IterationResult = serde_json::from_value(serde_json::json!({
            "accel_ms": 5.0,
            "parallel_ms": 10.0,
            "cache_purge": "not_requested",
            "cache_state": "warm"
        }))
        .expect("legacy iteration should deserialize");
        assert!(!decoded.accel_first);
    }

    /// Minimal `CacheModeSummary` builder for tests that need to plant a
    /// specific warm/cold subsample summary directly, independent of
    /// `WorkloadResult::from_iterations`.
    fn mock_cache_mode_summary(cache_state: CacheState, speedup_median: f64) -> CacheModeSummary {
        CacheModeSummary {
            cache_state,
            n: 5,
            accel_mean_ms: 10.0,
            accel_median_ms: 10.0,
            accel_stddev_ms: 0.0,
            accel_p95_ms: 10.0,
            accel_cv_pct: 0.0,
            accel_ci_95: (10.0, 10.0),
            parallel_mean_ms: 10.0 * speedup_median,
            parallel_median_ms: 10.0 * speedup_median,
            parallel_stddev_ms: 0.0,
            parallel_p95_ms: 10.0 * speedup_median,
            parallel_cv_pct: 0.0,
            parallel_ci_95: (10.0 * speedup_median, 10.0 * speedup_median),
            speedup_mean_vs_parallel: speedup_median,
            speedup_median_vs_parallel: speedup_median,
            p_value_vs_parallel: 0.0,
            cohens_d_vs_parallel: 5.0,
            effect_size_meaningful: true,
        }
    }

    fn with_cold_cache_evidence(
        mut workload: WorkloadResult,
        purge: CachePurgeState,
    ) -> WorkloadResult {
        let cold_iterations = (0..10)
            .map(|_| IterationResult {
                accel_ms: 20.0,
                parallel_ms: 40.0,
                accel_first: false,
                cache_purge: purge,
                cache_state: CacheState::Cold,
            })
            .collect::<Vec<_>>();
        workload.cold_summary =
            CacheModeSummary::from_iterations(CacheState::Cold, &cold_iterations);
        workload.iterations.extend(cold_iterations);
        workload.pg_accel_queries_accelerated_delta = workload
            .pg_accel_queries_accelerated_delta
            .saturating_add(10);
        workload.cold_shared_buffers_resident = Some(false);
        workload
    }

    /// `warm_speedup_for_gate` (and therefore `gpu_winner_evidence_verified`)
    /// must read `WorkloadResult::warm_summary` directly rather than the flat
    /// `speedup_median_vs_parallel`. Plant a flat speedup that would FAIL a
    /// 1.5x gate and a `warm_summary` speedup that would PASS it — the gate
    /// must follow the warm summary.
    #[test]
    fn test_warm_speedup_for_gate_reads_warm_summary_over_flat_field() {
        let mut w = mock_workload_result("gpu_reduce_sum", 1_000_000, 10.0, 20.0);
        w.speedup_median_vs_parallel = 0.5; // would fail a 1.5x gate if read directly
        w.warm_summary = Some(mock_cache_mode_summary(CacheState::Warm, 2.0));
        assert!((warm_speedup_for_gate(&w) - 2.0).abs() < f64::EPSILON);

        // Warm-only runs (no `warm_summary` populated) fall back to the flat
        // field, which already describes the only subsample measured.
        let mut warm_only = mock_workload_result("gpu_reduce_sum", 1_000_000, 10.0, 20.0);
        warm_only.warm_summary = None;
        assert!(
            (warm_speedup_for_gate(&warm_only) - warm_only.speedup_median_vs_parallel).abs()
                < f64::EPSILON
        );
    }

    #[test]
    fn test_gpu_winner_evidence_verified_gates_on_warm_summary_not_flat_speedup() {
        let mut w = mock_workload_result("gpu_reduce_sum", 1_000_000, 10.0, 20.0);
        w.plan_selected = true;
        w.gpu_kernel_dispatched = true;
        w.dispatch_counter_captured = true;
        w.gpu_kernel_execution_delta = 1;
        w.rows_returned_to_cpu = 100;
        w.accel_output_rows_consumed = 100;
        // Flat field alone would fail a 1.5x gate...
        w.speedup_median_vs_parallel = 0.5;
        // ...but the warm-subsample evidence clears it, and the gate must
        // follow the warm-subsample evidence.
        w.warm_summary = Some(mock_cache_mode_summary(CacheState::Warm, 2.0));
        assert!(gpu_winner_evidence_verified(&w, "unrelated_lane", 1.5));

        // With no warm_summary at all, the flat field (0.5x) governs and the
        // gate correctly fails.
        w.warm_summary = None;
        assert!(!gpu_winner_evidence_verified(&w, "unrelated_lane", 1.5));
    }

    /// The h3_/raster_ cache-mode-both gate must require populated warm/cold
    /// summaries and successful per-iteration purge proof, not merely a global
    /// `cache_mode == "both"` methodology string.
    #[test]
    fn test_operation_cache_gate_verified_requires_complete_successful_cache_evidence() {
        let mut w = mock_workload_result("h3_cell_to_parent", 1_000_000, 10.0, 50.0);
        w.category = "gpu_h3".to_owned();
        assert!(
            w.warm_summary.is_some(),
            "sanity: mock_workload_result's all-Warm iterations must populate warm_summary"
        );
        assert!(w.cold_summary.is_none());
        assert!(
            !operation_cache_gate_verified(&w, "both", 10),
            "a warm summary and methodology label must not impersonate cold evidence"
        );

        let verified = with_cold_cache_evidence(w.clone(), CachePurgeState::Completed);
        assert!(operation_cache_gate_verified(&verified, "both", 10));

        let mut one_cold = verified.clone();
        let mut retained_cold = false;
        one_cold.iterations.retain(|iteration| {
            iteration.cache_state == CacheState::Warm
                || (!retained_cold && {
                    retained_cold = true;
                    true
                })
        });
        one_cold.cold_summary = CacheModeSummary::from_iterations(
            CacheState::Cold,
            &one_cold
                .iterations
                .iter()
                .filter(|iteration| iteration.cache_state == CacheState::Cold)
                .cloned()
                .collect::<Vec<_>>(),
        );
        assert!(!operation_cache_gate_verified(&one_cold, "both", 10));
        one_cold.cold_summary.as_mut().expect("one cold summary").n = 10;
        assert!(
            !operation_cache_gate_verified(&one_cold, "both", 10),
            "a forged summary count must not replace raw cold samples"
        );

        for residency in [None, Some(true), Some(false)] {
            let mut visible = verified.clone();
            visible.cold_shared_buffers_resident = residency;
            assert!(
                operation_cache_gate_verified(&visible, "both", 10),
                "shared-buffer residency {residency:?} is visibility-only because the qualified profile can retain the 1M fixture"
            );
        }
        let mut forged_warm = verified.clone();
        forged_warm.warm_summary.as_mut().expect("warm summary").n = 9;
        assert!(!operation_cache_gate_verified(&forged_warm, "both", 10));

        for purge in [
            CachePurgeState::NotRequested,
            CachePurgeState::Unavailable,
            CachePurgeState::Failed,
        ] {
            let unproven = with_cold_cache_evidence(w.clone(), purge);
            assert!(
                !operation_cache_gate_verified(&unproven, "both", 10),
                "cold evidence with purge state {purge:?} must fail closed"
            );
        }

        w.warm_summary = None;
        assert!(
            !operation_cache_gate_verified(&w, "both", 10),
            "cache_mode=both alone must not satisfy the gate without a row-level warm_summary"
        );

        // And the existing requirement still holds: cache_mode must actually
        // be "both", regardless of warm_summary.
        assert!(!operation_cache_gate_verified(&verified, "warm", 10));
    }

    /// `native_decline_reason_verified` must read only
    /// `WorkloadResult::native_decline_evidence`. Plan-snippet text — even if
    /// it happens to mention a decline-sounding reason — is not evidence by
    /// itself; only the tagged evidence field, sourced from a real planner
    /// rejection, counts.
    #[test]
    fn test_native_decline_reason_verified_ignores_plan_snippet_text() {
        let mut w = mock_workload_result("gpu_sort_multikey", 100_000, 10.0, 10.0);
        w.plan_snippet = Some(
            "Sort\n  -> Seq Scan on bench_sort_multi\n  Note: sort_multikey_no_gpu_kernel"
                .to_owned(),
        );
        assert!(w.native_decline_evidence.is_none());
        assert!(!native_decline_reason_verified(
            &w,
            "sort_multikey_no_gpu_kernel"
        ));

        w.native_decline_evidence = Some(NativeDeclineEvidence {
            reason: "sort_multikey_no_gpu_kernel".to_owned(),
            source: DeclineReasonSource::PlannerReported,
        });
        assert!(native_decline_reason_verified(
            &w,
            "sort_multikey_no_gpu_kernel"
        ));
    }

    /// `ExpectedUnconfirmed` decline evidence must never verify, and must
    /// render as "expected, unconfirmed" via `native_decline_evidence_label`.
    #[test]
    fn test_native_decline_reason_verified_rejects_unconfirmed_and_mismatched_reason() {
        let mut w = mock_workload_result("gpu_sort_multikey", 100_000, 10.0, 10.0);
        w.native_decline_evidence = Some(NativeDeclineEvidence {
            reason: "sort_multikey_no_gpu_kernel".to_owned(),
            source: DeclineReasonSource::ExpectedUnconfirmed,
        });
        assert!(!native_decline_reason_verified(
            &w,
            "sort_multikey_no_gpu_kernel"
        ));
        assert_eq!(
            native_decline_evidence_label(&w),
            "sort_multikey_no_gpu_kernel (expected, unconfirmed)"
        );

        // A mismatched reason string must not verify even when the source is
        // PlannerReported.
        w.native_decline_evidence = Some(NativeDeclineEvidence {
            reason: "some_other_reason".to_owned(),
            source: DeclineReasonSource::PlannerReported,
        });
        assert!(!native_decline_reason_verified(
            &w,
            "sort_multikey_no_gpu_kernel"
        ));

        w.native_decline_evidence = None;
        assert_eq!(native_decline_evidence_label(&w), "-");
    }

    /// The crash-summary error-message truncation at
    /// `render_geomean_headline` must be char-boundary safe: byte-slicing at
    /// a fixed offset panics if the cut falls inside a multibyte UTF-8
    /// sequence. Use a string whose 77th *byte* lands inside a multibyte
    /// character to prove the fix.
    #[test]
    fn test_markdown_crash_summary_truncates_multibyte_error_without_panicking() {
        // 76 ASCII chars, then a 3-byte UTF-8 character (e), so byte offset
        // 77 falls inside the multibyte sequence — the old `&s[..77]`
        // byte-slice would panic here.
        let prefix: String = "a".repeat(76);
        let error = format!("{prefix}\u{2705} trailing detail that pushes this past 80 chars");
        assert!(
            error.len() > 80,
            "fixture must exceed the truncation threshold"
        );

        let mut workload = mock_workload_result("wl_crash", 1000, 5.0, 15.0);
        workload.name = "wl_ok".to_owned();
        let mut report = mock_report(vec![workload]);
        report.crashes.push(CrashedScale {
            workload: "wl_crash".to_owned(),
            rows: 1000,
            error,
            repro_command: None,
            plan_snippet_artifact: None,
            correctness_diff_artifact: None,
            log_tail_artifacts: Vec::new(),
        });

        // Must not panic.
        let md = report.to_markdown();
        assert!(md.contains("### Crashed scales"));
        assert!(md.contains("CRASH:"));
    }

    /// Plan-snippet display truncation is renderer-only: a full plan beyond
    /// `PLAN_SNIPPET_DISPLAY_MAX_LINES` is truncated with a trailing marker,
    /// but classification helpers (exercised via `native_decline_reason_verified`
    /// and `dispatch_classification`, tested elsewhere) always see the FULL
    /// text — only `truncate_plan_for_display` itself shortens anything.
    #[test]
    fn test_truncate_plan_for_display_caps_long_plans_and_preserves_short_ones() {
        let short_plan = "Seq Scan on bench\n  Filter: x > 1\n";
        assert_eq!(truncate_plan_for_display(short_plan), short_plan);

        let long_plan = (0..50)
            .map(|i| format!("  -> Node {i}"))
            .collect::<Vec<_>>()
            .join("\n");
        let truncated = truncate_plan_for_display(&long_plan);
        assert!(truncated.lines().count() > PLAN_SNIPPET_DISPLAY_MAX_LINES);
        assert!(truncated.contains("(20 more lines)"));
        assert!(truncated.contains("Node 0"));
        assert!(!truncated.contains("Node 49"));
    }

    /// Detailed Results must render warm/cold summaries separately (never a
    /// pooled median), the resident-cache preload note, the cold-cache
    /// `shared_buffers`-resident warning, and native-decline evidence with
    /// its source label.
    #[test]
    fn test_markdown_detailed_results_renders_cache_split_and_resident_evidence() {
        let mut workload =
            mock_workload_result("resident_star_groupagg_case", 1_000_000, 10.0, 20.0);
        workload.warm_summary = Some(mock_cache_mode_summary(CacheState::Warm, 4.0));
        workload.cold_summary = Some(mock_cache_mode_summary(CacheState::Cold, 1.2));
        workload.resident_lane = true;
        workload.resident_load_ms = Some(42.5);
        workload.cold_shared_buffers_resident = Some(true);
        workload.native_decline_evidence = Some(NativeDeclineEvidence {
            reason: "some_reason".to_owned(),
            source: DeclineReasonSource::PlannerReported,
        });
        workload.plan_snippet = Some("Custom Scan (GpuAccelAgg)\n  Strategy: GpuAgg\n".to_owned());

        let report = mock_report(vec![workload]);
        let md = report.to_markdown();

        assert!(
            md.contains("Warm (n=5)"),
            "must render warm summary; md:\n{md}"
        );
        assert!(
            md.contains("Cold (n=5)"),
            "must render cold summary; md:\n{md}"
        );
        assert!(
            md.contains("42.50ms"),
            "resident_load_ms must appear in Detailed Results; md:\n{md}"
        );
        assert!(
            md.contains("shared_buffers"),
            "cold_shared_buffers_resident must render a warning; md:\n{md}"
        );
        assert!(
            md.contains("`some_reason` (planner-reported, verified)"),
            "native-decline evidence must render with its source label; md:\n{md}"
        );
    }

    #[test]
    fn test_report_renders_cache_purge_audit_rows() {
        let mut workload = mock_workload_result("gpu_reduce_sum", 10_000, 10.0, 20.0);
        workload.iterations[0].cache_purge = CachePurgeState::Unavailable;
        workload.iterations[3].cache_purge = CachePurgeState::Failed;
        let report = with_cache_mode(mock_report(vec![workload]), "cold");

        let markdown = report.to_markdown();

        assert!(markdown.contains("## Cache Purge Audit"));
        assert!(markdown.contains("| gpu_reduce_sum | 10K | 1 | 4 |"));
    }

    #[test]
    fn test_warmup_iterations_populate_summary_fields() {
        let mut workload = mock_workload_result("h3_bulk", 100_000, 10.0, 20.0);
        workload.set_warmup_iterations(vec![
            IterationResult {
                accel_ms: 250.0,
                parallel_ms: 40.0,
                accel_first: true,
                cache_purge: CachePurgeState::NotRequested,
                cache_state: CacheState::Warm,
            },
            IterationResult {
                accel_ms: 30.0,
                parallel_ms: 35.0,
                accel_first: false,
                cache_purge: CachePurgeState::NotRequested,
                cache_state: CacheState::Warm,
            },
            IterationResult {
                accel_ms: 80.0,
                parallel_ms: 32.0,
                accel_first: true,
                cache_purge: CachePurgeState::NotRequested,
                cache_state: CacheState::Warm,
            },
        ]);

        assert_eq!(workload.warmup_iterations.len(), 3);
        assert_eq!(workload.warmup_accel_first_ms, Some(250.0));
        assert_eq!(workload.warmup_accel_max_ms, Some(250.0));
        assert_eq!(workload.warmup_accel_post_first_max_ms, Some(80.0));
        assert_eq!(workload.warmup_parallel_first_ms, Some(40.0));
        assert_eq!(workload.warmup_parallel_max_ms, Some(40.0));
    }

    #[test]
    fn test_report_renders_warmup_jit_audit_for_post_first_spike() {
        let mut workload = mock_workload_result("h3_bulk", 100_000, 10.0, 20.0);
        workload.set_warmup_iterations(vec![
            IterationResult {
                accel_ms: 50.0,
                parallel_ms: 40.0,
                accel_first: true,
                cache_purge: CachePurgeState::NotRequested,
                cache_state: CacheState::Warm,
            },
            IterationResult {
                accel_ms: 1_500.0,
                parallel_ms: 42.0,
                accel_first: false,
                cache_purge: CachePurgeState::NotRequested,
                cache_state: CacheState::Warm,
            },
        ]);
        let report = mock_report(vec![workload]);

        let markdown = report.to_markdown();

        assert!(markdown.contains("## Warmup/JIT Audit"));
        assert!(markdown.contains("| h3_bulk | 100K | 2 | 50.00ms | 1500.00ms | 1500.00ms |"));
        assert!(markdown.contains("post-first warmup max 1500.00ms"));
    }

    #[test]
    fn test_report_renders_harness_profile() {
        let report = mock_report(vec![mock_workload_result("h3_bulk", 100_000, 10.0, 20.0)]);

        let json = report.to_json().expect("json");
        let markdown = report.to_markdown();
        let value: serde_json::Value = serde_json::from_str(&json).expect("json value");

        assert_eq!(value["methodology"]["harness_profile"], "test");
        assert!(markdown.contains("| Harness build profile | `test` |"));
    }

    #[test]
    fn test_markdown_contains_header() {
        let report = mock_report(vec![mock_workload_result("wl1", 1000, 5.0, 15.0)]);
        let md = report.to_markdown();
        assert!(md.contains("# pg_accel Benchmark Report"));
    }

    #[test]
    fn test_markdown_renders_sanity_checks() {
        let mut result = mock_workload_result("ssbm_q2_3", 100_000, 10.0, 20.0);
        result.category = "ssbm".to_owned();
        result.sanity_checks = vec![SanityCheck {
            label: "ssbm_part.p_brand1 = MFGR#2239 (SSBM Q2.3)".to_owned(),
            count: 25,
            passed: true,
        }];
        let report = mock_report(vec![result]);
        let md = report.to_markdown();
        assert!(md.contains("## Benchmark Sanity Checks"));
        assert!(md.contains("ssbm_part.p_brand1 = MFGR#2239"));
        assert!(md.contains("| ssbm_q2_3 | 100K |"));
    }

    #[test]
    fn test_markdown_renders_planner_threshold_matrix() {
        // No real planner rejection reason was captured for this row — the
        // static matrix merely *expects* a decline. That must render as
        // "expected, unconfirmed" and FAIL the row's status, never be
        // laundered into a passing "verified" decline.
        let mut workload = mark_no_dispatch(
            mock_workload_result("gpu_sort_multikey", 100_000, 10.0, 10.0),
            "Sort\n  Sort Key: key1, key2\n  -> Seq Scan on bench_sort_multi",
            "Sort\n  Sort Key: key1, key2\n  -> Seq Scan on bench_sort_multi",
        );
        workload.native_decline_evidence = Some(NativeDeclineEvidence {
            reason: "sort_multikey_no_gpu_kernel".to_owned(),
            source: DeclineReasonSource::ExpectedUnconfirmed,
        });
        let report = mock_report(vec![workload]);
        let md = report.to_markdown();

        assert!(md.contains("## Planner Threshold Matrix"));
        assert!(md.contains("Prepared Geometry"));
        assert!(md.contains("Index/Pruning"));
        assert!(md.contains("sort_multikey_no_gpu_kernel"));
        assert!(md.contains("| standalone_heap_sort | gpu_sort_multikey | 100K |"));
        assert!(
            md.contains("expected, unconfirmed"),
            "unconfirmed decline evidence must render honestly; md:\n{md}"
        );
        assert!(
            md.contains("| FAIL |"),
            "unconfirmed decline evidence must never pass the threshold-matrix status; md:\n{md}"
        );
    }

    #[test]
    fn test_markdown_contains_row_scales() {
        let report = mock_report(vec![mock_workload_result("wl1", 1000, 5.0, 15.0)]);
        let md = report.to_markdown();
        assert!(md.contains("Row scales"));
        assert!(md.contains("1K"));
        assert!(md.contains("1M"));
    }

    #[test]
    fn test_markdown_multi_scale_table() {
        let report = mock_report(vec![
            mock_workload_result("wl1", 1_000, 5.0, 15.0),
            mock_workload_result("wl1", 1_000_000, 5.0, 15.0),
        ]);
        let md = report.to_markdown();
        // Summary table should have scale columns
        assert!(md.contains("| 1K |"));
        assert!(md.contains("| 1M |"));
    }

    #[test]
    fn test_markdown_warns_on_no_dispatch_timing_skew() {
        let plan = "Aggregate\n  Output: count(*)\n  -> Seq Scan on public.bench\n";
        let workload = mark_no_dispatch(
            mock_workload_result("native_skew", 100_000, 20.0, 10.0),
            plan,
            plan,
        );
        let report = mock_report(vec![workload]);
        let md = report.to_markdown();

        assert!(md.contains("## No-Dispatch Timing Audit"));
        assert!(md.contains("native_skew"));
        assert!(md.contains("same native plan timing skew; rerun/inspect harness"));
    }

    #[test]
    fn test_markdown_warns_on_no_dispatch_plan_mismatch() {
        let accel_plan = "Aggregate\n  Output: count(*)\n  -> Seq Scan on public.bench\n";
        let baseline_plan = "Finalize Aggregate\n  -> Gather\n        Workers Planned: 2\n        -> Partial Aggregate\n             -> Parallel Seq Scan on public.bench\n";
        let workload = mark_no_dispatch(
            mock_workload_result("native_plan_diff", 100_000, 10.0, 10.0),
            accel_plan,
            baseline_plan,
        );
        let report = mock_report(vec![workload]);
        let md = report.to_markdown();

        assert!(md.contains("native_plan_diff"));
        assert!(md.contains("| DIFF |"));
    }

    #[test]
    fn test_markdown_omits_no_dispatch_audit_for_comparable_native_plan() {
        let plan = "Aggregate\n  Output: count(*)\n  -> Seq Scan on public.bench\n";
        let workload = mark_no_dispatch(
            mock_workload_result("native_same", 100_000, 10.0, 10.0),
            plan,
            plan,
        );
        let report = mock_report(vec![workload]);
        let md = report.to_markdown();

        assert!(!md.contains("## No-Dispatch Timing Audit"));
    }

    #[test]
    fn test_no_dispatch_plan_shape_ignores_pg_accel_decline_diagnostics() {
        // A real `pg_accel planner rejection reason:` line (sourced from
        // `pg_accel_last_planner_rejection_reason()`) is still stripped from
        // the plan-shape signature so it does not itself cause a plan
        // mismatch against the baseline plan, which never carries it.
        let baseline_plan = "Aggregate\n  Output: count(*)\n  -> Seq Scan on public.bench\n";
        let accel_plan = "Aggregate\n  Output: count(*)\n  -> Seq Scan on public.bench\n\
             pg_accel planner rejection reason: nestloop_scalar_no_gpu_kernel";
        let mut workload = mark_no_dispatch(
            mock_workload_result("native_decline_with_evidence", 50_000, 10.0, 10.0),
            accel_plan,
            baseline_plan,
        );
        workload.native_decline_evidence = Some(NativeDeclineEvidence {
            reason: "nestloop_scalar_no_gpu_kernel".to_owned(),
            source: DeclineReasonSource::PlannerReported,
        });
        let audit = mock_report(vec![workload]).no_dispatch_audit();

        assert_eq!(audit.evaluated_no_dispatch_rows, 1);
        assert_eq!(audit.warning_rows, 0);
        assert_eq!(audit.plan_mismatch_rows, 0);
        assert_eq!(
            audit.rows[0].status,
            NoDispatchAuditStatus::ComparableNative
        );
    }

    #[test]
    fn test_no_dispatch_audit_classifies_native_evidence_quality() {
        let native_plan = "Aggregate\n  Output: count(*)\n  -> Seq Scan on public.bench\n";
        let different_plan = "Finalize Aggregate\n  -> Gather\n        Workers Planned: 2\n        -> Partial Aggregate\n             -> Parallel Seq Scan on public.bench\n";
        let clean = mark_no_dispatch(
            mock_workload_result("native_clean", 100_000, 10.0, 10.0),
            native_plan,
            native_plan,
        );
        let skew = mark_no_dispatch(
            mock_workload_result("native_skew", 100_000, 20.0, 10.0),
            native_plan,
            native_plan,
        );
        let mismatch = mark_no_dispatch(
            mock_workload_result("native_mismatch", 100_000, 10.0, 10.0),
            native_plan,
            different_plan,
        );
        let mut missing_plan = mock_workload_result("native_missing_plan", 100_000, 10.0, 10.0);
        missing_plan.plan_selected = false;
        missing_plan.gpu_kernel_dispatched = false;
        let mut missing_plan_skew =
            mock_workload_result("native_missing_plan_skew", 100_000, 20.0, 10.0);
        missing_plan_skew.plan_selected = false;
        missing_plan_skew.gpu_kernel_dispatched = false;
        let selected_not_dispatched = mark_no_dispatch(
            mock_workload_result("custom_scan_cpu_fallback", 100_000, 10.0, 10.0),
            "Custom Scan (GpuAccelScan)\n  GPU Dispatched: false\n",
            native_plan,
        );
        let mut dispatching = mock_workload_result("gpu_dispatch", 100_000, 10.0, 50.0);
        dispatching.dispatch_counter_captured = true;
        dispatching.gpu_kernel_execution_delta = 1;
        dispatching.accel_output_rows_consumed = 10;

        let audit = mock_report(vec![
            clean,
            skew,
            mismatch,
            missing_plan,
            missing_plan_skew,
            selected_not_dispatched,
            dispatching,
        ])
        .no_dispatch_audit();

        assert_eq!(audit.schema_version, NO_DISPATCH_AUDIT_SCHEMA_VERSION);
        assert_eq!(audit.evaluated_no_dispatch_rows, 6);
        assert_eq!(audit.clean_rows, 1);
        assert_eq!(audit.warning_rows, 5);
        assert_eq!(audit.timing_skew_rows, 2);
        assert_eq!(audit.plan_mismatch_rows, 2);
        assert_eq!(audit.selected_custom_scan_not_dispatched_rows, 1);
        assert_eq!(audit.missing_plan_evidence_rows, 2);
        assert_eq!(audit.ignored_dispatching_rows, 1);
        assert!(audit.warning_rows > 0);
        assert_eq!(
            audit
                .rows
                .iter()
                .find(|row| row.workload == "native_clean")
                .expect("clean row should be present")
                .status,
            NoDispatchAuditStatus::ComparableNative
        );
        assert_eq!(
            audit
                .rows
                .iter()
                .find(|row| row.workload == "native_skew")
                .expect("skew row should be present")
                .status,
            NoDispatchAuditStatus::TimingSkew
        );
        assert_eq!(
            audit
                .rows
                .iter()
                .find(|row| row.workload == "native_mismatch")
                .expect("mismatch row should be present")
                .status,
            NoDispatchAuditStatus::PlanMismatch
        );
        assert_eq!(
            audit
                .rows
                .iter()
                .find(|row| row.workload == "native_missing_plan")
                .expect("missing-plan row should be present")
                .status,
            NoDispatchAuditStatus::MissingPlanEvidence
        );
        let missing_plan_skew = audit
            .rows
            .iter()
            .find(|row| row.workload == "native_missing_plan_skew")
            .expect("missing-plan timing-skew row should be present");
        assert_eq!(missing_plan_skew.status, NoDispatchAuditStatus::TimingSkew);
        assert!(missing_plan_skew.missing_plan_evidence);
        assert_eq!(
            audit
                .rows
                .iter()
                .find(|row| row.workload == "custom_scan_cpu_fallback")
                .expect("selected no-dispatch row should be present")
                .status,
            NoDispatchAuditStatus::SelectedCustomScanNotDispatched
        );

        let md = audit.to_markdown();
        assert!(md.contains("No-Dispatch Audit"));
        assert!(md.contains("custom_scan_cpu_fallback"));
        assert!(md.contains("selected_custom_scan_not_dispatched"));
        assert!(md.contains("no GPU credit; use only as native-decline/stability evidence"));
    }

    #[test]
    fn test_markdown_excludes_planner_declined_rows_from_regressions() {
        let plan = "Limit\n  -> Sort\n       Sort Key: bench.val\n       -> Seq Scan on bench\n";
        let workload = mark_no_dispatch(
            mock_workload_result("topk_wide", 1_000_000, 30.0, 15.0),
            plan,
            plan,
        );
        let report = mock_report(vec![workload]);
        let md = report.to_markdown();

        assert!(md.contains("## No-Dispatch Timing Audit"));
        assert!(md.contains("topk_wide"));
        assert!(md.contains("| 1M |"));
        assert!(md.contains("| planner_declined |"));
        assert!(md.contains("same native plan timing skew; rerun/inspect harness"));
        assert!(!md.contains("## Regressions"));
    }

    #[test]
    fn test_h3_resident_groupagg_counts_as_custom_scan_gpu_dispatched() {
        let mut workload = mock_workload_result("h3_cell_to_parent", 1_000_000, 10.0, 50.0);
        workload.category = "gpu_h3".to_owned();
        workload.kernel_class = "h3_cell_to_parent".to_owned();
        workload.plan_selected = false;
        workload.gpu_kernel_dispatched = false;
        workload.function_srf_kernel_dispatched = false;
        workload.dispatch_counter_captured = true;
        workload.gpu_kernel_execution_delta = 1;
        workload.accel_output_rows_consumed = 10;
        workload.plan_snippet = Some(
            "Custom Scan (GpuAccelAgg)\n  Strategy: GpuAgg\n  GPU Dispatched: true\n  \
             GPU Resident Pipeline: true\n  \
             GPU Resident Proof Version: 2\n  \
             GPU Resident Operator Class: resident_groupagg\n  \
             GPU Resident GroupAgg Key: h3index\n  \
             GPU Resident GroupAgg Measure: count_star\n  \
             GPU Resident GroupAgg Filter: none\n  \
             GPU Resident GroupAgg Predicate Guard: none\n  \
             GPU Resident GroupAgg Value Predicate: none\n  \
             GPU Resident GroupAgg Predicate IR: guard=none;value=none\n  \
             GPU Resident GroupAgg Aggregate Mask: 8\n  \
             GPU Resident Stage Mask: 17417\n  \
             GPU Resident Device Columns: 4"
                .to_owned(),
        );
        let report = mock_report(vec![workload]);

        let md = report.to_markdown();
        assert!(md.contains("geomean across 1 GPU-dispatched workloads"));
        assert!(md.contains("| pg_accel Custom Scan plan selected | 1 |"));
        assert!(md.contains("| Function/SRF kernel dispatched | 0 |"));
        assert!(!md.contains("## Non-Dispatching Workloads"));

        let csv = report.to_csv();
        assert!(csv.contains(
            "h3_cell_to_parent,gpu_h3,h3_cell_to_parent,true,true,false,false,false,0,10,\
             reported,true,1,10,0,0,0,0,10,1000000"
        ));
    }

    #[test]
    fn test_h3_function_kernel_requires_output_consumption() {
        let mut workload =
            mock_workload_result("h3_function_dispatch_fixture", 100_000, 10.0, 50.0);
        workload.category = "gpu_h3".to_owned();
        workload.kernel_class = "h3_latlng".to_owned();
        workload.plan_selected = false;
        workload.gpu_kernel_dispatched = false;
        workload.function_srf_kernel_dispatched = false;
        workload.dispatch_counter_captured = true;
        workload.gpu_kernel_execution_delta = 1;
        workload.accel_output_rows_consumed = 0;
        let report = mock_report(vec![workload]);

        let md = report.to_markdown();
        assert!(md.contains("geomean across 0 GPU-dispatched workloads"));
        assert!(md.contains("| Function/SRF kernel dispatched | 0 |"));
    }

    #[test]
    fn test_benchmark_ship_gate_flags_crashes() {
        let mut report = mock_report(Vec::new());
        report.crashes.push(CrashedScale {
            workload: "gpu_hashjoin_large_build".to_owned(),
            rows: 100_000,
            error: "backend disconnected".to_owned(),
            repro_command: None,
            plan_snippet_artifact: None,
            correctness_diff_artifact: None,
            log_tail_artifacts: Vec::new(),
        });

        let failures = report.evaluate_benchmark_ship_gate();
        assert_eq!(failures.len(), 1);
        assert_eq!(failures[0].kind, BenchmarkShipGateFailureKind::Crash);
    }

    #[test]
    fn test_crashed_scales_render_correctness_diff_artifact() {
        let mut report = mock_report(Vec::new());
        report.crashes.push(CrashedScale {
            workload: "bad_correctness".to_owned(),
            rows: 100_000,
            error: "correctness diff failed".to_owned(),
            repro_command: None,
            plan_snippet_artifact: None,
            correctness_diff_artifact: Some(
                "correctness_diffs/bad-correctness-100000.json".to_owned(),
            ),
            log_tail_artifacts: Vec::new(),
        });

        let md = report.to_markdown();
        assert!(md.contains("Correctness Diff"));
        assert!(md.contains("correctness_diffs/bad-correctness-100000.json"));
    }

    #[test]
    fn test_benchmark_ship_gate_flags_selected_plan_without_dispatch() {
        let mut workload = mock_workload_result("gpu_reduce_sum", 100_000, 10.0, 20.0);
        workload.plan_selected = true;
        workload.gpu_kernel_dispatched = false;
        workload.dispatch_counter_captured = true;
        workload.plan_snippet = Some(
            "Custom Scan (GpuAccelAgg)\n  Strategy: GpuReduce\n  GPU Dispatched: false".to_owned(),
        );
        let report = mock_report(vec![workload]);

        let failures = report.evaluate_benchmark_ship_gate();
        assert_eq!(failures.len(), 1);
        assert_eq!(
            failures[0].kind,
            BenchmarkShipGateFailureKind::SelectedPlanMissedDispatch
        );
        assert!(
            report
                .to_markdown()
                .contains("### Benchmark Ship Gate Failures")
        );
    }

    #[test]
    fn test_benchmark_ship_gate_flags_selected_plan_without_resident_proof() {
        let mut workload = mock_workload_result("generic_gpu_dispatch", 100_000, 10.0, 20.0);
        workload.plan_selected = true;
        workload.dispatch_counter_captured = true;
        workload.gpu_kernel_execution_delta = 1;
        workload.accel_output_rows_consumed = 10;
        workload.pg_accel_stock_exec_delta = 0;
        workload.plan_snippet =
            Some("Custom Scan (GpuAccelMystery)\n  GPU Dispatched: true\n".to_owned());
        let report = mock_report(vec![workload]);

        let failures = report.evaluate_benchmark_ship_gate();
        assert_eq!(failures.len(), 1);
        assert_eq!(
            failures[0].kind,
            BenchmarkShipGateFailureKind::SelectedPlanNotGpuResident
        );
        assert!(
            report
                .to_markdown()
                .contains("selected_plan_not_gpu_resident")
        );
    }

    #[test]
    fn test_benchmark_ship_gate_flags_selected_plan_with_inferred_boundary() {
        let mut workload = mock_workload_result("generic_gpu_dispatch", 100_000, 10.0, 20.0);
        workload.plan_selected = true;
        workload.dispatch_counter_captured = true;
        workload.gpu_kernel_execution_delta = 1;
        workload.accel_output_rows_consumed = 10;
        workload.pg_accel_stock_exec_delta = 0;
        workload.plan_snippet = Some(
            "Custom Scan (GpuAccelAgg)\n  Strategy: GpuAgg\n  GPU Dispatched: true\n".to_owned(),
        );
        let report = mock_report(vec![workload]);

        let failures = report.evaluate_benchmark_ship_gate();
        assert_eq!(failures.len(), 1);
        assert_eq!(
            failures[0].kind,
            BenchmarkShipGateFailureKind::SelectedPlanNotGpuResident
        );
    }

    #[test]
    fn test_benchmark_ship_gate_allows_selected_plan_with_reported_resident_pipeline() {
        let mut workload = mock_workload_result("generic_gpu_dispatch", 100_000, 10.0, 20.0);
        workload.plan_selected = true;
        workload.dispatch_counter_captured = true;
        workload.gpu_kernel_execution_delta = 1;
        workload.accel_output_rows_consumed = 10;
        workload.pg_accel_stock_exec_delta = 0;
        workload.plan_snippet = Some(
            "Custom Scan (GpuAccelScan)\n  GPU Dispatched: true\n  \
             GPU Resident Pipeline: true\n  \
             GPU Resident Proof Version: 2\n  \
             GPU Resident Operator Class: resident_expression\n  \
             GPU Resident Stage Mask: 3\n  \
             GPU Resident Device Columns: 2\n"
                .to_owned(),
        );
        let report = mock_report(vec![workload]);

        assert!(report.evaluate_benchmark_ship_gate().is_empty());
    }

    #[test]
    fn test_benchmark_ship_gate_flags_dispatched_rows_below_parity() {
        let mut workload = mock_workload_result("generic_gpu_dispatch", 100_000, 20.0, 10.0);
        workload.dispatch_counter_captured = true;
        workload.gpu_kernel_execution_delta = 1;
        workload.accel_output_rows_consumed = 10;
        workload.plan_snippet = Some(
            "Custom Scan (GpuAccelAgg)\n  Strategy: GpuAgg\n  GPU Dispatched: true\n  \
             GPU Resident Pipeline: true\n  \
             GPU Resident Proof Version: 2\n  \
             GPU Resident Operator Class: resident_groupagg\n  \
             GPU Resident Stage Mask: 5\n  \
             GPU Resident Device Columns: 1"
                .to_owned(),
        );
        let report = mock_report(vec![workload]);

        let failures = report.evaluate_benchmark_ship_gate();
        assert_eq!(failures.len(), 1);
        assert_eq!(
            failures[0].kind,
            BenchmarkShipGateFailureKind::DispatchedBelowParity
        );
        assert!(failures[0].speedup_median < BENCHMARK_SHIP_GATE_MIN_SPEEDUP);
    }

    #[test]
    fn test_benchmark_ship_gate_flags_expected_winner_missing_evidence() {
        let mut workload = mock_workload_result("grouped_agg_int4", 1_000_000, 10.0, 20.0);
        workload.dispatch_counter_captured = true;
        workload.gpu_kernel_execution_delta = 1;
        workload.accel_output_rows_consumed = 0;
        workload.plan_snippet = Some(
            "Custom Scan (GpuAccelAgg)\n  Strategy: GpuAgg\n  GPU Dispatched: true\n  \
             GPU Resident Pipeline: true\n  \
             GPU Resident Proof Version: 2\n  \
             GPU Resident Operator Class: resident_groupagg\n  \
             GPU Resident Stage Mask: 5\n  \
             GPU Resident Device Columns: 2"
                .to_owned(),
        );
        let report = mock_report(vec![workload]);

        let failures = report.evaluate_benchmark_ship_gate();
        assert_eq!(failures.len(), 1);
        assert_eq!(
            failures[0].kind,
            BenchmarkShipGateFailureKind::SelectedPlanMissedDispatch
        );
        assert!(
            failures[0]
                .detail
                .contains("without credited GPU kernel dispatch")
        );
    }

    #[test]
    fn test_benchmark_ship_gate_allows_groupagg_winner_with_logical_spec() {
        let mut workload = mock_workload_result("grouped_agg_int4", 1_000_000, 10.0, 20.0);
        workload.dispatch_counter_captured = true;
        workload.gpu_kernel_execution_delta = 1;
        workload.accel_output_rows_consumed = 10;
        workload.pg_accel_stock_exec_delta = 0;
        workload.plan_snippet = Some(
            "Custom Scan (GpuAccelAgg)\n  Strategy: GpuAgg\n  GPU Dispatched: true\n  \
             GPU Resident Pipeline: true\n  \
             GPU Resident Proof Version: 2\n  \
             GPU Resident Operator Class: resident_groupagg\n  \
             GPU Resident GroupAgg Key: resident_i32\n  \
             GPU Resident GroupAgg Measure: direct_column\n  \
             GPU Resident GroupAgg Filter: none\n  \
             GPU Resident GroupAgg Predicate Guard: none\n  \
             GPU Resident GroupAgg Value Predicate: none\n  \
             GPU Resident GroupAgg Predicate IR: guard=none;value=none\n  \
             GPU Resident GroupAgg Aggregate Mask: 3\n  \
             GPU Resident Stage Mask: 5\n  \
             GPU Resident Device Columns: 2"
                .to_owned(),
        );
        let report = mock_report(vec![workload]);

        assert!(report.evaluate_benchmark_ship_gate().is_empty());
    }

    #[test]
    fn test_benchmark_ship_gate_requires_verified_nonserial_physical_mode_for_groupagg_winner() {
        let base = || {
            let mut workload = mock_workload_result("grouped_agg_int4", 1_000_000, 10.0, 20.0);
            workload.dispatch_counter_captured = true;
            workload.gpu_kernel_execution_delta = 1;
            workload.accel_output_rows_consumed = 10;
            workload.pg_accel_stock_exec_delta = 0;
            workload.plan_snippet = Some(
                "Custom Scan (GpuAccelAgg)\n  Strategy: GpuAgg\n  GPU Dispatched: true\n  \
                 GPU Resident Pipeline: true\n  \
                 GPU Resident Proof Version: 2\n  \
                 GPU Resident Operator Class: resident_groupagg\n  \
                 GPU Resident GroupAgg Key: resident_i32\n  \
                 GPU Resident GroupAgg Measure: direct_column\n  \
                 GPU Resident GroupAgg Filter: none\n  \
                 GPU Resident GroupAgg Predicate Guard: none\n  \
                 GPU Resident GroupAgg Value Predicate: none\n  \
                 GPU Resident GroupAgg Predicate IR: guard=none;value=none\n  \
                 GPU Resident GroupAgg Aggregate Mask: 3\n  \
                 GPU Resident Stage Mask: 5\n  \
                 GPU Resident Device Columns: 2\n  \
                 GPU Physical Kernel Mode: parallel_dense_integer"
                    .to_owned(),
            );
            workload
        };

        let mut missing = base();
        missing.physical_kernel_mode = None;
        missing.physical_kernel_mode_verified = false;
        let failures = mock_report(vec![missing]).evaluate_benchmark_ship_gate();
        assert_eq!(failures.len(), 1, "{failures:?}");
        assert_eq!(
            failures[0].kind,
            BenchmarkShipGateFailureKind::ExpectedWinnerPhysicalKernelModeUnverified
        );

        let mut serial = base();
        serial.physical_kernel_mode_counts.parallel_dense_integer = 0;
        serial.physical_kernel_mode_counts.serial_generic = 1;
        serial.physical_kernel_mode = Some("serial_generic".to_owned());
        serial.physical_kernel_mode_verified = true;
        let failures = mock_report(vec![serial]).evaluate_benchmark_ship_gate();
        assert_eq!(failures.len(), 1, "{failures:?}");
        assert_eq!(
            failures[0].kind,
            BenchmarkShipGateFailureKind::ExpectedWinnerPhysicalKernelModeUnverified
        );
    }

    #[test]
    fn test_current_descriptor_proves_groupagg_logical_spec() {
        let plan = "Custom Scan (GpuAccelAgg)\n  \
                    GPU Resident Operator Class: resident_groupagg\n  \
                    GPU Descriptor Strategy: descriptor_grouped_aggregate\n  \
                    GPU Descriptor Group Keys: k0:h3_cell_to_parent(cell, 0) type=16396\n  \
                    GPU Descriptor Aggregates: m0:count_star -> value.count\n  \
                    GPU Descriptor Filter: fact=none; measures=[m0=none]; dimensions=[none]\n  \
                    GPU Descriptor Output: slot0:group[k0]; slot1:aggregate[m0].value.count";
        assert!(plan_contains_resident_groupagg_logical_evidence(plan));

        let incomplete = plan.replace(
            "GPU Descriptor Output: slot0:group[k0]; slot1:aggregate[m0].value.count",
            "GPU Descriptor Output: none",
        );
        assert!(!plan_contains_resident_groupagg_logical_evidence(
            &incomplete
        ));
    }

    #[test]
    fn test_benchmark_ship_gate_requires_groupagg_logical_spec_for_winners() {
        let mut workload = mock_workload_result("grouped_agg_int4", 1_000_000, 10.0, 20.0);
        workload.dispatch_counter_captured = true;
        workload.gpu_kernel_execution_delta = 1;
        workload.accel_output_rows_consumed = 10;
        workload.pg_accel_stock_exec_delta = 0;
        workload.plan_snippet = Some(
            "Custom Scan (GpuAccelAgg)\n  Strategy: GpuAgg\n  GPU Dispatched: true\n  \
             GPU Resident Pipeline: true\n  \
             GPU Resident Proof Version: 2\n  \
             GPU Resident Operator Class: resident_groupagg\n  \
             GPU Resident Stage Mask: 5\n  \
             GPU Resident Device Columns: 2"
                .to_owned(),
        );
        let report = mock_report(vec![workload]);

        let failures = report.evaluate_benchmark_ship_gate();
        assert_eq!(failures.len(), 1);
        assert_eq!(
            failures[0].kind,
            BenchmarkShipGateFailureKind::ExpectedWinnerMissingGroupAggLogicalSpec
        );
        assert!(failures[0].detail.contains("ResidentGroupAgg logical spec"));
    }

    #[test]
    fn test_benchmark_ship_gate_requires_groupagg_predicate_ir_for_winners() {
        let mut workload = mock_workload_result("grouped_agg_int4", 1_000_000, 10.0, 20.0);
        workload.dispatch_counter_captured = true;
        workload.gpu_kernel_execution_delta = 1;
        workload.accel_output_rows_consumed = 10;
        workload.pg_accel_stock_exec_delta = 0;
        workload.plan_snippet = Some(
            "Custom Scan (GpuAccelAgg)\n  Strategy: GpuAgg\n  GPU Dispatched: true\n  \
             GPU Resident Pipeline: true\n  \
             GPU Resident Proof Version: 2\n  \
             GPU Resident Operator Class: resident_groupagg\n  \
             GPU Resident GroupAgg Key: resident_i32\n  \
             GPU Resident GroupAgg Measure: direct_column\n  \
             GPU Resident GroupAgg Filter: none\n  \
             GPU Resident GroupAgg Predicate Guard: none\n  \
             GPU Resident GroupAgg Value Predicate: none\n  \
             GPU Resident GroupAgg Aggregate Mask: 3\n  \
             GPU Resident Stage Mask: 5\n  \
             GPU Resident Device Columns: 2"
                .to_owned(),
        );
        let report = mock_report(vec![workload]);

        let failures = report.evaluate_benchmark_ship_gate();
        assert_eq!(failures.len(), 1);
        assert_eq!(
            failures[0].kind,
            BenchmarkShipGateFailureKind::ExpectedWinnerMissingGroupAggLogicalSpec
        );
        assert!(failures[0].detail.contains("ResidentGroupAgg logical spec"));
    }

    #[test]
    fn test_benchmark_ship_gate_requires_hashjoin_filter_groupagg_logical_spec() {
        let mut workload = mock_workload_result("mixed_join_agg_int4", 1_000_000, 10.0, 20.0);
        workload.dispatch_counter_captured = true;
        workload.gpu_kernel_execution_delta = 1;
        workload.accel_output_rows_consumed = 10;
        workload.pg_accel_stock_exec_delta = 0;
        workload.plan_snippet = Some(
            "Custom Scan (GpuAccelAgg)\n  Strategy: GpuAgg\n  GPU Dispatched: true\n  \
             GPU Resident Pipeline: true\n  \
             GPU Resident Proof Version: 2\n  \
             GPU Resident Operator Class: resident_groupagg\n  \
             GPU Resident Stage Mask: 7\n  \
             GPU Resident Device Columns: 4"
                .to_owned(),
        );
        let report = mock_report(vec![workload]);

        let failures = report.evaluate_benchmark_ship_gate();
        assert_eq!(failures.len(), 1);
        assert_eq!(
            failures[0].kind,
            BenchmarkShipGateFailureKind::ExpectedWinnerMissingGroupAggLogicalSpec
        );
        assert!(
            failures[0]
                .detail
                .contains("hashjoin_groupagg_exact_sum_count")
        );
    }

    #[test]
    fn test_benchmark_ship_gate_requires_ssbm_groupagg_logical_spec_for_winners() {
        let mut workload = mock_workload_result("ssbm_resident_int4_star", 1_000_000, 10.0, 20.0);
        workload.dispatch_counter_captured = true;
        workload.gpu_kernel_execution_delta = 1;
        workload.accel_output_rows_consumed = 10;
        workload.pg_accel_stock_exec_delta = 0;
        workload.plan_snippet = Some(
            "Custom Scan (GpuAccelAgg)\n  Strategy: GpuAgg\n  GPU Dispatched: true\n  \
             GPU Resident Pipeline: true\n  \
             GPU Resident Proof Version: 2\n  \
             GPU Resident Operator Class: resident_groupagg\n  \
             GPU Resident Stage Mask: 13\n  \
             GPU Resident Device Columns: 5"
                .to_owned(),
        );
        let report = mock_report(vec![workload]);

        let failures = report.evaluate_benchmark_ship_gate();
        assert_eq!(failures.len(), 1);
        assert_eq!(
            failures[0].kind,
            BenchmarkShipGateFailureKind::ExpectedWinnerMissingGroupAggLogicalSpec
        );
        assert!(
            failures[0]
                .detail
                .contains("ssbm_resident_int4_year_size_revenue")
        );
    }

    fn exact_ssbm_two_dimension_descriptor_plan() -> String {
        "Custom Scan (GpuAccelAgg)\n  Strategy: GpuAgg\n  GPU Dispatched: true\n  \
         GPU Resident Pipeline: true\n  \
         GPU Resident Proof Version: 2\n  \
         GPU Resident Operator Class: resident_groupagg\n  \
         GPU Resident Stage Mask: 29\n  \
         GPU Resident Device Columns: 7\n  \
         GPU Descriptor Strategy: descriptor_grouped_aggregate\n  \
         GPU Descriptor Group Keys: k0:dimension[0](200.5:type=23) type=23 collation=0 encoding=dense_i32(min=1992, cardinality=7, null=none); k1:dimension[1](300.8:type=23) type=23 collation=0 encoding=dense_i32(min=1, cardinality=50, null=none)\n  \
         GPU Descriptor Aggregates: m0:column(100.13:type=23) -> value.sum; m1:count_star -> value.count\n  \
         GPU Descriptor Filter: fact=none; measures=[m0=none; m1=none]; dimensions=[d0=none; d1=none]\n  \
         GPU Descriptor Star Dimensions: d0:rel=200 join=100.6:type=23<->200.1:type=23 collation=0 multiplicity=unique filter=none; d1:rel=300 join=100.4:type=23<->300.1:type=23 collation=0 multiplicity=unique filter=none\n  \
         GPU Descriptor Output: slot0:group[k0] source_type=23 result_type=23 typmod=-1 collation=0 nullable=false; slot1:group[k1] source_type=23 result_type=23 typmod=-1 collation=0 nullable=false; slot2:aggregate[m0].value.sum source_type=23 result_type=20 typmod=-1 collation=0 nullable=true; slot3:aggregate[m1].value.count source_type=0 result_type=20 typmod=-1 collation=0 nullable=false"
            .to_owned()
    }

    fn assert_ssbm_sentinel_ship_gate_rejects(plan: String) {
        assert!(plan_contains_resident_groupagg_logical_evidence(&plan));
        assert!(!plan_contains_exact_ssbm_two_dimension_descriptor(&plan));

        let mut workload = mock_workload_result("ssbm_resident_int4_star", 1_000_000, 10.0, 20.0);
        workload.dispatch_counter_captured = true;
        workload.gpu_kernel_execution_delta = 1;
        workload.accel_output_rows_consumed = 350;
        workload.pg_accel_stock_exec_delta = 0;
        workload.plan_snippet = Some(plan);

        let failures = mock_report(vec![workload]).evaluate_benchmark_ship_gate();
        assert_eq!(failures.len(), 1, "{failures:?}");
        assert_eq!(
            failures[0].kind,
            BenchmarkShipGateFailureKind::ExpectedWinnerMissingGroupAggLogicalSpec
        );
    }

    #[test]
    fn test_benchmark_ship_gate_allows_exact_ssbm_two_dimension_descriptor() {
        let mut workload = mock_workload_result("ssbm_resident_int4_star", 1_000_000, 10.0, 20.0);
        workload.dispatch_counter_captured = true;
        workload.gpu_kernel_execution_delta = 1;
        workload.accel_output_rows_consumed = 350;
        workload.pg_accel_stock_exec_delta = 0;
        workload.plan_snippet = Some(exact_ssbm_two_dimension_descriptor_plan());
        let report = mock_report(vec![workload]);

        assert!(report.evaluate_benchmark_ship_gate().is_empty());
    }

    #[test]
    fn test_ssbm_sentinel_allows_date_and_part_dimension_index_permutation() {
        let plan = exact_ssbm_two_dimension_descriptor_plan()
            .replace("k0:dimension[0]", "k0:dimension[date]")
            .replace("k1:dimension[1]", "k1:dimension[0]")
            .replace("k0:dimension[date]", "k0:dimension[1]")
            .replace(
                "d0:rel=200 join=100.6:type=23<->200.1:type=23 collation=0 multiplicity=unique filter=none; d1:rel=300 join=100.4:type=23<->300.1:type=23 collation=0 multiplicity=unique filter=none",
                "d0:rel=300 join=100.4:type=23<->300.1:type=23 collation=0 multiplicity=unique filter=none; d1:rel=200 join=100.6:type=23<->200.1:type=23 collation=0 multiplicity=unique filter=none",
            );
        assert!(plan_contains_exact_ssbm_two_dimension_descriptor(&plan));
    }

    #[test]
    fn test_ssbm_ship_gate_rejects_wrong_dependency_alias_or_output_metadata() {
        let valid = exact_ssbm_two_dimension_descriptor_plan();
        for invalid in [
            valid.replace("join=100.6:type=23", "join=100.7:type=23"),
            valid.replace("dimension[0](200.5:type=23)", "dimension[0](200.6:type=23)"),
            valid.replace("m0:column(100.13:type=23)", "m0:column(100.12:type=23)"),
            valid
                .replace("200.5:type=23", "100.5:type=23")
                .replace("d0:rel=200", "d0:rel=100")
                .replace("<->200.1:type=23", "<->100.1:type=23"),
            valid
                .replace("300.8:type=23", "200.8:type=23")
                .replace("d1:rel=300", "d1:rel=200")
                .replace("<->300.1:type=23", "<->200.1:type=23"),
            valid.replace(
                "dimension[0](200.5:type=23) type=23 collation=0",
                "dimension[0](200.5:type=23) type=20 collation=0",
            ),
            valid.replace(
                "dimension[1](300.8:type=23) type=23 collation=0",
                "dimension[1](300.8:type=23) type=23 collation=42",
            ),
            valid.replace(
                "slot3:aggregate[m1].value.count source_type=0",
                "slot3:aggregate[m1].value.count source_type=20",
            ),
            valid.replace(
                "slot2:aggregate[m0].value.sum source_type=23 result_type=20 typmod=-1 collation=0 nullable=true",
                "slot2:aggregate[m0].value.sum source_type=23 result_type=20 typmod=-1 collation=0 nullable=false",
            ),
        ] {
            assert_ssbm_sentinel_ship_gate_rejects(invalid);
        }
    }

    #[test]
    fn test_ssbm_sentinel_rejects_incompatible_legacy_q1_and_q4_specs() {
        let resident_proof = "Custom Scan (GpuAccelAgg)\nGPU Dispatched: true\nGPU Resident Pipeline: true\nGPU Resident Proof Version: 2\nGPU Resident Operator Class: resident_groupagg\nGPU Resident Stage Mask: 29\nGPU Resident Device Columns: 7\n";
        for legacy_spec in [
            "GPU Resident GroupAgg Key: single_group\nGPU Resident GroupAgg Measure: ssbm_discounted_revenue\nGPU Resident GroupAgg Filter: ssbm_date_fact_predicate\nGPU Resident GroupAgg Predicate Guard: ssbm_date_fact_predicate\nGPU Resident GroupAgg Value Predicate: none\nGPU Resident GroupAgg Predicate IR: guard=ssbm_date_fact_predicate;value=none\nGPU Resident GroupAgg Aggregate Mask: 1",
            "GPU Resident GroupAgg Key: ssbm_year_geo_part\nGPU Resident GroupAgg Measure: ssbm_profit_revenue_minus_supplycost\nGPU Resident GroupAgg Filter: ssbm_star_join_membership\nGPU Resident GroupAgg Predicate Guard: ssbm_star_join_membership\nGPU Resident GroupAgg Value Predicate: none\nGPU Resident GroupAgg Predicate IR: guard=ssbm_star_join_membership;value=none\nGPU Resident GroupAgg Aggregate Mask: 1",
        ] {
            assert_ssbm_sentinel_ship_gate_rejects(format!("{resident_proof}{legacy_spec}"));
        }

        let one_dimension = exact_ssbm_two_dimension_descriptor_plan()
            .replace("; k1:dimension[1](300.8:type=23) type=23 collation=0 encoding=dense_i32(min=1, cardinality=50, null=none)", "")
            .replace("; d1:rel=300 join=100.4:type=23<->300.1:type=23 collation=0 multiplicity=unique filter=none", "");
        assert_ssbm_sentinel_ship_gate_rejects(one_dimension);
    }

    #[test]
    fn test_benchmark_ship_gate_flags_expected_winner_below_threshold() {
        let mut workload = mock_workload_result("h3_cell_to_parent", 1_000_000, 10.0, 10.0);
        workload.category = "gpu_h3".to_owned();
        workload.kernel_class = "h3_latlng".to_owned();
        workload.plan_selected = false;
        workload.dispatch_counter_captured = true;
        workload.gpu_kernel_execution_delta = 1;
        workload.accel_output_rows_consumed = 10;
        workload.plan_snippet = Some(
            "Custom Scan (GpuAccelAgg)\n  Strategy: GpuAgg\n  GPU Dispatched: true\n  \
             GPU Resident Pipeline: true\n  \
             GPU Resident Proof Version: 2\n  \
             GPU Resident Operator Class: resident_groupagg\n  \
             GPU Resident GroupAgg Key: h3index\n  \
             GPU Resident GroupAgg Measure: count_star\n  \
             GPU Resident GroupAgg Filter: none\n  \
             GPU Resident GroupAgg Predicate Guard: none\n  \
             GPU Resident GroupAgg Value Predicate: none\n  \
             GPU Resident GroupAgg Predicate IR: guard=none;value=none\n  \
             GPU Resident GroupAgg Aggregate Mask: 8\n  \
             GPU Resident Stage Mask: 17417\n  \
             GPU Resident Device Columns: 4"
                .to_owned(),
        );
        let report = mock_report(vec![workload]);

        let failures = report.evaluate_benchmark_ship_gate();
        assert_eq!(failures.len(), 1);
        assert_eq!(
            failures[0].kind,
            BenchmarkShipGateFailureKind::ExpectedWinnerBelowThreshold
        );
        assert!((failures[0].gate_floor - 1.15).abs() < f64::EPSILON);
    }

    #[test]
    fn test_operation_cache_gate_is_separate_from_mandatory_warm_ship_gate() {
        let mut workload = mock_workload_result("h3_cell_to_parent", 1_000_000, 10.0, 50.0);
        workload.category = "gpu_h3".to_owned();
        workload.kernel_class = "h3_latlng".to_owned();
        workload.plan_selected = true;
        workload.dispatch_counter_captured = true;
        workload.gpu_kernel_execution_delta = 1;
        workload.accel_output_rows_consumed = 10;
        workload.pg_accel_stock_exec_delta = 0;
        workload.plan_snippet = Some(
            "Custom Scan (GpuAccelAgg)\n  Strategy: GpuAgg\n  GPU Dispatched: true\n  \
             GPU Resident Pipeline: true\n  \
             GPU Resident Proof Version: 2\n  \
             GPU Resident Operator Class: resident_groupagg\n  \
             GPU Resident GroupAgg Key: h3index\n  \
             GPU Resident GroupAgg Measure: count_star\n  \
             GPU Resident GroupAgg Filter: none\n  \
             GPU Resident GroupAgg Predicate Guard: none\n  \
             GPU Resident GroupAgg Value Predicate: none\n  \
             GPU Resident GroupAgg Predicate IR: guard=none;value=none\n  \
             GPU Resident GroupAgg Aggregate Mask: 8\n  \
             GPU Resident Stage Mask: 17417\n  \
             GPU Resident Device Columns: 4"
                .to_owned(),
        );

        let warm_report = mock_report(vec![workload.clone()]);
        assert!(warm_report.evaluate_benchmark_ship_gate().is_empty());
        let failures = warm_report.evaluate_operation_cache_gate();
        assert_eq!(failures.len(), 1);
        assert_eq!(
            failures[0].kind,
            BenchmarkShipGateFailureKind::ExpectedWinnerMissingCacheEvidence
        );
        assert!(failures[0].detail.contains("cache-mode both"));

        let verified_workload =
            with_cold_cache_evidence(workload.clone(), CachePurgeState::Completed);
        let mut cache_both_report = with_cache_mode(mock_report(vec![verified_workload]), "both");
        cache_both_report.methodology.iterations = 10;
        assert!(cache_both_report.evaluate_benchmark_ship_gate().is_empty());
        assert!(cache_both_report.evaluate_operation_cache_gate().is_empty());

        let unproven = with_cold_cache_evidence(workload, CachePurgeState::Failed);
        let mut unproven_report = with_cache_mode(mock_report(vec![unproven]), "both");
        unproven_report.methodology.iterations = 10;
        assert!(unproven_report.evaluate_benchmark_ship_gate().is_empty());
        let failures = unproven_report.evaluate_operation_cache_gate();
        assert!(failures.iter().any(|failure| {
            failure.kind == BenchmarkShipGateFailureKind::ExpectedWinnerMissingCacheEvidence
        }));
    }

    #[test]
    fn test_benchmark_ship_gate_flags_expected_winner_missed_selection() {
        let workload = mark_no_dispatch(
            mock_workload_result("grouped_agg_int4", 1_000_000, 10.0, 20.0),
            "HashAggregate\n  -> Seq Scan on bench_grouped_agg",
            "HashAggregate\n  -> Seq Scan on bench_grouped_agg",
        );
        let report = mock_report(vec![workload]);

        let failures = report.evaluate_benchmark_ship_gate();
        assert_eq!(failures.len(), 1);
        assert_eq!(
            failures[0].kind,
            BenchmarkShipGateFailureKind::ExpectedWinnerMissedSelection
        );
    }

    #[test]
    fn test_benchmark_ship_gate_flags_native_decline_unexpected_dispatch() {
        let mut workload = mock_workload_result("gpu_sort_multikey", 100_000, 10.0, 20.0);
        workload.plan_selected = true;
        workload.dispatch_counter_captured = true;
        workload.gpu_kernel_execution_delta = 1;
        workload.plan_snippet = Some(
            "Custom Scan (GpuAccelSort)\n  Strategy: GpuSort\n  GPU Dispatched: true".to_owned(),
        );
        let report = mock_report(vec![workload]);

        let failures = report.evaluate_benchmark_ship_gate();
        assert_eq!(failures.len(), 1);
        assert_eq!(
            failures[0].kind,
            BenchmarkShipGateFailureKind::NativeDeclineUnexpectedDispatch
        );
    }

    #[test]
    fn test_phase9_native_declines_reject_custom_scan_or_kernel_dispatch() {
        for contract in crate::workloads::PHASE9_OPERATOR_DECLINES {
            let name = contract.workload;
            let workload = crate::workloads::find_workload(name)
                .unwrap_or_else(|| panic!("workload for {name}"));
            for &rows in workload.row_scales() {
                for (plan_selected, kernel_delta) in [(true, 0), (false, 1)] {
                    let mut result = mock_workload_result(name, rows, 10.0, 10.0);
                    result.plan_selected = plan_selected;
                    result.dispatch_counter_captured = true;
                    result.gpu_kernel_execution_delta = kernel_delta;
                    result.accel_output_rows_consumed = kernel_delta;
                    result.plan_snippet = plan_selected.then(|| {
                        "Custom Scan (GpuAccelUnexpected)\n  GPU Dispatched: false".to_owned()
                    });

                    let failures = mock_report(vec![result]).evaluate_benchmark_ship_gate();
                    assert_eq!(failures.len(), 1, "{name} at {rows}");
                    assert_eq!(
                        failures[0].kind,
                        BenchmarkShipGateFailureKind::NativeDeclineUnexpectedDispatch,
                        "{name} at {rows}"
                    );
                }
            }
        }
    }

    #[test]
    fn test_phase9_native_declines_require_dispatch_counter_capture() {
        for contract in crate::workloads::PHASE9_OPERATOR_DECLINES {
            let name = contract.workload;
            let workload = crate::workloads::find_workload(name)
                .unwrap_or_else(|| panic!("workload for {name}"));
            for &rows in workload.row_scales() {
                let mut result = mark_no_dispatch(
                    mock_workload_result(name, rows, 10.0, 10.0),
                    "PostgreSQL native plan",
                    "PostgreSQL native plan",
                );
                result.dispatch_counter_captured = false;
                result.dispatch_counter_error = Some("counter query unavailable".to_owned());
                result.native_decline_evidence = Some(NativeDeclineEvidence {
                    reason: contract.reason.to_owned(),
                    source: DeclineReasonSource::PlannerReported,
                });

                let failures = mock_report(vec![result]).evaluate_benchmark_ship_gate();
                assert_eq!(failures.len(), 1, "{name} at {rows}");
                assert_eq!(
                    failures[0].kind,
                    BenchmarkShipGateFailureKind::NativeDeclineDispatchCounterUnavailable,
                    "{name} at {rows}"
                );
                assert!(failures[0].detail.contains("counter query unavailable"));
            }
        }
    }

    #[test]
    fn test_benchmark_ship_gate_allows_planner_declined_native_rows() {
        // Honest evidence: the planner itself reported this decline reason
        // (`DeclineReasonSource::PlannerReported`), so the ship gate passes.
        let mut workload = mark_no_dispatch(
            mock_workload_result("mergejoin_decline", 100_000, 10.0, 10.0),
            "Aggregate\n  ->  Merge Join",
            "Aggregate\n  ->  Merge Join",
        );
        workload.native_decline_evidence = Some(NativeDeclineEvidence {
            reason: "mergejoin_no_gpu_kernel".to_owned(),
            source: DeclineReasonSource::PlannerReported,
        });
        let report = mock_report(vec![workload]);

        assert!(report.evaluate_benchmark_ship_gate().is_empty());
        assert!(
            !report
                .to_markdown()
                .contains("### Benchmark Ship Gate Failures")
        );
    }

    #[test]
    fn test_phase9_structural_decline_cells_require_planner_confirmation() {
        for contract in crate::workloads::PHASE9_OPERATOR_DECLINES {
            let name = contract.workload;
            let reason = contract.reason;
            let workload = crate::workloads::find_workload(name)
                .unwrap_or_else(|| panic!("workload for {name}"));
            for &rows in workload.row_scales() {
                let mut result = mark_no_dispatch(
                    mock_workload_result(name, rows, 10.0, 10.0),
                    "PostgreSQL native plan",
                    "PostgreSQL native plan",
                );
                result.native_decline_evidence = Some(NativeDeclineEvidence {
                    reason: reason.to_owned(),
                    source: DeclineReasonSource::ExpectedUnconfirmed,
                });
                let failures = mock_report(vec![result.clone()]).evaluate_benchmark_ship_gate();
                assert_eq!(failures.len(), 1, "{name} at {rows}");
                assert_eq!(
                    failures[0].kind,
                    BenchmarkShipGateFailureKind::NativeDeclineReasonMissing,
                    "{name} at {rows}"
                );

                result.native_decline_evidence = Some(NativeDeclineEvidence {
                    reason: reason.to_owned(),
                    source: DeclineReasonSource::PlannerReported,
                });
                assert!(
                    mock_report(vec![result])
                        .evaluate_benchmark_ship_gate()
                        .is_empty(),
                    "{name} at {rows}"
                );
            }
        }
    }

    #[test]
    fn test_benchmark_ship_gate_requires_spatial_decline_reason() {
        let missing_reason = mark_no_dispatch(
            mock_workload_result("spatial_sel_10pct", 1_000_000, 10.0, 10.0),
            "Finalize Aggregate\n  ->  Gather\n        ->  Parallel Seq Scan",
            "Finalize Aggregate\n  ->  Gather\n        ->  Parallel Seq Scan",
        );
        let report = mock_report(vec![missing_reason]);
        let failures = report.evaluate_benchmark_ship_gate();
        assert_eq!(failures.len(), 1);
        assert_eq!(
            failures[0].kind,
            BenchmarkShipGateFailureKind::NativeDeclineReasonMissing
        );

        // The runner tags a real `pg_accel planner rejection reason:` line
        // (captured from `pg_accel_last_planner_rejection_reason()`) into
        // `native_decline_evidence` as `PlannerReported` — that tagged field,
        // not the raw plan text, is what the ship gate reads.
        let mut with_reason = mark_no_dispatch(
            mock_workload_result("spatial_sel_10pct", 1_000_000, 10.0, 10.0),
            "Finalize Aggregate\n  ->  Gather\n        ->  Parallel Seq Scan\n\
             pg_accel planner rejection reason: generic_descriptor_capability",
            "Finalize Aggregate\n  ->  Gather\n        ->  Parallel Seq Scan",
        );
        with_reason.native_decline_evidence = Some(NativeDeclineEvidence {
            reason: "generic_descriptor_capability".to_owned(),
            source: DeclineReasonSource::PlannerReported,
        });
        let report = mock_report(vec![with_reason]);
        assert!(report.evaluate_benchmark_ship_gate().is_empty());
    }

    #[test]
    fn test_benchmark_ship_gate_requires_threshold_decline_reason_evidence() {
        let missing_generic_reason = mark_no_dispatch(
            mock_workload_result("gpu_sort_multikey", 100_000, 10.0, 10.0),
            "Sort\n  Sort Key: key1, key2\n  -> Seq Scan on bench_sort_multi",
            "Sort\n  Sort Key: key1, key2\n  -> Seq Scan on bench_sort_multi",
        );
        let report = mock_report(vec![missing_generic_reason]);
        let failures = report.evaluate_benchmark_ship_gate();
        assert_eq!(failures.len(), 1);
        assert_eq!(
            failures[0].kind,
            BenchmarkShipGateFailureKind::NativeDeclineReasonMissing
        );

        // Planner-reported evidence with the matching reason passes.
        let mut with_generic_reason = mark_no_dispatch(
            mock_workload_result("gpu_sort_multikey", 100_000, 10.0, 10.0),
            "Sort\n  Sort Key: key1, key2\n  -> Seq Scan on bench_sort_multi",
            "Sort\n  Sort Key: key1, key2\n  -> Seq Scan on bench_sort_multi",
        );
        with_generic_reason.native_decline_evidence = Some(NativeDeclineEvidence {
            reason: "sort_multikey_no_gpu_kernel".to_owned(),
            source: DeclineReasonSource::PlannerReported,
        });
        let report = mock_report(vec![with_generic_reason]);
        assert!(report.evaluate_benchmark_ship_gate().is_empty());

        // An *unconfirmed* expectation — the static matrix expected this
        // decline but the planner never reported a reason — must still fail
        // the gate. Only a confirmed planner-reported reason may pass.
        let mut with_unconfirmed_reason = mark_no_dispatch(
            mock_workload_result("gpu_sort_multikey", 100_000, 10.0, 10.0),
            "Sort\n  Sort Key: key1, key2\n  -> Seq Scan on bench_sort_multi",
            "Sort\n  Sort Key: key1, key2\n  -> Seq Scan on bench_sort_multi",
        );
        with_unconfirmed_reason.native_decline_evidence = Some(NativeDeclineEvidence {
            reason: "sort_multikey_no_gpu_kernel".to_owned(),
            source: DeclineReasonSource::ExpectedUnconfirmed,
        });
        let report = mock_report(vec![with_unconfirmed_reason]);
        let failures = report.evaluate_benchmark_ship_gate();
        assert_eq!(
            failures.len(),
            1,
            "unconfirmed expected-decline evidence must not satisfy the ship gate"
        );
        assert_eq!(
            failures[0].kind,
            BenchmarkShipGateFailureKind::NativeDeclineReasonMissing
        );

        let missing_reason = mark_no_dispatch(
            mock_workload_result("h3_bulk", 10_000, 10.0, 10.0),
            "HashAggregate\n  -> Seq Scan on bench_h3_points",
            "HashAggregate\n  -> Seq Scan on bench_h3_points",
        );
        let report = mock_report(vec![missing_reason]);
        let failures = report.evaluate_benchmark_ship_gate();
        assert_eq!(failures.len(), 1);
        assert_eq!(
            failures[0].kind,
            BenchmarkShipGateFailureKind::NativeDeclineReasonMissing
        );

        let mut with_reason = mark_no_dispatch(
            mock_workload_result("h3_bulk", 10_000, 10.0, 10.0),
            "HashAggregate\n  -> Seq Scan on bench_h3_points",
            "HashAggregate\n  -> Seq Scan on bench_h3_points",
        );
        with_reason.native_decline_evidence = Some(NativeDeclineEvidence {
            reason: "shape_unsupported_rte".to_owned(),
            source: DeclineReasonSource::PlannerReported,
        });
        let report = mock_report(vec![with_reason]);
        assert!(report.evaluate_benchmark_ship_gate().is_empty());
    }

    // -----------------------------------------------------------------------
    // H3 winner and native-decline dispatch-classification gates.
    // -----------------------------------------------------------------------

    fn mock_h3_native_decline(name: &str, rows: usize, reason: &str) -> WorkloadResult {
        let mut workload = mark_no_dispatch(
            mock_workload_result(name, rows, 10.0, 10.0),
            "HashAggregate\n  -> Seq Scan on native_h3_fixture",
            "HashAggregate\n  -> Seq Scan on native_h3_fixture",
        );
        workload.category = "gpu_h3".to_owned();
        workload.kernel_class = "h3_latlng".to_owned();
        workload.dispatch_counter_captured = true;
        workload.gpu_kernel_execution_delta = 0;
        workload.pg_accel_stock_exec_delta = 0;
        workload.native_decline_evidence = Some(NativeDeclineEvidence {
            reason: reason.to_owned(),
            source: DeclineReasonSource::PlannerReported,
        });
        workload
    }

    #[test]
    fn test_threshold_matrix_renders_evidence_columns() {
        let workload = mock_workload_result("h3_cell_to_parent", 1_000_000, 10.0, 20.0);
        let report = mock_report(vec![workload]);
        let md = report.to_markdown();

        assert!(md.contains("## Planner Threshold Matrix"));
        assert!(md.contains("Dispatch/Output Evidence"));
        assert!(md.contains("Correctness Evidence"));
        assert!(md.contains("Cache Gate"));
        assert!(md.contains("resident H3 GpuAgg"));
    }

    #[test]
    fn test_grouped_h3_point_to_cell_lanes_require_verified_native_declines() {
        for (name, reason) in [
            ("h3_bulk", "shape_unsupported_rte"),
            ("h3_resolution_sweep", "shape_group_expression"),
            ("h3_latlng_res15", "shape_group_expression"),
        ] {
            let workload = mock_h3_native_decline(name, 1_000_000, reason);
            let classification = workload.dispatch_classification();
            assert!(
                classification.planner_declined,
                "{name}: {classification:?}"
            );
            assert!(!classification.gpu_kernel_dispatched, "{name}");
            assert!(!classification.function_srf_kernel_dispatched, "{name}");
            assert_eq!(classification.function_kernel_count, 0, "{name}");

            let report = mock_report(vec![workload]);
            assert!(report.evaluate_benchmark_ship_gate().is_empty(), "{name}");
            assert!(report.evaluate_h3_lane_gate().is_empty(), "{name}");
        }
    }

    #[test]
    fn test_grouped_h3_point_to_cell_native_declines_reject_any_kernel_delta() {
        for (name, reason) in [
            ("h3_bulk", "shape_unsupported_rte"),
            ("h3_resolution_sweep", "shape_group_expression"),
            ("h3_latlng_res15", "shape_group_expression"),
        ] {
            let mut workload = mock_h3_native_decline(name, 1_000_000, reason);
            workload.gpu_kernel_execution_delta = 1;
            workload.accel_output_rows_consumed = 1;
            let report = mock_report(vec![workload]);
            assert!(report.evaluate_benchmark_ship_gate().iter().any(|failure| {
                failure.kind == BenchmarkShipGateFailureKind::NativeDeclineUnexpectedDispatch
            }));
            assert!(report.evaluate_h3_lane_gate().iter().any(|failure| {
                failure.kind == H3LaneGateFailureKind::ParityUnexpectedlyDispatched
            }));
        }
    }

    /// The `h3_cell_to_parent` benchmark is the fused grouped COUNT(*) shape,
    /// not standalone scalar exposure. A selected Custom Scan with a kernel
    /// delta must be credited as GPU dispatch rather than function/SRF
    /// fallback.
    #[test]
    fn test_h3_cell_to_parent_grouped_count_row_classified_as_gpu_dispatched() {
        let mut workload = mock_workload_result("h3_cell_to_parent", 1_000_000, 10.0, 3.0);
        workload.category = "gpu_h3".to_owned();
        workload.kernel_class = "h3_cell_to_parent".to_owned();
        workload.plan_selected = true;
        workload.gpu_kernel_dispatched = true;
        workload.function_srf_kernel_dispatched = false;
        workload.dispatch_counter_captured = true;
        workload.gpu_kernel_execution_delta = 2;
        workload.accel_output_rows_consumed = 32;
        workload.pg_accel_stock_exec_delta = 0;
        workload.plan_snippet = Some(
            "Custom Scan (GpuAgg)\n  Output: (h3_cell_to_parent(cell, 0)), count(*)\n  \
             Group Key: h3_cell_to_parent(bench_h3_parent.cell, 0)\n  \
             GPU Kernel Dispatched: true\n"
                .to_owned(),
        );

        let classification = workload.dispatch_classification();
        assert!(
            !classification.function_srf_kernel_dispatched,
            "grouped parent-count should be a Custom Scan dispatch, not function/SRF dispatch"
        );
        assert!(
            classification.gpu_kernel_dispatched,
            "selected grouped parent-count row must be credited as GPU-dispatched"
        );
        assert!(
            !classification.planner_declined,
            "selected grouped parent-count row must not be marked planner_declined"
        );
    }

    /// If a quarantined scalar H3 lane accidentally starts incrementing the
    /// kernel counter (e.g. an agent re-registers it in the h3 adapter), the row
    /// will look like a function/SRF dispatch in the report — that surfaces
    /// clearly in the dispatch classification because the report-side
    /// heuristic is purely name-prefix + counter-driven. The lane policy
    /// itself (parity vs winning) is enforced by `h3_lane_class()` in
    /// `pg_accel_bench/src/workloads/mod.rs`. This test pins what the bench
    /// report WILL show in that regression scenario so a future runner-side
    /// cross-check has a stable surface to assert against.
    #[test]
    fn test_h3_grid_distance_with_unexpected_kernel_delta_classifier_visible() {
        let mut workload = mock_workload_result("h3_grid_distance", 1_000_000, 10.0, 12.0);
        workload.category = "gpu_h3".to_owned();
        workload.kernel_class = "h3_grid_distance".to_owned();
        workload.plan_selected = false;
        workload.gpu_kernel_dispatched = false;
        workload.function_srf_kernel_dispatched = false;
        workload.dispatch_counter_captured = true;
        workload.gpu_kernel_execution_delta = 1;
        workload.accel_output_rows_consumed = 10;
        workload.pg_accel_stock_exec_delta = 0;
        workload.plan_snippet =
            Some("Aggregate\n  Output: avg(h3_grid_distance(cell_a, cell_b))\n".to_owned());

        let classification = workload.dispatch_classification();
        assert!(
            classification.function_srf_kernel_dispatched,
            "report classifier must surface parity-lane kernel deltas as function/SRF \
             dispatch so a regression in the h3 adapter quarantine (where a parity-lane \
             scalar op accidentally gets re-registered and fires a kernel) is loudly \
             visible in the bench report. The lane policy itself (parity vs winning) \
             is enforced by h3_lane_class() in workloads/mod.rs."
        );
        // The lane policy is the orthogonal gate; assert it disagrees with the
        // dispatch classification so a future cross-check can flag this as a
        // protected-lane violation.
        assert_eq!(
            crate::workloads::h3_lane_class("h3_grid_distance"),
            Some(crate::workloads::H3LaneClass::Parity),
            "h3_grid_distance must remain a parity lane; dispatch classifier crediting \
             it as function/SRF is a regression signal, not an admission of winning"
        );
    }

    // -----------------------------------------------------------------------
    // H3 winning-lane protection report-level hard gate
    //
    // These three tests pin `BenchReport::evaluate_h3_lane_gate` to the
    // contract documented on the function: a Winner that regresses below
    // `H3_LANE_GATE_MIN_WARM_SPEEDUP` (1.0x), a Winner that fails to
    // dispatch, and a Parity row that dispatches all surface as gate
    // failures. The bench process turns these into a non-zero exit code in
    // `main::enforce_h3_lane_gate`, so a regression that prints red text in
    // the report can no longer leave CI green.
    // -----------------------------------------------------------------------

    /// `h3_cell_to_parent` is the canonical H3 Winner. Dispatched, but with a
    /// `speedup_median_vs_parallel` of 0.5x (well below the 1.0x gate floor)
    /// MUST produce exactly one `WinnerBelowFloor` failure.
    #[test]
    fn test_h3_winner_below_threshold_triggers_gate_fail() {
        // 20ms accel vs 10ms parallel → median speedup ~0.5x
        let mut workload = mock_workload_result("h3_cell_to_parent", 1_000_000, 20.0, 10.0);
        workload.category = "gpu_h3".to_owned();
        workload.kernel_class = "h3_cell_to_parent".to_owned();
        // The gate reads `gpu_kernel_dispatched` AFTER `with_normalized_dispatch`
        // re-runs the classifier, so seed the inputs the classifier consumes.
        workload.plan_selected = true;
        workload.dispatch_counter_captured = true;
        workload.gpu_kernel_execution_delta = 1;
        workload.accel_output_rows_consumed = 10;
        workload.pg_accel_stock_exec_delta = 0;
        workload.plan_snippet = Some(
            "Custom Scan (GpuAgg)\n  Output: (h3_cell_to_parent(cell, 0)), count(*)\n  \
             Group Key: h3_cell_to_parent(bench_h3_parent.cell, 0)\n"
                .to_owned(),
        );

        let report = mock_report(vec![workload]);
        let failures = report.evaluate_h3_lane_gate();
        assert_eq!(
            failures.len(),
            1,
            "regressed h3_cell_to_parent Winner must produce exactly one gate failure; got: {failures:?}"
        );
        assert_eq!(failures[0].workload, "h3_cell_to_parent");
        assert_eq!(failures[0].kind, H3LaneGateFailureKind::WinnerBelowFloor);
        assert!(
            failures[0].speedup_median < H3_LANE_GATE_MIN_WARM_SPEEDUP,
            "failure record must carry the observed sub-floor speedup; got {sp}",
            sp = failures[0].speedup_median,
        );

        // The markdown must render the `### H3 Lane Gate Failures` section.
        let md = report.to_markdown();
        assert!(
            md.contains("### H3 Lane Gate Failures"),
            "markdown must surface the gate failure section; full md:\n{md}"
        );
        assert!(
            md.contains("winner_below_floor"),
            "failure section must label the failure kind; full md:\n{md}"
        );
        assert!(
            md.contains("h3_cell_to_parent"),
            "failure section must name the failing workload; full md:\n{md}"
        );
    }

    /// `h3_grid_distance` is a canonical H3 Parity workload. If a row shows
    /// `gpu_kernel_dispatched=true` (a quarantine breach), the gate MUST
    /// produce a `ParityUnexpectedlyDispatched` failure.
    #[test]
    fn test_h3_parity_unexpectedly_dispatched_triggers_gate_fail() {
        let mut workload = mock_workload_result("h3_grid_distance", 1_000_000, 10.0, 12.0);
        workload.category = "gpu_h3".to_owned();
        workload.kernel_class = "h3_grid_distance".to_owned();
        // Quarantine breach: the parity-lane row fired a kernel.
        workload.plan_selected = false;
        workload.dispatch_counter_captured = true;
        workload.gpu_kernel_execution_delta = 1;
        workload.accel_output_rows_consumed = 10;
        workload.pg_accel_stock_exec_delta = 0;
        workload.plan_snippet =
            Some("Aggregate\n  Output: avg(h3_grid_distance(cell_a, cell_b))\n".to_owned());

        let report = mock_report(vec![workload]);
        let failures = report.evaluate_h3_lane_gate();
        assert_eq!(
            failures.len(),
            1,
            "parity-lane dispatch must produce exactly one gate failure; got: {failures:?}"
        );
        assert_eq!(failures[0].workload, "h3_grid_distance");
        assert_eq!(
            failures[0].kind,
            H3LaneGateFailureKind::ParityUnexpectedlyDispatched
        );

        let md = report.to_markdown();
        assert!(
            md.contains("### H3 Lane Gate Failures"),
            "markdown must surface gate failure section; md:\n{md}"
        );
        assert!(
            md.contains("parity_unexpectedly_dispatched"),
            "failure section must label parity breach kind; md:\n{md}"
        );
    }

    #[test]
    fn test_h3_below_grouped_floor_passes_as_native_decline() {
        let mut workload = mock_workload_result("h3_cell_to_parent", 10_000, 10.0, 30.0);
        workload.category = "gpu_h3".to_owned();
        workload.kernel_class = "h3_latlng".to_owned();
        workload.plan_selected = false;
        workload.dispatch_counter_captured = true;
        workload.gpu_kernel_execution_delta = 0;
        workload.accel_output_rows_consumed = 9_998;
        workload.pg_accel_stock_exec_delta = 0;
        workload.plan_snippet =
            Some("HashAggregate\n  Output: (h3_latlng_to_cell(geom, 7)), count(*)\n".to_owned());
        // Honest evidence: the planner itself reported the expected decline
        // reason. Without this field populated (or with it tagged
        // `ExpectedUnconfirmed`) the generic ship gate must NOT pass — see
        // `test_h3_below_grouped_floor_native_decline_requires_confirmed_evidence`.
        workload.native_decline_evidence = Some(NativeDeclineEvidence {
            reason: "h3_rows_below_grouped_agg_min".to_owned(),
            source: DeclineReasonSource::PlannerReported,
        });

        let report = mock_report(vec![workload]);
        assert!(
            report.evaluate_benchmark_ship_gate().is_empty(),
            "below-floor h3_cell_to_parent row must satisfy the generic native-decline ship gate \
             when the planner reported the expected decline reason"
        );
        let failures = report.evaluate_h3_lane_gate();
        assert!(
            failures.is_empty(),
            "below-floor h3_cell_to_parent row must follow the threshold matrix native-decline expectation; got: {failures:?}"
        );

        let md = report.to_markdown();
        assert!(
            !md.contains("### H3 Lane Gate Failures"),
            "below-floor native-decline row must not render an H3 gate failure; md:\n{md}"
        );
    }

    /// Counterpart to the test above: without a planner-reported decline
    /// reason, the same below-floor `h3_cell_to_parent` row must NOT pass the generic
    /// ship gate — neither when no evidence at all was captured, nor when
    /// the evidence is present but tagged `ExpectedUnconfirmed` (the static
    /// matrix assumed the decline; the planner never confirmed it).
    #[test]
    fn test_h3_below_grouped_floor_native_decline_requires_confirmed_evidence() {
        let base = || {
            let mut workload = mock_workload_result("h3_cell_to_parent", 10_000, 10.0, 30.0);
            workload.category = "gpu_h3".to_owned();
            workload.kernel_class = "h3_latlng".to_owned();
            workload.plan_selected = false;
            workload.dispatch_counter_captured = true;
            workload.gpu_kernel_execution_delta = 0;
            workload.accel_output_rows_consumed = 9_998;
            workload.pg_accel_stock_exec_delta = 0;
            workload.plan_snippet = Some(
                "HashAggregate\n  Output: (h3_latlng_to_cell(geom, 7)), count(*)\n".to_owned(),
            );
            workload
        };

        let no_evidence = base();
        let report = mock_report(vec![no_evidence]);
        let failures = report.evaluate_benchmark_ship_gate();
        assert_eq!(
            failures.len(),
            1,
            "missing decline evidence must fail the generic ship gate"
        );
        assert_eq!(
            failures[0].kind,
            BenchmarkShipGateFailureKind::NativeDeclineReasonMissing
        );

        let mut unconfirmed = base();
        unconfirmed.native_decline_evidence = Some(NativeDeclineEvidence {
            reason: "h3_rows_below_grouped_agg_min".to_owned(),
            source: DeclineReasonSource::ExpectedUnconfirmed,
        });
        let report = mock_report(vec![unconfirmed]);
        let failures = report.evaluate_benchmark_ship_gate();
        assert_eq!(
            failures.len(),
            1,
            "unconfirmed expected-decline evidence must fail the generic ship gate"
        );
        assert_eq!(
            failures[0].kind,
            BenchmarkShipGateFailureKind::NativeDeclineReasonMissing
        );
    }

    #[test]
    fn test_benchmark_ship_gate_allows_small_raster_native_decline() {
        let mut workload = mark_no_dispatch(
            mock_workload_result("raster_reclass", 100, 10.0, 10.0),
            "Aggregate\n  ->  Seq Scan on bench_raster_tiles",
            "Aggregate\n  ->  Seq Scan on bench_raster_tiles",
        );
        workload.native_decline_evidence = Some(NativeDeclineEvidence {
            reason: "shape_unsupported_rte".to_owned(),
            source: DeclineReasonSource::PlannerReported,
        });
        let report = mock_report(vec![workload]);

        assert!(
            report.evaluate_benchmark_ship_gate().is_empty(),
            "small raster native-decline row must satisfy the operation-specific threshold matrix \
             when the planner reported the expected decline reason"
        );
    }

    /// Happy path: every H3 Winner dispatches AND beats the gate floor; no
    /// Parity row dispatches. The gate produces zero failures and the
    /// `### H3 Lane Gate Failures` section is omitted from the markdown.
    #[test]
    fn test_h3_winners_all_above_threshold_passes() {
        // Build a representative happy-path Winner for every name in
        // `h3_winning_lane_names()`. Each is 10ms accel vs 50ms parallel →
        // median speedup ~5x, well above the 1.0x gate floor and the highest
        // per-Winner advisory threshold (1.5x).
        let mut workloads = Vec::new();
        for name in crate::workloads::h3_winning_lane_names() {
            let mut wl = mock_workload_result(name, 1_000_000, 10.0, 50.0);
            wl.category = if name == "h3_fp64_ops" {
                "fp64_matrix".to_owned()
            } else {
                "gpu_h3".to_owned()
            };
            wl.kernel_class = if name == "h3_cell_to_parent" {
                "h3_cell_to_parent".to_owned()
            } else {
                "h3_latlng".to_owned()
            };
            wl.plan_selected = name == "h3_cell_to_parent";
            wl.dispatch_counter_captured = true;
            wl.gpu_kernel_execution_delta = 1;
            wl.accel_output_rows_consumed = 10;
            wl.pg_accel_stock_exec_delta = 0;
            wl.plan_snippet = Some(if name == "h3_cell_to_parent" {
                "Custom Scan (GpuAgg)\n  Output: (h3_cell_to_parent(cell, 0)), count(*)\n  \
                 Group Key: h3_cell_to_parent(bench_h3_parent.cell, 0)\n"
                    .to_owned()
            } else {
                "HashAggregate\n  Output: (h3_latlng_to_cell(geom, 7)), count(*)\n  \
                 Group Key: h3_latlng_to_cell(bench_h3_points.geom, 7)\n"
                    .to_owned()
            });
            workloads.push(wl);
        }
        // And an h3_grid_distance parity row that stays native (no kernel
        // delta) — the gate must NOT flag it.
        let mut parity = mock_workload_result("h3_grid_distance", 1_000_000, 10.0, 10.0);
        parity.category = "gpu_h3".to_owned();
        parity.kernel_class = "h3_grid_distance".to_owned();
        parity.plan_selected = false;
        parity.dispatch_counter_captured = true;
        parity.gpu_kernel_execution_delta = 0;
        parity.accel_output_rows_consumed = 1;
        parity.pg_accel_stock_exec_delta = 0;
        parity.plan_snippet =
            Some("Aggregate\n  Output: avg(h3_grid_distance(cell_a, cell_b))\n".to_owned());
        workloads.push(parity);

        let report = mock_report(workloads);
        let failures = report.evaluate_h3_lane_gate();
        assert!(
            failures.is_empty(),
            "happy-path H3 lane suite must produce no gate failures; got: {failures:?}"
        );

        // The markdown must NOT render the failure section when the gate is
        // green — otherwise the section becomes noise that reviewers learn to
        // ignore.
        let md = report.to_markdown();
        assert!(
            !md.contains("### H3 Lane Gate Failures"),
            "markdown must omit the gate failure section when no failures exist; md:\n{md}"
        );
    }

    /// Acceptance contract: every canonical H3 winning lane must be classified
    /// as Winning by `h3_lane_class` (a cross-module pin so the report tests
    /// stay aligned with the workload registry).
    #[test]
    fn test_h3_winning_lanes_have_lane_class_winning() {
        for name in crate::workloads::h3_winning_lane_names() {
            match crate::workloads::h3_lane_class(name) {
                Some(crate::workloads::H3LaneClass::Winning { min_warm_speedup }) => {
                    assert!(
                        min_warm_speedup >= 1.0,
                        "H3 winning lane `{name}` must require >= 1.0x speedup; \
                         got min_warm_speedup={min_warm_speedup}"
                    );
                }
                other => panic!(
                    "report-side winning-lane gate failed: `{name}` not classified \
                     as Winning by h3_lane_class(); got {other:?}"
                ),
            }
        }
    }

    #[test]
    fn test_geomean_by_dispatch_source_splits_custom_scan_vs_function_srf() {
        // Custom Scan win: reduce_sum_i64-style row with a Custom Scan plan
        // and runtime kernel delta.
        let mut custom_scan_workload =
            mock_workload_result("gpu_reduce_sum_i64", 1_000_000, 5.0, 50.0);
        custom_scan_workload.category = "gpu_reduce".to_owned();
        custom_scan_workload.kernel_class = "reduce".to_owned();
        custom_scan_workload.plan_selected = true;
        custom_scan_workload.gpu_kernel_dispatched = true;
        custom_scan_workload.function_srf_kernel_dispatched = false;
        custom_scan_workload.dispatch_counter_captured = true;
        custom_scan_workload.gpu_kernel_execution_delta = 1;
        custom_scan_workload.pg_accel_rows_dispatched_delta = 1_000_000;
        custom_scan_workload.pg_accel_gpu_rows_processed_delta = 1_000_000;
        custom_scan_workload.accel_output_rows_consumed = 1;
        custom_scan_workload.plan_snippet =
            Some("Custom Scan (GpuAccelReduce)\n  Strategy: GpuReduce\n".to_owned());

        // Synthetic function/SRF row with no Custom Scan plan but a kernel
        // delta and consumed output. It deliberately is not a registered
        // release workload.
        let mut function_srf_workload =
            mock_workload_result("h3_function_dispatch_fixture", 1_000_000, 7.0, 70.0);
        function_srf_workload.category = "gpu_h3".to_owned();
        function_srf_workload.kernel_class = "h3_latlng".to_owned();
        function_srf_workload.plan_selected = false;
        function_srf_workload.gpu_kernel_dispatched = false;
        function_srf_workload.function_srf_kernel_dispatched = false;
        function_srf_workload.dispatch_counter_captured = true;
        function_srf_workload.gpu_kernel_execution_delta = 1;
        function_srf_workload.accel_output_rows_consumed = 12;
        function_srf_workload.plan_snippet = Some(
            "HashAggregate\n  Output: (h3_latlng_to_cell(geom, 7)), count(*)\n  \
             Group Key: h3_latlng_to_cell(bench_h3_points.geom, 7)\n"
                .to_owned(),
        );

        let report = mock_report(vec![custom_scan_workload, function_srf_workload]);
        let md = report.to_markdown();

        // The split table must exist and credit each path separately.
        assert!(
            md.contains("### Geomean by Dispatch Source"),
            "report missing Geomean by Dispatch Source section: {md}"
        );
        // One Custom Scan workload, one function/SRF workload.
        assert!(
            md.contains("| Custom Scan dispatch | 1 |"),
            "Custom Scan dispatch row count wrong: {md}"
        );
        assert!(
            md.contains("| Function/SRF kernel dispatch | 1 |"),
            "Function/SRF kernel dispatch row count wrong: {md}"
        );
        // The combined headline still counts both.
        assert!(
            md.contains("geomean across 2 GPU-dispatched workloads"),
            "combined headline must still see both workloads: {md}"
        );
    }

    #[test]
    fn test_geomean_by_dispatch_source_renders_zero_buckets() {
        // No GPU-dispatched workloads at all: both buckets must still render
        // with zero counts and a NaN geomean so the report shape is stable.
        let mut workload = mock_workload_result("native_only", 100_000, 10.0, 10.0);
        workload.plan_selected = false;
        workload.gpu_kernel_dispatched = false;
        workload.function_srf_kernel_dispatched = false;
        workload.dispatch_counter_captured = true;
        workload.plan_snippet = Some("Aggregate\n  -> Seq Scan on public.bench\n".to_owned());
        let report = mock_report(vec![workload]);

        let md = report.to_markdown();
        assert!(
            md.contains("### Geomean by Dispatch Source"),
            "split table must render even when nothing is dispatched: {md}"
        );
        assert!(
            md.contains("| Custom Scan dispatch | 0 |"),
            "Custom Scan dispatch zero bucket missing: {md}"
        );
        assert!(
            md.contains("| Function/SRF kernel dispatch | 0 |"),
            "Function/SRF kernel dispatch zero bucket missing: {md}"
        );
    }

    #[test]
    fn test_cpu_backed_pg_accel_plan_is_not_a_win() {
        let mut workload = mock_workload_result("spatial_filter", 100_000, 10.0, 50.0);
        workload.plan_selected = true;
        workload.gpu_kernel_dispatched = true;
        workload.dispatch_counter_captured = true;
        workload.gpu_kernel_execution_delta = 1;
        workload.pg_accel_stock_exec_delta = 1;
        workload.accel_output_rows_consumed = 10;
        workload.plan_snippet = Some("Custom Scan (GpuAccelScan)\n".to_owned());
        let report = mock_report(vec![workload]);

        let md = report.to_markdown();
        assert!(md.contains("geomean across 0 GPU-dispatched workloads"));
        assert!(md.contains("| pg_accel stock executor fallback delta > 0 | 1 |"));
    }

    #[test]
    fn test_explicit_gpu_dispatched_false_is_plan_selected_only() {
        let mut workload = mock_workload_result("spatial_sel_90pct", 100_000, 20.0, 10.0);
        workload.plan_selected = true;
        workload.gpu_kernel_dispatched = true;
        workload.plan_snippet = Some(
            "Custom Scan (GpuAccelAgg)\n  Strategy: GpuAgg\n  -> Seq Scan on public.bench\n  \
             GPU Dispatched: false\n"
                .to_owned(),
        );
        let report = mock_report(vec![workload]);

        let md = report.to_markdown();
        assert!(md.contains("geomean across 0 GPU-dispatched workloads"));
        assert!(md.contains("| pg_accel Custom Scan plan selected | 1 |"));
        assert!(md.contains("| Custom Scan selected but no GPU dispatch | 1 |"));

        let csv = report.to_csv();
        assert!(csv.contains(
            "spatial_sel_90pct,gpu,unclassified,true,false,false,false,true,0,0,\
             selected_not_dispatched,false,0,10,0,0,0,0,0,100000"
        ));
    }

    #[test]
    fn test_plan_explicit_gpu_kernel_dispatched_aliases_are_parsed() {
        assert_eq!(
            plan_explicit_gpu_dispatched("Custom Scan\n  GPU Kernel Dispatched: true\n"),
            Some(true)
        );
        assert_eq!(
            plan_explicit_gpu_dispatched("Custom Scan\n  GPU Kernel Dispatched: false\n"),
            Some(false)
        );
    }

    #[test]
    fn test_dispatch_classification_marks_planner_decline() {
        let mut workload = mock_workload_result("native_only", 100_000, 10.0, 10.0);
        workload.plan_selected = false;
        workload.gpu_kernel_dispatched = false;
        workload.dispatch_counter_captured = true;
        workload.plan_snippet = Some("Aggregate\n  -> Seq Scan on public.bench\n".to_owned());

        let classification = workload.dispatch_classification();

        assert!(classification.planner_declined);
        assert!(!classification.plan_selected);
        assert!(!classification.gpu_kernel_dispatched);
        assert_eq!(
            classification.gpu_resident_pipeline,
            GpuResidentPipelineStatus::PlannerDeclined
        );
    }

    #[test]
    fn test_dispatch_classification_marks_custom_scan_no_dispatch() {
        let mut workload = mock_workload_result("plan_only", 100_000, 10.0, 10.0);
        workload.plan_selected = false;
        workload.gpu_kernel_dispatched = true;
        workload.dispatch_counter_captured = true;
        workload.gpu_kernel_execution_delta = 1;
        workload.accel_output_rows_consumed = 1;
        workload.plan_snippet = Some(
            "Custom Scan (GpuAccelAgg)\n  Strategy: GpuAgg\n  GPU Dispatched: false\n".to_owned(),
        );

        let classification = workload.dispatch_classification();

        assert!(classification.plan_selected);
        assert!(!classification.gpu_kernel_dispatched);
        assert!(classification.custom_scan_selected_not_dispatched);
        assert_eq!(
            classification.gpu_resident_pipeline,
            GpuResidentPipelineStatus::SelectedNotDispatched
        );
    }

    #[test]
    fn test_dispatch_classification_honors_json_gpu_dispatched_false() {
        let mut workload = mock_workload_result("json_plan_only", 100_000, 10.0, 10.0);
        workload.plan_selected = false;
        workload.dispatch_counter_captured = true;
        workload.gpu_kernel_execution_delta = 2;
        workload.accel_output_rows_consumed = 1;
        workload.plan_snippet =
            Some(r#"[{"Plan":{"Node Type":"Custom Scan","GPU Dispatched":false}}]"#.to_owned());

        let classification = workload.dispatch_classification();

        assert!(classification.plan_selected);
        assert!(!classification.gpu_kernel_dispatched);
        assert!(classification.custom_scan_selected_not_dispatched);
        assert_eq!(classification.function_kernel_count, 0);
    }

    #[test]
    fn test_full_plan_gpu_dispatched_false_overrides_counter_delta() {
        let mut workload = mock_workload_result("artifact_plan_only", 100_000, 10.0, 10.0);
        workload.plan_selected = false;
        workload.dispatch_counter_captured = true;
        workload.gpu_kernel_execution_delta = 2;
        workload.accel_output_rows_consumed = 1;
        workload.plan_snippet = Some("Custom Scan (GpuAccelAgg)\n".to_owned());
        let full_plan = "Custom Scan (GpuAccelAgg)\n  Strategy: GpuAgg\n  GPU Dispatched: false\n";

        let classification = workload.dispatch_classification_with_plan_artifact(Some(full_plan));

        assert!(classification.plan_selected);
        assert!(!classification.gpu_kernel_dispatched);
        assert!(classification.custom_scan_selected_not_dispatched);
    }

    #[test]
    fn dispatch_classification_requires_complete_counter_query_and_output_evidence() {
        let mut workload = mock_workload_result("generic_gpu_dispatch", 100_000, 10.0, 20.0);
        workload.plan_selected = true;
        workload.dispatch_counter_captured = true;
        workload.gpu_kernel_execution_delta = 1;
        workload.accel_output_rows_consumed = 10;
        workload.plan_snippet = Some("Custom Scan (GpuAccelAgg)".to_owned());
        assert!(workload.dispatch_classification().gpu_kernel_dispatched);

        workload.dispatch_counter_captured = false;
        workload.dispatch_counter_error = Some("warm counter arm failed".to_owned());
        assert!(
            !workload.dispatch_classification().gpu_kernel_dispatched,
            "an error marker and retained delta cannot replace complete capture"
        );

        workload.dispatch_counter_captured = true;
        workload.dispatch_counter_error = None;
        workload.pg_accel_queries_accelerated_delta = 9;
        assert!(
            !workload.dispatch_classification().gpu_kernel_dispatched,
            "every measured selected pair needs queries_accelerated proof"
        );

        workload.pg_accel_queries_accelerated_delta = 10;
        workload.accel_output_rows_consumed = 0;
        assert!(
            !workload.dispatch_classification().gpu_kernel_dispatched,
            "kernel launch without consumed output is not performance credit"
        );
    }

    #[test]
    fn unattributed_kernel_delta_is_not_function_or_custom_scan_credit() {
        let mut workload = mock_workload_result("generic_gpu_dispatch", 100_000, 10.0, 20.0);
        workload.plan_selected = false;
        workload.dispatch_counter_captured = true;
        workload.gpu_kernel_execution_delta = 1;
        workload.accel_output_rows_consumed = 10;
        workload.plan_snippet = Some("Seq Scan on bench".to_owned());
        let classification = workload.dispatch_classification();
        assert!(!classification.gpu_kernel_dispatched);
        assert!(!classification.function_srf_kernel_dispatched);
        assert!(classification.planner_declined);
    }

    #[test]
    fn test_dispatch_classification_counts_function_kernel_rows() {
        let mut workload =
            mock_workload_result("h3_function_dispatch_fixture", 100_000, 10.0, 50.0);
        workload.category = "gpu_h3".to_owned();
        workload.kernel_class = "h3_latlng".to_owned();
        workload.plan_selected = false;
        workload.gpu_kernel_dispatched = false;
        workload.dispatch_counter_captured = true;
        workload.gpu_kernel_execution_delta = 3;
        workload.accel_output_rows_consumed = 12;

        let classification = workload.dispatch_classification();

        assert!(classification.gpu_kernel_dispatched);
        assert!(classification.function_srf_kernel_dispatched);
        assert_eq!(classification.function_kernel_count, 3);
        assert_eq!(classification.rows_returned_to_cpu, 12);
        assert_eq!(
            classification.gpu_resident_pipeline,
            GpuResidentPipelineStatus::NotApplicableFunctionSrf
        );
    }

    #[test]
    fn test_dispatch_classification_marks_selected_strategy_not_resident_without_true_audit() {
        let mut workload = mock_workload_result("ssbm_q1", 1_000_000, 10.0, 50.0);
        workload.plan_selected = true;
        workload.dispatch_counter_captured = true;
        workload.gpu_kernel_execution_delta = 2;
        workload.pg_accel_rows_dispatched_delta = 1_000_000;
        workload.pg_accel_gpu_rows_processed_delta = 1_000_000;
        workload.accel_output_rows_consumed = 10;
        workload.plan_snippet = Some(
            "Custom Scan (GpuAccelPreAgg)\n  Strategy: GpuPreAgg\n  Fact Rows Scanned: 1000000\n"
                .to_owned(),
        );

        let classification = workload.dispatch_classification();

        assert!(classification.plan_selected);
        assert!(classification.gpu_kernel_dispatched);
        assert_eq!(
            classification.gpu_resident_pipeline,
            GpuResidentPipelineStatus::NotResident
        );
    }

    #[test]
    fn test_dispatch_classification_rejects_bare_gpu_resident_true_without_proof() {
        let mut workload = mock_workload_result("ssbm_q1", 1_000_000, 10.0, 50.0);
        workload.plan_selected = true;
        workload.dispatch_counter_captured = true;
        workload.gpu_kernel_execution_delta = 2;
        workload.accel_output_rows_consumed = 10;
        workload.plan_snippet = Some(
            "Custom Scan (GpuAccelPreAgg)\n  Strategy: GpuPreAgg\n  GPU Resident Pipeline: true\n"
                .to_owned(),
        );

        let classification = workload.dispatch_classification();

        assert_eq!(
            classification.gpu_resident_pipeline,
            GpuResidentPipelineStatus::NotResident
        );
    }

    #[test]
    fn test_dispatch_classification_honors_versioned_gpu_resident_proof() {
        let mut workload = mock_workload_result("ssbm_q1", 1_000_000, 10.0, 50.0);
        workload.plan_selected = true;
        workload.dispatch_counter_captured = true;
        workload.gpu_kernel_execution_delta = 2;
        workload.accel_output_rows_consumed = 10;
        workload.plan_snippet = Some(
            "Custom Scan (GpuAccelPreAgg)\n  Strategy: GpuPreAgg\n  \
             GPU Resident Pipeline: true\n  \
             GPU Resident Proof Version: 2\n  \
             GPU Resident Operator Class: resident_preagg\n  \
             GPU Resident Stage Mask: 33\n  \
             GPU Resident Device Columns: 4\n"
                .to_owned(),
        );

        let classification = workload.dispatch_classification();

        assert_eq!(
            classification.gpu_resident_pipeline,
            GpuResidentPipelineStatus::Reported
        );
    }

    #[test]
    fn test_json_gpu_resident_proof_metadata_is_parsed_structurally() {
        let plan = r#"[{"Plan":{"Node Type":"Custom Scan","GPU Resident Pipeline":true,"GPU Resident Proof Version":2,"GPU Resident Operator Class":"resident_preagg","GPU Resident Stage Mask":33,"GPU Resident Device Columns":4}}]"#;

        assert!(plan_contains_gpu_resident_pipeline_evidence(plan));
    }

    #[test]
    fn test_dispatch_classification_does_not_let_child_resident_proof_satisfy_parent() {
        let mut workload = mock_workload_result("nested_custom_scan", 1_000_000, 10.0, 50.0);
        workload.plan_selected = true;
        workload.dispatch_counter_captured = true;
        workload.gpu_kernel_execution_delta = 2;
        workload.accel_output_rows_consumed = 10;
        workload.plan_snippet = Some(
            "Custom Scan (GpuAccelAgg)\n  Strategy: GpuAgg\n  \
             GPU Resident Pipeline: false\n  \
             GPU Resident Boundary: GpuAgg drains heap or child tuples on CPU\n  \
             -> Custom Scan (GpuAccelScan)\n       Strategy: GpuScan\n       \
             GPU Resident Pipeline: true\n       GPU Resident Proof Version: 2\n       \
             GPU Resident Operator Class: resident_expression\n       \
             GPU Resident Stage Mask: 3\n       GPU Resident Device Columns: 2\n"
                .to_owned(),
        );

        let classification = workload.dispatch_classification();

        assert_eq!(
            classification.gpu_resident_pipeline,
            GpuResidentPipelineStatus::NotResident
        );
    }

    #[test]
    fn test_report_preserves_gpu_resident_boundary_reason() {
        let mut workload = mock_workload_result("gpu_reduce_sum", 100_000, 10.0, 50.0);
        workload.plan_selected = true;
        workload.dispatch_counter_captured = true;
        workload.gpu_kernel_execution_delta = 2;
        workload.accel_output_rows_consumed = 1;
        workload.plan_snippet = Some(
            "Custom Scan (GpuAccelAgg)\n  Strategy: GpuAgg\n  GPU Resident Pipeline: false\n  \
             GPU Resident Boundary: GpuAgg drains heap or child tuples on CPU and stages host input/key/value buffers before GPU reduce or grouped aggregation\n"
                .to_owned(),
        );
        let report = mock_report(vec![workload]);

        let json = report.to_json().expect("json");
        let markdown = report.to_markdown();

        assert!(json.contains("\"gpu_resident_pipeline\": \"not_resident\""));
        assert!(json.contains("\"gpu_resident_boundary_reason\""));
        assert!(markdown.contains(
            "GpuAgg drains heap or child tuples on CPU and stages host input/key/value buffers"
        ));
        assert!(markdown.contains("| Custom Scan rows with recorded CPU boundary | 1 |"));
    }

    #[test]
    fn native_output_filter_is_reported_without_reclassifying_device_aggregation() {
        let mut workload = mock_workload_result("grouped_int4_native_having", 1_000_000, 5.0, 20.0);
        workload.plan_selected = true;
        workload.dispatch_counter_captured = true;
        workload.gpu_kernel_execution_delta = 10;
        workload.accel_output_rows_consumed = 20;
        workload.plan_snippet = Some(
            "Custom Scan (GpuAccelAgg)\n  Strategy: GpuAgg\n  GPU Resident Pipeline: true\n  \
             GPU Resident Proof Version: 2\n  GPU Resident Operator Class: resident_groupagg\n  \
             GPU Resident Stage Mask: 16393\n  GPU Resident Device Columns: 2\n  \
             GPU Resident Boundary: none: no CPU boundary\n  \
             GPU Post-Aggregate Filter: PostgreSQL HAVING\n"
                .to_owned(),
        );
        let original = mock_report(vec![workload]);
        let report = original.with_normalized_dispatch();
        assert_eq!(
            report.workloads[0].gpu_resident_pipeline,
            GpuResidentPipelineStatus::Reported
        );
        assert_eq!(
            report.workloads[0].native_post_aggregate_filter.as_deref(),
            Some("PostgreSQL HAVING")
        );
        assert!(
            report
                .to_json()
                .expect("JSON")
                .contains("\"native_post_aggregate_filter\": \"PostgreSQL HAVING\"")
        );
        let markdown = original.to_markdown();
        assert!(markdown.contains("| Custom Scan rows with native post-aggregate filtering | 1 |"));
        assert!(markdown.contains("CPU evaluation is included in query timings"));
    }

    #[test]
    fn test_report_preserves_boundary_reason_for_selected_not_dispatched_rows() {
        let mut workload = mock_workload_result("plan_only", 100_000, 10.0, 10.0);
        workload.plan_selected = false;
        workload.dispatch_counter_captured = true;
        workload.gpu_kernel_execution_delta = 1;
        workload.accel_output_rows_consumed = 1;
        workload.plan_snippet = Some(
            "Custom Scan (GpuAccelAgg)\n  Strategy: GpuAgg\n  GPU Dispatched: false\n  \
             GPU Resident Pipeline: false\n  \
             GPU Resident Boundary: GpuAgg drains heap or child tuples on CPU and stages host input/key/value buffers before GPU reduce or grouped aggregation\n"
                .to_owned(),
        );
        let report = mock_report(vec![workload]);

        let json = report.to_json().expect("json");
        let markdown = report.to_markdown();

        assert!(json.contains("\"gpu_resident_pipeline\": \"selected_not_dispatched\""));
        assert!(json.contains("\"gpu_resident_boundary_reason\""));
        assert!(markdown.contains("custom_scan_selected_not_dispatched"));
        assert!(markdown.contains(
            "GpuAgg drains heap or child tuples on CPU and stages host input/key/value buffers"
        ));
    }

    #[test]
    fn test_resident_boundary_audit_flags_selected_custom_scan_boundary() {
        let mut workload = mock_workload_result("generic_gpu_dispatch", 100_000, 10.0, 20.0);
        workload.plan_selected = true;
        workload.dispatch_counter_captured = true;
        workload.gpu_kernel_execution_delta = 1;
        workload.accel_output_rows_consumed = 10;
        workload.pg_accel_stock_exec_delta = 0;
        workload.plan_snippet = Some(
            "Custom Scan (GpuAccelAgg)\n  Strategy: GpuAgg\n  GPU Dispatched: true\n".to_owned(),
        );
        let audit = mock_report(vec![workload]).resident_boundary_audit();

        assert_eq!(audit.schema_version, RESIDENT_BOUNDARY_AUDIT_SCHEMA_VERSION);
        assert_eq!(audit.selected_custom_scan_rows, 1);
        assert_eq!(audit.passed_rows, 0);
        assert_eq!(audit.failed_rows, 1);
        assert!(audit.has_failures());
        assert_eq!(
            audit.rows[0].status,
            ResidentBoundaryAuditStatus::NonResidentPipeline
        );
        assert_eq!(audit.rows[0].gpu_resident_pipeline, "not_resident");
        assert!(
            audit.rows[0]
                .boundary_reason
                .as_deref()
                .is_some_and(|reason| reason.starts_with("GpuAgg drains heap or child tuples"))
        );
    }

    #[test]
    fn test_resident_boundary_audit_flags_selected_custom_scan_missing_evidence() {
        let mut workload = mock_workload_result("generic_gpu_dispatch", 100_000, 10.0, 20.0);
        workload.plan_selected = true;
        workload.dispatch_counter_captured = true;
        workload.gpu_kernel_execution_delta = 1;
        workload.accel_output_rows_consumed = 10;
        workload.pg_accel_stock_exec_delta = 0;
        workload.plan_snippet =
            Some("Custom Scan (GpuAccelMystery)\n  GPU Dispatched: true\n".to_owned());
        let audit = mock_report(vec![workload]).resident_boundary_audit();

        assert_eq!(audit.selected_custom_scan_rows, 1);
        assert_eq!(audit.passed_rows, 0);
        assert_eq!(audit.failed_rows, 1);
        assert!(audit.has_failures());
        assert_eq!(
            audit.rows[0].status,
            ResidentBoundaryAuditStatus::MissingResidentPipelineEvidence
        );
        assert_eq!(audit.rows[0].gpu_resident_pipeline, "not_reported");
        assert!(audit.rows[0].boundary_reason.is_none());
        assert!(
            audit
                .to_markdown()
                .contains("missing_resident_pipeline_evidence")
        );
    }

    #[test]
    fn resident_boundary_audit_accepts_lifecycle_produced_artifact_reuse() {
        let audit =
            mock_report(vec![valid_derived_output_artifact_reuse()]).resident_boundary_audit();

        assert_eq!(audit.selected_custom_scan_rows, 1);
        assert_eq!(audit.passed_rows, 1);
        assert_eq!(audit.failed_rows, 0);
        assert!(!audit.has_failures());
        assert_eq!(
            audit.rows[0].status,
            ResidentBoundaryAuditStatus::LifecycleProducedArtifactReuse
        );
        assert!(audit.rows[0].gpu_kernel_dispatched);
        assert_eq!(audit.rows[0].gpu_resident_pipeline, "reported");
        assert!(audit.rows[0].boundary_reason.is_none());
        assert!(
            audit
                .to_markdown()
                .contains("lifecycle_produced_artifact_reuse")
        );
    }

    #[test]
    fn resident_boundary_audit_rejects_unbuilt_artifact_reuse() {
        let mut workload = valid_derived_output_artifact_reuse();
        workload
            .artifact_lifecycle_probe
            .as_mut()
            .expect("valid probe")
            .gpu_kernel_executions = 0;
        let audit = mock_report(vec![workload]).resident_boundary_audit();

        assert_eq!(audit.passed_rows, 0);
        assert_eq!(audit.failed_rows, 1);
        assert!(audit.has_failures());
        assert_ne!(
            audit.rows[0].status,
            ResidentBoundaryAuditStatus::LifecycleProducedArtifactReuse
        );
    }

    #[test]
    fn test_resident_boundary_audit_ignores_function_srf_dispatch_rows() {
        let mut workload =
            mock_workload_result("h3_function_dispatch_fixture", 100_000, 10.0, 50.0);
        workload.category = "gpu_h3".to_owned();
        workload.kernel_class = "h3_latlng".to_owned();
        workload.plan_selected = false;
        workload.dispatch_counter_captured = true;
        workload.gpu_kernel_execution_delta = 1;
        workload.accel_output_rows_consumed = 10;
        let audit = mock_report(vec![workload]).resident_boundary_audit();

        assert_eq!(audit.selected_custom_scan_rows, 0);
        assert_eq!(audit.ignored_non_custom_scan_rows, 1);
        assert!(audit.rows.is_empty());
    }

    #[test]
    fn test_gpu_resident_false_does_not_count_as_positive_evidence() {
        let plan =
            "Custom Scan (GpuAccelAgg)\n  Strategy: GpuAgg\n  GPU Resident Pipeline: false\n";

        assert!(!plan_contains_gpu_resident_pipeline_evidence(plan));
        assert_eq!(plan_gpu_resident_pipeline_value(plan), Some(false));
        assert_eq!(
            infer_gpu_resident_boundary_reason_from_plan(plan).as_deref(),
            Some(
                "GpuAgg drains heap or child tuples on CPU and stages host input/key/value buffers before GPU reduce or grouped aggregation"
            )
        );
    }

    #[test]
    fn test_boundary_reason_strategy_map_covers_explain_labels() {
        let expected = [
            (
                "GpuScan",
                "GpuScan consumes heap or child tuples on CPU via table_scan_getnextslot/ExecProcNode/MinimalTuple staging and emits PostgreSQL slots",
            ),
            (
                "GpuJoin",
                "GpuJoin collects child rows through ExecProcNode into host MinimalTuple/key buffers and reconstructs joined PostgreSQL slots",
            ),
            (
                "GpuAgg",
                "GpuAgg drains heap or child tuples on CPU and stages host input/key/value buffers before GPU reduce or grouped aggregation",
            ),
            (
                "GpuSort",
                "GpuSort is a retired wire identity; standalone sort must stay PostgreSQL-native because no sort kernel/executor is registered",
            ),
            (
                "GpuWindow",
                "GpuWindow is a retired wire identity; standalone window must stay PostgreSQL-native because no window kernel/executor is registered",
            ),
            (
                "GpuPreAgg",
                "GpuPreAgg materializes dimensions in host HashMap state and scans/probes fact rows through ExecProcNode/materialized slots",
            ),
            (
                "GpuFunctionScan",
                "GpuFunctionScan dispatches constant arguments once, buffers host Datums, and drains output through PostgreSQL slots",
            ),
            (
                "GpuAccelSrfTargetList",
                "GpuAccelSrfTargetList drives ProjectSet input through ExecProcNode, buffers per-row SRF output, and emits expanded PostgreSQL tuples",
            ),
        ];

        for (strategy, reason) in expected {
            assert_eq!(
                gpu_resident_boundary_reason_for_strategy(strategy),
                Some(reason)
            );
            assert!(
                reason.contains("CPU")
                    || reason.contains("ExecProcNode")
                    || reason.contains("host")
                    || reason.contains("PostgreSQL-native")
                    || reason.contains("PostgreSQL slots")
                    || reason.contains("PostgreSQL tuples"),
                "{strategy} boundary reason must identify the CPU/PostgreSQL boundary: {reason}"
            );
        }
        assert_eq!(
            gpu_resident_boundary_reason_for_strategy("GpuUnknown"),
            None
        );
    }

    #[test]
    #[allow(clippy::expect_used)]
    fn test_json_roundtrip() {
        let report = mock_report(vec![mock_workload_result("json_wl", 100_000, 8.0, 16.0)]);
        let json_str = report.to_json().expect("serialization should succeed");
        let deserialized: BenchReport =
            serde_json::from_str(&json_str).expect("deserialization should succeed");
        assert_eq!(deserialized.workloads.len(), 1);
        assert_eq!(deserialized.workloads[0].rows, 100_000);
        assert!(
            (deserialized.workloads[0].accel_mean_ms - report.workloads[0].accel_mean_ms).abs()
                < f64::EPSILON
        );
        assert_eq!(
            deserialized.workloads[0].accel_ci_95,
            report.workloads[0].accel_ci_95
        );
    }

    #[test]
    #[allow(clippy::expect_used)]
    fn test_single_iteration_json_roundtrip_preserves_undefined_statistics() {
        let workload = WorkloadResult::from_iterations(
            "single_iteration".to_owned(),
            "single iteration report round-trip".to_owned(),
            "regression".to_owned(),
            classify_kernel("unclassified"),
            1_000,
            vec![IterationResult {
                accel_ms: 5.0,
                parallel_ms: 10.0,
                accel_first: false,
                cache_purge: CachePurgeState::NotRequested,
                cache_state: CacheState::Warm,
            }],
            false,
        );
        let json = mock_report(vec![workload])
            .to_json()
            .expect("single-iteration report should serialize");
        let value: serde_json::Value =
            serde_json::from_str(&json).expect("serialized report should be JSON");

        assert_eq!(
            value["workloads"][0]["accel_ci_95"],
            serde_json::json!([null, null])
        );
        assert!(value["workloads"][0]["p_value_vs_parallel"].is_null());
        assert!(value["workloads"][0]["cohens_d_vs_parallel"].is_null());
        assert!(value["workloads"][0]["cv_ratio"].is_null());
        assert_eq!(
            value["workloads"][0]["warm_summary"]["parallel_ci_95"],
            serde_json::json!([null, null])
        );

        let decoded: BenchReport =
            serde_json::from_str(&json).expect("null statistics should deserialize");
        let decoded_workload = &decoded.workloads[0];
        assert!(decoded_workload.accel_ci_95.0.is_nan());
        assert!(decoded_workload.accel_ci_95.1.is_nan());
        assert!(decoded_workload.p_value_vs_parallel.is_nan());
        assert!(decoded_workload.cohens_d_vs_parallel.is_nan());
        assert!(decoded_workload.cv_ratio.is_nan());
        let warm = decoded_workload
            .warm_summary
            .expect("warm summary should survive the round-trip");
        assert!(warm.parallel_ci_95.0.is_nan());
        assert!(warm.parallel_ci_95.1.is_nan());
        assert!((decoded_workload.accel_mean_ms - 5.0).abs() < f64::EPSILON);
        assert!((decoded_workload.speedup_vs_parallel - 2.0).abs() < f64::EPSILON);
    }

    #[test]
    #[allow(clippy::expect_used)]
    fn test_producer_nullable_statistics_accept_json_null() {
        const WORKLOAD_SCALAR_STATS: &[&str] =
            &["p_value_vs_parallel", "cohens_d_vs_parallel", "cv_ratio"];
        const CACHE_SCALAR_STATS: &[&str] = &["p_value_vs_parallel", "cohens_d_vs_parallel"];
        const PAIR_STATS: &[&str] = &["accel_ci_95", "parallel_ci_95"];

        fn replace_stats_with_null(
            object: &mut serde_json::Map<String, serde_json::Value>,
            scalar_fields: &[&str],
            pair_fields: &[&str],
        ) {
            for field in scalar_fields {
                object.insert((*field).to_owned(), serde_json::Value::Null);
            }
            for field in pair_fields {
                object.insert((*field).to_owned(), serde_json::json!([null, null]));
            }
        }

        fn assert_stats_are_null(
            object: &serde_json::Map<String, serde_json::Value>,
            scalar_fields: &[&str],
            pair_fields: &[&str],
        ) {
            for field in scalar_fields {
                assert!(
                    object[*field].is_null(),
                    "{field} did not round-trip as null"
                );
            }
            for field in pair_fields {
                assert_eq!(
                    object[*field],
                    serde_json::json!([null, null]),
                    "{field} did not round-trip as a null pair"
                );
            }
        }

        let report = mock_report(vec![mock_workload_result("all_stats", 100_000, 8.0, 16.0)]);
        let mut value = serde_json::to_value(report).expect("report should serialize");
        let workload = value["workloads"][0]
            .as_object_mut()
            .expect("workload should be an object");
        replace_stats_with_null(workload, WORKLOAD_SCALAR_STATS, PAIR_STATS);
        let warm = workload["warm_summary"]
            .as_object_mut()
            .expect("warm summary should be an object");
        replace_stats_with_null(warm, CACHE_SCALAR_STATS, PAIR_STATS);

        let decoded: BenchReport =
            serde_json::from_value(value).expect("producer-nullable statistics should deserialize");
        let encoded = serde_json::to_value(decoded).expect("decoded report should serialize");
        let encoded_workload = encoded["workloads"][0]
            .as_object()
            .expect("encoded workload should be an object");
        assert_stats_are_null(encoded_workload, WORKLOAD_SCALAR_STATS, PAIR_STATS);
        let encoded_warm = encoded_workload["warm_summary"]
            .as_object()
            .expect("encoded warm summary should be an object");
        assert_stats_are_null(encoded_warm, CACHE_SCALAR_STATS, PAIR_STATS);
    }

    #[test]
    #[allow(clippy::expect_used)]
    fn test_ordinary_statistics_and_whole_null_ci_pairs_remain_strict() {
        const WORKLOAD_SCALAR_STATS: &[&str] = &[
            "accel_mean_ms",
            "accel_stddev_ms",
            "accel_median_ms",
            "accel_p25_ms",
            "accel_p75_ms",
            "accel_p95_ms",
            "accel_cv_pct",
            "accel_min_ms",
            "accel_max_ms",
            "parallel_mean_ms",
            "parallel_stddev_ms",
            "parallel_median_ms",
            "parallel_p25_ms",
            "parallel_p75_ms",
            "parallel_p95_ms",
            "parallel_cv_pct",
            "parallel_min_ms",
            "parallel_max_ms",
            "speedup_vs_parallel",
            "speedup_median_vs_parallel",
        ];
        const CACHE_SCALAR_STATS: &[&str] = &[
            "accel_mean_ms",
            "accel_median_ms",
            "accel_stddev_ms",
            "accel_p95_ms",
            "accel_cv_pct",
            "parallel_mean_ms",
            "parallel_median_ms",
            "parallel_stddev_ms",
            "parallel_p95_ms",
            "parallel_cv_pct",
            "speedup_mean_vs_parallel",
            "speedup_median_vs_parallel",
        ];
        const PAIR_STATS: &[&str] = &["accel_ci_95", "parallel_ci_95"];

        let make_value = || {
            serde_json::to_value(mock_report(vec![mock_workload_result(
                "strict_stats",
                100_000,
                8.0,
                16.0,
            )]))
            .expect("report should serialize")
        };

        for field in WORKLOAD_SCALAR_STATS {
            let mut value = make_value();
            value["workloads"][0][*field] = serde_json::Value::Null;
            let error = serde_json::from_value::<BenchReport>(value)
                .expect_err("ordinary workload statistic must reject null")
                .to_string();
            assert!(
                error.contains("invalid type: null"),
                "{field} failed for an unexpected reason: {error}"
            );
        }
        for field in CACHE_SCALAR_STATS {
            let mut value = make_value();
            value["workloads"][0]["warm_summary"][*field] = serde_json::Value::Null;
            let error = serde_json::from_value::<BenchReport>(value)
                .expect_err("ordinary cache statistic must reject null")
                .to_string();
            assert!(
                error.contains("invalid type: null"),
                "{field} failed for an unexpected reason: {error}"
            );
        }
        for field in PAIR_STATS {
            let mut workload_value = make_value();
            workload_value["workloads"][0][*field] = serde_json::Value::Null;
            let workload_error = serde_json::from_value::<BenchReport>(workload_value)
                .expect_err("whole-null workload CI must fail")
                .to_string();
            assert!(workload_error.contains("invalid type: null"));

            let mut cache_value = make_value();
            cache_value["workloads"][0]["warm_summary"][*field] = serde_json::Value::Null;
            let cache_error = serde_json::from_value::<BenchReport>(cache_value)
                .expect_err("whole-null cache CI must fail")
                .to_string();
            assert!(cache_error.contains("invalid type: null"));

            for mixed_pair in [
                serde_json::json!([null, 5.0]),
                serde_json::json!([5.0, null]),
            ] {
                let mut workload_value = make_value();
                workload_value["workloads"][0][*field] = mixed_pair.clone();
                let workload_error = serde_json::from_value::<BenchReport>(workload_value)
                    .expect_err("mixed-null workload CI must fail")
                    .to_string();
                assert!(
                    workload_error.contains("endpoints must both be numbers or both be null"),
                    "{field} accepted malformed workload interval: {workload_error}"
                );

                let mut cache_value = make_value();
                cache_value["workloads"][0]["warm_summary"][*field] = mixed_pair;
                let cache_error = serde_json::from_value::<BenchReport>(cache_value)
                    .expect_err("mixed-null cache CI must fail")
                    .to_string();
                assert!(
                    cache_error.contains("endpoints must both be numbers or both be null"),
                    "{field} accepted malformed cache interval: {cache_error}"
                );
            }
        }
    }

    #[test]
    #[allow(clippy::expect_used)]
    fn test_json_contains_all_fields() {
        let report = mock_report(vec![mock_workload_result("fields", 100_000, 10.0, 20.0)]);
        let json_str = report.to_json().expect("serialization should succeed");
        assert!(json_str.contains("\"rows\""));
        assert!(json_str.contains("\"accel_mean_ms\""));
        assert!(json_str.contains("\"parallel_mean_ms\""));
        assert!(json_str.contains("\"row_scales\""));
        assert!(json_str.contains("\"planner_declined\""));
        assert!(json_str.contains("\"function_kernel_count\""));
        assert!(json_str.contains("\"rows_returned_to_cpu\""));
        assert!(json_str.contains("\"gpu_resident_pipeline\""));
        assert!(json_str.contains("\"correctness_diff_artifact\""));
        // Must NOT contain single-threaded fields
        assert!(!json_str.contains("\"single_mean_ms\""));
    }

    #[test]
    fn test_benchmark_failure_ledger_merges_gate_and_parity_sources() {
        let mut workload = mock_workload_result("filtered_grouped_agg", 10_000, 1.48, 0.56);
        workload.category = "mixed".to_owned();
        workload.kernel_class = "hash_agg".to_owned();
        workload.dispatch_counter_captured = true;
        workload.gpu_kernel_execution_delta = 10;
        workload.accel_output_rows_consumed = 51;
        workload.rows_returned_to_cpu = 51;
        workload.gpu_resident_pipeline = GpuResidentPipelineStatus::Reported;
        workload.plan_snippet = Some(
            "Custom Scan (pg_accel)\n\
             GPU Resident Operator Class: resident_groupagg\n\
             GPU Resident GroupAgg Key: dept\n\
             GPU Resident GroupAgg Measure: salary\n\
             GPU Resident GroupAgg Filter: active\n\
             GPU Resident GroupAgg Predicate Guard: boolean_filter\n\
             GPU Resident GroupAgg Value Predicate: aggregate_filter\n\
             GPU Resident GroupAgg Predicate IR: filter(active)\n\
             GPU Resident GroupAgg Aggregate Mask: 7\n"
                .to_owned(),
        );
        let report = mock_report(vec![workload]);

        let ledger = report.benchmark_failure_ledger();

        assert_eq!(
            ledger.schema_version,
            BENCHMARK_FAILURE_LEDGER_SCHEMA_VERSION
        );
        assert_eq!(ledger.rows_below_parity_count, 1);
        assert_eq!(ledger.gpu_dispatched_below_parity_count, 1);
        assert_eq!(ledger.unique_work_items, 1);
        let row = &ledger.rows[0];
        assert_eq!(row.workload, "filtered_grouped_agg");
        assert_eq!(row.priority, "p1_release_blocker");
        assert_eq!(row.next_track, "resident_groupagg_small_input_overhead");
        assert!(row.sources.contains(&"benchmark_ship_gate".to_owned()));
        assert!(
            row.sources
                .contains(&"gpu_dispatched_below_parity".to_owned())
        );
        assert!(row.details.iter().any(|detail| {
            detail.contains("expected_winner_below_threshold")
                || detail.contains("credited GPU dispatch below PG-parallel parity")
        }));
        assert!(ledger.to_markdown().contains("Benchmark Failure Ledger"));
    }

    #[test]
    fn test_benchmark_failure_ledger_includes_h3_and_stock_fallback_sources() {
        let h3 = mock_h3_native_decline(
            "h3_cell_to_parent",
            1_000_000,
            "h3_parent_grouped_count_unexpected_native_decline",
        );
        let mut stock = mock_workload_result("stock_fallback_probe", 100_000, 10.0, 20.0);
        stock.pg_accel_stock_exec_delta = 3;
        let ledger = mock_report(vec![h3, stock]).benchmark_failure_ledger();

        let h3_row = ledger
            .rows
            .iter()
            .find(|row| row.workload == "h3_cell_to_parent")
            .expect("H3 gate failure must enter the ledger");
        assert!(h3_row.sources.contains(&"h3_lane_gate".to_owned()));
        assert_eq!(h3_row.next_track, "h3_cache_evidence_and_lane_policy");

        let stock_row = ledger
            .rows
            .iter()
            .find(|row| row.workload == "stock_fallback_probe")
            .expect("stock fallback must enter the ledger");
        assert!(
            stock_row
                .sources
                .contains(&"stock_executor_fallback".to_owned())
        );
        assert!(
            stock_row
                .details
                .iter()
                .any(|detail| detail.contains("fallback count was 3"))
        );
    }

    #[test]
    fn test_failure_labels_and_ledger_helper_edge_classes() {
        let expected_labels = [
            (BenchmarkShipGateFailureKind::Crash, "crash"),
            (
                BenchmarkShipGateFailureKind::SelectedPlanMissedDispatch,
                "selected_plan_missed_dispatch",
            ),
            (
                BenchmarkShipGateFailureKind::SelectedPlanNotGpuResident,
                "selected_plan_not_gpu_resident",
            ),
            (
                BenchmarkShipGateFailureKind::DispatchedBelowParity,
                "dispatched_below_parity",
            ),
            (
                BenchmarkShipGateFailureKind::ExpectedWinnerMissedSelection,
                "expected_winner_missed_selection",
            ),
            (
                BenchmarkShipGateFailureKind::ExpectedWinnerMissingEvidence,
                "expected_winner_missing_evidence",
            ),
            (
                BenchmarkShipGateFailureKind::ExpectedWinnerBelowThreshold,
                "expected_winner_below_threshold",
            ),
            (
                BenchmarkShipGateFailureKind::ExpectedWinnerMissingGroupAggLogicalSpec,
                "expected_winner_missing_groupagg_logical_spec",
            ),
            (
                BenchmarkShipGateFailureKind::ExpectedWinnerPhysicalKernelModeUnverified,
                "expected_winner_physical_kernel_mode_unverified",
            ),
            (
                BenchmarkShipGateFailureKind::ExpectedWinnerMissingCacheEvidence,
                "expected_winner_missing_cache_evidence",
            ),
            (
                BenchmarkShipGateFailureKind::ResidentLifecycleEvidenceMissing,
                "resident_lifecycle_evidence_missing",
            ),
            (
                BenchmarkShipGateFailureKind::NativeDeclineUnexpectedDispatch,
                "native_decline_unexpected_dispatch",
            ),
            (
                BenchmarkShipGateFailureKind::NativeDeclineDispatchCounterUnavailable,
                "native_decline_dispatch_counter_unavailable",
            ),
            (
                BenchmarkShipGateFailureKind::NativeDeclineReasonMissing,
                "native_decline_reason_missing",
            ),
        ];
        for (kind, expected) in expected_labels {
            assert_eq!(kind.label(), expected);
        }

        let empty_crash = CrashedScale {
            workload: "empty_crash".to_owned(),
            rows: 1,
            error: "failed".to_owned(),
            repro_command: None,
            plan_snippet_artifact: None,
            correctness_diff_artifact: None,
            log_tail_artifacts: Vec::new(),
        };
        assert_eq!(
            crash_ledger_detail(&empty_crash),
            "crash inventory has no attached artifacts"
        );

        let mut workload = mock_workload_result("classification", 1, 1.0, 1.0);
        workload.gpu_kernel_dispatched = false;
        workload.function_srf_kernel_dispatched = false;
        workload.custom_scan_selected_not_dispatched = false;
        workload.planner_declined = false;
        workload.plan_selected = false;
        assert_eq!(ledger_classification(&workload), "native_or_unclassified");
        workload.plan_selected = true;
        assert_eq!(
            ledger_classification(&workload),
            "custom_scan_selected_without_gpu_credit"
        );
        workload.plan_selected = false;
        workload.planner_declined = true;
        assert_eq!(ledger_classification(&workload), "planner_declined_native");
        workload.planner_declined = false;
        workload.gpu_kernel_dispatched = true;
        workload.function_srf_kernel_dispatched = true;
        assert_eq!(
            ledger_classification(&workload),
            "function_srf_gpu_dispatch"
        );
        assert_eq!(ledger_priority_rank("future_priority"), 3);

        let mut rows = BTreeMap::new();
        for (source, priority, track) in [
            ("parity", "p3_parity_noise", "parity_track"),
            ("gate", "p1_release_blocker", "gate_track"),
        ] {
            merge_ledger_item(
                &mut rows,
                LedgerMergeItem {
                    workload: None,
                    workload_name: "priority_probe",
                    row_count: 1,
                    source,
                    priority,
                    next_track: track,
                    speedup: None,
                    gate_floor: None,
                    detail: source.to_owned(),
                },
            );
        }
        let merged = rows
            .get(&("priority_probe".to_owned(), 1))
            .expect("priority probe must be merged");
        assert_eq!(merged.priority, "p1_release_blocker");
        assert_eq!(merged.next_track, "gate_track");
    }

    #[test]
    fn test_benchmark_failure_ledger_preserves_crash_inventory_artifacts() {
        let mut report = mock_report(Vec::new());
        report.crashes.push(CrashedScale {
            workload: "gpu_hashjoin_large_build".to_owned(),
            rows: 100_000,
            error: "backend disconnected".to_owned(),
            repro_command: Some(
                "cargo run -p pg_accel_bench -- crash-repro --workload gpu_hashjoin_large_build \
                 --rows 100000"
                    .to_owned(),
            ),
            plan_snippet_artifact: Some(
                "plan_snippets/gpu_hashjoin_large_build-100000.txt".to_owned(),
            ),
            correctness_diff_artifact: Some(
                "correctness_diffs/gpu_hashjoin_large_build-100000.json".to_owned(),
            ),
            log_tail_artifacts: vec![
                "log_tails/postgres-gpu_hashjoin_large_build-100000.log".to_owned(),
            ],
        });

        let ledger = report.benchmark_failure_ledger();

        assert_eq!(ledger.crash_count, 1);
        assert_eq!(ledger.ship_gate_failure_count, 1);
        assert_eq!(ledger.unique_work_items, 1);
        let row = &ledger.rows[0];
        assert_eq!(row.classification, "crash_or_missing_result");
        assert!(row.sources.contains(&"benchmark_ship_gate".to_owned()));
        assert!(row.sources.contains(&"crash_inventory".to_owned()));
        assert_eq!(
            row.plan_snippet_artifact.as_deref(),
            Some("plan_snippets/gpu_hashjoin_large_build-100000.txt")
        );
        assert_eq!(
            row.correctness_diff_artifact.as_deref(),
            Some("correctness_diffs/gpu_hashjoin_large_build-100000.json")
        );
        assert_eq!(
            row.log_tail_artifacts,
            vec!["log_tails/postgres-gpu_hashjoin_large_build-100000.log".to_owned()]
        );
        assert!(
            row.repro_command
                .as_deref()
                .is_some_and(|cmd| cmd.contains("crash-repro"))
        );
        let md = ledger.to_markdown();
        assert!(md.contains("Crash artifacts"));
        assert!(md.contains("plan_snippets/gpu_hashjoin_large_build-100000.txt"));
        assert!(md.contains("correctness_diffs/gpu_hashjoin_large_build-100000.json"));
        assert!(md.contains("log_tails/postgres-gpu_hashjoin_large_build-100000.log"));
        assert!(md.contains("crash-repro"));
    }

    #[test]
    fn test_csv_header_row() {
        let report = mock_report(vec![mock_workload_result("csv_wl", 100_000, 10.0, 20.0)]);
        let csv = report.to_csv();
        let lines: Vec<&str> = csv.lines().collect();
        assert!(
            lines[0]
                .starts_with("workload,category,kernel_class,plan_selected,gpu_kernel_dispatched,")
        );
        assert!(lines[0].contains("no_dispatch_timing_skew"));
        assert!(lines[0].contains("planner_declined"));
        assert!(lines[0].contains("function_kernel_count"));
        assert!(lines[0].contains("rows_returned_to_cpu"));
        assert!(lines[0].contains("gpu_resident_pipeline"));
        assert!(lines[0].contains("correctness_diff_artifact"));
        assert!(lines[0].contains("sanity_check_count"));
        assert!(lines[0].contains("sanity_check_failed"));
        assert!(lines[0].contains("accel_mean_ms"));
    }

    #[test]
    fn test_csv_includes_rows() {
        let report = mock_report(vec![
            mock_workload_result("wl", 1_000, 5.0, 10.0),
            mock_workload_result("wl", 1_000_000, 5.0, 10.0),
        ]);
        let csv = report.to_csv();
        let lines: Vec<&str> = csv.lines().collect();
        assert_eq!(lines.len(), 3); // header + 2 data rows
        assert!(lines[1].contains(",1000,"));
        assert!(lines[2].contains(",1000000,"));
    }

    #[test]
    fn test_csv_column_count_matches_header() {
        let report = mock_report(vec![mock_workload_result("col_test", 100_000, 10.0, 20.0)]);
        let csv = report.to_csv();
        let lines: Vec<&str> = csv.lines().collect();
        let header_cols = lines[0].split(',').count();
        let data_cols = lines[1].split(',').count();
        assert_eq!(header_cols, data_cols);
    }

    #[test]
    fn test_correctness_diff_artifact_renders_in_reports() {
        let mut workload = mock_workload_result("diff_artifact", 100_000, 10.0, 20.0);
        workload.correctness_diff_artifact =
            Some("correctness_diffs/diff-artifact-100000.json".to_owned());
        let report = mock_report(vec![workload]);

        let json = report.to_json().expect("json");
        let csv = report.to_csv();
        let markdown = report.to_markdown();

        assert!(json.contains("correctness_diffs/diff-artifact-100000.json"));
        assert!(csv.contains("correctness_diffs/diff-artifact-100000.json"));
        assert!(markdown.contains("correctness_diffs/diff-artifact-100000.json"));
    }

    #[test]
    fn test_generate_report_no_connection() {
        let workloads = vec![
            mock_workload_result("gen_test", 1_000, 10.0, 20.0),
            mock_workload_result("gen_test", 1_000_000, 10.0, 20.0),
        ];
        let report = generate_report(
            workloads,
            Vec::new(),
            None,
            30,
            5,
            None,
            crate::runner::TimingMode::RawWallClock,
            crate::runner::CacheMode::Warm,
        );
        assert!(report.hardware.is_some());
        assert!(report.gucs.is_none());
        assert_eq!(report.methodology.row_scales, vec![1_000, 1_000_000]);
        assert_eq!(report.workloads.len(), 2);
    }

    #[test]
    fn test_generate_report_uses_observed_gucs_and_all_mode_labels() {
        let observed = crate::config::ObservedGucs {
            settings: vec![("work_mem".to_owned(), "64MB".to_owned())],
            postmaster_start_time: Some("2026-08-11 12:34:56Z".to_owned()),
        };
        let explain_cold = generate_report(
            Vec::new(),
            Vec::new(),
            None,
            1,
            0,
            Some(observed.clone()),
            crate::runner::TimingMode::ExplainAnalyze,
            crate::runner::CacheMode::Cold,
        );
        assert_eq!(
            explain_cold.gucs.as_ref().expect("observed GUCs").settings,
            observed.settings
        );
        assert_eq!(explain_cold.methodology.timing_mode, "explain-analyze");
        assert_eq!(explain_cold.methodology.cache_mode, "cold");
        assert_eq!(
            explain_cold.postmaster_start_time.as_deref(),
            Some("2026-08-11 12:34:56Z")
        );

        let both = generate_report(
            Vec::new(),
            Vec::new(),
            None,
            1,
            0,
            Some(observed),
            crate::runner::TimingMode::Both,
            crate::runner::CacheMode::Both,
        );
        assert_eq!(both.methodology.timing_mode, "both");
        assert_eq!(both.methodology.cache_mode, "both");
    }

    #[test]
    fn test_format_rows() {
        assert_eq!(format_rows(1_000), "1K");
        assert_eq!(format_rows(10_000), "10K");
        assert_eq!(format_rows(100_000), "100K");
        assert_eq!(format_rows(1_000_000), "1M");
    }
}
