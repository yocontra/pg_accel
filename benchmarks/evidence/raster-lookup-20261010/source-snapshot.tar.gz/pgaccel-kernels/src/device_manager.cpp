#include <sycl/sycl.hpp>

#include <signal.h>
#include <unistd.h>

#include <algorithm>
#include <atomic>
#include <cctype>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <limits>
#include <memory>
#include <stdexcept>
#include <string>

#include "pgaccel_ffi.h"
#include "pgaccel_queue.h"

// ---------------------------------------------------------------------------
// GPU execution observability — thread-local counter
// ---------------------------------------------------------------------------

static thread_local uint64_t tl_gpu_exec_count = 0;

namespace {
constexpr size_t kLastErrorCapacity = 2048;
thread_local char tl_last_error[kLastErrorCapacity] = {};
}  // namespace

extern "C" void pgaccel_clear_last_error(void) {
  tl_last_error[0] = 0;
}

extern "C" size_t pgaccel_copy_last_error(char* buffer, size_t capacity) {
  const size_t length = std::strlen(tl_last_error);
  if (buffer == nullptr || capacity == 0)
    return length;
  const size_t copied = std::min(length, capacity - 1);
  std::memcpy(buffer, tl_last_error, copied);
  buffer[copied] = 0;
  return length;
}

void pgaccel_set_last_error(const char* entry_point, const std::exception* e) noexcept {
  const char* safe_entry_point = entry_point != nullptr ? entry_point : "<unknown>";
  const char* message = e != nullptr ? e->what() : "unknown C++ exception";
  std::snprintf(tl_last_error, sizeof(tl_last_error),
                "pgaccel: %s: GPU kernel failure: %s", safe_entry_point, message);
  tl_last_error[sizeof(tl_last_error) - 1] = 0;
}

extern "C" uint64_t pgaccel_gpu_exec_count(void) {
  return tl_gpu_exec_count;
}

extern "C" void pgaccel_reset_gpu_exec_count(void) {
  tl_gpu_exec_count = 0;
}

void pgaccel_record_gpu_exec() {
  tl_gpu_exec_count++;
}

// ---------------------------------------------------------------------------
// Module-level state (initialized once, read-only after init)
// ---------------------------------------------------------------------------

static std::atomic<bool> g_initialized{false};
/// PID that called pgaccel_init(). After fork(), getpid() differs, so
/// we know to reinitialize the SYCL runtime in the child process.
static pid_t g_init_pid = 0;
static pgaccel_device_info g_device_info = {};
static pgaccel_platform_caps g_caps = {};

sycl::queue* g_queue = nullptr;
sycl::queue* g_ooo_queue = nullptr;

#if defined(PGACCEL_TEST_HOOKS)
static std::atomic<bool> g_test_fail_before_ooo_queue{false};
static std::atomic<bool> g_test_fail_after_fork_invalidation{false};
static std::atomic<unsigned> g_test_unpublished_queues{0};

class TestUnpublishedQueue {
 public:
  TestUnpublishedQueue() { g_test_unpublished_queues.fetch_add(1, std::memory_order_relaxed); }
  TestUnpublishedQueue(const TestUnpublishedQueue&) = delete;
  TestUnpublishedQueue& operator=(const TestUnpublishedQueue&) = delete;
  ~TestUnpublishedQueue() {
    if (unpublished_)
      g_test_unpublished_queues.fetch_sub(1, std::memory_order_relaxed);
  }

  void publish() {
    g_test_unpublished_queues.fetch_sub(1, std::memory_order_relaxed);
    unpublished_ = false;
  }

 private:
  bool unpublished_ = true;
};

extern "C" void pgacceltest_fail_before_ooo_queue_once(void) {
  g_test_fail_before_ooo_queue.store(true, std::memory_order_release);
}

extern "C" unsigned pgacceltest_unpublished_queue_count(void) {
  return g_test_unpublished_queues.load(std::memory_order_acquire);
}

extern "C" void pgacceltest_seed_inherited_runtime_state(void) {
  g_device_info.compute_units = 999;
  std::strncpy(g_device_info.device_name, "stale-parent-device",
               sizeof(g_device_info.device_name) - 1);
  g_caps.compute_units = 999;
  std::strncpy(g_caps.backend_name, "stale-parent-backend", sizeof(g_caps.backend_name) - 1);
  // Sentinel values are never dereferenced: the production fork branch clears
  // them before any queue access, and the parent uses the reset hook below.
  g_queue = reinterpret_cast<sycl::queue*>(uintptr_t{1});
  g_ooo_queue = reinterpret_cast<sycl::queue*>(uintptr_t{2});
  g_init_pid = getpid();
  g_initialized.store(true, std::memory_order_release);
}

extern "C" void pgacceltest_fail_after_fork_invalidation_once(void) {
  g_test_fail_after_fork_invalidation.store(true, std::memory_order_release);
}

extern "C" void pgacceltest_clear_seeded_runtime_state(void) {
  g_queue = nullptr;
  g_ooo_queue = nullptr;
  std::memset(&g_device_info, 0, sizeof(g_device_info));
  std::memset(&g_caps, 0, sizeof(g_caps));
  g_init_pid = 0;
  g_initialized.store(false, std::memory_order_release);
  g_test_fail_after_fork_invalidation.store(false, std::memory_order_release);
}

extern "C" void pgacceltest_seed_foreign_runtime_state(void) {
  g_device_info.compute_units = 999;
  g_caps.compute_units = 999;
  g_queue = reinterpret_cast<sycl::queue*>(uintptr_t{1});
  g_ooo_queue = reinterpret_cast<sycl::queue*>(uintptr_t{2});
  g_init_pid = getpid() == std::numeric_limits<pid_t>::max() ? getpid() - 1 : getpid() + 1;
  g_initialized.store(true, std::memory_order_release);
}
#endif

// ---------------------------------------------------------------------------
// Backend name detection
// ---------------------------------------------------------------------------

static std::string backend_name_from_platform(std::string platform_name) {
  // Lowercase for matching.
  std::transform(platform_name.begin(), platform_name.end(), platform_name.begin(),
                 [](unsigned char c) { return std::tolower(c); });

  if (platform_name.find("cuda") != std::string::npos)
    return "cuda";
  if (platform_name.find("hip") != std::string::npos)
    return "hip";
  if (platform_name.find("level-zero") != std::string::npos ||
      platform_name.find("level zero") != std::string::npos ||
      platform_name.find("oneapi") != std::string::npos)
    return "level_zero";
  if (platform_name.find("metal") != std::string::npos)
    return "metal";

  return "unknown";
}

static std::string detect_backend_name(const sycl::device& dev) {
  // SAFETY: platform name is always available on a valid SYCL device.
  return backend_name_from_platform(dev.get_platform().get_info<sycl::info::platform::name>());
}

// ---------------------------------------------------------------------------
// Device scoring — higher is better
// ---------------------------------------------------------------------------

static int score_backend(bool is_gpu, const std::string& backend) {
  if (!is_gpu)
    return -1;

  // Discrete GPU backends, ranked by maturity.
  if (backend == "cuda")
    return 100;
  if (backend == "hip")
    return 90;
  if (backend == "level_zero")
    return 80;

  // Integrated GPU backends.
  if (backend == "metal")
    return 50;

  // Generic GPU we don't recognize.
  return 40;
}

static int score_device(const sycl::device& dev) {
  return score_backend(dev.is_gpu(), detect_backend_name(dev));
}

#if defined(PGACCEL_TEST_HOOKS)
extern "C" bool pgacceltest_backend_name_matches(const char* platform, const char* expected) {
  return platform != nullptr && expected != nullptr &&
         backend_name_from_platform(platform) == expected;
}

extern "C" int pgacceltest_score_backend(bool is_gpu, const char* backend) {
  return score_backend(is_gpu, backend == nullptr ? "" : backend);
}
#endif

// ---------------------------------------------------------------------------
// Populate caps from SYCL device
// ---------------------------------------------------------------------------

static pgaccel_platform_caps make_caps(const sycl::device& dev, const std::string& backend) {
  pgaccel_platform_caps caps = {};
  caps.has_native_fp64 = dev.has(sycl::aspect::fp64);
  caps.has_atomic64 = dev.has(sycl::aspect::atomic64);
  caps.has_ooo_queue = false;
  caps.max_alloc_bytes = dev.get_info<sycl::info::device::max_mem_alloc_size>();
  caps.compute_units = dev.get_info<sycl::info::device::max_compute_units>();
  std::strncpy(caps.backend_name, backend.c_str(), sizeof(caps.backend_name) - 1);
  caps.backend_name[sizeof(caps.backend_name) - 1] = '\0';
  return caps;
}

// ---------------------------------------------------------------------------
// Populate device info from SYCL device
// ---------------------------------------------------------------------------

static pgaccel_device_info make_device_info(const sycl::device& dev, const std::string& backend) {
  pgaccel_device_info info = {};
  // SAFETY: device name is always available on a valid SYCL device.
  std::string name = dev.get_info<sycl::info::device::name>();
  std::strncpy(info.device_name, name.c_str(), sizeof(info.device_name) - 1);
  info.device_name[sizeof(info.device_name) - 1] = '\0';

  std::strncpy(info.backend_name, backend.c_str(), sizeof(info.backend_name) - 1);
  info.backend_name[sizeof(info.backend_name) - 1] = '\0';

  info.compute_units = dev.get_info<sycl::info::device::max_compute_units>();
  info.max_alloc_bytes = dev.get_info<sycl::info::device::max_mem_alloc_size>();
  info.has_native_fp64 = dev.has(sycl::aspect::fp64);
  info.has_atomic64 = dev.has(sycl::aspect::atomic64);
  return info;
}

// ===========================================================================
// Public API
// ===========================================================================

extern "C" pgaccel_status pgaccel_init(void) {
  // Detect fork: if PID changed, the SYCL runtime context from the
  // parent process is stale. Reset state so we reinitialize.
  pid_t current_pid = getpid();
  if (g_initialized.load(std::memory_order_acquire)) {
    if (g_init_pid == current_pid) {
      return PGACCEL_OK;
    }
    // Forked child — drop our cached SYCL queue and fall through to a
    // fresh device pick + queue construction. AdaptiveCpp detects the
    // fork internally at its dispatch chokepoints and recovers (Metal /
    // ROCm) or raises a clean error (CUDA / Level Zero) on the next use.
    g_queue = nullptr;
    g_ooo_queue = nullptr;
    std::memset(&g_device_info, 0, sizeof(g_device_info));
    std::memset(&g_caps, 0, sizeof(g_caps));
    fprintf(stderr,
            "pgaccel: fork detected (parent=%d, child=%d)"
            " — attempting fresh GPU init\n",
            g_init_pid, current_pid);
    g_init_pid = 0;
    g_initialized.store(false, std::memory_order_release);
#if defined(PGACCEL_TEST_HOOKS)
    if (g_test_fail_after_fork_invalidation.exchange(false, std::memory_order_acq_rel)) {
      fprintf(stderr, "pgaccel: FATAL: injected failure after fork-state invalidation\n");
      return PGACCEL_ERROR;
    }
#endif
    // Fall through to normal init path below.
  }

  // Narrow the signal surface around SYCL init instead of resetting all 31
  // handlers to SIG_DFL. PG installs custom SIGSEGV/SIGBUS handlers that
  // interfere with Metal/IOKit driver initialization (the driver relies on
  // default fault-signal dispositions during device enumeration), so only
  // the synchronous fault signals are reset to SIG_DFL for the window.
  // Every asynchronous signal (SIGTERM, SIGQUIT, SIGINT, SIGUSR1, ...) is
  // instead BLOCKED via sigprocmask: PG's die/quickdie handlers stay
  // installed and a signal arriving mid-enumeration is deferred until the
  // mask is restored, then delivered to PG's own handler. The previous
  // blanket SIG_DFL reset meant a SIGTERM in this window killed the backend
  // outright, bypassing PostgreSQL shared-memory cleanup.
  //
  // shared_preload_libraries ensures libacpp-rt.dylib was loaded in the
  // postmaster before fork, so the child inherits the loaded library and
  // can create a fresh MTLDevice without triggering the compiler service.
  static const int k_fault_signals[] = {SIGSEGV, SIGBUS, SIGILL, SIGFPE, SIGTRAP};
  constexpr size_t k_fault_count = sizeof(k_fault_signals) / sizeof(k_fault_signals[0]);

  // Block all async signals for the window. Fault signals must never be
  // blocked (delivery of a blocked synchronous fault is undefined), and
  // SIGKILL/SIGSTOP are unblockable anyway (sigprocmask ignores them).
  sigset_t block_mask;
  sigset_t old_mask;
  sigfillset(&block_mask);
  for (size_t i = 0; i < k_fault_count; i++) {
    sigdelset(&block_mask, k_fault_signals[i]);
  }
  sigprocmask(SIG_BLOCK, &block_mask, &old_mask);

  // Reset only the fault-signal handlers PG hooks to SIG_DFL.
  struct sigaction old_handlers[k_fault_count];
  for (size_t i = 0; i < k_fault_count; i++) {
    struct sigaction sa = {};
    sa.sa_handler = SIG_DFL;
    sigemptyset(&sa.sa_mask);
    sigaction(k_fault_signals[i], &sa, &old_handlers[i]);
  }

  // Preserve the distinction between an expected no-GPU host and a real
  // runtime/queue-construction failure. Callers use NO_DEVICE to decline GPU
  // work without hiding genuine initialization errors.
  pgaccel_status init_status = PGACCEL_ERROR;
  try {
    auto devices = sycl::device::get_devices();

    if (devices.empty()) {
      fprintf(stderr, "pgaccel: no SYCL devices found; GPU acceleration unavailable\n");
      init_status = PGACCEL_ERROR_NO_DEVICE;
    } else {
      sycl::device best = devices[0];
      int best_score = score_device(best);
      for (size_t i = 1; i < devices.size(); ++i) {
        int s = score_device(devices[i]);
        if (s > best_score) {
          best = devices[i];
          best_score = s;
        }
      }

      if (best_score < 0 || !best.is_gpu()) {
        fprintf(stderr, "pgaccel: no SYCL GPU device found; GPU acceleration unavailable\n");
        init_status = PGACCEL_ERROR_NO_DEVICE;
      } else {
        std::string backend = detect_backend_name(best);
        pgaccel_platform_caps caps = make_caps(best, backend);
        pgaccel_device_info device_info = make_device_info(best, backend);

        // Async exception handler: AdaptiveCpp's Metal backend (and
        // other backends) report kernel-launch failures asynchronously
        // through the queue's exception list instead of throwing
        // synchronously from submit().  Without this handler, a
        // failed dispatch (e.g. MTLCompilerService unreachable) logs
        // "[AdaptiveCpp Error] ... metal: Failed to create compute
        // pipeline state" to stderr but q.submit(...).wait() returns
        // silently and the caller reads a zero-initialized output
        // buffer as if the kernel had succeeded.
        //
        // By installing a handler that rethrows every sycl::exception
        // it sees, callers that use wait_and_throw() (on either the
        // queue or the returned event) will surface these async
        // errors as synchronous exceptions at the wait site.
        auto async_handler = [](sycl::exception_list exceptions) {
          for (std::exception_ptr const& e : exceptions) {
            try {
              std::rethrow_exception(e);
            } catch (const sycl::exception& ex) {
              fprintf(stderr, "pgaccel: async SYCL error: %s\n", ex.what());
              throw;
            } catch (const std::exception& ex) {
              fprintf(stderr, "pgaccel: async error: %s\n", ex.what());
              throw;
            }
          }
        };

        auto queue = std::make_unique<sycl::queue>(
            best, async_handler, sycl::property_list{sycl::property::queue::in_order{}});
#if defined(PGACCEL_TEST_HOOKS)
        TestUnpublishedQueue queue_publication;
        if (g_test_fail_before_ooo_queue.exchange(false, std::memory_order_acq_rel))
          throw std::runtime_error("injected out-of-order queue construction failure");
#endif
        auto ooo_queue = std::make_unique<sycl::queue>(
            best, async_handler, sycl::property_list{sycl::property::queue::enable_profiling{}});
#if defined(PGACCEL_TEST_HOOKS)
        TestUnpublishedQueue ooo_queue_publication;
#endif
        caps.has_ooo_queue = !ooo_queue->is_in_order();

        // Publish only after both queues and all metadata have been created.
        // Until this non-throwing block, local RAII owns both queues, so any
        // failure leaves the process globals in their prior all-null state.
        g_device_info = device_info;
        g_caps = caps;
#if defined(PGACCEL_TEST_HOOKS)
        queue_publication.publish();
        ooo_queue_publication.publish();
#endif
        g_queue = queue.release();
        g_ooo_queue = ooo_queue.release();

        // Silent success: backend init fires per-forked-backend, so
        // logging here produces O(queries) log lines. See Justfile
        // `log-rails` recipe for how PG's own log is rotated.
        init_status = PGACCEL_OK;
      }
    }
  } catch (const sycl::exception& e) {
    fprintf(stderr, "pgaccel: FATAL: SYCL init failed: %s\n", e.what());
  } catch (const std::exception& e) {
    fprintf(stderr, "pgaccel: FATAL: init failed: %s\n", e.what());
  } catch (...) {
    // Without this arm a non-std exception would escape the extern "C"
    // boundary (std::terminate) AND skip the handler/mask restore below.
    fprintf(stderr, "pgaccel: FATAL: init failed: unknown C++ exception\n");
  }

  // Restore PG's fault-signal handlers, then the signal mask. Any async
  // signal that arrived during the window is delivered now, to PG's own
  // handlers.
  for (size_t i = 0; i < k_fault_count; i++) {
    sigaction(k_fault_signals[i], &old_handlers[i], nullptr);
  }
  sigprocmask(SIG_SETMASK, &old_mask, nullptr);

  if (init_status != PGACCEL_OK)
    return init_status;

  g_init_pid = current_pid;
  g_initialized.store(true, std::memory_order_release);
  return PGACCEL_OK;
}

// Fork-safe queue accessors (declared in pgaccel_queue.h). pgaccel_init()
// is idempotent and re-checks getpid() on every call, so routing every
// queue access through these guarantees a forked child never dispatches on
// the parent's stale Metal/CUDA context.
sycl::queue* pgaccel_get_queue() {
  if (pgaccel_init() != PGACCEL_OK)
    return nullptr;
  return g_queue;
}

sycl::queue* pgaccel_get_ooo_queue() {
  if (pgaccel_init() != PGACCEL_OK)
    return nullptr;
  return g_ooo_queue;
}

extern "C" pgaccel_status pgaccel_shutdown(void) {
  const pid_t current_pid = getpid();
  if (g_initialized.load(std::memory_order_acquire) && g_init_pid != current_pid) {
    // A forked child must never wait on or delete queue objects inherited from
    // its parent. They belong to the parent's SYCL runtime context.
    g_queue = nullptr;
    g_ooo_queue = nullptr;
    std::memset(&g_device_info, 0, sizeof(g_device_info));
    std::memset(&g_caps, 0, sizeof(g_caps));
    g_init_pid = 0;
    g_initialized.store(false, std::memory_order_release);
    return PGACCEL_OK;
  }
  if (!g_initialized.load(std::memory_order_acquire)) {
    return PGACCEL_OK;
  }

  // SAFETY: queues are only modified during init/shutdown which are
  // guaranteed to be called from the PG backend main thread (single writer).
  if (g_queue != nullptr || g_ooo_queue != nullptr) {
    try {
      if (g_ooo_queue != nullptr)
        g_ooo_queue->wait_and_throw();
      if (g_queue != nullptr)
        g_queue->wait_and_throw();
    } catch (const std::exception& e) {
      // Best-effort flush during teardown; log so a failing in-flight
      // kernel is visible, but continue releasing the queues.
      fprintf(stderr, "pgaccel: shutdown queue flush failed: %s\n", e.what());
    } catch (...) {
      fprintf(stderr, "pgaccel: shutdown queue flush failed: unknown C++ exception\n");
    }
    if (g_ooo_queue != nullptr) {
      delete g_ooo_queue;
      g_ooo_queue = nullptr;
    }
    if (g_queue != nullptr) {
      delete g_queue;
      g_queue = nullptr;
    }
  }

  std::memset(&g_device_info, 0, sizeof(g_device_info));
  std::memset(&g_caps, 0, sizeof(g_caps));
  g_init_pid = 0;
  g_initialized.store(false, std::memory_order_release);
  return PGACCEL_OK;
}

extern "C" pgaccel_device_info pgaccel_get_device_info(void) {
  if (!g_initialized.load(std::memory_order_acquire) || g_init_pid != getpid() ||
      g_queue == nullptr || g_ooo_queue == nullptr)
    return {};
  return g_device_info;
}

extern "C" pgaccel_platform_caps pgaccel_get_caps(void) {
  if (!g_initialized.load(std::memory_order_acquire) || g_init_pid != getpid() ||
      g_queue == nullptr || g_ooo_queue == nullptr)
    return {};
  return g_caps;
}

extern "C" void pgaccel_prefork_warmup(void) {
#if defined(__APPLE__)
  // Establish inherited fork-safety policy before PostgreSQL creates any
  // backend. Some macOS releases can crash a forked child in unified
  // logging/CoreAnalytics while Metal initializes. OS_ACTIVITY_MODE disables
  // that Apple activity telemetry; PostgreSQL's elog/stderr logging is
  // unaffected. Preserve explicit operator choices by never overwriting them.
  setenv("OBJC_DISABLE_INITIALIZE_FORK_SAFETY", "YES", 0);
  setenv("OS_ACTIVITY_MODE", "disable", 0);

  // Deliberately do NOT initialize SYCL or touch Metal in the parent: the AGX
  // device stack caches process-local state that cannot be reset on the child
  // side. Kernel compilation is deferred to the first child and cached on
  // disk, avoiding stale IOKit handles in PostgreSQL backends.
#endif
}
