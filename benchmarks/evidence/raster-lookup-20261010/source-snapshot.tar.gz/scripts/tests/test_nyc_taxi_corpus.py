from contextlib import contextmanager
import bz2
import hashlib
import json
import os
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

from scripts import nyc_taxi_corpus as corpus


class NycCorpusTests(unittest.TestCase):
    def setUp(self):
        self.directory = tempfile.TemporaryDirectory()
        self.addCleanup(self.directory.cleanup)
        self.root = Path(self.directory.name)
        self.source = self.root / "source.csv"
        self.source.write_text('source_id,lon,lat\na,-73.9,40.7\nb,0,0\nc,,\n')
        self.manifest = {
            "schema_version": 1,
            "source_sha256": hashlib.sha256(self.source.read_bytes()).hexdigest(),
            "columns": ["source_id", "lon", "lat"],
            "rows": 3,
            "max_download_bytes": 1000,
        }

    def test_pinned_source_keeps_null_and_zero_coordinates(self):
        self.assertEqual(corpus.verify_source(self.source, self.manifest), 3)

    def test_modified_source_is_rejected(self):
        self.source.write_text(self.source.read_text().replace("40.7", "41.7"))
        with self.assertRaisesRegex(ValueError, "SHA-256 mismatch"):
            corpus.verify_source(self.source, self.manifest)

    def test_wrong_header_row_count_and_size_fail_closed(self):
        for changes, message in [({"columns": ["lat", "lon", "source_id"]}, "header"),
                                 ({"rows": 4}, "source rows"),
                                 ({"max_download_bytes": 2}, "byte limit")]:
            with self.subTest(changes=changes):
                with self.assertRaisesRegex(ValueError, message):
                    corpus.verify_source(self.source, self.manifest | changes)

    def test_unpinned_manifest_fails_before_network(self):
        manifest = self.root / "manifest.json"
        manifest.write_text(json.dumps(self.manifest | {"source_sha256": "UNPINNED"}))
        with self.assertRaisesRegex(ValueError, "reviewed pinned"):
            corpus.read_manifest(manifest)
        manifest.write_text(json.dumps(self.manifest | {"archive": {"sha256": "UNPINNED"}}))
        with self.assertRaisesRegex(ValueError, "archive must have a reviewed pinned"):
            corpus.read_manifest(manifest)

    def test_existing_verified_download_needs_no_network(self):
        with patch("urllib.request.urlopen", side_effect=AssertionError("unexpected network")):
            self.assertEqual(corpus.fetch(self.source, self.manifest), 3)

    def test_fetch_rejects_oversize_and_never_publishes_partial(self):
        target = self.root / "download.csv"
        manifest = self.manifest | {"archive": {"url": "https://example.invalid/data.bz2",
                                               "max_download_bytes": 1}}
        with self.source.open("rb") as stream, patch("urllib.request.urlopen", return_value=stream):
            with self.assertRaisesRegex(ValueError, "byte limit"):
                corpus.download_archive(target, manifest)
        self.assertFalse(target.exists())
        self.assertTrue(target.with_suffix(".csv.partial").exists())

    def test_airport_asset_preserves_pinned_complete_geometry(self):
        manifest = json.loads(corpus.MANIFEST.read_text())
        airport = corpus.MANIFEST.parent / manifest["airport"]["asset"]
        self.assertEqual(corpus.sha256(airport), manifest["airport"]["sha256"])
        self.assertTrue(airport.read_text().startswith("SRID=4326;MULTIPOLYGON"))
        self.assertEqual(manifest["airport"]["components"], 4)

    def archive_fixture(self):
        body = ("date,lon,lat\n"
                "2015-01-01,0,0\n"
                "2014-12-31,-73.123456789123456,40.7\n"
                "2015-01-01,0,0\n"
                "2015-01-02,,\n")
        archive = self.root / "archive.bz2"
        archive.write_bytes(bz2.compress(body.encode()))
        manifest = self.manifest | {
            "columns": ["source_id", "date", "lon", "lat"], "rows": 4,
            "archive": {"columns": ["date", "lon", "lat"], "projection_indices": [0, 1, 2],
                        "sha256": corpus.sha256(archive), "max_download_bytes": 1000},
        }
        return archive, manifest

    def test_projection_keeps_order_duplicates_outliers_nulls_and_decimal_text(self):
        archive, manifest = self.archive_fixture()
        target = self.root / "projection.csv"
        candidate = corpus.project_archive(archive, target, manifest, candidate=True)
        self.assertEqual(target.read_text(), "source_id,date,lon,lat\n"
                         "csv:1,2015-01-01,0,0\n"
                         "csv:2,2014-12-31,-73.123456789123456,40.7\n"
                         "csv:3,2015-01-01,0,0\n"
                         "csv:4,2015-01-02,,\n")
        self.assertEqual(candidate["observed_dates"]["outside_january_rows"], 1)
        self.assertEqual(corpus.verify_source(target, candidate), 4)
        second = self.root / "reproduced.csv"
        corpus.project_archive(archive, second, candidate)
        self.assertEqual(second.read_bytes(), target.read_bytes())

    def test_projection_rejects_wrong_hash_header_and_count(self):
        archive, manifest = self.archive_fixture()
        for changes, error in [
            ({"archive": manifest["archive"] | {"sha256": "0" * 64}}, "SHA-256"),
            ({"archive": manifest["archive"] | {"columns": ["wrong"]}}, "header"),
            ({"rows": 5}, "archive rows"),
        ]:
            with self.subTest(error=error):
                target = self.root / (error + ".csv")
                with self.assertRaisesRegex(ValueError, error):
                    corpus.project_archive(archive, target, manifest | changes)
                self.assertFalse(target.exists())

    def test_truncated_bzip_is_never_published(self):
        archive, manifest = self.archive_fixture()
        archive.write_bytes(archive.read_bytes()[:-10])
        target = self.root / "truncated.csv"
        with self.assertRaises(EOFError):
            corpus.project_archive(archive, target, manifest, candidate=True)
        self.assertFalse(target.exists())

    @unittest.skipUnless(os.environ.get("PG_ACCEL_CORPUS_TEST_DSN"), "opt-in live importer test")
    def test_live_import_preserves_rows_generated_columns_and_immutability(self):
        import psycopg2
        manifest = json.loads(corpus.MANIFEST.read_text())
        self.source.write_text(
            ",".join(manifest["columns"]) + "\n"
            "valid,2015-01-01,-73.9,40.7,1,2,12.34,1.25,15.34\n"
            "zero,2015-01-01,0,0,2,1,0,0,0\n"
            "missing,2015-01-01,,,1,1,1,1,1\n"
            "outside,2015-01-01,181,91,1,1,1,1,1\n")
        manifest |= {"source_sha256": corpus.sha256(self.source), "rows": 4}
        client = psycopg2.connect(os.environ["PG_ACCEL_CORPUS_TEST_DSN"])
        self.addCleanup(client.close)

        @contextmanager
        def rollback_connection(_):
            try:
                yield client
                with client.cursor() as cursor:
                    cursor.execute("SELECT source_id,coordinate_valid,pickup_geom IS NULL,cell IS NULL "
                                   "FROM pgaccel_corpus.nyc_yellow_2015_01 ORDER BY id")
                    self.assertEqual(cursor.fetchall(), [("valid", True, False, False),
                        ("zero", True, False, False), ("missing", False, True, True),
                        ("outside", False, True, True)])
                    cursor.execute("SAVEPOINT mutation")
                    with self.assertRaisesRegex(psycopg2.Error, "immutable"):
                        cursor.execute("TRUNCATE pgaccel_corpus.nyc_yellow_2015_01")
                    cursor.execute("ROLLBACK TO SAVEPOINT mutation")
            finally:
                client.rollback()

        with patch("psycopg2.connect", rollback_connection):
            self.assertEqual(corpus.import_source(self.source, manifest, "test"),
                             {"rows": 4, "invalid_coordinates": 2, "zero_coordinates": 1})


if __name__ == "__main__":
    unittest.main()
