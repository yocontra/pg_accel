//! Batch-boundary preparation of the existing byte-per-row NULL sidecar.
//!
//! Producers append flags and OR `saw_null` in their existing row loop. Until
//! the first NULL, completed all-zero prefixes are implicit; only one load
//! batch needs scratch. Once a NULL appears, backfill that prefix exactly once.

pub(super) const STAGING_ROWS: usize = 8192;

fn normalize(nulls: &mut Vec<u8>, saw_null: bool, rows: usize) -> Result<(), String> {
    if nulls.len() > rows {
        return Err("resident NULL sidecar exceeds staged row count".to_owned());
    }
    if !saw_null {
        nulls.clear();
        return Ok(());
    }
    let tail = nulls.len();
    let prefix = rows - tail;
    if prefix != 0 {
        nulls
            .try_reserve(prefix)
            .map_err(|error| format!("resident NULL sidecar allocation failed: {error}"))?;
        nulls.resize(rows, 0);
        nulls.copy_within(..tail, prefix);
        // resize already zeroed [tail, rows). Only the old tail bytes left
        // before the destination can still be nonzero. For a late first NULL,
        // do not write the potentially table-sized zero prefix a second time.
        nulls[..tail.min(prefix)].fill(0);
    }
    Ok(())
}

/// Called before a producer's next batch (or row), never from its flag append
/// hot path. `rows` counts all published values, including discarded zero
/// prefixes; `additional` is only a capacity hint. Producers must reserve at
/// least once per STAGING_ROWS to keep the scratch bound.
#[inline]
pub(super) fn reserve(
    nulls: &mut Vec<u8>,
    saw_null: bool,
    rows: usize,
    additional: usize,
) -> Result<(), String> {
    // After the first NULL's prefix has been restored, length equality proves
    // that no normalization is needed. Keep nullable batches on Vec's ordinary
    // reserve path without entering the backfill/error-formatting helper.
    if !saw_null || nulls.len() != rows {
        normalize(nulls, saw_null, rows)?;
    }
    nulls
        .try_reserve(if saw_null {
            additional
        } else {
            additional.min(STAGING_ROWS)
        })
        .map_err(|error| format!("resident NULL sidecar allocation failed: {error}"))
}

pub(super) fn finish(
    mut nulls: Vec<u8>,
    saw_null: bool,
    rows: usize,
) -> Result<Option<Vec<u8>>, String> {
    if !saw_null {
        return Ok(None);
    }
    normalize(&mut nulls, true, rows)?;
    Ok(Some(nulls))
}

#[cfg(test)]
mod tests {
    use super::*;

    fn stage(input: &[bool], batch: usize) -> (Option<Vec<u8>>, usize) {
        let mut flags = Vec::new();
        let mut saw_null = false;
        let mut rows = 0;
        for chunk in input.chunks(batch) {
            reserve(&mut flags, saw_null, rows, chunk.len()).expect("batch reserve");
            for &null in chunk {
                flags.push(u8::from(null));
                saw_null |= null;
                rows += 1;
            }
        }
        let capacity = flags.capacity();
        (
            finish(flags, saw_null, rows).expect("complete mask"),
            capacity,
        )
    }

    #[test]
    fn null_free_columns_keep_only_one_batch_of_scratch() {
        for rows in [0, 1, 8191, 8192, 8193, 1_000_000] {
            let (mask, capacity) = stage(&vec![false; rows], STAGING_ROWS);
            assert!(mask.is_none());
            assert!(capacity <= STAGING_ROWS);
        }
    }

    #[test]
    fn first_null_in_any_batch_preserves_the_complete_mask() {
        for batch in [1, 3, 64, 8192] {
            for first in [0, 1, 63, 64, 8191, 8192, 8193, 24577] {
                let mut input = vec![false; first + 7];
                input[first] = true;
                input[first + 3] = true;
                let (mask, _) = stage(&input, batch);
                assert_eq!(mask, Some(input.into_iter().map(u8::from).collect()));
            }
        }
    }

    #[test]
    fn backfill_handles_overlapping_moves_and_all_nulls() {
        for prefix in [1, 2, 3, 1000] {
            let mut flags = vec![1, 0, 1, 1, 0, 0, 1];
            let expected = [vec![0; prefix], flags.clone()].concat();
            normalize(&mut flags, true, prefix + 7).expect("backfill");
            assert_eq!(flags, expected);
        }
        assert_eq!(stage(&vec![true; 20_000], 8192).0, Some(vec![1; 20_000]));
    }

    #[test]
    fn backfill_zeroes_only_old_tail_without_losing_overlap() {
        for tail in 0..=10 {
            for bits in 0..(1_u32 << tail) {
                let flags: Vec<_> = (0..tail)
                    .map(|bit| u8::from(bits & (1 << bit) != 0))
                    .collect();
                for prefix in [0, 1, 2, 3, 7, 10, 11, 31, 8192] {
                    let mut actual = flags.clone();
                    normalize(&mut actual, true, prefix + tail).expect("backfill");
                    assert!(actual[..prefix].iter().all(|byte| *byte == 0));
                    assert_eq!(&actual[prefix..], flags);
                    let pointer = actual.as_ptr();
                    reserve(&mut actual, true, prefix + tail, 0).expect("already normalized");
                    assert_eq!(actual.as_ptr(), pointer);
                    assert!(actual[..prefix].iter().all(|byte| *byte == 0));
                    assert_eq!(&actual[prefix..], flags);
                }
            }
        }
    }

    #[test]
    fn impossible_backfill_does_not_mutate_the_pending_tail() {
        let mut flags = vec![0, 1, 0];
        assert!(reserve(&mut flags, true, usize::MAX, 1).is_err());
        assert_eq!(flags, [0, 1, 0]);
        assert!(reserve(&mut flags, true, 2, 1).is_err());
        assert_eq!(flags, [0, 1, 0]);
        reserve(&mut flags, true, 6, 1).expect("retry");
        assert_eq!(flags, [0, 0, 0, 0, 1, 0]);
    }
}
