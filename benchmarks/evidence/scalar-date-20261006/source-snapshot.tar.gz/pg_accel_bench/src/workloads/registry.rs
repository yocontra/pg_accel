//! Declarative metadata for every benchmark workload.
//!
//! Workload implementations own SQL and fixture construction. This registry
//! owns cross-cutting harness policy keyed by the exact workload name.

/// Stable workload categories used by CLI filters and report rollups.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum WorkloadCategory {
    GpuReduce,
    GpuHashAgg,
    GpuSort,
    GpuHashJoin,
    GpuJoin,
    GpuSpatial,
    GpuH3,
    GpuExpr,
    GpuWindow,
    /// Star-schema workloads generated from the SSBM fixture.
    StarSchemaSsbm,
    /// Deterministic TPC-H-shaped system workloads (not a certified TPC-H run).
    Tpch,
    /// Deterministic ClickBench-style high-volume event workloads.
    ClickBench,
    /// Opt-in pinned real-coordinate NYC taxi corpus (not a synthetic suite).
    NycTaxi,
    Mixed,
    GpuRaster,
    Regression,
    Fp64Matrix,
}

impl WorkloadCategory {
    #[must_use]
    pub const fn as_str(self) -> &'static str {
        match self {
            Self::GpuReduce => "gpu_reduce",
            Self::GpuHashAgg => "gpu_hashagg",
            Self::GpuSort => "gpu_sort",
            Self::GpuHashJoin => "gpu_hashjoin",
            Self::GpuJoin => "gpu_join",
            Self::GpuSpatial => "gpu_spatial",
            Self::GpuH3 => "gpu_h3",
            Self::GpuExpr => "gpu_expr",
            Self::GpuWindow => "gpu_window",
            Self::StarSchemaSsbm => "ssbm",
            Self::Tpch => "tpch",
            Self::ClickBench => "clickbench",
            Self::NycTaxi => "nyc_taxi",
            Self::Mixed => "mixed",
            Self::GpuRaster => "gpu_raster",
            Self::Regression => "regression",
            Self::Fp64Matrix => "fp64_matrix",
        }
    }
}

/// Physical kernel family represented by a workload.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum KernelClass {
    Reduce,
    HashAgg,
    Sort,
    HashJoin,
    MergeJoin,
    SetOp,
    RecursiveUnion,
    NestedLoopInequality,
    PointInRing,
    H3LatLng,
    H3CellToParent,
    Expr,
    Window,
    Raster,
    ResidentStarGroupAgg,
    ResidentF64Reduce,
    ResidentF64GroupedStats,
    Unclassified,
}

impl KernelClass {
    #[must_use]
    pub const fn as_str(self) -> &'static str {
        match self {
            Self::Reduce => "reduce",
            Self::HashAgg => "hash_agg",
            Self::Sort => "sort",
            Self::HashJoin => "hash_join",
            Self::MergeJoin => "merge_join",
            Self::SetOp => "set_op",
            Self::RecursiveUnion => "recursive_union",
            Self::NestedLoopInequality => "nested_loop_ineq",
            Self::PointInRing => "point_in_ring",
            Self::H3LatLng => "h3_latlng",
            Self::H3CellToParent => "h3_cell_to_parent",
            Self::Expr => "expr",
            Self::Window => "window",
            Self::Raster => "raster",
            Self::ResidentStarGroupAgg => "resident_star_groupagg",
            Self::ResidentF64Reduce => "resident_f64_reduce",
            Self::ResidentF64GroupedStats => "resident_f64_grouped_stats",
            Self::Unclassified => "unclassified",
        }
    }
}

/// One table/column set loaded into the resident cache before measurement.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct ResidentPinSpec {
    pub table: &'static str,
    pub columns: &'static [&'static str],
}

/// PostgreSQL extensions a workload fixture or query depends on.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum RequiredExtension {
    Postgis,
    H3,
    PostgisRaster,
}

impl RequiredExtension {
    #[must_use]
    pub const fn as_str(self) -> &'static str {
        match self {
            Self::Postgis => "postgis",
            Self::H3 => "h3",
            Self::PostgisRaster => "postgis_raster",
        }
    }
}

/// Release policy for an H3 workload.
#[derive(Debug, Clone, Copy, PartialEq)]
pub enum H3LaneClass {
    Winning { min_warm_speedup: f64 },
    Parity,
}

/// Whether threshold-matrix evidence is expected from a workload.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum ThresholdEvidenceEligibility {
    NotGated,
    GpuWinner,
    NativeDeclineOnly,
}

/// Static eligibility for evidence paths that previously inferred policy from
/// workload-name prefixes or category strings.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct EvidenceEligibility {
    pub threshold: ThresholdEvidenceEligibility,
    flags: u8,
}

impl EvidenceEligibility {
    const FUNCTION_KERNEL: u8 = 1 << 0;
    const CACHE_MODE_BOTH: u8 = 1 << 1;
    const FP64_CALIBRATION: u8 = 1 << 2;
    const H3_RESIDENT_ROLLUP: u8 = 1 << 3;
    const DERIVED_OUTPUT_ARTIFACT_REUSE: u8 = 1 << 4;

    const NONE: Self = Self {
        threshold: ThresholdEvidenceEligibility::NotGated,
        flags: 0,
    };

    #[must_use]
    pub const fn function_kernel(self) -> bool {
        self.flags & Self::FUNCTION_KERNEL != 0
    }

    #[must_use]
    pub const fn requires_cache_mode_both(self) -> bool {
        self.flags & Self::CACHE_MODE_BOTH != 0
    }

    #[must_use]
    pub const fn fp64_calibration(self) -> bool {
        self.flags & Self::FP64_CALIBRATION != 0
    }

    #[must_use]
    pub const fn h3_resident_rollup(self) -> bool {
        self.flags & Self::H3_RESIDENT_ROLLUP != 0
    }

    /// The selected path constructs the exact final output with a GPU kernel
    /// in a sealed lifecycle probe, then serves measured warm queries from a
    /// dependency-stamped derived artifact without launching a fresh kernel.
    #[must_use]
    pub const fn derived_output_artifact_reuse(self) -> bool {
        self.flags & Self::DERIVED_OUTPUT_ARTIFACT_REUSE != 0
    }
}

/// Cross-cutting metadata for one exact workload identifier.
#[derive(Debug, Clone, Copy, PartialEq)]
pub struct WorkloadMetadata {
    pub name: &'static str,
    pub category: WorkloadCategory,
    pub kernel_class: KernelClass,
    pub resident_pins: &'static [ResidentPinSpec],
    pub required_extensions: &'static [RequiredExtension],
    pub h3_lane: Option<H3LaneClass>,
    pub evidence: EvidenceEligibility,
}

/// Phase 9 operator lanes that intentionally remain PostgreSQL-native.
#[derive(Debug, Clone, Copy, PartialEq, Eq, PartialOrd, Ord)]
pub enum Phase9OperatorLane {
    WindowFullOutput,
    WindowRowNumberTopN,
    WindowRankFilter,
    WindowDenseRankFilter,
    WindowRunningAggregate,
    WindowAnalytics,
    WindowCountSumAvgRank,
    ExistsMembership,
    InMembership,
    NotExistsMembership,
    NotInMembership,
    AggregateModifiers,
    AggregateOrderedSet,
    NumericAccumulator,
    NonFloatAvg,
    SetOp,
    RecursiveUnion,
    MergeJoin,
    MultiKeySort,
    NestedLoopInequality,
}

impl Phase9OperatorLane {
    #[must_use]
    pub const fn as_str(self) -> &'static str {
        match self {
            Self::WindowFullOutput => "window_full_output",
            Self::WindowRowNumberTopN => "window_row_number_topn",
            Self::WindowRankFilter => "window_rank_filter",
            Self::WindowDenseRankFilter => "window_dense_rank_filter",
            Self::WindowRunningAggregate => "window_running_aggregate",
            Self::WindowAnalytics => "window_analytics",
            Self::WindowCountSumAvgRank => "window_count_sum_avg_rank",
            Self::ExistsMembership => "exists_membership",
            Self::InMembership => "in_membership",
            Self::NotExistsMembership => "not_exists_membership",
            Self::NotInMembership => "not_in_membership",
            Self::AggregateModifiers => "aggregate_modifiers",
            Self::AggregateOrderedSet => "aggregate_ordered_set",
            Self::NumericAccumulator => "numeric_accumulator",
            Self::NonFloatAvg => "nonfloat_avg",
            Self::SetOp => "setop",
            Self::RecursiveUnion => "recursive_union",
            Self::MergeJoin => "merge_join",
            Self::MultiKeySort => "multi_key_sort",
            Self::NestedLoopInequality => "nested_loop_inequality",
        }
    }
}

/// Exact benchmark and planner-reason contract for one Phase 9 lane.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct Phase9DeclineContract {
    pub lane: Phase9OperatorLane,
    pub workload: &'static str,
    pub reason: &'static str,
}

/// Independent oracle and execution policy for one Phase 6 domain lane.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Phase6DomainOracle {
    /// Compare the accelerated result with PostGIS while preserving the exact
    /// PostGIS recheck contract for any GPU-classified spatial row.
    PostgisExactRecheck,
    /// Compare with an h3-pg spelling that pg_accel does not intercept.
    NativeH3,
    /// Keep unsupported row-expanding/topology H3 operations PostgreSQL-native.
    NativeH3FailClosed,
    /// Compare raster output with PostGIS Raster while pg_accel is disabled.
    PostgisRaster,
}

/// Canonical live verification cells for one registered Phase 6 workload.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct Phase6DomainContract {
    pub workload: &'static str,
    pub category: WorkloadCategory,
    pub oracle: Phase6DomainOracle,
    pub verification_rows: &'static [usize],
}

const PHASE6_SMOKE_ROWS: &[usize] = &[10_000];
const PHASE6_H3_PARENT_ROWS: &[usize] = &[100_000];
const H3_RESOLUTION_ROWS: &[usize] = &[1_000_000];
const PHASE6_H3_DECLINE_ROWS: &[usize] = &[100_000, 1_000_000];
const PHASE6_RASTER_ROWS: &[usize] = &[100];
const PHASE6_RASTER_EXACT_RECLASS_ROWS: &[usize] = &[10_000, 100_000, 1_000_000];
const PHASE6_SPATIAL_RESIDENT_AGG_ROWS: &[usize] = &[1_000_000];
const PHASE6_SPATIAL_TOPOLOGY_ROWS: &[usize] = &[1_000_000, 2_000_000];

/// The old spatial unsafe-row quarantine covered this interval. The executor
/// now dispatches in bounded 65,536-row chunks, so these are positive live
/// verification cells rather than planner exclusions.
pub const PHASE6_SPATIAL_CRASH_BAND_ROWS: &[usize] = &[80_000, 100_000, 150_000];

macro_rules! phase6_contract {
    ($workload:literal, $category:expr, $oracle:expr, $rows:expr) => {
        Phase6DomainContract {
            workload: $workload,
            category: $category,
            oracle: $oracle,
            verification_rows: $rows,
        }
    };
}

/// Exhaustive Phase 6 live matrix. Every workload registered in a release
/// domain category appears exactly once; representative simple/cooperative
/// point-in-ring lanes additionally span the complete historical crash band.
pub const PHASE6_DOMAIN_CONTRACTS: &[Phase6DomainContract] = &[
    phase6_contract!(
        "spatial_filter",
        WorkloadCategory::GpuSpatial,
        Phase6DomainOracle::PostgisExactRecheck,
        PHASE6_SMOKE_ROWS
    ),
    phase6_contract!(
        "spatial_complex_poly",
        WorkloadCategory::GpuSpatial,
        Phase6DomainOracle::PostgisExactRecheck,
        PHASE6_SMOKE_ROWS
    ),
    phase6_contract!(
        "spatial_selectivity",
        WorkloadCategory::GpuSpatial,
        Phase6DomainOracle::PostgisExactRecheck,
        PHASE6_SMOKE_ROWS
    ),
    phase6_contract!(
        "spatial_mega_1kv",
        WorkloadCategory::GpuSpatial,
        Phase6DomainOracle::PostgisExactRecheck,
        PHASE6_SPATIAL_CRASH_BAND_ROWS
    ),
    phase6_contract!(
        "vsweep_low",
        WorkloadCategory::GpuSpatial,
        Phase6DomainOracle::PostgisExactRecheck,
        PHASE6_SMOKE_ROWS
    ),
    phase6_contract!(
        "vsweep_mid",
        WorkloadCategory::GpuSpatial,
        Phase6DomainOracle::PostgisExactRecheck,
        PHASE6_SMOKE_ROWS
    ),
    phase6_contract!(
        "vsweep_high",
        WorkloadCategory::GpuSpatial,
        Phase6DomainOracle::PostgisExactRecheck,
        PHASE6_SMOKE_ROWS
    ),
    phase6_contract!(
        "vsweep_pathological",
        WorkloadCategory::GpuSpatial,
        Phase6DomainOracle::PostgisExactRecheck,
        PHASE6_SMOKE_ROWS
    ),
    phase6_contract!(
        "spatial_concentric",
        WorkloadCategory::GpuSpatial,
        Phase6DomainOracle::PostgisExactRecheck,
        PHASE6_SMOKE_ROWS
    ),
    phase6_contract!(
        "spatial_star_1kv",
        WorkloadCategory::GpuSpatial,
        Phase6DomainOracle::PostgisExactRecheck,
        PHASE6_SMOKE_ROWS
    ),
    phase6_contract!(
        "spatial_multihole",
        WorkloadCategory::GpuSpatial,
        Phase6DomainOracle::PostgisExactRecheck,
        PHASE6_SMOKE_ROWS
    ),
    phase6_contract!(
        "spatial_zigzag",
        WorkloadCategory::GpuSpatial,
        Phase6DomainOracle::PostgisExactRecheck,
        PHASE6_SMOKE_ROWS
    ),
    phase6_contract!(
        "spatial_sel_1pct",
        WorkloadCategory::GpuSpatial,
        Phase6DomainOracle::PostgisExactRecheck,
        PHASE6_SMOKE_ROWS
    ),
    phase6_contract!(
        "spatial_sel_10pct",
        WorkloadCategory::GpuSpatial,
        Phase6DomainOracle::PostgisExactRecheck,
        PHASE6_SPATIAL_CRASH_BAND_ROWS
    ),
    phase6_contract!(
        "spatial_sel_50pct",
        WorkloadCategory::GpuSpatial,
        Phase6DomainOracle::PostgisExactRecheck,
        PHASE6_SMOKE_ROWS
    ),
    phase6_contract!(
        "spatial_sel_90pct",
        WorkloadCategory::GpuSpatial,
        Phase6DomainOracle::PostgisExactRecheck,
        PHASE6_SMOKE_ROWS
    ),
    phase6_contract!(
        "h3_bulk",
        WorkloadCategory::GpuH3,
        Phase6DomainOracle::NativeH3FailClosed,
        PHASE6_H3_DECLINE_ROWS
    ),
    phase6_contract!(
        "h3_cell_to_parent",
        WorkloadCategory::GpuH3,
        Phase6DomainOracle::NativeH3,
        PHASE6_H3_PARENT_ROWS
    ),
    phase6_contract!(
        "h3_parent_res4",
        WorkloadCategory::GpuH3,
        Phase6DomainOracle::NativeH3,
        H3_RESOLUTION_ROWS
    ),
    phase6_contract!(
        "h3_parent_res9",
        WorkloadCategory::GpuH3,
        Phase6DomainOracle::NativeH3,
        H3_RESOLUTION_ROWS
    ),
    phase6_contract!(
        "h3_parent_res15",
        WorkloadCategory::GpuH3,
        Phase6DomainOracle::NativeH3,
        H3_RESOLUTION_ROWS
    ),
    phase6_contract!(
        "h3_grid_distance",
        WorkloadCategory::GpuH3,
        Phase6DomainOracle::NativeH3FailClosed,
        PHASE6_SMOKE_ROWS
    ),
    phase6_contract!(
        "h3_resolution_sweep",
        WorkloadCategory::GpuH3,
        Phase6DomainOracle::NativeH3FailClosed,
        PHASE6_H3_DECLINE_ROWS
    ),
    phase6_contract!(
        "h3_srf_grid_disk",
        WorkloadCategory::GpuH3,
        Phase6DomainOracle::NativeH3FailClosed,
        PHASE6_SMOKE_ROWS
    ),
    phase6_contract!(
        "h3_latlng_res15",
        WorkloadCategory::GpuH3,
        Phase6DomainOracle::NativeH3FailClosed,
        PHASE6_H3_DECLINE_ROWS
    ),
    phase6_contract!(
        "h3_dist_near",
        WorkloadCategory::GpuH3,
        Phase6DomainOracle::NativeH3FailClosed,
        PHASE6_SMOKE_ROWS
    ),
    phase6_contract!(
        "h3_dist_far",
        WorkloadCategory::GpuH3,
        Phase6DomainOracle::NativeH3FailClosed,
        PHASE6_SMOKE_ROWS
    ),
    phase6_contract!(
        "h3_parent_deep",
        WorkloadCategory::GpuH3,
        Phase6DomainOracle::NativeH3FailClosed,
        PHASE6_SMOKE_ROWS
    ),
    phase6_contract!(
        "spatial_resident_agg_candidate",
        WorkloadCategory::GpuSpatial,
        Phase6DomainOracle::PostgisExactRecheck,
        PHASE6_SPATIAL_RESIDENT_AGG_ROWS
    ),
    phase6_contract!(
        "raster_ndvi",
        WorkloadCategory::GpuRaster,
        Phase6DomainOracle::PostgisRaster,
        PHASE6_RASTER_ROWS
    ),
    phase6_contract!(
        "spatial_holes_intersects",
        WorkloadCategory::GpuSpatial,
        Phase6DomainOracle::PostgisExactRecheck,
        PHASE6_SPATIAL_TOPOLOGY_ROWS
    ),
    phase6_contract!(
        "spatial_holes_contains",
        WorkloadCategory::GpuSpatial,
        Phase6DomainOracle::PostgisExactRecheck,
        PHASE6_SPATIAL_TOPOLOGY_ROWS
    ),
    phase6_contract!(
        "spatial_holes_within",
        WorkloadCategory::GpuSpatial,
        Phase6DomainOracle::PostgisExactRecheck,
        PHASE6_SPATIAL_TOPOLOGY_ROWS
    ),
    phase6_contract!(
        "spatial_holes_covers",
        WorkloadCategory::GpuSpatial,
        Phase6DomainOracle::PostgisExactRecheck,
        PHASE6_SPATIAL_TOPOLOGY_ROWS
    ),
    phase6_contract!(
        "spatial_holes_coveredby",
        WorkloadCategory::GpuSpatial,
        Phase6DomainOracle::PostgisExactRecheck,
        PHASE6_SPATIAL_TOPOLOGY_ROWS
    ),
    phase6_contract!(
        "raster_slope",
        WorkloadCategory::GpuRaster,
        Phase6DomainOracle::PostgisRaster,
        PHASE6_RASTER_ROWS
    ),
    phase6_contract!(
        "raster_reclass",
        WorkloadCategory::GpuRaster,
        Phase6DomainOracle::PostgisRaster,
        PHASE6_RASTER_ROWS
    ),
    phase6_contract!(
        "raster_algebra_deep",
        WorkloadCategory::GpuRaster,
        Phase6DomainOracle::PostgisRaster,
        PHASE6_RASTER_ROWS
    ),
    phase6_contract!(
        "raster_resident_exact_reclass",
        WorkloadCategory::GpuRaster,
        Phase6DomainOracle::PostgisRaster,
        PHASE6_RASTER_EXACT_RECLASS_ROWS
    ),
];

/// Exhaustive Phase 9 native-decline disposition. A lane may leave this table
/// only when it gains a differential-correct selected GPU workload.
pub const PHASE9_OPERATOR_DECLINES: &[Phase9DeclineContract] = &[
    Phase9DeclineContract {
        lane: Phase9OperatorLane::WindowFullOutput,
        workload: "window_full_output_decline",
        reason: "no_gpu_resident_pipeline",
    },
    Phase9DeclineContract {
        lane: Phase9OperatorLane::WindowRowNumberTopN,
        workload: "window_row_number",
        reason: "no_gpu_resident_pipeline",
    },
    Phase9DeclineContract {
        lane: Phase9OperatorLane::WindowRankFilter,
        workload: "window_rank",
        reason: "no_gpu_resident_pipeline",
    },
    Phase9DeclineContract {
        lane: Phase9OperatorLane::WindowDenseRankFilter,
        workload: "window_dense_rank",
        reason: "no_gpu_resident_pipeline",
    },
    Phase9DeclineContract {
        lane: Phase9OperatorLane::WindowRunningAggregate,
        workload: "window_running_sum",
        reason: "no_gpu_resident_pipeline",
    },
    Phase9DeclineContract {
        lane: Phase9OperatorLane::WindowAnalytics,
        workload: "window_analytics",
        reason: "no_gpu_resident_pipeline",
    },
    Phase9DeclineContract {
        lane: Phase9OperatorLane::WindowCountSumAvgRank,
        workload: "window_reducing_decline",
        reason: "no_gpu_resident_pipeline",
    },
    Phase9DeclineContract {
        lane: Phase9OperatorLane::ExistsMembership,
        workload: "semi_join_null_decline",
        reason: "no_gpu_resident_pipeline",
    },
    Phase9DeclineContract {
        lane: Phase9OperatorLane::InMembership,
        workload: "in_join_null_decline",
        reason: "no_gpu_resident_pipeline",
    },
    Phase9DeclineContract {
        lane: Phase9OperatorLane::NotExistsMembership,
        workload: "anti_join_null_decline",
        reason: "no_gpu_resident_pipeline",
    },
    Phase9DeclineContract {
        lane: Phase9OperatorLane::NotInMembership,
        workload: "not_in_join_null_decline",
        reason: "shape_sublink",
    },
    Phase9DeclineContract {
        lane: Phase9OperatorLane::AggregateModifiers,
        workload: "aggregate_semantic_modifier_decline",
        reason: "shape_aggregate_modifier",
    },
    Phase9DeclineContract {
        lane: Phase9OperatorLane::AggregateOrderedSet,
        workload: "aggregate_ordered_set_decline",
        reason: "shape_aggregate_modifier",
    },
    Phase9DeclineContract {
        lane: Phase9OperatorLane::NumericAccumulator,
        workload: "numeric_agg_decline",
        reason: "shape_numeric_accumulator_unavailable",
    },
    Phase9DeclineContract {
        lane: Phase9OperatorLane::NonFloatAvg,
        workload: "avg_nonfloat_decline",
        reason: "shape_numeric_accumulator_unavailable",
    },
    Phase9DeclineContract {
        lane: Phase9OperatorLane::SetOp,
        workload: "setop_intersect_decline",
        reason: "setop_no_gpu_kernel",
    },
    Phase9DeclineContract {
        lane: Phase9OperatorLane::RecursiveUnion,
        workload: "recursive_union_decline",
        reason: "recursiveunion_no_gpu_kernel",
    },
    Phase9DeclineContract {
        lane: Phase9OperatorLane::MergeJoin,
        workload: "mergejoin_decline",
        reason: "mergejoin_no_gpu_kernel",
    },
    Phase9DeclineContract {
        lane: Phase9OperatorLane::MultiKeySort,
        workload: "gpu_sort_multikey",
        reason: "sort_multikey_no_gpu_kernel",
    },
    Phase9DeclineContract {
        lane: Phase9OperatorLane::NestedLoopInequality,
        workload: "gpu_nlj_between",
        reason: "shape_non_equality_join",
    },
];

const fn workload(
    name: &'static str,
    category: WorkloadCategory,
    kernel_class: KernelClass,
) -> WorkloadMetadata {
    WorkloadMetadata {
        name,
        category,
        kernel_class,
        resident_pins: &[],
        required_extensions: &[],
        h3_lane: None,
        evidence: EvidenceEligibility::NONE,
    }
}

impl WorkloadMetadata {
    const fn pins(mut self, resident_pins: &'static [ResidentPinSpec]) -> Self {
        self.resident_pins = resident_pins;
        self
    }

    const fn extensions(mut self, required_extensions: &'static [RequiredExtension]) -> Self {
        self.required_extensions = required_extensions;
        self
    }

    const fn h3(mut self, h3_lane: H3LaneClass) -> Self {
        self.h3_lane = Some(h3_lane);
        self
    }

    const fn evidence(mut self, evidence: EvidenceEligibility) -> Self {
        self.evidence = evidence;
        self
    }
}

use KernelClass as K;
use WorkloadCategory as C;

const POSTGIS: &[RequiredExtension] = &[RequiredExtension::Postgis];
const H3: &[RequiredExtension] = &[RequiredExtension::H3];
const POSTGIS_RASTER: &[RequiredExtension] = &[RequiredExtension::PostgisRaster];

const WINNER: EvidenceEligibility = EvidenceEligibility {
    threshold: ThresholdEvidenceEligibility::GpuWinner,
    ..EvidenceEligibility::NONE
};
const NATIVE_DECLINE: EvidenceEligibility = EvidenceEligibility {
    threshold: ThresholdEvidenceEligibility::NativeDeclineOnly,
    ..EvidenceEligibility::NONE
};
const H3_WINNER: EvidenceEligibility = EvidenceEligibility {
    threshold: ThresholdEvidenceEligibility::GpuWinner,
    flags: EvidenceEligibility::FUNCTION_KERNEL
        | EvidenceEligibility::CACHE_MODE_BOTH
        | EvidenceEligibility::H3_RESIDENT_ROLLUP,
};
const H3_NATIVE_DECLINE: EvidenceEligibility = EvidenceEligibility {
    threshold: ThresholdEvidenceEligibility::NativeDeclineOnly,
    flags: EvidenceEligibility::FUNCTION_KERNEL | EvidenceEligibility::CACHE_MODE_BOTH,
};
const RASTER_NATIVE_DECLINE: EvidenceEligibility = EvidenceEligibility {
    threshold: ThresholdEvidenceEligibility::NativeDeclineOnly,
    flags: EvidenceEligibility::FUNCTION_KERNEL | EvidenceEligibility::CACHE_MODE_BOTH,
};
const RASTER_WINNER: EvidenceEligibility = EvidenceEligibility {
    threshold: ThresholdEvidenceEligibility::GpuWinner,
    flags: EvidenceEligibility::CACHE_MODE_BOTH
        | EvidenceEligibility::DERIVED_OUTPUT_ARTIFACT_REUSE,
};
const FP64_CALIBRATION: EvidenceEligibility = EvidenceEligibility {
    threshold: ThresholdEvidenceEligibility::NotGated,
    flags: EvidenceEligibility::FP64_CALIBRATION,
};
const FP64_NATIVE_DECLINE: EvidenceEligibility = EvidenceEligibility {
    threshold: ThresholdEvidenceEligibility::NativeDeclineOnly,
    flags: EvidenceEligibility::FP64_CALIBRATION,
};
const H3_FP64_NATIVE_DECLINE: EvidenceEligibility = EvidenceEligibility {
    threshold: ThresholdEvidenceEligibility::NativeDeclineOnly,
    flags: EvidenceEligibility::FUNCTION_KERNEL
        | EvidenceEligibility::CACHE_MODE_BOTH
        | EvidenceEligibility::FP64_CALIBRATION,
};

macro_rules! pin {
    ($table:literal, [$($column:literal),+ $(,)?]) => {
        ResidentPinSpec {
            table: $table,
            columns: &[$($column),+],
        }
    };
}

const PINS_HASHAGG_SWEEP: &[ResidentPinSpec] = &[pin!("bench_hagg_sweep", ["grp", "val"])];
const PINS_HASHAGG_MED: &[ResidentPinSpec] = &[pin!("bench_hashagg_med", ["user_id", "val"])];
const PINS_FILTERED_GROUPAGG: &[ResidentPinSpec] =
    &[pin!("bench_employees", ["dept", "salary", "active"])];
const PINS_GROUPED_AGG: &[ResidentPinSpec] = &[pin!("bench_employees_agg", ["dept", "salary"])];
const PINS_GROUPED_AGG_INT4: &[ResidentPinSpec] =
    &[pin!("bench_employees_agg_int4", ["dept", "salary"])];
const PINS_GROUPED_COUNT_BOOL: &[ResidentPinSpec] =
    &[pin!("bench_grouped_count_bool", ["bool_key", "observed"])];
const PINS_GROUPED_COUNT_DATE: &[ResidentPinSpec] =
    &[pin!("bench_grouped_count_date", ["bool_key", "observed"])];
const PINS_GROUPED_COUNT_FLOAT4: &[ResidentPinSpec] =
    &[pin!("bench_grouped_count_float4", ["bool_key", "observed"])];
const PINS_GROUPED_COUNT_FLOAT8: &[ResidentPinSpec] =
    &[pin!("bench_grouped_count_float8", ["bool_key", "observed"])];
const PINS_GROUPED_COUNT_TIMESTAMP: &[ResidentPinSpec] = &[pin!(
    "bench_grouped_count_timestamp",
    ["bool_key", "observed"]
)];
const PINS_GROUPED_COUNT_TIMESTAMPTZ: &[ResidentPinSpec] = &[pin!(
    "bench_grouped_count_timestamptz",
    ["bool_key", "observed"]
)];
const PINS_GROUPED_COUNT_INT2: &[ResidentPinSpec] =
    &[pin!("bench_grouped_count_int2", ["bool_key", "observed"])];
const PINS_GROUPED_COUNT_INT8: &[ResidentPinSpec] =
    &[pin!("bench_grouped_count_int8", ["bool_key", "observed"])];
const PINS_GROUPED_INT2_SUM_AVG: &[ResidentPinSpec] =
    &[pin!("bench_grouped_int2_sum_avg", ["bool_key", "observed"])];
const PINS_GROUPED_INT4_SUM_AVG: &[ResidentPinSpec] =
    &[pin!("bench_grouped_int4_sum_avg", ["bool_key", "observed"])];
const PINS_GROUPED_AGG_HIGH_CARD: &[ResidentPinSpec] =
    &[pin!("bench_events_agg", ["user_id", "val"])];
const PINS_TIMESERIES: &[ResidentPinSpec] = &[pin!("sensor_data", ["sensor_id", "value"])];
const PINS_DICTIONARY: &[ResidentPinSpec] = &[pin!("bench_dictionary_sales", ["region", "amount"])];
const PINS_EXPRESSION: &[ResidentPinSpec] = &[pin!(
    "bench_expression_sales",
    ["product_id", "price", "discount"]
)];
const PINS_PREDICATE_EXPRESSION: &[ResidentPinSpec] = &[pin!(
    "bench_predicate_expression_sales",
    ["product_id", "price", "discount", "active"]
)];
const PINS_PREDICATE_EXPRESSION_INT4: &[ResidentPinSpec] = &[pin!(
    "bench_predicate_expression_sales_int4",
    ["product_id", "price", "quantity", "active"]
)];
const PINS_AGGREGATE_FILTER_INT4: &[ResidentPinSpec] = &[pin!(
    "bench_aggregate_filter_sales_int4",
    ["product_id", "price"]
)];
const PINS_AND_RANGE_PREDICATE_EXPRESSION_INT4: &[ResidentPinSpec] = &[pin!(
    "bench_and_range_predicate_expression_sales_int4",
    ["product_id", "price", "quantity"]
)];
const PINS_RASTER_RESIDENT_EXACT_RECLASS: &[ResidentPinSpec] =
    &[pin!("bench_raster_resident_exact_reclass", ["rast"])];
const PINS_CASE_EXPRESSION: &[ResidentPinSpec] = &[pin!(
    "bench_case_when_expression_sales",
    ["product_id", "price", "discount", "active"]
)];
const PINS_CASE_RANGE: &[ResidentPinSpec] = &[pin!(
    "bench_case_when_range_expression_sales",
    ["product_id", "price", "discount", "active"]
)];
const PINS_CASE_VALUE: &[ResidentPinSpec] = &[pin!(
    "bench_case_when_value_predicate_expression_sales",
    ["product_id", "price", "discount", "active"]
)];
const PINS_CASE_NULL: &[ResidentPinSpec] = &[pin!(
    "bench_case_when_null_predicate_expression_sales",
    ["product_id", "price", "discount", "active"]
)];
const PINS_CASE_OR: &[ResidentPinSpec] = &[pin!(
    "bench_case_when_or_expression_sales",
    ["product_id", "price", "discount", "active"]
)];
const PINS_CASE_IN: &[ResidentPinSpec] = &[pin!(
    "bench_case_when_in_expression_sales",
    ["product_id", "price", "discount", "active"]
)];
const PINS_CASE_NOT: &[ResidentPinSpec] = &[pin!(
    "bench_case_when_not_expression_sales",
    ["product_id", "price", "discount", "active"]
)];
const PINS_REDUCE_F64: &[ResidentPinSpec] = &[pin!("bench_fp64_num", ["v_f64"])];
const PINS_HASHAGG_F64: &[ResidentPinSpec] = &[pin!("bench_fp64_num", ["gk", "v_f64", "w_f64"])];
const PINS_H3_PARENT: &[ResidentPinSpec] = &[pin!("bench_h3_parent", ["cell"])];
const PINS_SPATIAL_RESIDENT_AGG: &[ResidentPinSpec] =
    &[pin!("bench_spatial_resident_agg", ["geom"])];
const PINS_HASH_JOIN: &[ResidentPinSpec] = &[
    pin!("bench_orders", ["customer_id"]),
    pin!("bench_customers", ["customer_id"]),
];
const PINS_WEIGHTED_GLOBAL_COUNT_INT4: &[ResidentPinSpec] = &[
    pin!("bench_weighted_count_fact", ["k"]),
    pin!("bench_weighted_count_dim", ["k"]),
];
const PINS_HASHJOIN_SWEEP: &[ResidentPinSpec] = &[
    pin!("bench_hj_outer", ["key"]),
    pin!("bench_hj_inner", ["key"]),
];
const PINS_HASHJOIN_LARGE_BUILD: &[ResidentPinSpec] = &[
    pin!("bench_hj_left", ["key"]),
    pin!("bench_hj_right", ["key"]),
];
const PINS_HASHJOIN_FILTER: &[ResidentPinSpec] = &[
    pin!("bench_hjf_fact", ["dim_id", "amount"]),
    pin!("bench_hjf_dim", ["id", "category", "name"]),
];
const PINS_MIXED_JOIN: &[ResidentPinSpec] = &[
    pin!("bench_mixed_facts", ["dim_id", "amount"]),
    pin!("bench_mixed_dims", ["id", "label"]),
];
const PINS_MIXED_JOIN_INT4: &[ResidentPinSpec] = &[
    pin!("bench_mixed_facts_int4", ["dim_id", "amount"]),
    pin!("bench_mixed_dims_int4", ["id", "label"]),
];

const SSBM_Q1_FACT: &[&str] = &[
    "lo_orderdate",
    "lo_extendedprice",
    "lo_discount",
    "lo_quantity",
];
const SSBM_Q2_FACT: &[&str] = &["lo_orderdate", "lo_partkey", "lo_suppkey", "lo_revenue"];
const SSBM_Q3_FACT: &[&str] = &["lo_orderdate", "lo_custkey", "lo_suppkey", "lo_revenue"];
const SSBM_Q4_FACT: &[&str] = &[
    "lo_orderdate",
    "lo_custkey",
    "lo_suppkey",
    "lo_partkey",
    "lo_revenue",
    "lo_supplycost",
];
const PINS_SSBM_RESIDENT_INT4_STAR: &[ResidentPinSpec] = &[
    pin!(
        "ssbm_lineorder",
        ["lo_orderdate", "lo_partkey", "lo_revenue"]
    ),
    pin!("ssbm_date", ["d_datekey", "d_year"]),
    pin!("ssbm_part", ["p_partkey", "p_size"]),
];
const PINS_SSBM_RESIDENT_INT8_STAR: &[ResidentPinSpec] = &[
    pin!(
        "ssbm_lineorder",
        ["lo_orderdate", "lo_partkey", "lo_revenue"]
    ),
    pin!("ssbm_date", ["d_datekey", "d_year"]),
    pin!("ssbm_part", ["p_partkey", "p_size"]),
];
const PINS_SSBM_Q1_1: &[ResidentPinSpec] = &[
    ResidentPinSpec {
        table: "ssbm_lineorder",
        columns: SSBM_Q1_FACT,
    },
    pin!("ssbm_date", ["d_datekey", "d_year"]),
];
const PINS_SSBM_Q1_2: &[ResidentPinSpec] = &[
    ResidentPinSpec {
        table: "ssbm_lineorder",
        columns: SSBM_Q1_FACT,
    },
    pin!("ssbm_date", ["d_datekey", "d_yearmonthnum"]),
];
const PINS_SSBM_Q1_3: &[ResidentPinSpec] = &[
    ResidentPinSpec {
        table: "ssbm_lineorder",
        columns: SSBM_Q1_FACT,
    },
    pin!("ssbm_date", ["d_datekey", "d_weeknuminyear", "d_year"]),
];
const PINS_SSBM_Q2_1: &[ResidentPinSpec] = &[
    ResidentPinSpec {
        table: "ssbm_lineorder",
        columns: SSBM_Q2_FACT,
    },
    pin!("ssbm_date", ["d_datekey", "d_year"]),
    pin!("ssbm_part", ["p_partkey", "p_category", "p_brand1"]),
    pin!("ssbm_supplier", ["s_suppkey", "s_region"]),
];
const PINS_SSBM_Q2_2_3: &[ResidentPinSpec] = &[
    ResidentPinSpec {
        table: "ssbm_lineorder",
        columns: SSBM_Q2_FACT,
    },
    pin!("ssbm_date", ["d_datekey", "d_year"]),
    pin!("ssbm_part", ["p_partkey", "p_brand1"]),
    pin!("ssbm_supplier", ["s_suppkey", "s_region"]),
];
const PINS_SSBM_Q3_1: &[ResidentPinSpec] = &[
    ResidentPinSpec {
        table: "ssbm_lineorder",
        columns: SSBM_Q3_FACT,
    },
    pin!("ssbm_date", ["d_datekey", "d_year"]),
    pin!("ssbm_customer", ["c_custkey", "c_nation", "c_region"]),
    pin!("ssbm_supplier", ["s_suppkey", "s_nation", "s_region"]),
];
const PINS_SSBM_Q3_2: &[ResidentPinSpec] = &[
    ResidentPinSpec {
        table: "ssbm_lineorder",
        columns: SSBM_Q3_FACT,
    },
    pin!("ssbm_date", ["d_datekey", "d_year"]),
    pin!("ssbm_customer", ["c_custkey", "c_city", "c_nation"]),
    pin!("ssbm_supplier", ["s_suppkey", "s_city", "s_nation"]),
];
const PINS_SSBM_Q3_3: &[ResidentPinSpec] = &[
    ResidentPinSpec {
        table: "ssbm_lineorder",
        columns: SSBM_Q3_FACT,
    },
    pin!("ssbm_date", ["d_datekey", "d_year"]),
    pin!("ssbm_customer", ["c_custkey", "c_city"]),
    pin!("ssbm_supplier", ["s_suppkey", "s_city"]),
];
const PINS_SSBM_Q3_4: &[ResidentPinSpec] = &[
    ResidentPinSpec {
        table: "ssbm_lineorder",
        columns: SSBM_Q3_FACT,
    },
    pin!("ssbm_date", ["d_datekey", "d_year", "d_yearmonth"]),
    pin!("ssbm_customer", ["c_custkey", "c_city"]),
    pin!("ssbm_supplier", ["s_suppkey", "s_city"]),
];
const PINS_SSBM_Q4_1: &[ResidentPinSpec] = &[
    ResidentPinSpec {
        table: "ssbm_lineorder",
        columns: SSBM_Q4_FACT,
    },
    pin!("ssbm_date", ["d_datekey", "d_year"]),
    pin!("ssbm_customer", ["c_custkey", "c_nation", "c_region"]),
    pin!("ssbm_supplier", ["s_suppkey", "s_region"]),
    pin!("ssbm_part", ["p_partkey", "p_mfgr"]),
];
const PINS_SSBM_Q4_2: &[ResidentPinSpec] = &[
    ResidentPinSpec {
        table: "ssbm_lineorder",
        columns: SSBM_Q4_FACT,
    },
    pin!("ssbm_date", ["d_datekey", "d_year"]),
    pin!("ssbm_customer", ["c_custkey", "c_region"]),
    pin!("ssbm_supplier", ["s_suppkey", "s_nation", "s_region"]),
    pin!("ssbm_part", ["p_partkey", "p_category", "p_mfgr"]),
];
const PINS_SSBM_Q4_3: &[ResidentPinSpec] = &[
    ResidentPinSpec {
        table: "ssbm_lineorder",
        columns: SSBM_Q4_FACT,
    },
    pin!("ssbm_date", ["d_datekey", "d_year"]),
    pin!("ssbm_customer", ["c_custkey", "c_region"]),
    pin!("ssbm_supplier", ["s_suppkey", "s_city", "s_nation"]),
    pin!("ssbm_part", ["p_partkey", "p_brand1", "p_category"]),
];
const PINS_TPCH_Q1: &[ResidentPinSpec] = &[pin!(
    "tpch_lineitem",
    ["l_returnflag", "l_linestatus", "l_shipdate"]
)];
const PINS_TPCH_Q6: &[ResidentPinSpec] = &[pin!("tpch_lineitem", ["l_shipdate"])];
const PINS_TPCH_Q12: &[ResidentPinSpec] = &[
    pin!("tpch_orders", ["o_orderkey", "o_orderpriority"]),
    pin!(
        "tpch_lineitem",
        [
            "l_orderkey",
            "l_shipmode",
            "l_commitdate",
            "l_receiptdate",
            "l_shipdate"
        ]
    ),
];
const PINS_CLICKBENCH_GROUPED: &[ResidentPinSpec] = &[pin!(
    "clickbench_hits",
    ["project_id", "event_type", "revenue"]
)];
const PINS_CLICKBENCH_DISTINCT: &[ResidentPinSpec] = &[pin!(
    "clickbench_hits",
    ["event_time", "country", "user_id", "is_mobile"]
)];
const PINS_CLICKBENCH_TOP_URLS: &[ResidentPinSpec] = &[pin!(
    "clickbench_hits",
    ["url", "duration_ms", "project_id"]
)];

/// Canonical registry. Exact workload names appear once and only once here.
pub const WORKLOAD_REGISTRY: &[WorkloadMetadata] = &[
    workload("gpu_reduce_sum", C::GpuReduce, K::Reduce),
    workload("gpu_reduce_scaling", C::GpuReduce, K::Reduce),
    workload("reduce_sum_f32", C::GpuReduce, K::Reduce),
    workload("reduce_sum_f64", C::GpuReduce, K::Reduce),
    workload("reduce_sum_i64", C::GpuReduce, K::Reduce),
    workload("reduce_min_f64", C::GpuReduce, K::Reduce),
    workload("reduce_max_f64", C::GpuReduce, K::Reduce),
    workload("reduce_multi", C::GpuReduce, K::Reduce),
    workload("grouped_agg", C::GpuHashAgg, K::HashAgg)
        .pins(PINS_GROUPED_AGG)
        .evidence(NATIVE_DECLINE),
    workload("grouped_agg_int4", C::GpuHashAgg, K::HashAgg)
        .pins(PINS_GROUPED_AGG_INT4)
        .evidence(WINNER),
    workload("grouped_count_bool_candidate", C::GpuHashAgg, K::HashAgg)
        .pins(PINS_GROUPED_COUNT_BOOL)
        .evidence(WINNER),
    workload("grouped_count_date_candidate", C::GpuHashAgg, K::HashAgg)
        .pins(PINS_GROUPED_COUNT_DATE)
        .evidence(WINNER),
    workload("grouped_count_float4_candidate", C::GpuHashAgg, K::HashAgg)
        .pins(PINS_GROUPED_COUNT_FLOAT4)
        .evidence(WINNER),
    workload("grouped_count_float8_candidate", C::GpuHashAgg, K::HashAgg)
        .pins(PINS_GROUPED_COUNT_FLOAT8)
        .evidence(WINNER),
    workload(
        "grouped_count_timestamp_candidate",
        C::GpuHashAgg,
        K::HashAgg,
    )
    .pins(PINS_GROUPED_COUNT_TIMESTAMP)
    .evidence(WINNER),
    workload(
        "grouped_count_timestamptz_candidate",
        C::GpuHashAgg,
        K::HashAgg,
    )
    .pins(PINS_GROUPED_COUNT_TIMESTAMPTZ)
    .evidence(WINNER),
    workload("grouped_count_int2_candidate", C::GpuHashAgg, K::HashAgg)
        .pins(PINS_GROUPED_COUNT_INT2)
        .evidence(WINNER),
    workload("grouped_count_int8_candidate", C::GpuHashAgg, K::HashAgg)
        .pins(PINS_GROUPED_COUNT_INT8)
        .evidence(WINNER),
    workload("grouped_int2_sum_avg_candidate", C::GpuHashAgg, K::HashAgg)
        .pins(PINS_GROUPED_INT2_SUM_AVG)
        .evidence(WINNER),
    workload("grouped_int4_sum_avg_candidate", C::GpuHashAgg, K::HashAgg)
        .pins(PINS_GROUPED_INT4_SUM_AVG)
        .evidence(WINNER),
    workload("grouped_int4_native_having", C::GpuHashAgg, K::HashAgg)
        .pins(PINS_GROUPED_INT4_SUM_AVG)
        .evidence(WINNER),
    workload("grouped_int4_hidden_having", C::GpuHashAgg, K::HashAgg)
        .pins(PINS_GROUPED_INT4_SUM_AVG)
        .evidence(WINNER),
    workload("grouped_int4_avg_only", C::GpuHashAgg, K::HashAgg)
        .pins(PINS_GROUPED_INT4_SUM_AVG)
        .evidence(WINNER),
    workload("grouped_multikey_integer", C::GpuHashAgg, K::HashAgg)
        .pins(&[ResidentPinSpec {
            table: "bench_multikey_sales",
            columns: &["region", "sales_day", "is_return", "amount"],
        }])
        .evidence(WINNER),
    workload("grouped_multimeasure_integer", C::GpuHashAgg, K::HashAgg)
        .pins(&[ResidentPinSpec {
            table: "bench_multimeasure_sales",
            columns: &[
                "region",
                "sales_day",
                "is_return",
                "amount",
                "units",
                "discount",
            ],
        }])
        .evidence(WINNER),
    workload("grouped_scalar_program", C::GpuHashAgg, K::HashAgg).pins(&[ResidentPinSpec {
        table: "bench_scalar_sales",
        columns: &["region", "price", "adjustment"],
    }]),
    workload("global_scalar_program", C::GpuReduce, K::Reduce).pins(&[ResidentPinSpec {
        table: "bench_scalar_sales",
        columns: &["price", "adjustment"],
    }]),
    workload("grouped_coalesced_integer", C::GpuHashAgg, K::HashAgg).pins(&[ResidentPinSpec {
        table: "bench_scalar_sales",
        columns: &["region", "price", "adjustment"],
    }]),
    workload("grouped_simple_case", C::GpuHashAgg, K::HashAgg).pins(&[ResidentPinSpec {
        table: "bench_scalar_sales",
        columns: &["region", "price", "adjustment"],
    }]),
    workload("grouped_simple_case_linear", C::GpuHashAgg, K::HashAgg).pins(&[ResidentPinSpec {
        table: "bench_scalar_sales",
        columns: &["region", "price", "adjustment"],
    }]),
    workload("grouped_membership_integer", C::GpuHashAgg, K::HashAgg).pins(&[ResidentPinSpec {
        table: "bench_scalar_sales",
        columns: &["region", "price", "adjustment"],
    }]),
    workload("grouped_scalar_filter", C::GpuHashAgg, K::HashAgg).pins(&[ResidentPinSpec {
        table: "bench_scalar_sales",
        columns: &["region", "price", "adjustment"],
    }]),
    workload("grouped_date_span", C::GpuHashAgg, K::HashAgg).pins(&[ResidentPinSpec {
        table: "bench_scalar_sales",
        columns: &["region", "order_date", "ship_date"],
    }]),
    workload("spatial_grouped_date_span", C::GpuHashAgg, K::HashAgg)
        .pins(&[ResidentPinSpec {
            table: "bench_scalar_sales",
            columns: &["region", "order_date", "ship_date", "geom"],
        }])
        .extensions(POSTGIS),
    workload("spatial_grouped_scalar_filter", C::GpuHashAgg, K::HashAgg)
        .pins(&[ResidentPinSpec {
            table: "bench_scalar_sales",
            columns: &["region", "price", "adjustment", "geom"],
        }])
        .extensions(POSTGIS),
    workload(
        "spatial_grouped_membership_integer",
        C::GpuHashAgg,
        K::HashAgg,
    )
    .pins(&[ResidentPinSpec {
        table: "bench_scalar_sales",
        columns: &["region", "price", "adjustment", "geom"],
    }])
    .extensions(POSTGIS),
    workload("spatial_global_scalar_program", C::GpuReduce, K::Reduce)
        .pins(&[ResidentPinSpec {
            table: "bench_scalar_sales",
            columns: &["price", "adjustment", "geom"],
        }])
        .extensions(POSTGIS),
    workload("spatial_grouped_scalar_program", C::GpuHashAgg, K::HashAgg)
        .pins(&[ResidentPinSpec {
            table: "bench_scalar_sales",
            columns: &["region", "price", "adjustment", "geom"],
        }])
        .extensions(POSTGIS),
    workload("grouped_computed_integer", C::GpuHashAgg, K::HashAgg).pins(&[ResidentPinSpec {
        table: "bench_computed_sales",
        columns: &["region", "price", "adjustment"],
    }]),
    workload("global_computed_integer", C::GpuHashAgg, K::HashAgg)
        .pins(&[ResidentPinSpec {
            table: "bench_computed_sales",
            columns: &["price", "adjustment"],
        }])
        .evidence(WINNER),
    workload("grouped_filtered_integer", C::GpuHashAgg, K::HashAgg)
        .pins(&[ResidentPinSpec {
            table: "bench_filtered_sales",
            columns: &["region", "sales_day", "is_return", "amount", "units"],
        }])
        .evidence(WINNER),
    workload(
        "grouped_boolean_filtered_integer",
        C::GpuHashAgg,
        K::HashAgg,
    )
    .pins(&[ResidentPinSpec {
        table: "bench_filtered_sales",
        columns: &["region", "sales_day", "is_return", "amount", "units"],
    }])
    .evidence(WINNER),
    workload(
        "grouped_conditional_integer_counts",
        C::GpuHashAgg,
        K::HashAgg,
    )
    .pins(&[ResidentPinSpec {
        table: "bench_filtered_sales",
        columns: &["region", "sales_day", "is_return", "amount", "units"],
    }])
    .evidence(WINNER),
    workload("grouped_agg_high_card", C::GpuHashAgg, K::HashAgg)
        .pins(PINS_GROUPED_AGG_HIGH_CARD)
        .evidence(NATIVE_DECLINE),
    workload("gpu_hashagg_med_card", C::GpuHashAgg, K::HashAgg)
        .pins(PINS_HASHAGG_MED)
        .evidence(NATIVE_DECLINE),
    workload("timeseries_sensor_rollup", C::GpuHashAgg, K::HashAgg)
        .pins(PINS_TIMESERIES)
        .evidence(NATIVE_DECLINE),
    workload("dictionary_grouped_agg", C::GpuHashAgg, K::Unclassified)
        .pins(PINS_DICTIONARY)
        .evidence(NATIVE_DECLINE),
    workload("expression_grouped_agg", C::GpuHashAgg, K::HashAgg)
        .pins(PINS_EXPRESSION)
        .evidence(NATIVE_DECLINE),
    workload(
        "predicate_filter_expression_grouped_agg",
        C::GpuHashAgg,
        K::HashAgg,
    )
    .pins(PINS_PREDICATE_EXPRESSION)
    .evidence(NATIVE_DECLINE),
    workload(
        "predicate_expression_grouped_agg_int4",
        C::GpuHashAgg,
        K::HashAgg,
    )
    .pins(PINS_PREDICATE_EXPRESSION_INT4)
    .evidence(WINNER),
    workload(
        "aggregate_filter_grouped_agg_int4",
        C::GpuHashAgg,
        K::HashAgg,
    )
    .pins(PINS_AGGREGATE_FILTER_INT4)
    .evidence(WINNER),
    workload(
        "and_range_predicate_expression_grouped_agg_int4",
        C::GpuHashAgg,
        K::HashAgg,
    )
    .pins(PINS_AND_RANGE_PREDICATE_EXPRESSION_INT4)
    .evidence(WINNER),
    workload(
        "case_when_expression_grouped_agg",
        C::GpuHashAgg,
        K::HashAgg,
    )
    .pins(PINS_CASE_EXPRESSION)
    .evidence(NATIVE_DECLINE),
    workload(
        "case_when_range_expression_grouped_agg",
        C::GpuHashAgg,
        K::HashAgg,
    )
    .pins(PINS_CASE_RANGE)
    .evidence(NATIVE_DECLINE),
    workload(
        "case_when_value_predicate_expression_grouped_agg",
        C::GpuHashAgg,
        K::HashAgg,
    )
    .pins(PINS_CASE_VALUE)
    .evidence(NATIVE_DECLINE),
    workload(
        "case_when_null_predicate_expression_grouped_agg",
        C::GpuHashAgg,
        K::HashAgg,
    )
    .pins(PINS_CASE_NULL)
    .evidence(NATIVE_DECLINE),
    workload(
        "case_when_or_expression_grouped_agg",
        C::GpuHashAgg,
        K::HashAgg,
    )
    .pins(PINS_CASE_OR)
    .evidence(NATIVE_DECLINE),
    workload(
        "case_when_in_expression_grouped_agg",
        C::GpuHashAgg,
        K::HashAgg,
    )
    .pins(PINS_CASE_IN)
    .evidence(NATIVE_DECLINE),
    workload(
        "case_when_not_expression_grouped_agg",
        C::GpuHashAgg,
        K::HashAgg,
    )
    .pins(PINS_CASE_NOT)
    .evidence(NATIVE_DECLINE),
    workload("hashagg_10g", C::GpuHashAgg, K::HashAgg)
        .pins(PINS_HASHAGG_SWEEP)
        .evidence(NATIVE_DECLINE),
    workload("hashagg_100g", C::GpuHashAgg, K::HashAgg)
        .pins(PINS_HASHAGG_SWEEP)
        .evidence(NATIVE_DECLINE),
    workload("hashagg_256g", C::GpuHashAgg, K::HashAgg)
        .pins(PINS_HASHAGG_SWEEP)
        .evidence(NATIVE_DECLINE),
    workload("hashagg_1kg", C::GpuHashAgg, K::HashAgg)
        .pins(PINS_HASHAGG_SWEEP)
        .evidence(NATIVE_DECLINE),
    workload("hashagg_10kg", C::GpuHashAgg, K::HashAgg)
        .pins(PINS_HASHAGG_SWEEP)
        .evidence(NATIVE_DECLINE),
    workload("large_sort", C::GpuSort, K::Sort).evidence(NATIVE_DECLINE),
    workload("gpu_sort_multikey", C::GpuSort, K::Sort).evidence(NATIVE_DECLINE),
    workload("gpu_sort_topk_wide", C::GpuSort, K::Sort).evidence(NATIVE_DECLINE),
    workload("sort_int4", C::GpuSort, K::Sort).evidence(NATIVE_DECLINE),
    workload("sort_int8", C::GpuSort, K::Sort).evidence(NATIVE_DECLINE),
    workload("sort_float4", C::GpuSort, K::Sort).evidence(NATIVE_DECLINE),
    workload("sort_float8", C::GpuSort, K::Sort).evidence(NATIVE_DECLINE),
    workload("hash_join", C::GpuHashJoin, K::HashJoin)
        .pins(PINS_HASH_JOIN)
        .evidence(WINNER),
    workload(
        "weighted_global_count_int4",
        C::GpuHashJoin,
        K::ResidentStarGroupAgg,
    )
    .pins(PINS_WEIGHTED_GLOBAL_COUNT_INT4)
    .evidence(WINNER),
    workload("gpu_hashjoin_large_build", C::GpuHashJoin, K::HashJoin)
        .pins(PINS_HASHJOIN_LARGE_BUILD),
    workload(
        "gpu_hashjoin_filter",
        C::GpuHashJoin,
        K::ResidentStarGroupAgg,
    )
    .pins(PINS_HASHJOIN_FILTER)
    .evidence(NATIVE_DECLINE),
    workload("gpu_nlj_between", C::GpuJoin, K::NestedLoopInequality).evidence(NATIVE_DECLINE),
    workload("hashjoin_100_1m", C::GpuHashJoin, K::HashJoin).pins(PINS_HASHJOIN_SWEEP),
    workload("hashjoin_1k_1m", C::GpuHashJoin, K::HashJoin).pins(PINS_HASHJOIN_SWEEP),
    workload("hashjoin_10k_1m", C::GpuHashJoin, K::HashJoin)
        .pins(PINS_HASHJOIN_SWEEP)
        .evidence(WINNER),
    workload("hashjoin_100k_1m", C::GpuHashJoin, K::HashJoin).pins(PINS_HASHJOIN_SWEEP),
    workload("spatial_filter", C::GpuSpatial, K::PointInRing)
        .extensions(POSTGIS)
        .evidence(NATIVE_DECLINE),
    workload(
        "spatial_resident_agg_candidate",
        C::GpuSpatial,
        K::PointInRing,
    )
    .pins(PINS_SPATIAL_RESIDENT_AGG)
    .extensions(POSTGIS)
    .evidence(WINNER),
    workload("spatial_complex_poly", C::GpuSpatial, K::PointInRing).extensions(POSTGIS),
    workload("spatial_holes_intersects", C::GpuSpatial, K::PointInRing)
        .pins(PINS_SPATIAL_RESIDENT_AGG)
        .extensions(POSTGIS)
        .evidence(WINNER),
    workload("spatial_holes_contains", C::GpuSpatial, K::PointInRing)
        .pins(PINS_SPATIAL_RESIDENT_AGG)
        .extensions(POSTGIS)
        .evidence(WINNER),
    workload("spatial_holes_within", C::GpuSpatial, K::PointInRing)
        .pins(PINS_SPATIAL_RESIDENT_AGG)
        .extensions(POSTGIS)
        .evidence(WINNER),
    workload("spatial_holes_covers", C::GpuSpatial, K::PointInRing)
        .pins(PINS_SPATIAL_RESIDENT_AGG)
        .extensions(POSTGIS)
        .evidence(WINNER),
    workload("spatial_holes_coveredby", C::GpuSpatial, K::PointInRing)
        .pins(PINS_SPATIAL_RESIDENT_AGG)
        .extensions(POSTGIS)
        .evidence(WINNER),
    workload("spatial_selectivity", C::GpuSpatial, K::PointInRing)
        .extensions(POSTGIS)
        .evidence(NATIVE_DECLINE),
    workload("spatial_mega_1kv", C::GpuSpatial, K::PointInRing)
        .extensions(POSTGIS)
        .evidence(NATIVE_DECLINE),
    workload("vsweep_low", C::GpuSpatial, K::PointInRing)
        .extensions(POSTGIS)
        .evidence(NATIVE_DECLINE),
    workload("vsweep_mid", C::GpuSpatial, K::PointInRing)
        .extensions(POSTGIS)
        .evidence(NATIVE_DECLINE),
    workload("vsweep_high", C::GpuSpatial, K::PointInRing)
        .extensions(POSTGIS)
        .evidence(NATIVE_DECLINE),
    workload("vsweep_pathological", C::GpuSpatial, K::PointInRing)
        .extensions(POSTGIS)
        .evidence(NATIVE_DECLINE),
    workload("spatial_concentric", C::GpuSpatial, K::PointInRing).extensions(POSTGIS),
    workload("spatial_star_1kv", C::GpuSpatial, K::PointInRing).extensions(POSTGIS),
    workload("spatial_multihole", C::GpuSpatial, K::PointInRing).extensions(POSTGIS),
    workload("spatial_zigzag", C::GpuSpatial, K::PointInRing).extensions(POSTGIS),
    workload("spatial_sel_1pct", C::GpuSpatial, K::PointInRing)
        .extensions(POSTGIS)
        .evidence(NATIVE_DECLINE),
    workload("spatial_sel_10pct", C::GpuSpatial, K::PointInRing)
        .extensions(POSTGIS)
        .evidence(NATIVE_DECLINE),
    workload("spatial_sel_50pct", C::GpuSpatial, K::PointInRing)
        .extensions(POSTGIS)
        .evidence(NATIVE_DECLINE),
    workload("spatial_sel_90pct", C::GpuSpatial, K::PointInRing)
        .extensions(POSTGIS)
        .evidence(NATIVE_DECLINE),
    workload("h3_bulk", C::GpuH3, K::H3LatLng)
        .extensions(H3)
        .h3(H3LaneClass::Parity)
        .evidence(H3_NATIVE_DECLINE),
    workload("h3_cell_to_parent", C::GpuH3, K::H3CellToParent)
        .pins(PINS_H3_PARENT)
        .extensions(H3)
        .h3(H3LaneClass::Winning {
            min_warm_speedup: 1.15,
        })
        .evidence(H3_WINNER),
    workload("h3_parent_res4", C::GpuH3, K::H3CellToParent)
        .pins(PINS_H3_PARENT)
        .extensions(H3)
        .h3(H3LaneClass::Winning {
            min_warm_speedup: 1.15,
        })
        .evidence(H3_WINNER),
    workload("h3_parent_res9", C::GpuH3, K::H3CellToParent)
        .pins(PINS_H3_PARENT)
        .extensions(H3)
        .h3(H3LaneClass::Winning {
            min_warm_speedup: 1.15,
        })
        .evidence(H3_WINNER),
    workload("h3_parent_res15", C::GpuH3, K::H3CellToParent)
        .pins(PINS_H3_PARENT)
        .extensions(H3)
        .h3(H3LaneClass::Winning {
            min_warm_speedup: 1.15,
        })
        .evidence(H3_WINNER),
    workload("h3_grid_distance", C::GpuH3, K::H3LatLng)
        .extensions(H3)
        .h3(H3LaneClass::Parity)
        .evidence(H3_NATIVE_DECLINE),
    workload("h3_resolution_sweep", C::GpuH3, K::H3LatLng)
        .extensions(H3)
        .h3(H3LaneClass::Parity)
        .evidence(H3_NATIVE_DECLINE),
    workload("h3_srf_grid_disk", C::GpuH3, K::H3LatLng)
        .extensions(H3)
        .h3(H3LaneClass::Parity)
        .evidence(H3_NATIVE_DECLINE),
    workload("h3_latlng_res15", C::GpuH3, K::H3LatLng)
        .extensions(H3)
        .h3(H3LaneClass::Parity)
        .evidence(H3_NATIVE_DECLINE),
    workload("h3_dist_near", C::GpuH3, K::H3LatLng)
        .extensions(H3)
        .h3(H3LaneClass::Parity)
        .evidence(H3_NATIVE_DECLINE),
    workload("h3_dist_far", C::GpuH3, K::H3LatLng)
        .extensions(H3)
        .h3(H3LaneClass::Parity)
        .evidence(H3_NATIVE_DECLINE),
    workload("h3_parent_deep", C::GpuH3, K::H3LatLng)
        .extensions(H3)
        .h3(H3LaneClass::Parity)
        .evidence(H3_NATIVE_DECLINE),
    workload("gpu_expr_filter", C::GpuExpr, K::Expr),
    workload("gpu_expr_complex", C::GpuExpr, K::Expr),
    workload("gpu_expr_null_heavy", C::GpuExpr, K::Expr),
    workload("expr_2pred", C::GpuExpr, K::Expr),
    workload("expr_3pred", C::GpuExpr, K::Expr),
    workload("expr_4pred", C::GpuExpr, K::Expr),
    workload("expr_arith_chain", C::GpuExpr, K::Expr),
    workload("expr_deep_arith", C::GpuExpr, K::Expr),
    workload("expr_multi_or", C::GpuExpr, K::Expr),
    workload("expr_sqrt_heavy", C::GpuExpr, K::Expr),
    workload("expr_pow_chain", C::GpuExpr, K::Expr),
    workload("expr_math_mixed", C::GpuExpr, K::Expr),
    workload("window_analytics", C::GpuWindow, K::Window).evidence(NATIVE_DECLINE),
    workload("window_row_number", C::GpuWindow, K::Window).evidence(NATIVE_DECLINE),
    workload("window_rank", C::GpuWindow, K::Window).evidence(NATIVE_DECLINE),
    workload("window_dense_rank", C::GpuWindow, K::Window).evidence(NATIVE_DECLINE),
    workload("window_running_sum", C::GpuWindow, K::Window).evidence(NATIVE_DECLINE),
    workload("window_lag", C::GpuWindow, K::Window),
    workload("window_lead", C::GpuWindow, K::Window),
    workload("window_full_output_decline", C::GpuWindow, K::Window).evidence(NATIVE_DECLINE),
    workload("window_reducing_decline", C::GpuWindow, K::Window).evidence(NATIVE_DECLINE),
    workload(
        "ssbm_resident_int4_star",
        C::StarSchemaSsbm,
        K::ResidentStarGroupAgg,
    )
    .pins(PINS_SSBM_RESIDENT_INT4_STAR)
    .evidence(WINNER),
    workload(
        "ssbm_resident_int8_star",
        C::StarSchemaSsbm,
        K::ResidentStarGroupAgg,
    )
    .pins(PINS_SSBM_RESIDENT_INT8_STAR)
    .evidence(WINNER),
    workload("ssbm_q1_1", C::StarSchemaSsbm, K::ResidentStarGroupAgg)
        .pins(PINS_SSBM_Q1_1)
        .evidence(NATIVE_DECLINE),
    workload("ssbm_q1_2", C::StarSchemaSsbm, K::ResidentStarGroupAgg)
        .pins(PINS_SSBM_Q1_2)
        .evidence(NATIVE_DECLINE),
    workload("ssbm_q1_3", C::StarSchemaSsbm, K::ResidentStarGroupAgg)
        .pins(PINS_SSBM_Q1_3)
        .evidence(NATIVE_DECLINE),
    workload("ssbm_q2_1", C::StarSchemaSsbm, K::ResidentStarGroupAgg)
        .pins(PINS_SSBM_Q2_1)
        .evidence(NATIVE_DECLINE),
    workload("ssbm_q2_2", C::StarSchemaSsbm, K::ResidentStarGroupAgg)
        .pins(PINS_SSBM_Q2_2_3)
        .evidence(NATIVE_DECLINE),
    workload("ssbm_q2_3", C::StarSchemaSsbm, K::ResidentStarGroupAgg)
        .pins(PINS_SSBM_Q2_2_3)
        .evidence(NATIVE_DECLINE),
    workload("ssbm_q3_1", C::StarSchemaSsbm, K::ResidentStarGroupAgg)
        .pins(PINS_SSBM_Q3_1)
        .evidence(NATIVE_DECLINE),
    workload("ssbm_q3_2", C::StarSchemaSsbm, K::ResidentStarGroupAgg)
        .pins(PINS_SSBM_Q3_2)
        .evidence(NATIVE_DECLINE),
    workload("ssbm_q3_3", C::StarSchemaSsbm, K::ResidentStarGroupAgg)
        .pins(PINS_SSBM_Q3_3)
        .evidence(NATIVE_DECLINE),
    workload("ssbm_q3_4", C::StarSchemaSsbm, K::ResidentStarGroupAgg)
        .pins(PINS_SSBM_Q3_4)
        .evidence(NATIVE_DECLINE),
    workload("ssbm_q4_1", C::StarSchemaSsbm, K::ResidentStarGroupAgg)
        .pins(PINS_SSBM_Q4_1)
        .evidence(NATIVE_DECLINE),
    workload("ssbm_q4_2", C::StarSchemaSsbm, K::ResidentStarGroupAgg)
        .pins(PINS_SSBM_Q4_2)
        .evidence(NATIVE_DECLINE),
    workload("ssbm_q4_3", C::StarSchemaSsbm, K::ResidentStarGroupAgg)
        .pins(PINS_SSBM_Q4_3)
        .evidence(NATIVE_DECLINE),
    workload("tpch_q1", C::Tpch, K::HashAgg).pins(PINS_TPCH_Q1),
    workload("tpch_q6", C::Tpch, K::Reduce).pins(PINS_TPCH_Q6),
    workload("tpch_q12", C::Tpch, K::HashAgg).pins(PINS_TPCH_Q12),
    workload("clickbench_grouped_events", C::ClickBench, K::HashAgg).pins(PINS_CLICKBENCH_GROUPED),
    workload("clickbench_distinct_users", C::ClickBench, K::HashAgg).pins(PINS_CLICKBENCH_DISTINCT),
    workload("clickbench_top_urls", C::ClickBench, K::Sort).pins(PINS_CLICKBENCH_TOP_URLS),
    workload("nyc_taxi_h3_res9", C::NycTaxi, K::H3CellToParent)
        .extensions(H3)
        .pins(&[ResidentPinSpec {
            table: "bench_nyc_taxi",
            columns: &["cell"],
        }]),
    workload("nyc_taxi_airport_indexed", C::NycTaxi, K::PointInRing)
        .extensions(POSTGIS)
        .pins(&[ResidentPinSpec {
            table: "bench_nyc_taxi",
            columns: &["pickup_geom"],
        }]),
    workload("nyc_taxi_airport_scan", C::NycTaxi, K::PointInRing)
        .extensions(POSTGIS)
        .pins(&[ResidentPinSpec {
            table: "bench_nyc_taxi",
            columns: &["pickup_geom"],
        }]),
    workload("nyc_taxi_fare_rollup", C::NycTaxi, K::HashAgg).pins(&[ResidentPinSpec {
        table: "bench_nyc_taxi",
        columns: &[
            "vendor_id",
            "passenger_count",
            "fare_amount",
            "trip_distance",
        ],
    }]),
    workload("nyc_taxi_mixed_rollup", C::NycTaxi, K::HashAgg).pins(&[ResidentPinSpec {
        table: "bench_nyc_taxi",
        columns: &[
            "vendor_id",
            "passenger_count",
            "fare_amount",
            "trip_distance",
        ],
    }]),
    workload("numeric_global_sum_avg", C::GpuHashAgg, K::HashAgg).pins(&[ResidentPinSpec {
        table: "bench_numeric_rollup",
        columns: &["v"],
    }]),
    workload("bigint_global_sum_avg", C::GpuHashAgg, K::HashAgg).pins(&[ResidentPinSpec {
        table: "bench_bigint_rollup",
        columns: &["v"],
    }]),
    workload("bigint_nullable_filters", C::GpuHashAgg, K::HashAgg).pins(&[ResidentPinSpec {
        table: "bench_bigint_rollup",
        columns: &["g", "h", "v"],
    }]),
    workload("bigint_grouped_sum_avg", C::GpuHashAgg, K::HashAgg).pins(&[ResidentPinSpec {
        table: "bench_bigint_rollup",
        columns: &["g", "h", "k", "v", "w"],
    }]),
    workload("bigint_filtered_mixed", C::GpuHashAgg, K::HashAgg).pins(&[ResidentPinSpec {
        table: "bench_bigint_rollup",
        columns: &["g", "h", "k", "v", "w", "qty"],
    }]),
    workload("numeric_global_count", C::GpuHashAgg, K::HashAgg).pins(&[ResidentPinSpec {
        table: "bench_numeric_rollup",
        columns: &["v", "w"],
    }]),
    workload("numeric_mixed_global", C::GpuHashAgg, K::HashAgg).pins(&[ResidentPinSpec {
        table: "bench_numeric_rollup",
        columns: &["v", "qty", "g"],
    }]),
    workload("integer_where_ranges", C::GpuHashAgg, K::HashAgg).pins(&[ResidentPinSpec {
        table: "bench_filtered_sales",
        columns: &["region", "sales_day", "is_return", "amount", "units"],
    }]),
    workload("integer_where_mask", C::GpuHashAgg, K::HashAgg).pins(&[ResidentPinSpec {
        table: "bench_filtered_sales",
        columns: &["is_return", "amount", "units"],
    }]),
    workload("global_boolean_filtered_integer", C::GpuHashAgg, K::HashAgg).pins(&[
        ResidentPinSpec {
            table: "bench_filtered_sales",
            columns: &["amount", "units"],
        },
    ]),
    workload(
        "global_conditional_integer_counts",
        C::GpuHashAgg,
        K::HashAgg,
    )
    .pins(&[ResidentPinSpec {
        table: "bench_filtered_sales",
        columns: &["amount", "units"],
    }]),
    workload("numeric_where_ranges", C::GpuHashAgg, K::HashAgg).pins(&[ResidentPinSpec {
        table: "bench_numeric_rollup",
        columns: &["g", "h", "k", "v", "qty"],
    }]),
    workload("numeric_where_mask", C::GpuHashAgg, K::HashAgg).pins(&[ResidentPinSpec {
        table: "bench_numeric_rollup",
        columns: &["v", "w", "qty", "b"],
    }]),
    workload("nyc_taxi_filtered_rollup", C::NycTaxi, K::HashAgg).pins(&[ResidentPinSpec {
        table: "bench_nyc_taxi",
        columns: &["vendor_id", "fare_amount", "trip_distance"],
    }]),
    workload("nyc_taxi_airport_passengers", C::NycTaxi, K::HashAgg).pins(&[ResidentPinSpec {
        table: "bench_nyc_taxi",
        columns: &["vendor_id", "passenger_count", "pickup_geom"],
    }]),
    workload("nyc_taxi_passenger_where", C::NycTaxi, K::HashAgg).pins(&[ResidentPinSpec {
        table: "bench_nyc_taxi",
        columns: &["vendor_id", "passenger_count"],
    }]),
    workload("nyc_taxi_nullable_passengers", C::NycTaxi, K::HashAgg).pins(&[ResidentPinSpec {
        table: "bench_nyc_taxi",
        columns: &["vendor_id", "passenger_count"],
    }]),
    workload(
        "nyc_taxi_airport_nullable_passengers",
        C::NycTaxi,
        K::HashAgg,
    )
    .pins(&[ResidentPinSpec {
        table: "bench_nyc_taxi",
        columns: &["vendor_id", "passenger_count", "pickup_geom"],
    }]),
    workload("nyc_taxi_passenger_filters", C::NycTaxi, K::HashAgg).pins(&[ResidentPinSpec {
        table: "bench_nyc_taxi",
        columns: &["vendor_id", "passenger_count"],
    }]),
    workload("nyc_taxi_airport_passenger_filters", C::NycTaxi, K::HashAgg).pins(&[
        ResidentPinSpec {
            table: "bench_nyc_taxi",
            columns: &["vendor_id", "passenger_count", "pickup_geom"],
        },
    ]),
    workload("nyc_taxi_airport_vendor_passengers", C::NycTaxi, K::HashAgg).pins(&[
        ResidentPinSpec {
            table: "bench_nyc_taxi",
            columns: &["vendor_id", "passenger_count", "pickup_geom"],
        },
    ]),
    workload("nyc_taxi_airport_vendor_rollup", C::NycTaxi, K::HashAgg).pins(&[ResidentPinSpec {
        table: "bench_nyc_taxi",
        columns: &["vendor_id", "fare_amount", "trip_distance", "pickup_geom"],
    }]),
    workload("nyc_taxi_passenger_extrema", C::NycTaxi, K::HashAgg).pins(&[ResidentPinSpec {
        table: "bench_nyc_taxi",
        columns: &["vendor_id", "passenger_count"],
    }]),
    workload("nyc_taxi_airport_passenger_extrema", C::NycTaxi, K::HashAgg).pins(&[
        ResidentPinSpec {
            table: "bench_nyc_taxi",
            columns: &["vendor_id", "passenger_count", "pickup_geom"],
        },
    ]),
    workload("nyc_taxi_airport_rollup", C::NycTaxi, K::HashAgg).pins(&[ResidentPinSpec {
        table: "bench_nyc_taxi",
        columns: &[
            "vendor_id",
            "fare_amount",
            "trip_distance",
            "passenger_count",
            "pickup_geom",
        ],
    }]),
    workload("numeric_mixed_grouped", C::GpuHashAgg, K::HashAgg).pins(&[ResidentPinSpec {
        table: "bench_numeric_rollup",
        columns: &["g", "h", "k", "v", "qty"],
    }]),
    workload("numeric_grouped_counts", C::GpuHashAgg, K::HashAgg).pins(&[ResidentPinSpec {
        table: "bench_numeric_rollup",
        columns: &["g", "h", "k", "v", "w"],
    }]),
    workload("numeric_grouped_sum_count", C::GpuHashAgg, K::HashAgg).pins(&[ResidentPinSpec {
        table: "bench_numeric_rollup",
        columns: &["g", "h", "v", "w"],
    }]),
    workload("numeric_grouped_three_keys", C::GpuHashAgg, K::HashAgg).pins(&[ResidentPinSpec {
        table: "bench_numeric_rollup",
        columns: &["g", "h", "k", "v", "w"],
    }]),
    workload("numeric_grouped_wide_scale", C::GpuHashAgg, K::HashAgg).pins(&[ResidentPinSpec {
        table: "bench_numeric_rollup",
        columns: &["g", "v"],
    }]),
    workload("numeric_grouped_filtered", C::GpuHashAgg, K::HashAgg).pins(&[ResidentPinSpec {
        table: "bench_numeric_rollup",
        columns: &["g", "h", "k", "v", "w"],
    }]),
    workload("parallel_stress", C::GpuReduce, K::Unclassified),
    workload("parallel_stress_grouped", C::GpuHashAgg, K::Unclassified),
    workload("parallel_stress_sort", C::GpuSort, K::Unclassified),
    workload("parallel_stress_window", C::GpuWindow, K::Unclassified),
    workload("spatial_agg", C::Mixed, K::HashAgg).extensions(POSTGIS),
    workload("spatial_sort", C::Mixed, K::Sort).extensions(POSTGIS),
    workload("filtered_grouped_agg", C::Mixed, K::HashAgg)
        .pins(PINS_FILTERED_GROUPAGG)
        .evidence(NATIVE_DECLINE),
    workload("mixed_megapoly_agg", C::Mixed, K::PointInRing).extensions(POSTGIS),
    workload("mixed_expr_agg", C::Mixed, K::Expr),
    workload("mixed_join_agg", C::Mixed, K::ResidentStarGroupAgg)
        .pins(PINS_MIXED_JOIN)
        .evidence(NATIVE_DECLINE),
    workload("mixed_join_agg_int4", C::Mixed, K::ResidentStarGroupAgg)
        .pins(PINS_MIXED_JOIN_INT4)
        .evidence(WINNER),
    workload("mixed_spatial_sort", C::Mixed, K::Sort).extensions(POSTGIS),
    workload("raster_ndvi", C::GpuRaster, K::Raster)
        .extensions(POSTGIS_RASTER)
        .evidence(RASTER_NATIVE_DECLINE),
    workload("raster_slope", C::GpuRaster, K::Raster)
        .extensions(POSTGIS_RASTER)
        .evidence(RASTER_NATIVE_DECLINE),
    workload("raster_reclass", C::GpuRaster, K::Raster)
        .extensions(POSTGIS_RASTER)
        .evidence(RASTER_NATIVE_DECLINE),
    workload("raster_algebra_deep", C::GpuRaster, K::Raster)
        .extensions(POSTGIS_RASTER)
        .evidence(RASTER_NATIVE_DECLINE),
    workload("raster_resident_exact_reclass", C::GpuRaster, K::Raster)
        .pins(PINS_RASTER_RESIDENT_EXACT_RECLASS)
        .extensions(POSTGIS_RASTER)
        .evidence(RASTER_WINNER),
    workload("proximity", C::Regression, K::PointInRing).extensions(POSTGIS),
    workload("index_recheck", C::Regression, K::PointInRing).extensions(POSTGIS),
    workload("spatial_join", C::Regression, K::PointInRing).extensions(POSTGIS),
    workload("spatial_contains", C::Regression, K::PointInRing).extensions(POSTGIS),
    workload("spatial_multi_pred", C::Regression, K::PointInRing).extensions(POSTGIS),
    workload("oltp_point_lookup", C::Regression, K::PointInRing),
    workload("aggregate_ordered_set_decline", C::Regression, K::HashAgg).evidence(NATIVE_DECLINE),
    workload(
        "aggregate_semantic_modifier_decline",
        C::Regression,
        K::HashAgg,
    )
    .evidence(NATIVE_DECLINE),
    workload("anti_join_null_decline", C::Regression, K::HashJoin).evidence(NATIVE_DECLINE),
    workload("avg_nonfloat_decline", C::Regression, K::Reduce).evidence(NATIVE_DECLINE),
    workload(
        "bitmap_heap_gpuexpr_decline",
        C::Regression,
        K::Unclassified,
    )
    .evidence(NATIVE_DECLINE),
    workload("mergejoin_decline", C::Regression, K::MergeJoin).evidence(NATIVE_DECLINE),
    workload("numeric_agg_decline", C::Regression, K::Reduce).evidence(NATIVE_DECLINE),
    workload("in_join_null_decline", C::Regression, K::HashJoin).evidence(NATIVE_DECLINE),
    workload("not_in_join_null_decline", C::Regression, K::HashJoin).evidence(NATIVE_DECLINE),
    workload(
        "parallel_hashjoin_rebuild_decline",
        C::Regression,
        K::Unclassified,
    )
    .evidence(NATIVE_DECLINE),
    workload("recursive_union_decline", C::Regression, K::RecursiveUnion).evidence(NATIVE_DECLINE),
    workload("semi_join_null_decline", C::Regression, K::HashJoin).evidence(NATIVE_DECLINE),
    workload("setop_intersect_decline", C::Regression, K::SetOp).evidence(NATIVE_DECLINE),
    workload("small_table_scan", C::Regression, K::Unclassified),
    workload("topk_wide", C::Regression, K::Sort).evidence(NATIVE_DECLINE),
    workload("reduce_f64_sum", C::Fp64Matrix, K::ResidentF64Reduce)
        .pins(PINS_REDUCE_F64)
        .evidence(FP64_NATIVE_DECLINE),
    workload("reduce_f64_minmax", C::Fp64Matrix, K::ResidentF64Reduce)
        .pins(PINS_REDUCE_F64)
        .evidence(FP64_NATIVE_DECLINE),
    workload("reduce_f64_stats", C::Fp64Matrix, K::ResidentF64Reduce)
        .pins(PINS_REDUCE_F64)
        .evidence(FP64_NATIVE_DECLINE),
    workload("sort_f64_keys", C::Fp64Matrix, K::Unclassified).evidence(FP64_CALIBRATION),
    workload("hashagg_f64_keys", C::Fp64Matrix, K::HashAgg).evidence(FP64_CALIBRATION),
    workload(
        "hashagg_f64_aggs",
        C::Fp64Matrix,
        K::ResidentF64GroupedStats,
    )
    .pins(PINS_HASHAGG_F64)
    .evidence(FP64_NATIVE_DECLINE),
    workload("spatial_fp64_recheck", C::Fp64Matrix, K::Unclassified)
        .extensions(POSTGIS)
        .evidence(FP64_CALIBRATION),
    workload("h3_fp64_ops", C::Fp64Matrix, K::H3LatLng)
        .extensions(H3)
        .h3(H3LaneClass::Parity)
        .evidence(H3_FP64_NATIVE_DECLINE),
];

/// Look up metadata by the exact, case-sensitive workload identifier.
#[must_use]
pub fn workload_metadata(name: &str) -> Option<&'static WorkloadMetadata> {
    WORKLOAD_REGISTRY.iter().find(|entry| entry.name == name)
}

#[cfg(test)]
mod tests {
    use std::collections::BTreeSet;

    use super::*;

    #[test]
    fn registry_names_are_unique() {
        let names = WORKLOAD_REGISTRY
            .iter()
            .map(|entry| entry.name)
            .collect::<BTreeSet<_>>();
        assert_eq!(names.len(), WORKLOAD_REGISTRY.len());
    }

    #[test]
    fn registry_covers_runtime_workloads_without_drift() {
        let workloads = super::super::all_workloads();
        let runtime_names = workloads
            .iter()
            .map(|workload| workload.name())
            .collect::<BTreeSet<_>>();
        assert_eq!(
            runtime_names.len(),
            workloads.len(),
            "all_workloads() contains duplicate exact names"
        );
        let registry_names = WORKLOAD_REGISTRY
            .iter()
            .map(|entry| entry.name)
            .collect::<BTreeSet<_>>();
        assert_eq!(runtime_names, registry_names);
        assert_eq!(workloads.len(), WORKLOAD_REGISTRY.len());
        for workload in workloads {
            let metadata = workload_metadata(workload.name()).unwrap_or_else(|| {
                panic!("registered workload `{}` lacks metadata", workload.name())
            });
            assert_eq!(metadata.category.as_str(), workload.category());
            assert_eq!(
                metadata.kernel_class.as_str(),
                crate::report::classify_kernel(workload.name())
            );
        }
    }

    #[test]
    fn only_ssbm_workloads_use_the_star_schema_category() {
        for entry in WORKLOAD_REGISTRY {
            assert_eq!(
                entry.category == WorkloadCategory::StarSchemaSsbm,
                entry.name.starts_with("ssbm_")
            );
        }
    }

    #[test]
    fn registry_policy_collections_are_nonempty_and_unique() {
        for entry in WORKLOAD_REGISTRY {
            let mut tables = BTreeSet::new();
            for pin in entry.resident_pins {
                assert!(
                    !pin.table.is_empty(),
                    "{} has an empty pin table",
                    entry.name
                );
                assert!(!pin.columns.is_empty(), "{} has an empty pin", entry.name);
                assert!(
                    tables.insert(pin.table),
                    "{} pins table `{}` more than once",
                    entry.name,
                    pin.table
                );
                let columns = pin.columns.iter().copied().collect::<BTreeSet<_>>();
                assert_eq!(
                    columns.len(),
                    pin.columns.len(),
                    "{} has duplicate columns for `{}`",
                    entry.name,
                    pin.table
                );
            }

            let extensions = entry
                .required_extensions
                .iter()
                .map(|extension| extension.as_str())
                .collect::<BTreeSet<_>>();
            assert_eq!(extensions.len(), entry.required_extensions.len());
        }
    }

    #[test]
    fn registry_typed_policy_is_complete_for_special_families() {
        for entry in WORKLOAD_REGISTRY {
            let is_h3 = matches!(entry.kernel_class, K::H3LatLng | K::H3CellToParent);
            // Real-data characterization has no pre-declared winner/parity
            // policy. It must report the observed lane, including losers;
            // all existing release-H3 policies remain mandatory.
            let released_h3 = is_h3 && entry.category != C::NycTaxi;
            assert_eq!(
                released_h3,
                entry.h3_lane.is_some(),
                "{} H3 policy",
                entry.name
            );
            if is_h3 {
                assert!(entry.required_extensions.contains(&RequiredExtension::H3));
            }
            if released_h3 {
                assert!(
                    entry.evidence.function_kernel(),
                    "{} function evidence",
                    entry.name
                );
                assert!(
                    entry.evidence.requires_cache_mode_both(),
                    "{} cache evidence",
                    entry.name
                );
                assert!(entry.required_extensions.contains(&RequiredExtension::H3));
            }

            assert_eq!(
                entry.category == C::Fp64Matrix,
                entry.evidence.fp64_calibration(),
                "{} fp64 calibration eligibility",
                entry.name
            );
            if entry.category == C::GpuRaster {
                assert_eq!(
                    entry.name != "raster_resident_exact_reclass",
                    entry.evidence.function_kernel()
                );
                assert!(entry.evidence.requires_cache_mode_both());
                assert!(
                    entry
                        .required_extensions
                        .contains(&RequiredExtension::PostgisRaster)
                );
                assert_eq!(
                    entry.name == "raster_resident_exact_reclass",
                    entry.evidence.derived_output_artifact_reuse(),
                    "{} derived-output artifact policy",
                    entry.name
                );
            } else {
                assert!(
                    !entry.evidence.derived_output_artifact_reuse(),
                    "{} unexpectedly credits derived-output artifact reuse",
                    entry.name
                );
            }
        }
    }

    #[test]
    fn lookup_is_exact() {
        assert!(workload_metadata("h3_bulk").is_some());
        assert!(workload_metadata("H3_BULK").is_none());
    }

    #[test]
    fn phase6_domain_registry_is_exhaustive_and_typed() {
        let release_categories = [C::GpuSpatial, C::GpuH3, C::GpuRaster];
        let expected = WORKLOAD_REGISTRY
            .iter()
            .filter(|entry| release_categories.contains(&entry.category))
            .map(|entry| entry.name)
            .collect::<BTreeSet<_>>();
        let actual = PHASE6_DOMAIN_CONTRACTS
            .iter()
            .map(|contract| contract.workload)
            .collect::<BTreeSet<_>>();
        assert_eq!(actual, expected);
        assert_eq!(actual.len(), PHASE6_DOMAIN_CONTRACTS.len());

        let runtime = super::super::all_workloads();
        for contract in PHASE6_DOMAIN_CONTRACTS {
            let metadata = workload_metadata(contract.workload).expect("Phase 6 metadata");
            assert_eq!(
                metadata.category, contract.category,
                "{}",
                contract.workload
            );
            assert!(
                !contract.verification_rows.is_empty(),
                "{}",
                contract.workload
            );
            assert!(
                contract
                    .verification_rows
                    .windows(2)
                    .all(|rows| rows[0] < rows[1]),
                "{} has duplicate or unordered verification rows",
                contract.workload
            );
            let workload = runtime
                .iter()
                .find(|workload| workload.name() == contract.workload)
                .unwrap_or_else(|| panic!("missing Phase 6 workload `{}`", contract.workload));
            if matches!(
                contract.oracle,
                Phase6DomainOracle::NativeH3 | Phase6DomainOracle::NativeH3FailClosed
            ) {
                assert!(
                    workload.baseline_query_sql().is_some(),
                    "{} must name an independent h3-pg oracle",
                    contract.workload
                );
            }
        }

        for workload in ["spatial_mega_1kv", "spatial_sel_10pct"] {
            let crash_band = PHASE6_DOMAIN_CONTRACTS
                .iter()
                .find(|contract| contract.workload == workload)
                .expect("spatial crash-band contract");
            assert_eq!(crash_band.verification_rows, PHASE6_SPATIAL_CRASH_BAND_ROWS);
        }
        assert_eq!(PHASE6_SPATIAL_CRASH_BAND_ROWS, &[80_000, 100_000, 150_000]);

        for workload in ["h3_bulk", "h3_resolution_sweep", "h3_latlng_res15"] {
            let contract = PHASE6_DOMAIN_CONTRACTS
                .iter()
                .find(|contract| contract.workload == workload)
                .expect("H3 native-decline contract");
            assert_eq!(contract.oracle, Phase6DomainOracle::NativeH3FailClosed);
            assert_eq!(contract.verification_rows, &[100_000, 1_000_000]);
        }
    }

    #[test]
    fn phase9_operator_decline_registry_is_exhaustive_and_typed() {
        let mut lanes = BTreeSet::new();
        let mut workloads = BTreeSet::new();
        let runtime = super::super::all_workloads();

        assert_eq!(
            PHASE9_OPERATOR_DECLINES
                .iter()
                .find(|contract| contract.lane == Phase9OperatorLane::NotInMembership)
                .map(|contract| contract.reason),
            Some("shape_sublink")
        );

        for contract in PHASE9_OPERATOR_DECLINES {
            assert!(lanes.insert(contract.lane), "duplicate Phase 9 lane");
            assert!(
                workloads.insert(contract.workload),
                "duplicate Phase 9 workload `{}`",
                contract.workload
            );
            assert!(!contract.lane.as_str().is_empty());
            assert!(!contract.reason.is_empty());

            let metadata = workload_metadata(contract.workload)
                .unwrap_or_else(|| panic!("missing metadata for `{}`", contract.workload));
            assert_ne!(
                metadata.kernel_class,
                KernelClass::Unclassified,
                "{} must have a typed kernel class",
                contract.workload
            );
            assert_eq!(
                metadata.evidence.threshold,
                ThresholdEvidenceEligibility::NativeDeclineOnly,
                "{} must reject CustomScan/kernel dispatch",
                contract.workload
            );

            let workload = runtime
                .iter()
                .find(|workload| workload.name() == contract.workload)
                .unwrap_or_else(|| panic!("missing runtime workload `{}`", contract.workload));
            for &rows in workload.row_scales() {
                let threshold =
                    super::super::benchmark_threshold_matrix_entry(contract.workload, rows)
                        .unwrap_or_else(|| {
                            panic!(
                                "missing threshold entry for `{}` at {rows}",
                                contract.workload
                            )
                        });
                assert_eq!(
                    threshold.expectation.decline_reason(),
                    Some(contract.reason),
                    "{} at {rows}",
                    contract.workload
                );
                assert_eq!(
                    threshold.dispatch_evidence,
                    super::super::GENERIC_NATIVE_DISPATCH_EVIDENCE,
                    "{} at {rows}",
                    contract.workload
                );
            }
        }

        assert_eq!(
            lanes.len(),
            Phase9OperatorLane::NestedLoopInequality as usize + 1
        );
    }

    #[test]
    fn phase9_decline_workloads_are_deterministic_and_do_not_force_admission() {
        let runtime = super::super::all_workloads();
        let banned_settings = [
            "pg_accel.cost_multiplier",
            "pg_accel.min_batch_size",
            "max_parallel_workers_per_gather",
        ];

        for contract in PHASE9_OPERATOR_DECLINES {
            let workload = runtime
                .iter()
                .find(|workload| workload.name() == contract.workload)
                .unwrap_or_else(|| panic!("missing runtime workload `{}`", contract.workload));
            let rows = workload.row_scales()[0];
            let setup = workload.setup_sql(rows).join("\n").to_ascii_lowercase();
            assert!(
                !setup.contains("random()"),
                "{} fixture must be deterministic",
                contract.workload
            );
            let session_sql = workload.pre_query_sql().join("\n").to_ascii_lowercase();
            for setting in banned_settings {
                assert!(
                    !setup.contains(setting) && !session_sql.contains(setting),
                    "{} must not force `{setting}`",
                    contract.workload
                );
            }
        }
    }
}
