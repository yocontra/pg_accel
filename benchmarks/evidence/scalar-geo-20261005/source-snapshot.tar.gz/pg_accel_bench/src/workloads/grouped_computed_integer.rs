use std::collections::BTreeMap;

use super::{ExpectedResultValue, ResultOracle, Workload};

pub struct GroupedComputedInteger(pub bool);

pub enum ScalarProgramAggregate {
    GlobalRollup,
    GroupedRollup,
    GroupedCoalesce,
    SpatialGlobalRollup,
    SpatialGroupedRollup,
}

const SCALAR_ROLLUP: &str = "CASE WHEN adjustment IS NULL THEN price \
    WHEN price>0 THEN (price+adjustment)*(price-adjustment) \
    ELSE COALESCE(price,0)-adjustment END";

impl ScalarProgramAggregate {
    fn global(&self) -> bool {
        matches!(self, Self::GlobalRollup | Self::SpatialGlobalRollup)
    }

    fn spatial(&self) -> bool {
        matches!(self, Self::SpatialGlobalRollup | Self::SpatialGroupedRollup)
    }

    fn expression(&self) -> &'static str {
        if matches!(self, Self::GroupedCoalesce) {
            "COALESCE(price,adjustment,0)"
        } else {
            SCALAR_ROLLUP
        }
    }
}

impl Workload for ScalarProgramAggregate {
    fn name(&self) -> &'static str {
        match self {
            Self::GlobalRollup => "global_scalar_program",
            Self::GroupedRollup => "grouped_scalar_program",
            Self::GroupedCoalesce => "grouped_coalesced_integer",
            Self::SpatialGlobalRollup => "spatial_global_scalar_program",
            Self::SpatialGroupedRollup => "spatial_grouped_scalar_program",
        }
    }

    fn description(&self) -> &'static str {
        if self.spatial() {
            "Resident full-scan point/polygon-with-holes CASE/COALESCE rollup; independent coordinate and widened polynomial oracle, no spatial index"
        } else if matches!(self, Self::GroupedCoalesce) {
            "Nullable grouped COALESCE feeding shared exact SUM/AVG/COUNT/MIN/MAX"
        } else {
            "Shared nullable CASE/COALESCE program feeding exact SUM/AVG/COUNT/MIN/MAX"
        }
    }

    fn setup_sql(&self, rows: usize) -> Vec<String> {
        if self.spatial() {
            return vec![
                "DROP TABLE IF EXISTS bench_scalar_sales".into(),
                format!(
                    "CREATE TABLE bench_scalar_sales AS SELECT \
                    CASE WHEN i%97=0 THEN NULL ELSE i%32 END region, \
                    CASE WHEN i%11=0 THEN NULL ELSE i%1001-500 END price, \
                    CASE WHEN i%13=0 THEN NULL ELSE i%101-50 END adjustment, \
                    CASE WHEN i%37=0 THEN NULL \
                         WHEN i%41=0 THEN 'SRID=4326;POINT EMPTY'::geometry \
                         ELSE ST_SetSRID(ST_MakePoint((i%1000)::float8/50,((i/1000)%1000)::float8/50),4326) \
                    END::geometry(Point,4326) geom FROM generate_series(1,{rows}) s(i)"
                ),
                "ANALYZE bench_scalar_sales".into(),
            ];
        }
        GroupedComputedInteger(self.global())
            .setup_sql(rows)
            .into_iter()
            .map(|sql| sql.replace("bench_computed_sales", "bench_scalar_sales"))
            .collect()
    }

    fn query_sql(&self) -> String {
        let expression = self.expression();
        let restriction = if self.spatial() {
            format!(
                " WHERE ST_Intersects(geom,'{}'::geometry)",
                super::spatial_resident_agg_candidate::holes_polygon_wkt()
            )
        } else {
            String::new()
        };
        format!(
            "SELECT {}sum({expression}) total,avg({expression}) mean,\
            count({expression}) present,min({expression}) lo,max({expression}) hi,count(*) n \
            FROM bench_scalar_sales{restriction}{}",
            if self.global() { "" } else { "region," },
            if self.global() {
                ""
            } else {
                " GROUP BY region"
            }
        )
    }

    fn row_scales(&self) -> &'static [usize] {
        if self.spatial() {
            &[1_000_000, 2_000_000]
        } else {
            &[250_000, 1_000_000]
        }
    }

    fn result_oracle(&self, rows: usize) -> Option<ResultOracle> {
        #[derive(Default)]
        struct State {
            sum: i64,
            count: i64,
            low: Option<i64>,
            high: Option<i64>,
            total: i64,
        }
        let mut groups = BTreeMap::<Option<usize>, State>::new();
        if self.global() {
            groups.insert(Some(0), State::default());
        }
        for row in 1..=rows {
            if self.spatial() && !spatial_scalar_member(row) {
                continue;
            }
            let key = if self.global() {
                Some(0)
            } else {
                (row % 97 != 0).then_some(row % 32)
            };
            let state = groups.entry(key).or_default();
            state.total += 1;
            let price =
                (row % 11 != 0).then_some(i64::try_from(row % 1001).expect("bounded price") - 500);
            let adjustment = (row % 13 != 0)
                .then_some(i64::try_from(row % 101).expect("bounded adjustment") - 50);
            // Independently widened arithmetic, expressed as a polynomial
            // rather than replaying the SQL expression or device program.
            let value = if matches!(self, Self::GroupedCoalesce) {
                Some(price.or(adjustment).unwrap_or(0))
            } else {
                adjustment.map_or(price, |a| {
                    Some(match price {
                        Some(p) if p > 0 => p * p - a * a,
                        _ => price.unwrap_or(0) - a,
                    })
                })
            };
            if let Some(value) = value {
                state.sum += value;
                state.count += 1;
                state.low = Some(state.low.map_or(value, |previous| previous.min(value)));
                state.high = Some(state.high.map_or(value, |previous| previous.max(value)));
            }
        }
        let nullable =
            |value: Option<i64>| value.map_or_else(|| "NULL::bigint".into(), |v| v.to_string());
        let values = groups
            .iter()
            .map(|(key, state)| {
                format!(
                    "({},{},{},{},{},{})",
                    key.map_or_else(|| "NULL::int4".into(), |v| v.to_string()),
                    nullable((state.count != 0).then_some(state.sum)),
                    state.count,
                    nullable(state.low),
                    nullable(state.high),
                    state.total
                )
            })
            .collect::<Vec<_>>()
            .join(",");
        if values.is_empty() {
            return Some(ResultOracle::one_row(
                format!("SELECT count(*)::int8 FROM ({}) q", self.query_sql()),
                vec![ExpectedResultValue::I64(0)],
            ));
        }
        Some(ResultOracle::one_row(
            format!(
                "SELECT count(*)::int8,coalesce(bool_and(\
            actual.total IS NOT DISTINCT FROM expected.total AND \
            actual.mean IS NOT DISTINCT FROM expected.total::numeric/nullif(expected.present,0)::numeric AND \
            actual.present IS NOT DISTINCT FROM expected.present AND \
            actual.lo IS NOT DISTINCT FROM expected.lo AND actual.hi IS NOT DISTINCT FROM expected.hi AND \
            actual.n IS NOT DISTINCT FROM expected.n),false) \
            FROM ({}) actual {} (VALUES {values}) expected(region,total,present,lo,hi,n) {}",
                self.query_sql(),
                if self.global() {
                    "CROSS JOIN"
                } else {
                    "FULL JOIN"
                },
                if self.global() {
                    ""
                } else {
                    "ON jsonb_build_array(actual.region)=jsonb_build_array(expected.region)"
                }
            ),
            vec![
                ExpectedResultValue::I64(i64::try_from(groups.len()).expect("bounded groups")),
                ExpectedResultValue::Bool(true),
            ],
        ))
    }

    fn cleanup_sql(&self) -> Vec<String> {
        vec!["DROP TABLE IF EXISTS bench_scalar_sales".into()]
    }
}

// Exact integer coordinates, independent of PostGIS and the generated rings.
// Intersects includes the outer and hole boundaries, but excludes hole interiors.
fn spatial_scalar_member(row: usize) -> bool {
    let x = row % 1000;
    let y = (row / 1000) % 1000;
    !row.is_multiple_of(37)
        && !row.is_multiple_of(41)
        && (250..=750).contains(&x)
        && (250..=750).contains(&y)
        && !(x > 350 && x < 450 && y > 350 && y < 450)
        && !(x > 550 && x < 650 && y > 550 && y < 650)
}

impl Workload for GroupedComputedInteger {
    fn name(&self) -> &'static str {
        if self.0 {
            "global_computed_integer"
        } else {
            "grouped_computed_integer"
        }
    }

    fn description(&self) -> &'static str {
        "Checked INT4 sales arithmetic: product revenue, net price AVG and combined-price extrema"
    }

    fn setup_sql(&self, rows: usize) -> Vec<String> {
        vec![
            "DROP TABLE IF EXISTS bench_computed_sales".into(),
            "CREATE TABLE bench_computed_sales (region int4, price int4, adjustment int4)".into(),
            format!(
                "INSERT INTO bench_computed_sales SELECT \
                 CASE WHEN i%97=0 THEN NULL ELSE i%32 END, \
                 CASE WHEN i%11=0 THEN NULL ELSE i%1001-500 END, \
                 CASE WHEN i%13=0 THEN NULL ELSE i%101-50 END \
                 FROM generate_series(1,{rows}) s(i)"
            ),
            "ANALYZE bench_computed_sales".into(),
        ]
    }

    fn query_sql(&self) -> String {
        let aggregates = "sum(price*adjustment) revenue,avg(price-adjustment) net, \
         min(price+adjustment) lo,max(price+adjustment) hi,count(*) n \
         FROM bench_computed_sales";
        if self.0 {
            format!("SELECT {aggregates}")
        } else {
            format!("SELECT region,{aggregates} GROUP BY region")
        }
    }

    fn row_scales(&self) -> &'static [usize] {
        &[250_000, 1_000_000]
    }

    fn result_oracle(&self, rows: usize) -> Option<ResultOracle> {
        #[derive(Default)]
        struct State {
            revenue: i64,
            net: i64,
            count: i64,
            low: Option<i64>,
            high: Option<i64>,
            total: i64,
        }
        let mut groups = BTreeMap::<Option<usize>, State>::new();
        if self.0 {
            groups.insert(Some(0), State::default());
        }
        for row in 1..=rows {
            let state = groups
                .entry(if self.0 {
                    Some(0)
                } else {
                    (row % 97 != 0).then_some(row % 32)
                })
                .or_default();
            state.total += 1;
            if row % 11 == 0 || row % 13 == 0 {
                continue;
            }
            let price = i64::try_from(row % 1001).expect("bounded price") - 500;
            let adjustment = i64::try_from(row % 101).expect("bounded adjustment") - 50;
            state.revenue += price * adjustment;
            state.net += price - adjustment;
            state.count += 1;
            let combined = price + adjustment;
            state.low = Some(
                state
                    .low
                    .map_or(combined, |previous| previous.min(combined)),
            );
            state.high = Some(
                state
                    .high
                    .map_or(combined, |previous| previous.max(combined)),
            );
        }
        let nullable =
            |value: Option<i64>| value.map_or_else(|| "NULL::bigint".into(), |v| v.to_string());
        let values = groups
            .iter()
            .map(|(key, state)| {
                let key = key.map_or_else(|| "NULL::int4".into(), |v| v.to_string());
                format!(
                    "({key},{},{},{},{},{},{})",
                    nullable((state.count != 0).then_some(state.revenue)),
                    state.net,
                    state.count,
                    nullable(state.low),
                    nullable(state.high),
                    state.total
                )
            })
            .collect::<Vec<_>>()
            .join(",");
        let join = if self.0 { "CROSS JOIN" } else { "FULL JOIN" };
        let condition = if self.0 {
            ""
        } else {
            "ON jsonb_build_array(actual.region)=jsonb_build_array(expected.region)"
        };
        Some(ResultOracle::one_row(
            format!(
                "SELECT count(*)::int8,coalesce(bool_and( \
             actual.revenue IS NOT DISTINCT FROM expected.revenue AND \
             actual.net IS NOT DISTINCT FROM expected.net::numeric/nullif(expected.c,0)::numeric AND \
             actual.lo IS NOT DISTINCT FROM expected.lo AND actual.hi IS NOT DISTINCT FROM expected.hi AND \
             actual.n IS NOT DISTINCT FROM expected.n),false) \
             FROM ({query}) actual {join} (VALUES {values}) expected(region,revenue,net,c,lo,hi,n) \
             {condition}",
                query = self.query_sql()
            ),
            vec![
                ExpectedResultValue::I64(i64::try_from(groups.len()).expect("bounded groups")),
                ExpectedResultValue::Bool(true),
            ],
        ))
    }

    fn cleanup_sql(&self) -> Vec<String> {
        vec!["DROP TABLE IF EXISTS bench_computed_sales".into()]
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn spatial_scalar_oracle_covers_boundaries_holes_nulls_and_empty_points() {
        assert!(spatial_scalar_member(250_250)); // outer corner
        assert!(spatial_scalar_member(350_350)); // hole corner
        assert!(!spatial_scalar_member(400_400)); // first hole interior
        assert!(!spatial_scalar_member(600_600)); // second hole interior
        assert!(!spatial_scalar_member(249_500)); // outside
        assert!(!spatial_scalar_member(500_277)); // NULL (multiple of 37)
        assert!(!spatial_scalar_member(500_282)); // empty (multiple of 41)
        for workload in [
            ScalarProgramAggregate::SpatialGlobalRollup,
            ScalarProgramAggregate::SpatialGroupedRollup,
        ] {
            assert!(workload.query_sql().contains("ST_Intersects"));
            assert!(!workload.setup_sql(1).join(" ").contains("INDEX"));
            for rows in workload.row_scales() {
                assert_eq!(
                    workload
                        .result_oracle(*rows)
                        .expect("spatial oracle")
                        .expected_row,
                    vec![
                        ExpectedResultValue::I64(if workload.global() { 1 } else { 33 }),
                        ExpectedResultValue::Bool(true)
                    ]
                );
            }
        }
    }

    #[test]
    fn coalesced_rollup_oracle_covers_each_null_branch_and_null_group() {
        let workload = ScalarProgramAggregate::GroupedCoalesce;
        for (rows, expected) in [
            (1, "(1,-499,1,-499,-499,1)"),
            (11, "(11,-39,1,-39,-39,1)"),
            (13, "(13,-487,1,-487,-487,1)"),
            (143, "(15,-1748,5,-485,0,5)"),
            (143, "(NULL::int4,-403,1,-403,-403,1)"),
        ] {
            assert!(
                workload
                    .result_oracle(rows)
                    .expect("coalesced fixture")
                    .query_sql
                    .contains(expected),
                "missing golden group {expected} at {rows} rows"
            );
        }
        assert_eq!(
            workload
                .result_oracle(0)
                .expect("empty groups")
                .expected_row,
            vec![ExpectedResultValue::I64(0)]
        );
    }

    #[test]
    fn scalar_rollup_has_independent_nullable_polynomial_oracle() {
        let grouped = ScalarProgramAggregate::GroupedRollup;
        assert!(
            grouped
                .result_oracle(1)
                .expect("single row")
                .query_sql
                .contains("(1,-450,1,-450,-450,1)")
        );
        assert_eq!(
            grouped
                .result_oracle(0)
                .expect("empty grouping")
                .expected_row,
            vec![ExpectedResultValue::I64(0)]
        );
        let global = ScalarProgramAggregate::GlobalRollup;
        assert!(
            global
                .result_oracle(0)
                .expect("empty reduction")
                .query_sql
                .contains("(0,NULL::bigint,0,NULL::bigint,NULL::bigint,0)")
        );
        for rows in grouped.row_scales() {
            assert_eq!(
                grouped
                    .result_oracle(*rows)
                    .expect("grouped oracle")
                    .expected_row,
                vec![
                    ExpectedResultValue::I64(33),
                    ExpectedResultValue::Bool(true)
                ]
            );
            assert_eq!(
                global
                    .result_oracle(*rows)
                    .expect("global oracle")
                    .expected_row,
                vec![ExpectedResultValue::I64(1), ExpectedResultValue::Bool(true)]
            );
        }
    }

    #[test]
    fn mixed_arithmetic_has_an_independent_widened_oracle() {
        let workload = GroupedComputedInteger(false);
        for rows in workload.row_scales() {
            let oracle = workload.result_oracle(*rows).expect("oracle");
            assert_eq!(
                oracle.expected_row,
                [
                    ExpectedResultValue::I64(33),
                    ExpectedResultValue::Bool(true)
                ]
            );
            assert!(oracle.query_sql.contains(&workload.query_sql()));
            assert!(
                oracle
                    .query_sql
                    .contains("expected.net::numeric/nullif(expected.c,0)::numeric")
            );
        }
        let single = workload.result_oracle(1).expect("single row");
        assert!(single.query_sql.contains("(1,24451,-450,1,-548,-548,1)"));
        let global = GroupedComputedInteger(true);
        let oracle = global.result_oracle(1_000_000).expect("global oracle");
        assert_eq!(
            oracle.expected_row,
            [ExpectedResultValue::I64(1), ExpectedResultValue::Bool(true)]
        );
        assert!(!global.query_sql().contains("GROUP BY"));
        let empty = global.result_oracle(0).expect("empty global oracle");
        assert_eq!(
            empty.expected_row,
            [ExpectedResultValue::I64(1), ExpectedResultValue::Bool(true)]
        );
        assert!(
            empty
                .query_sql
                .contains("(0,NULL::bigint,0,0,NULL::bigint,NULL::bigint,0)")
        );
    }
}
