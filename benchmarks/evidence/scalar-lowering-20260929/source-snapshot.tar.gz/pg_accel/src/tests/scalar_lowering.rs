//! Live catalog/tree tests for SPG1 lowering, not GPU SQL admission tests.

#[cfg(any(test, feature = "pg_test"))]
#[pgrx::pg_schema]
mod tests {
    use std::ffi::CString;

    use pgrx::pg_sys;
    use pgrx::prelude::*;

    use crate::engine::ffi::planner_hooks::shape::{
        LoweredScalarExpression, lower_scalar_expression,
    };
    use crate::engine::spec::scalar::tests::{Value, evaluate};
    use crate::engine::spec::scalar::{ScalarInstruction as I, ScalarType};

    fn lower(
        sql: &str,
    ) -> Result<LoweredScalarExpression, crate::engine::ffi::planner_hooks::shape::ShapeDecline>
    {
        let text = CString::new(sql).expect("fixture SQL");
        // SAFETY: this pg_test runs on the backend main thread in an active
        // transaction. Parser/analyzer allocations stay alive for the whole
        // synchronous lowering call; no PostgreSQL pointers are returned.
        unsafe {
            let raw = pg_sys::pg_parse_query(text.as_ptr());
            assert_eq!(pg_sys::list_length(raw), 1);
            let statement = pg_sys::list_nth(raw, 0).cast::<pg_sys::RawStmt>();
            let query = pg_sys::parse_analyze_fixedparams(
                statement,
                text.as_ptr(),
                std::ptr::null(),
                0,
                std::ptr::null_mut(),
            );
            assert!(!query.is_null());
            let target = pg_sys::list_nth((*query).targetList, 0).cast::<pg_sys::TargetEntry>();
            let expression =
                pg_sys::eval_const_expressions(std::ptr::null_mut(), (*target).expr.cast());
            lower_scalar_expression(expression, &*query)
        }
    }

    fn setup() {
        Spi::run("SET pg_accel.enabled=off; CREATE TEMP TABLE scalar_rows(id int4,a int4,b int4,c int4,p bool,q bool,w int8,d date); \
            INSERT INTO scalar_rows VALUES \
            (1,7,3,-2,true,false,1,'2026-01-01'), \
            (2,-7,3,2,false,true,2,'2026-01-02'), \
            (3,NULL,3,0,NULL,false,3,'2026-01-03'), \
            (4,7,NULL,-1,true,NULL,4,'2026-01-04'), \
            (5,NULL,NULL,NULL,NULL,NULL,5,'2026-01-05');")
            .expect("native scalar fixture");
    }

    fn verify(expression: &str) {
        let lowered = lower(&format!("SELECT {expression} FROM scalar_rows")).expect(expression);
        let logical = lowered.clone().into_measure_expression();
        let crate::engine::spec::MeasureExpr::Bytecode {
            inputs,
            program,
            result_type_oid,
        } = logical
        else {
            panic!("lowering must preserve the versioned program envelope");
        };
        assert_eq!(program, lowered.program.encode());
        assert_eq!(
            inputs,
            lowered
                .inputs
                .iter()
                .map(|input| input.column)
                .collect::<Vec<_>>()
        );
        assert_eq!(
            result_type_oid,
            if lowered.program.result_type() == ScalarType::Int4 {
                23
            } else {
                16
            }
        );
        for id in 1..=5 {
            let values = lowered
                .inputs
                .iter()
                .map(|column| {
                    let name = match column.column.attno {
                        2 => "a",
                        3 => "b",
                        4 => "c",
                        5 => "p",
                        6 => "q",
                        _ => panic!("unexpected lowered input {column:?}"),
                    };
                    let sql = format!("SELECT {name} FROM scalar_rows WHERE id={id}");
                    match column.column.type_oid {
                        23 => Spi::get_one::<i32>(&sql)
                            .expect("int4 input")
                            .map_or(Value::Null(ScalarType::Int4), Value::Int4),
                        16 => Spi::get_one::<bool>(&sql)
                            .expect("Boolean input")
                            .map_or(Value::Null(ScalarType::Bool), Value::Bool),
                        _ => panic!("unsupported input type"),
                    }
                })
                .collect::<Vec<_>>();
            let expected = match lowered.program.result_type() {
                ScalarType::Int4 => Spi::get_one::<i32>(&format!(
                    "SELECT {expression} FROM scalar_rows WHERE id={id}"
                ))
                .expect(expression)
                .map_or(Value::Null(ScalarType::Int4), Value::Int4),
                ScalarType::Bool => Spi::get_one::<bool>(&format!(
                    "SELECT {expression} FROM scalar_rows WHERE id={id}"
                ))
                .expect(expression)
                .map_or(Value::Null(ScalarType::Bool), Value::Bool),
            };
            assert_eq!(
                evaluate(&lowered.program, &values),
                Ok(expected),
                "{expression}, row {id}"
            );
        }
    }

    #[pg_test]
    fn pg_scalar_lowering_matches_native_simplified_trees() {
        setup();
        for expression in [
            "a+(b*c)-(-a)",
            "a/b",
            "a%b",
            "a=b",
            "a<>b",
            "a<b",
            "a<=b",
            "a>b",
            "a>=b",
            "p=q",
            "p<>q",
            "p<q",
            "p<=q",
            "p>q",
            "p>=q",
            "p AND q",
            "p OR q",
            "NOT p",
            "a IS NULL",
            "p IS NOT NULL",
            "p AND q AND a>0",
            "p OR q OR a>0",
            "(a>0 OR b<0) AND (p OR NOT q)",
            "CASE WHEN p THEN a*b WHEN q THEN a+b ELSE c END",
            "CASE WHEN a IS NULL THEN COALESCE(b,c,42) ELSE a+COALESCE(b,c,0) END",
            "COALESCE(a,b,c,42)",
            "COALESCE(p,q,false)",
            "CASE WHEN a IS NULL THEN NULL ELSE a*2 END",
            "CASE WHEN p THEN CASE WHEN q THEN a ELSE b END ELSE c END",
            "42",
            "NULL::int4",
            "true",
            "NULL::boolean",
            "a+a+a",
            "ROW(a,b) IS NULL",
            "ROW(a,b) IS NOT NULL",
            "NOT (ROW(a,b) IS NULL)",
        ] {
            verify(expression);
        }
        let repeated = lower("SELECT a+a+a FROM scalar_rows").expect("deduplicated input");
        assert_eq!(repeated.inputs.len(), 1);
        let folded =
            lower("SELECT NULL::int4+(a/0) FROM scalar_rows").expect("PG folded literal NULL");
        assert!(folded.inputs.is_empty());
        assert_eq!(folded.program.instructions(), &[I::Null(ScalarType::Int4)]);
        let row_null = lower("SELECT a+(b/0) FROM scalar_rows").expect("runtime NULL");
        assert_eq!(
            evaluate(
                &row_null.program,
                &[Value::Null(ScalarType::Int4), Value::Int4(1)]
            ),
            Err(crate::engine::spec::scalar::tests::Fault::DivisionByZero)
        );
    }

    #[pg_test]
    fn pg_scalar_lowering_preserves_lazy_error_branches() {
        setup();
        for expression in [
            "CASE WHEN a IS NULL THEN 42 ELSE CASE WHEN b IS NULL THEN 7 ELSE a/b END END",
            "CASE WHEN a IS NOT NULL THEN a ELSE COALESCE(b,c,42) END",
            "CASE WHEN p IS NULL THEN 42 ELSE CASE WHEN p THEN a ELSE b END END",
            "COALESCE(a,COALESCE(b,c,42),a/0)",
            "(p IS NULL OR p IS NOT NULL) OR a/0>0",
            "(p IS NULL AND p IS NOT NULL) AND a/0>0",
        ] {
            verify(expression);
        }
        let lazy = lower("SELECT CASE WHEN p THEN a/0 ELSE 42 END FROM scalar_rows")
            .expect("searched CASE");
        assert_eq!(
            evaluate(&lazy.program, &[Value::Bool(false), Value::Int4(7)]),
            Ok(Value::Int4(42))
        );
        assert_eq!(
            evaluate(
                &lazy.program,
                &[Value::Null(ScalarType::Bool), Value::Int4(7)]
            ),
            Ok(Value::Int4(42))
        );
        assert_eq!(
            evaluate(&lazy.program, &[Value::Bool(true), Value::Int4(7)]),
            Err(crate::engine::spec::scalar::tests::Fault::DivisionByZero)
        );
    }

    #[pg_test]
    fn pg_scalar_lowering_matches_native_error_states() {
        setup();
        Spi::run("CREATE FUNCTION pg_temp.scalar_try(query text) RETURNS text LANGUAGE plpgsql AS $$ \
            DECLARE value text; BEGIN EXECUTE query INTO value; \
            RETURN 'ok:'||COALESCE(value,'NULL'); EXCEPTION WHEN OTHERS THEN RETURN 'error:'||SQLSTATE; END $$")
            .expect("native subtransaction error oracle");
        for expression in [
            "a+2147483647",
            "a-2147483647",
            "a*2147483647",
            "-(a+2147483647)",
            "a/(b-b)",
            "a%(b-b)",
            "a+(b/0)",
            "NULL::int4+(b/0)",
            "CASE WHEN p THEN a+2147483647 ELSE a/(b-b) END",
            "COALESCE(a,b/0)",
            "p AND a/0>0",
            "p OR a/0>0",
        ] {
            let lowered =
                lower(&format!("SELECT {expression} FROM scalar_rows")).expect(expression);
            for id in 1..=5 {
                let mut values = Vec::new();
                for column in &lowered.inputs {
                    let name = match column.column.attno {
                        2 => "a",
                        3 => "b",
                        5 => "p",
                        _ => panic!("unexpected input"),
                    };
                    let sql = format!("SELECT {name} FROM scalar_rows WHERE id={id}");
                    values.push(if column.column.type_oid == 23 {
                        Spi::get_one::<i32>(&sql)
                            .expect("integer input")
                            .map_or(Value::Null(ScalarType::Int4), Value::Int4)
                    } else {
                        Spi::get_one::<bool>(&sql)
                            .expect("Boolean input")
                            .map_or(Value::Null(ScalarType::Bool), Value::Bool)
                    });
                }
                let interpreted = match evaluate(&lowered.program, &values) {
                    Ok(Value::Null(_)) => "ok:NULL".to_owned(),
                    Ok(Value::Int4(value)) => format!("ok:{value}"),
                    Ok(Value::Bool(value)) => format!("ok:{value}"),
                    Err(crate::engine::spec::scalar::tests::Fault::Overflow) => {
                        "error:22003".to_owned()
                    }
                    Err(crate::engine::spec::scalar::tests::Fault::DivisionByZero) => {
                        "error:22012".to_owned()
                    }
                };
                let native = Spi::get_one::<String>(&format!("SELECT pg_temp.scalar_try($scalar$SELECT {expression} FROM scalar_rows WHERE id={id}$scalar$)"))
                    .expect("native error oracle").expect("non-null outcome");
                assert_eq!(interpreted, native, "{expression}, row {id}");
            }
        }
    }

    #[pg_test]
    fn pg_scalar_lowering_rejects_unqualified_catalog_and_relation_shapes() {
        setup();
        Spi::run("CREATE DOMAIN pg_temp.scalar_positive AS int4 CHECK(VALUE>0); \
            CREATE FUNCTION pg_temp.scalar_fake_add(int4,int4) RETURNS int4 LANGUAGE plpgsql VOLATILE AS $$ BEGIN RETURN $1-$2; END $$; \
            CREATE OPERATOR pg_temp.+ (FUNCTION=pg_temp.scalar_fake_add,LEFTARG=int4,RIGHTARG=int4)")
            .expect("adversarial catalogs");
        for expression in [
            "w::int4",
            "a::int8",
            "(a::int2)::int4",
            "(a::pg_temp.scalar_positive)::int4",
            "a OPERATOR(pg_temp.+) b",
            "pg_temp.scalar_fake_add(a,b)",
            "CASE a WHEN 1 THEN b ELSE c END",
            "scalar_rows IS NULL",
            "random()>0",
            "d>date '2026-01-02'",
            "a+(SELECT max(b) FROM scalar_rows)",
            "generate_series(1,a)",
        ] {
            assert!(
                lower(&format!("SELECT {expression} FROM scalar_rows")).is_err(),
                "must decline {expression}"
            );
        }
        assert!(
            lower("SELECT x.a+y.a FROM scalar_rows x CROSS JOIN scalar_rows y").is_err(),
            "same OID does not mean same occurrence"
        );
        assert!(
            lower("SELECT x.a+x.b FROM scalar_rows x CROSS JOIN scalar_rows y").is_ok(),
            "one occurrence's expression is representable; caller still rejects self join"
        );
    }

    #[pg_test]
    fn pg_scalar_lowering_enforces_instruction_stack_and_input_bounds() {
        setup();
        let expression = format!("-COALESCE({})", vec!["a"; 128].join(","));
        let exact =
            lower(&format!("SELECT {expression} FROM scalar_rows")).expect("256 instructions");
        assert_eq!(exact.program.instructions().len(), 256);
        let expression = format!("-COALESCE({})", vec!["a"; 129].join(","));
        assert!(lower(&format!("SELECT {expression} FROM scalar_rows")).is_err());
        let mut expression = "a".to_owned();
        for _ in 1..32 {
            expression = format!("a+({expression})");
        }
        assert_eq!(
            lower(&format!("SELECT {expression} FROM scalar_rows"))
                .expect("32 stack slots")
                .program
                .max_stack(),
            32
        );
        assert!(lower(&format!("SELECT a+({expression}) FROM scalar_rows")).is_err());
        Spi::run(&format!(
            "CREATE TEMP TABLE scalar_wide({})",
            (0..65)
                .map(|i| format!("c{i} int4"))
                .collect::<Vec<_>>()
                .join(",")
        ))
        .expect("wide input fixture");
        fn balanced(columns: &[String]) -> String {
            if columns.len() == 1 {
                return columns[0].clone();
            }
            let middle = columns.len() / 2;
            format!(
                "({})+({})",
                balanced(&columns[..middle]),
                balanced(&columns[middle..])
            )
        }
        let columns = (0..65).map(|i| format!("c{i}")).collect::<Vec<_>>();
        assert_eq!(
            lower(&format!(
                "SELECT {} FROM scalar_wide",
                balanced(&columns[..64])
            ))
            .expect("64 inputs")
            .inputs
            .len(),
            64
        );
        assert!(lower(&format!("SELECT {} FROM scalar_wide", balanced(&columns))).is_err());
    }
}
