//! Direct resident producer tests against PostgreSQL's join semantics. These
//! deliberately do not claim normal SQL planner selection of a row join.

#[pgrx::pg_schema]
mod tests {
    use pgrx::prelude::*;

    use crate::engine::residency::{ExecutionMemoryCharge, resident_live_bytes};
    use crate::gpu::ExprDeviceBuffer;
    use crate::gpu::join_project::{
        JoinProjectionColumn, JoinProjectionInput, JoinSide, ProjectedJoinColumn,
    };
    use crate::gpu::join_rows::{
        JOIN_NULL_ROW, JoinRowPair, ResidentJoin, ResidentJoinKey, ResidentJoinKind,
        ResidentJoinOutcome, ResidentJoinOutput,
    };

    struct Keys {
        a: Option<ExprDeviceBuffer<i32>>,
        a_nulls: Option<ExprDeviceBuffer<u8>>,
        b: Option<ExprDeviceBuffer<i64>>,
        b_nulls: Option<ExprDeviceBuffer<u8>>,
        _charge: ExecutionMemoryCharge,
    }

    impl Keys {
        fn upload(table: &str, rows: &[(Option<i32>, Option<i64>)]) -> Self {
            Spi::run(&format!(
                "CREATE TEMP TABLE {table}(id int8, a int4, b int8)"
            ))
            .expect("join oracle table");
            for (index, (a, b)) in rows.iter().enumerate() {
                Spi::run(&format!(
                    "INSERT INTO {table} VALUES ({index},{},{})",
                    a.map_or_else(|| "NULL".into(), |x| x.to_string()),
                    b.map_or_else(|| "NULL".into(), |x| x.to_string()),
                ))
                .expect("join oracle fixture");
            }
            let charge = ExecutionMemoryCharge::reserve(
                (rows.len() * 14) as u64,
                crate::engine::gucs::resident_memory_budget_bytes(),
            )
            .expect("test input reservation");
            let a: Vec<_> = rows.iter().map(|r| r.0.unwrap_or_default()).collect();
            let b: Vec<_> = rows.iter().map(|r| r.1.unwrap_or_default()).collect();
            let a_nulls: Vec<_> = rows.iter().map(|r| u8::from(r.0.is_none())).collect();
            let b_nulls: Vec<_> = rows.iter().map(|r| u8::from(r.1.is_none())).collect();
            let result = Self {
                a: ExprDeviceBuffer::copy_from_slice(&a),
                a_nulls: ExprDeviceBuffer::copy_from_slice(&a_nulls),
                b: ExprDeviceBuffer::copy_from_slice(&b),
                b_nulls: ExprDeviceBuffer::copy_from_slice(&b_nulls),
                _charge: charge,
            };
            if !rows.is_empty() {
                assert!(result.a.is_some() && result.b.is_some());
                assert!(result.a_nulls.is_some() && result.b_nulls.is_some());
            }
            result
        }

        fn keys(&self) -> [ResidentJoinKey<'_>; 2] {
            [
                ResidentJoinKey::Int32 {
                    values: self.a.as_ref(),
                    nulls: self.a_nulls.as_ref(),
                },
                ResidentJoinKey::Int64 {
                    values: self.b.as_ref(),
                    nulls: self.b_nulls.as_ref(),
                },
            ]
        }
    }

    fn oracle(
        kind: ResidentJoinKind,
        left: &str,
        right: &str,
        composite: bool,
    ) -> Vec<JoinRowPair> {
        let equality = if composite {
            "l.a=r.a AND l.b=r.b"
        } else {
            "l.a=r.a"
        };
        let query = match kind {
            ResidentJoinKind::Inner => {
                format!("SELECT l.id,r.id FROM {left} l JOIN {right} r ON {equality}")
            }
            ResidentJoinKind::Left => {
                format!("SELECT l.id,r.id FROM {left} l LEFT JOIN {right} r ON {equality}")
            }
            ResidentJoinKind::Semi => format!(
                "SELECT l.id,NULL::int8 FROM {left} l WHERE EXISTS (SELECT FROM {right} r WHERE {equality})"
            ),
            ResidentJoinKind::Anti => format!(
                "SELECT l.id,NULL::int8 FROM {left} l WHERE NOT EXISTS (SELECT FROM {right} r WHERE {equality})"
            ),
        };
        Spi::connect(|client| {
            client
                .select(&query, None, &[])
                .expect("native join oracle")
                .map(|row| JoinRowPair {
                    outer_row: row.get::<i64>(1).expect("outer id").expect("nonnull id") as u64,
                    inner_row: row
                        .get::<i64>(2)
                        .expect("inner id")
                        .map_or(JOIN_NULL_ROW, |id| id as u64),
                })
                .collect()
        })
    }

    fn project_and_aggregate(
        mappings: &ResidentJoinOutput,
        outer: &Keys,
        inner: &Keys,
        kind: ResidentJoinKind,
        left: &str,
        right: &str,
        composite: bool,
    ) {
        use crate::engine::spec::abi;
        use crate::engine::spec::scalar::{ScalarInstruction as I, ScalarProgram, ScalarType};
        use crate::gpu::{
            GroupedAggKernelMode, GroupedAggOutputStorage, GroupedAggStateLane,
            ResolvedGroupedAggPlan, cleanup_grouped_allocation_pools,
            execute_grouped_agg_one_shot_with_mode,
        };
        let inputs = [
            JoinProjectionInput {
                side: JoinSide::Outer,
                column: JoinProjectionColumn::Int32 {
                    values: outer.a.as_ref(),
                    nulls: outer.a_nulls.as_ref(),
                },
            },
            JoinProjectionInput {
                side: JoinSide::Inner,
                column: JoinProjectionColumn::Int32 {
                    values: inner.a.as_ref(),
                    nulls: inner.a_nulls.as_ref(),
                },
            },
            JoinProjectionInput {
                side: JoinSide::Outer,
                column: JoinProjectionColumn::Int64 {
                    values: outer.b.as_ref(),
                    nulls: outer.b_nulls.as_ref(),
                },
            },
            JoinProjectionInput {
                side: JoinSide::Inner,
                column: JoinProjectionColumn::Int64 {
                    values: inner.b.as_ref(),
                    nulls: inner.b_nulls.as_ref(),
                },
            },
            JoinProjectionInput {
                side: JoinSide::Outer,
                column: JoinProjectionColumn::Byte {
                    values: outer.a_nulls.as_ref(),
                    nulls: None,
                },
            },
        ];
        let baseline = resident_live_bytes();
        assert!(mappings.project(&[]).is_err());
        assert!(mappings.project(&[inputs[0]; 17]).is_err());
        if outer.a.as_ref().map_or(0, ExprDeviceBuffer::len)
            != inner.a.as_ref().map_or(0, ExprDeviceBuffer::len)
        {
            let wrong_domain = JoinProjectionInput {
                side: JoinSide::Outer,
                column: inputs[1].column,
            };
            assert!(mappings.project(&[wrong_domain]).is_err());
            assert_eq!(
                resident_live_bytes(),
                baseline,
                "bad domain rejects before reservation"
            );
        }
        let widest = mappings
            .project(&[inputs[0]; 16])
            .expect("maximum column-count projection");
        assert_eq!(widest.column_count(), 16);
        assert!(widest.column(15).is_some());
        assert!(widest.column(16).is_none());
        assert_eq!(
            resident_live_bytes(),
            baseline + (mappings.len() * 80) as u64
        );
        drop(widest);
        assert_eq!(resident_live_bytes(), baseline);
        let projection = mappings
            .project(&inputs)
            .expect("resident join column projection");
        assert_eq!(projection.column_count(), 5);
        assert_eq!(projection.len(), mappings.len());
        assert_eq!(projection.is_empty(), mappings.is_empty());
        assert!(projection.column(5).is_none());
        assert_eq!(
            resident_live_bytes(),
            baseline + (mappings.len() * 30) as u64
        );
        assert!(projection.is_empty() || projection.kernel_launches() > 0);
        let scalar_inputs = std::array::from_fn::<_, 2, _>(|index| {
            let ProjectedJoinColumn::Int32(column) =
                projection.column(index).expect("INT4 projection")
            else {
                panic!("INT4 output type");
            };
            abi::PgaccelScalarInput {
                values: column
                    .values()
                    .map_or(std::ptr::null(), |b| b.as_ptr().cast()),
                nulls: column
                    .nulls()
                    .map_or(std::ptr::null(), ExprDeviceBuffer::as_ptr),
                physical_type: abi::PGACCEL_GROUPED_AGG_PHYSICAL_INT32,
                reserved: 0,
            }
        });
        let words = ScalarProgram::new(
            vec![ScalarType::Int4; 2],
            ScalarType::Int4,
            vec![
                I::Input(0),
                I::Int4(0),
                I::Ge,
                I::JumpIfNotTrue(9),
                I::Input(0),
                I::Input(1),
                I::CoalesceInt4(10),
                I::Add,
                I::Jump(10),
                I::Null(ScalarType::Int4),
            ],
        )
        .expect("post-join aggregate FILTER program")
        .encode();
        let view = abi::PgaccelScalarView {
            version: abi::PGACCEL_SCALAR_VIEW_VERSION,
            word_count: words.len() as u32,
            input_count: 2,
            reserved: 0,
            row_count: projection.len() as u64,
            words: words.as_ptr(),
            inputs: scalar_inputs.as_ptr(),
        };
        // SAFETY: zero is valid for all ABI scalar/enum fields; active fields
        // are initialized below and inactive descriptor slots stay canonical.
        let mut desc: abi::PgaccelGroupedAggDesc = unsafe { std::mem::zeroed() };
        desc.abi_version = abi::PGACCEL_OLAP_ABI_VERSION;
        desc.size_bytes = size_of::<abi::PgaccelGroupedAggDesc>() as u32;
        desc.row_count = projection.len();
        desc.grouping_mode = abi::PGACCEL_GROUPED_AGG_GROUPING_DENSE_RADIX;
        desc.output_mode = abi::PGACCEL_GROUPED_AGG_OUTPUT_DENSE;
        desc.group_capacity = 1;
        desc.measure_count = 1;
        desc.where_filter.value_cmp_opcode = crate::engine::expr_compiler::opcode::ALWAYS_TRUE;
        for filter in &mut desc.measure_filters {
            filter.value_cmp_opcode = crate::engine::expr_compiler::opcode::ALWAYS_TRUE;
        }
        let measure = &mut desc.measures[0];
        measure.op = abi::PGACCEL_GROUPED_AGG_MEASURE_SCALAR;
        measure.agg_mask = abi::PGACCEL_GROUPED_AGG_LANE_SUM | abi::PGACCEL_GROUPED_AGG_LANE_COUNT;
        measure.accumulator_kind = abi::PGACCEL_GROUPED_AGG_ACCUM_I64;
        measure.state_bytes = 8;
        measure.value.values = std::ptr::from_ref(&view).cast();
        measure.value.element_bytes = size_of::<abi::PgaccelScalarView>() as u32;
        measure.value.physical_type = abi::PGACCEL_GROUPED_AGG_PHYSICAL_INT32;
        measure.value.flags = abi::PGACCEL_GROUPED_AGG_SCALAR_VIEW_V1;
        // SAFETY: projection retains the initialized resident value/NULL lanes
        // for the full plan/dispatch lifetime; view, words and bindings are live
        // and the facade snapshots host metadata. No row data is read on host.
        let plan =
            unsafe { ResolvedGroupedAggPlan::from_abi(desc) }.expect("post-join aggregate plan");
        let mut output =
            GroupedAggOutputStorage::new(&plan).expect("bounded final aggregate output");
        let (_, mode) = execute_grouped_agg_one_shot_with_mode(&plan, &mut output)
            .expect("join -> gather -> scalar aggregate");
        assert_eq!(mode, GroupedAggKernelMode::ParallelDenseInteger);
        let equality = if composite {
            "l.a=r.a AND l.b=r.b"
        } else {
            "l.a=r.a"
        };
        let native = match kind {
            ResidentJoinKind::Inner => format!(
                "SELECT l.a la,r.a ra,l.b lb,r.b rb FROM {left} l JOIN {right} r ON {equality}"
            ),
            ResidentJoinKind::Left => format!(
                "SELECT l.a la,r.a ra,l.b lb,r.b rb FROM {left} l LEFT JOIN {right} r ON {equality}"
            ),
            ResidentJoinKind::Semi => format!(
                "SELECT l.a la,NULL::int4 ra,l.b lb,NULL::int8 rb FROM {left} l WHERE EXISTS(SELECT FROM {right} r WHERE {equality})"
            ),
            ResidentJoinKind::Anti => format!(
                "SELECT l.a la,NULL::int4 ra,l.b lb,NULL::int8 rb FROM {left} l WHERE NOT EXISTS(SELECT FROM {right} r WHERE {equality})"
            ),
        };
        let expected_sum = Spi::get_one::<i64>(&format!(
            "SELECT coalesce(sum(la+coalesce(ra,10)) FILTER(WHERE la>=0),0)::int8 FROM ({native}) q"
        ))
        .expect("native sum")
        .expect("coalesced sum");
        let expected_count = Spi::get_one::<i64>(&format!(
            "SELECT count(la+coalesce(ra,10)) FILTER(WHERE la>=0) FROM ({native}) q"
        ))
        .expect("native count")
        .expect("count");
        assert_eq!(
            output
                .measure_i64_at(0, GroupedAggStateLane::Sum, 0)
                .expect("sum state"),
            expected_sum
        );
        assert_eq!(
            output.measure_nonnull_count(0).expect("nonnull count")[0],
            expected_count as u64
        );
        drop((output, plan));
        cleanup_grouped_allocation_pools();

        // Only oracle verification copies projected rows, after the complete
        // resident pipeline has executed. Compare exact INT8 extremes as well.
        let mut small = [Vec::new(), Vec::new()];
        let mut wide = [Vec::new(), Vec::new()];
        for (index, values) in small.iter_mut().enumerate() {
            let ProjectedJoinColumn::Int32(column) = projection.column(index).expect("column")
            else {
                panic!("int4");
            };
            let raw = column
                .values()
                .map_or_else(Vec::new, |b| b.copy_to_vec().expect("final int4 copy"));
            let nulls = column
                .nulls()
                .map_or_else(Vec::new, |b| b.copy_to_vec().expect("final null copy"));
            *values = raw
                .into_iter()
                .zip(nulls)
                .map(|(v, n)| {
                    assert!(n <= 1);
                    if n == 0 {
                        Some(v)
                    } else {
                        assert_eq!(v, 0);
                        None
                    }
                })
                .collect::<Vec<_>>();
        }
        for (index, values) in wide.iter_mut().enumerate() {
            let ProjectedJoinColumn::Int64(column) = projection.column(index + 2).expect("column")
            else {
                panic!("int8");
            };
            let raw = column
                .values()
                .map_or_else(Vec::new, |b| b.copy_to_vec().expect("final int8 copy"));
            let nulls = column
                .nulls()
                .map_or_else(Vec::new, |b| b.copy_to_vec().expect("final null copy"));
            *values = raw
                .into_iter()
                .zip(nulls)
                .map(|(v, n)| {
                    assert!(n <= 1);
                    if n == 0 {
                        Some(v)
                    } else {
                        assert_eq!(v, 0);
                        None
                    }
                })
                .collect::<Vec<_>>();
        }
        let ProjectedJoinColumn::Byte(bytes) = projection.column(4).expect("byte column") else {
            panic!("byte");
        };
        let raw_bytes = bytes
            .values()
            .map_or_else(Vec::new, |b| b.copy_to_vec().expect("final byte copy"));
        let byte_nulls = bytes
            .nulls()
            .map_or_else(Vec::new, |b| b.copy_to_vec().expect("final byte nulls"));
        let mut actual = (0..projection.len())
            .map(|i| {
                assert_eq!(byte_nulls[i], 0);
                assert_eq!(raw_bytes[i], u8::from(small[0][i].is_none()));
                (small[0][i], small[1][i], wide[0][i], wide[1][i])
            })
            .collect::<Vec<_>>();
        let mut expected = Spi::connect(|client| {
            client
                .select(&native, None, &[])
                .expect("native projected rows")
                .map(|row| {
                    (
                        row.get::<i32>(1).expect("la"),
                        row.get::<i32>(2).expect("ra"),
                        row.get::<i64>(3).expect("lb"),
                        row.get::<i64>(4).expect("rb"),
                    )
                })
                .collect::<Vec<_>>()
        });
        actual.sort();
        expected.sort();
        assert_eq!(actual, expected);
        drop(projection);
        assert_eq!(
            resident_live_bytes(),
            baseline,
            "consumer and metadata ownership released"
        );
        if !mappings.is_empty() {
            let budget = crate::engine::gucs::resident_memory_budget_bytes();
            let held = ExecutionMemoryCharge::reserve(
                budget - baseline - crate::gpu::join_project::JOIN_PROJECT_WORKSPACE_BYTES as u64,
                budget,
            )
            .expect("leave only gather workspace");
            assert!(mappings.project(&inputs).is_err());
            drop(held);
            assert_eq!(
                resident_live_bytes(),
                baseline,
                "partial gather reservation unwinds"
            );
        }
    }

    #[pg_test]
    fn pg_resident_join_rows_native_parity_and_ownership() {
        Spi::run("SET pg_accel.enabled=off").expect("native SQL oracles");
        let initial_bytes = resident_live_bytes();
        let left = Keys::upload(
            "jl",
            &[
                (Some(1), Some(i64::MIN)),
                (Some(1), Some(i64::MIN)),
                (Some(1), Some(i64::MAX)),
                (Some(-1), Some(-1)),
                (None, Some(0)),
                (Some(7), None),
                (Some(9), Some(3)),
            ],
        );
        let right = Keys::upload(
            "jr",
            &[
                (Some(1), Some(i64::MIN)),
                (Some(1), Some(i64::MIN)),
                (Some(-1), Some(-1)),
                (None, Some(0)),
                (Some(7), None),
            ],
        );
        let empty = Keys::upload("je", &[]);
        for (outer, inner, left_table, right_table) in [
            (&left, &right, "jl", "jr"),
            (&left, &left, "jl", "jl"),
            (&left, &empty, "jl", "je"),
            (&empty, &right, "je", "jr"),
            (&empty, &empty, "je", "je"),
        ] {
            for key_count in [1, 2] {
                for kind in [
                    ResidentJoinKind::Inner,
                    ResidentJoinKind::Left,
                    ResidentJoinKind::Semi,
                    ResidentJoinKind::Anti,
                ] {
                    let baseline = resident_live_bytes();
                    let mut expected = oracle(kind, left_table, right_table, key_count == 2);
                    expected.sort();
                    let plan = ResidentJoin::new(
                        kind,
                        &outer.keys()[..key_count],
                        &inner.keys()[..key_count],
                    )
                    .expect("borrowed join plan");
                    if !expected.is_empty() {
                        match plan
                            .execute(expected.len() - 1)
                            .expect("capacity detection")
                        {
                            ResidentJoinOutcome::NeedsCapacity {
                                required_rows,
                                kernel_launches,
                            } => {
                                assert_eq!(required_rows, expected.len() as u64);
                                assert!(kernel_launches > 0);
                            }
                            ResidentJoinOutcome::Complete(_) => {
                                panic!("capacity must not truncate duplicates")
                            }
                        }
                        assert_eq!(
                            resident_live_bytes(),
                            baseline,
                            "failed capacity releases both allocations"
                        );
                    }
                    let ResidentJoinOutcome::Complete(output) =
                        plan.execute(expected.len()).expect("exact capacity join")
                    else {
                        panic!("oracle exact capacity must fit");
                    };
                    assert_eq!(
                        resident_live_bytes(),
                        baseline + (expected.len() * 16) as u64,
                        "only output charge survives"
                    );
                    assert_eq!(output.len(), expected.len());
                    assert_eq!(output.is_empty(), expected.is_empty());
                    if outer.a.is_some() {
                        assert!(output.kernel_launches() > 0);
                    }
                    if !output.is_empty() {
                        assert!(!output.as_device_ptr().is_null());
                    }
                    project_and_aggregate(
                        &output,
                        outer,
                        inner,
                        kind,
                        left_table,
                        right_table,
                        key_count == 2,
                    );
                    let mut actual = vec![JoinRowPair::default(); output.len()];
                    output
                        .copy_final_rows(&mut actual)
                        .expect("bounded final copy");
                    actual.sort();
                    assert_eq!(actual, expected);
                    assert!(
                        output
                            .copy_final_rows(&mut vec![JoinRowPair::default(); output.len() + 1])
                            .is_err()
                    );
                    drop(output);
                    assert_eq!(resident_live_bytes(), baseline);
                }
            }
        }
        let left_keys = left.keys();
        let mismatched_rows = [left_keys[0], right.keys()[1]];
        assert!(ResidentJoin::new(ResidentJoinKind::Inner, &mismatched_rows, &left_keys).is_err());
        let short_nulls =
            ExprDeviceBuffer::copy_from_slice(&[0_u8]).expect("invalid sidecar fixture");
        let malformed = ResidentJoinKey::Int32 {
            values: left.a.as_ref(),
            nulls: Some(&short_nulls),
        };
        assert!(ResidentJoin::new(ResidentJoinKind::Inner, &[malformed], &[left_keys[0]]).is_err());
        let baseline = resident_live_bytes();
        let plan =
            ResidentJoin::new(ResidentJoinKind::Inner, &left_keys, &left_keys).expect("self join");
        assert!(plan.execute(usize::MAX).is_err());
        assert_eq!(resident_live_bytes(), baseline);
        let budget = crate::engine::gucs::resident_memory_budget_bytes();
        let held = ExecutionMemoryCharge::reserve(
            budget - baseline - plan.workspace_bytes().expect("workspace forecast") as u64,
            budget,
        )
        .expect("leave only workspace budget");
        assert!(
            plan.execute(1).is_err(),
            "output budget rejects before either allocation"
        );
        drop(held);
        assert_eq!(
            resident_live_bytes(),
            baseline,
            "partial reservation unwinds"
        );
        drop((left, right, empty));
        assert_eq!(
            resident_live_bytes(),
            initial_bytes,
            "inputs and outputs released"
        );
    }
}
