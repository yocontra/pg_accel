#include <algorithm>
#include <array>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <limits>
#include <vector>

#include "pgaccel_expr.h"
#include "pgaccel_join_rows.h"

namespace {
int passed = 0;
int failed = 0;
void check(bool condition, const char* message) {
  if (condition) ++passed;
  else { ++failed; std::fprintf(stderr, "FAIL: %s\n", message); }
}

struct Buffer {
  void* pointer = nullptr;
  Buffer() = default;
  Buffer(const Buffer&) = delete;
  Buffer& operator=(const Buffer&) = delete;
  ~Buffer() { pgaccel_expr_device_free(pointer); }
  bool allocate(size_t bytes) {
    return pgaccel_expr_device_alloc(bytes, &pointer) == PGACCEL_OK;
  }
  template <typename T> bool upload(const std::vector<T>& values) {
    return pgaccel_expr_device_alloc_copy(values.data(), values.size() * sizeof(T), &pointer) == PGACCEL_OK;
  }
  template <typename T> std::vector<T> download(size_t count) const {
    std::vector<T> values(count);
    if (count != 0)
      check(pgaccel_expr_device_copy_to_host(values.data(), pointer, count * sizeof(T)) == PGACCEL_OK,
            "device output copy");
    return values;
  }
};

struct HostKey {
  uint32_t type = PGACCEL_JOIN_ROWS_INT32;
  std::vector<int64_t> values;
  std::vector<uint8_t> nulls;
};

struct Fixture {
  pgaccel_join_rows_request request{};
  std::array<Buffer, 4> outer_values, outer_nulls, inner_values, inner_nulls;
  std::vector<HostKey> outer, inner;

  Fixture(std::vector<HostKey> left, std::vector<HostKey> right)
      : outer(std::move(left)), inner(std::move(right)) {
    request.version = PGACCEL_JOIN_ROWS_VERSION;
    request.key_count = static_cast<uint32_t>(outer.size());
    request.outer_rows = outer[0].values.size();
    request.inner_rows = inner[0].values.size();
    for (size_t i = 0; i < outer.size(); ++i) {
      request.outer_keys[i] = upload(outer[i], outer_values[i], outer_nulls[i]);
      request.inner_keys[i] = upload(inner[i], inner_values[i], inner_nulls[i]);
    }
  }

  static pgaccel_join_rows_key upload(const HostKey& key, Buffer& values, Buffer& nulls) {
    if (key.type == PGACCEL_JOIN_ROWS_INT32) {
      const std::vector<int32_t> narrow(key.values.begin(), key.values.end());
      check(values.upload(narrow), "INT32 keys uploaded");
    } else {
      check(values.upload(key.values), "INT64 keys uploaded");
    }
    check(nulls.upload(key.nulls), "null sidecar uploaded");
    return {values.pointer, static_cast<const uint8_t*>(nulls.pointer),
            key.values.size() * (key.type == PGACCEL_JOIN_ROWS_INT32 ? 4u : 8u),
            key.nulls.size(), key.type, 0};
  }

  bool equal(size_t left, size_t right) const {
    for (size_t k = 0; k < outer.size(); ++k) {
      if ((!outer[k].nulls.empty() && outer[k].nulls[left] != 0) ||
          (!inner[k].nulls.empty() && inner[k].nulls[right] != 0) ||
          outer[k].values[left] != inner[k].values[right])
        return false;
    }
    return true;
  }

  std::vector<pgaccel_join_row_pair> oracle(uint32_t kind) const {
    std::vector<pgaccel_join_row_pair> output;
    for (size_t left = 0; left < request.outer_rows; ++left) {
      bool matched = false;
      for (size_t right = 0; right < request.inner_rows; ++right) {
        if (!equal(left, right)) continue;
        matched = true;
        if (kind == PGACCEL_JOIN_ROWS_INNER || kind == PGACCEL_JOIN_ROWS_LEFT)
          output.push_back({left, right});
      }
      if ((!matched && (kind == PGACCEL_JOIN_ROWS_LEFT || kind == PGACCEL_JOIN_ROWS_ANTI)) ||
          (matched && kind == PGACCEL_JOIN_ROWS_SEMI))
        output.push_back({left, PGACCEL_JOIN_ROWS_NULL_ROW});
    }
    return output;
  }
};

bool pair_less(const pgaccel_join_row_pair& a, const pgaccel_join_row_pair& b) {
  return a.outer_row < b.outer_row || (a.outer_row == b.outer_row && a.inner_row < b.inner_row);
}

void compare(std::vector<pgaccel_join_row_pair> actual, std::vector<pgaccel_join_row_pair> expected) {
  check(std::is_sorted(actual.begin(), actual.end(), [](auto a, auto b) { return a.outer_row < b.outer_row; }),
        "outer row order is deterministic");
  std::sort(actual.begin(), actual.end(), pair_less);
  std::sort(expected.begin(), expected.end(), pair_less);
  check(actual.size() == expected.size(), "oracle row count");
  check(actual.size() == expected.size() &&
        (actual.empty() || std::memcmp(actual.data(), expected.data(), actual.size() * sizeof(actual[0])) == 0),
        "exact pair multiset matches independent SQL-equality oracle");
}

void project(Fixture& fixture, const pgaccel_join_row_pair* pairs,
             const std::vector<pgaccel_join_row_pair>& mappings) {
  const size_t rows = mappings.size();
  pgaccel_join_project_request request{};
  request.version = PGACCEL_JOIN_PROJECT_VERSION;
  request.column_count = 3;
  request.outer_rows = fixture.request.outer_rows;
  request.inner_rows = fixture.request.inner_rows;
  request.row_count = rows;
  request.pairs = rows == 0 ? nullptr : pairs;
  request.pair_bytes = rows * sizeof(*pairs);
  std::array<Buffer, 3> values, nulls;
  Buffer error, bytes;
  check(error.allocate(PGACCEL_JOIN_PROJECT_WORKSPACE_BYTES), "projection workspace");
  const std::vector<uint8_t> byte_values(fixture.request.outer_rows, 0xa5);
  check(bytes.upload(byte_values), "bit-preserving byte payload");
  for (size_t index = 0; index < request.column_count; ++index) {
    const auto key = index == 1 ? fixture.request.inner_keys[0] : fixture.request.outer_keys[0];
    const uint32_t width = index == 2 ? 1 : (key.type == PGACCEL_JOIN_ROWS_INT32 ? 4 : 8);
    check(values[index].upload(std::vector<uint8_t>(rows * width, 0xcd)), "projection output poison");
    check(nulls[index].upload(std::vector<uint8_t>(rows, 0xcd)), "projection null poison");
    request.columns[index] = {
        index == 1 ? PGACCEL_JOIN_PROJECT_INNER : PGACCEL_JOIN_PROJECT_OUTER, width,
        index == 2 ? bytes.pointer : key.values, key.nulls,
        index == 2 ? byte_values.size() : key.value_bytes, key.null_bytes,
        values[index].pointer, static_cast<uint8_t*>(nulls[index].pointer), rows * width, rows};
  }
  pgaccel_join_project_result result{};
  const auto before = pgaccel_gpu_exec_count();
  check(pgaccel_join_rows_project(&request, error.pointer, PGACCEL_JOIN_PROJECT_WORKSPACE_BYTES, &result) == PGACCEL_OK,
        "resident row mappings project to device columns");
  check(result.emitted_rows == rows && result.kernel_launches == pgaccel_gpu_exec_count() - before,
        "projection cardinality and launch accounting");
  for (size_t index = 0; index < request.column_count; ++index) {
    const auto& key = index == 1 ? fixture.inner[0] : fixture.outer[0];
    const auto actual_nulls = nulls[index].download<uint8_t>(rows);
    const auto actual_bytes = values[index].download<uint8_t>(rows * request.columns[index].width);
    bool correct = true;
    for (size_t row = 0; row < rows; ++row) {
      const auto source = index == 1 ? mappings[row].inner_row : mappings[row].outer_row;
      const bool is_null = source == PGACCEL_JOIN_ROWS_NULL_ROW || (!key.nulls.empty() && key.nulls[source] != 0);
      const uint64_t expected = is_null ? 0 : (index == 2 ? 0xa5 : static_cast<uint64_t>(key.values[source]));
      uint64_t actual = 0;
      const uint32_t width = request.columns[index].width;
      std::memcpy(&actual, &actual_bytes[row * width], width);
      const uint64_t mask = width == 8 ? UINT64_MAX : ((UINT64_C(1) << (width * 8)) - 1);
      correct &= actual_nulls[row] == static_cast<uint8_t>(is_null) && actual == (expected & mask);
    }
    check(correct, "resident projection preserves bits and canonical SQL NULLs");
  }
}

void run(Fixture& fixture) {
  for (uint32_t kind = PGACCEL_JOIN_ROWS_INNER; kind <= PGACCEL_JOIN_ROWS_ANTI; ++kind) {
    fixture.request.kind = kind;
    const auto expected = fixture.oracle(kind);
    uint64_t workspace_bytes = 0;
    const auto before_query = pgaccel_gpu_exec_count();
    check(pgaccel_join_rows_workspace_bytes(&fixture.request, &workspace_bytes) == PGACCEL_OK,
          "valid pure layout query");
    check(pgaccel_gpu_exec_count() == before_query, "layout query does not dispatch");
    Buffer workspace, output;
    check(workspace.allocate(workspace_bytes), "workspace allocated");
    const pgaccel_join_row_pair poison{UINT64_MAX - 1, UINT64_MAX - 2};
    const size_t capacity = expected.size() + 3;
    check(output.upload(std::vector<pgaccel_join_row_pair>(capacity, poison)), "output poison uploaded");
    if (!workspace.pointer || !output.pointer) return;
    auto* pairs = static_cast<pgaccel_join_row_pair*>(output.pointer);
    if (!expected.empty()) {
      pgaccel_join_rows_result insufficient{};
      check(pgaccel_join_rows_execute(&fixture.request, workspace.pointer, workspace_bytes,
                                      expected.size() == 1 ? nullptr : pairs, expected.size() - 1, &insufficient) == PGACCEL_OOM,
            "capacity exhaustion fails explicitly");
      check(insufficient.required_rows == expected.size() && insufficient.emitted_rows == 0,
            "capacity failure returns exact required cardinality");
      const auto unchanged = output.download<pgaccel_join_row_pair>(capacity);
      check(std::all_of(unchanged.begin(), unchanged.end(), [&](auto p) {
        return p.outer_row == poison.outer_row && p.inner_row == poison.inner_row;
      }), "capacity exhaustion never writes partial output");
    }
    pgaccel_join_rows_result result{};
    const auto before = pgaccel_gpu_exec_count();
    check(pgaccel_join_rows_execute(&fixture.request, workspace.pointer, workspace_bytes,
                                    pairs, capacity, &result) == PGACCEL_OK, "resident join executes");
    check(result.required_rows == expected.size() && result.emitted_rows == expected.size(),
          "successful count publication");
    check(pgaccel_gpu_exec_count() - before == result.kernel_launches, "exact dispatch accounting");
    check(fixture.request.outer_rows == 0 || result.kernel_launches > 0, "nonempty probe uses GPU");
    auto actual = output.download<pgaccel_join_row_pair>(capacity);
    check(std::all_of(actual.begin() + expected.size(), actual.end(), [&](auto p) {
      return p.outer_row == poison.outer_row && p.inner_row == poison.inner_row;
    }), "output tail is untouched");
    actual.resize(expected.size());
    project(fixture, pairs, actual);
    compare(actual, expected);
    // Reusing workspace resets every bucket/count/offset, not just the result.
    result = {};
    check(pgaccel_join_rows_execute(&fixture.request, workspace.pointer, workspace_bytes,
                                    pairs, capacity, &result) == PGACCEL_OK && result.emitted_rows == expected.size(),
          "repeat execution resets workspace");
    compare(output.download<pgaccel_join_row_pair>(expected.size()), expected);
  }
}

void invalid_projection_contracts() {
  Buffer pairs, source, destination, nulls, error;
  check(pairs.upload(std::vector<pgaccel_join_row_pair>{{0, 0}, {1, 1}}), "projection contract pairs");
  check(source.upload(std::vector<int32_t>{7, 11}), "projection contract input");
  check(destination.upload(std::vector<int32_t>{-47, -47}), "projection contract poison");
  check(nulls.upload(std::vector<uint8_t>{0xcd, 0xcd}), "projection contract null poison");
  check(error.allocate(PGACCEL_JOIN_PROJECT_WORKSPACE_BYTES), "projection contract workspace");
  pgaccel_join_project_request request{};
  request.version = PGACCEL_JOIN_PROJECT_VERSION;
  request.column_count = 1;
  request.outer_rows = 2;
  request.inner_rows = 2;
  request.row_count = 2;
  request.pairs = static_cast<const pgaccel_join_row_pair*>(pairs.pointer);
  request.pair_bytes = 32;
  request.columns[0] = {0, 4, source.pointer, nullptr, 8, 0, destination.pointer,
                        static_cast<uint8_t*>(nulls.pointer), 8, 2};
  int32_t host_values[] = {7, 11};
  for (size_t mutation = 0; mutation < 19; ++mutation) {
    auto invalid = request;
    auto* status_word = static_cast<uint32_t*>(error.pointer);
    uint64_t workspace_bytes = PGACCEL_JOIN_PROJECT_WORKSPACE_BYTES;
    switch (mutation) {
      case 0: invalid.version++; break;
      case 1: invalid.column_count = 0; break;
      case 2: invalid.column_count = 17; break;
      case 3: invalid.reserved = 1; break;
      case 4: invalid.pair_bytes = 16; break;
      case 5: invalid.columns[0].width = 2; break;
      case 6: invalid.columns[0].side = 2; break;
      case 7: invalid.columns[0].output_value_bytes = 4; break;
      case 8: invalid.columns[0].output_null_bytes = 1; break;
      case 9: invalid.columns[0].value_bytes = 4; break;
      case 10: invalid.columns[1] = invalid.columns[0]; break;
      case 11: invalid.columns[0].output_values = source.pointer; break;
      case 12: status_word = static_cast<uint32_t*>(destination.pointer); break;
      case 13: invalid.columns[0].output_nulls = static_cast<uint8_t*>(destination.pointer); break;
      case 14: invalid.row_count = UINT64_MAX; break;
      case 15: workspace_bytes--; break;
      case 16: status_word = reinterpret_cast<uint32_t*>(static_cast<uint8_t*>(error.pointer) + 4); break;
      case 17: status_word = nullptr; break;
      case 18: invalid.columns[0].values = host_values; break;
    }
    const pgaccel_join_project_result poison{53, 59};
    auto result = poison;
    const auto before = pgaccel_gpu_exec_count();
    const auto status = pgaccel_join_rows_project(&invalid, status_word, workspace_bytes, &result);
    check(status == PGACCEL_INVALID_ARGUMENT || status == PGACCEL_UNSUPPORTED, "invalid projection contract rejected");
    check(std::memcmp(&result, &poison, sizeof(result)) == 0, "invalid projection leaves metadata unchanged");
    check(pgaccel_gpu_exec_count() == before, "invalid projection contract never dispatches");
  }
  for (auto invalid_pair : {pgaccel_join_row_pair{2, 0}, pgaccel_join_row_pair{0, 2},
                            pgaccel_join_row_pair{UINT64_MAX, 0}}) {
    const pgaccel_join_row_pair invalid_pairs[]{{0, 0}, invalid_pair};
    check(pgaccel_expr_device_copy_from_host(pairs.pointer, invalid_pairs, sizeof(invalid_pairs)) == PGACCEL_OK,
          "invalid row index fixture");
    pgaccel_join_project_result result{53, 59};
    check(pgaccel_join_rows_project(&request, error.pointer, PGACCEL_JOIN_PROJECT_WORKSPACE_BYTES, &result) == PGACCEL_INVALID_ARGUMENT,
          "device row bounds fail before projection");
    check(result.emitted_rows == 53 && result.kernel_launches == 59, "invalid index never publishes success");
    check(destination.download<int32_t>(2) == std::vector<int32_t>({-47, -47}), "invalid index leaves values untouched");
    check(nulls.download<uint8_t>(2) == std::vector<uint8_t>({0xcd, 0xcd}), "invalid index leaves nulls untouched");
  }
  const pgaccel_join_row_pair valid_pairs[]{{1, 0}, {0, PGACCEL_JOIN_ROWS_NULL_ROW}};
  check(pgaccel_expr_device_copy_from_host(pairs.pointer, valid_pairs, sizeof(valid_pairs)) == PGACCEL_OK,
        "retry row mappings");
  pgaccel_join_project_result result{};
  check(pgaccel_join_rows_project(&request, error.pointer, PGACCEL_JOIN_PROJECT_WORKSPACE_BYTES, &result) == PGACCEL_OK,
        "projection resets poisoned error word");
  check(destination.download<int32_t>(2) == std::vector<int32_t>({11, 7}), "retry returns correct values");
  // Maximum-width regression: pass column metadata through resident workspace,
  // not a pointer-rich descriptor expanded into Metal argument bindings.
  std::array<Buffer, PGACCEL_JOIN_PROJECT_MAX_COLUMNS> wide_values, wide_nulls;
  request.column_count = PGACCEL_JOIN_PROJECT_MAX_COLUMNS;
  for (size_t index = 0; index < request.column_count; ++index) {
    check(wide_values[index].allocate(8), "wide projection value allocation");
    check(wide_nulls[index].allocate(2), "wide projection null allocation");
    request.columns[index] = {static_cast<uint32_t>(index % 2), 4, source.pointer, nullptr, 8, 0,
                              wide_values[index].pointer, static_cast<uint8_t*>(wide_nulls[index].pointer), 8, 2};
  }
  check(pgaccel_join_rows_project(&request, error.pointer, PGACCEL_JOIN_PROJECT_WORKSPACE_BYTES, &result) == PGACCEL_OK,
        "all sixteen resident columns project safely");
  for (size_t index = 0; index < request.column_count; ++index) {
    check(wide_values[index].download<int32_t>(2) ==
              (index % 2 == 0 ? std::vector<int32_t>{11, 7} : std::vector<int32_t>{7, 0}),
          "wide projection keeps exact side values");
    check(wide_nulls[index].download<uint8_t>(2) ==
              (index % 2 == 0 ? std::vector<uint8_t>{0, 0} : std::vector<uint8_t>{0, 1}),
          "wide projection preserves null padding");
  }
}

void invalid_contracts(Fixture& fixture) {
  uint64_t bytes = 0;
  check(pgaccel_join_rows_workspace_bytes(&fixture.request, &bytes) == PGACCEL_OK, "contract fixture layout");
  Buffer workspace, output;
  check(workspace.allocate(bytes), "contract workspace");
  check(output.allocate(4096), "contract output");
  auto* pairs = static_cast<pgaccel_join_row_pair*>(output.pointer);
  for (int mutation = 0; mutation < 19; ++mutation) {
    auto request = fixture.request;
    uint64_t declared = bytes;
    uint64_t capacity = 8;
    void* scratch = workspace.pointer;
    auto* destination = pairs;
    switch (mutation) {
      case 0: request.version++; break;
      case 1: request.kind = 4; break;
      case 2: request.key_count = 0; break;
      case 3: request.key_count = 5; break;
      case 4: request.reserved = 1; break;
      case 5: request.outer_keys[0].reserved = 1; break;
      case 6: request.inner_keys[0].type = request.outer_keys[0].type == PGACCEL_JOIN_ROWS_INT32
                  ? PGACCEL_JOIN_ROWS_INT64 : PGACCEL_JOIN_ROWS_INT32; break;
      case 7: request.outer_keys[0].value_bytes = 1; break;
      case 8: request.inner_rows = UINT64_MAX; break;
      case 9: request.outer_keys[3].value_bytes = 1; break;
      case 10: declared = bytes - 1; break;
      case 11: scratch = output.pointer; destination = pairs; break;
      case 12: destination = reinterpret_cast<pgaccel_join_row_pair*>(const_cast<void*>(request.outer_keys[0].values)); break;
      case 13: capacity = UINT64_MAX; break;
      case 14: request.outer_keys[0].null_bytes = 1; break;
      case 15: request.outer_keys[0].type = 99; break;
      case 16: scratch = static_cast<uint8_t*>(scratch) + 1; break;
      case 17: request.outer_keys[0].values = static_cast<const uint8_t*>(request.outer_keys[0].values) + 1; break;
      case 18: scratch = &request; break;
    }
    const pgaccel_join_rows_result poison{47, 53, 59};
    auto result = poison;
    const auto before = pgaccel_gpu_exec_count();
    const auto status = pgaccel_join_rows_execute(&request, scratch, declared, destination, capacity, &result);
    check(status == PGACCEL_INVALID_ARGUMENT || status == PGACCEL_UNSUPPORTED, "invalid contract rejected");
    check(std::memcmp(&result, &poison, sizeof(result)) == 0, "invalid contract leaves result untouched");
    check(pgaccel_gpu_exec_count() == before, "invalid contract does not dispatch");
  }
  auto host_request = fixture.request;
  std::vector<int32_t> host_keys(host_request.outer_rows, 1);
  host_request.outer_keys[0].values = host_keys.data();
  pgaccel_join_rows_result result{};
  check(pgaccel_join_rows_execute(&host_request, workspace.pointer, bytes, pairs, 8, &result) == PGACCEL_INVALID_ARGUMENT,
        "ordinary host input is not device input");
  check(pgaccel_join_rows_workspace_bytes(nullptr, &bytes) == PGACCEL_INVALID_ARGUMENT, "null metadata input");
  check(pgaccel_join_rows_workspace_bytes(&fixture.request, nullptr) == PGACCEL_INVALID_ARGUMENT, "null metadata output");
  check(pgaccel_join_rows_workspace_bytes(&fixture.request,
          reinterpret_cast<uint64_t*>(const_cast<void*>(fixture.request.outer_keys[0].values))) == PGACCEL_INVALID_ARGUMENT,
        "layout output cannot alias resident input");
  check(pgaccel_join_rows_execute(&fixture.request, workspace.pointer, bytes, pairs, 8,
          reinterpret_cast<pgaccel_join_rows_result*>(workspace.pointer)) == PGACCEL_INVALID_ARGUMENT,
        "result cannot alias workspace");
}
} // namespace

int main() {
  // Metadata-only validation must work before runtime initialization.
  pgaccel_join_rows_request empty_request{};
  empty_request.version = PGACCEL_JOIN_ROWS_VERSION;
  empty_request.key_count = 1;
  empty_request.outer_keys[0].type = PGACCEL_JOIN_ROWS_INT32;
  empty_request.inner_keys[0].type = PGACCEL_JOIN_ROWS_INT32;
  uint64_t empty_bytes = 0;
  check(pgaccel_join_rows_workspace_bytes(&empty_request, &empty_bytes) == PGACCEL_OK && empty_bytes == 64,
        "layout query works without initializing GPU");
  check(pgaccel_gpu_exec_count() == 0, "layout query has no dispatch side effect");
  if (pgaccel_init() != PGACCEL_OK) {
    std::fprintf(stderr, "No GPU for resident join-row tests\n");
    return 77;
  }
  invalid_projection_contracts();
  for (uint32_t type : {PGACCEL_JOIN_ROWS_INT32, PGACCEL_JOIN_ROWS_INT64}) {
    Fixture base({HostKey{type, {1, 2, 2, 3, -1, 0, 7}, {0, 0, 0, 0, 0, 0, 255}}},
                 {HostKey{type, {2, 2, -1, 8, 0, 1}, {0, 0, 0, 0, 1, 0}}});
    run(base);
    invalid_contracts(base);
    Fixture self({HostKey{type, {1, 1, -1, 3}, {0, 0, 0, 1}}},
                 {HostKey{type, {1, 1, -1, 3}, {0, 0, 0, 1}}});
    self.request.inner_keys[0] = self.request.outer_keys[0];
    run(self);
    Fixture empty({HostKey{type, {}, {}}}, {HostKey{type, {}, {}}});
    run(empty);
    Fixture no_inner({HostKey{type, {1, 2, 3}, {0, 1, 0}}}, {HostKey{type, {}, {}}});
    run(no_inner);
    Fixture no_outer({HostKey{type, {}, {}}}, {HostKey{type, {1, 2}, {}}});
    run(no_outer);
    Fixture all_null({HostKey{type, {1, 1, 1}, {1, 2, 255}}}, {HostKey{type, {1, 1}, {1, 255}}});
    run(all_null);
  }
  for (size_t key_count : {size_t{2}, size_t{3}, size_t{4}}) {
    std::vector<HostKey> outer, inner;
    for (size_t key = 0; key < key_count; ++key) {
      const uint32_t type = key % 2 == 0 ? PGACCEL_JOIN_ROWS_INT32 : PGACCEL_JOIN_ROWS_INT64;
      outer.push_back({type, {1, 1, 2, -1, 4, 5}, {0, 0, 0, 0, 0, static_cast<uint8_t>(key == 1)}});
      inner.push_back({type, {1, 1, 1, -1, 9, 5}, {0, 0, 0, 0, 0, 0}});
      inner.back().values[2] += static_cast<int64_t>(key);
    }
    Fixture composite(std::move(outer), std::move(inner));
    run(composite);
  }
  Fixture extremes({HostKey{PGACCEL_JOIN_ROWS_INT64, {INT64_MIN, INT64_MAX, -1, 0, INT64_MIN}, {}}},
                   {HostKey{PGACCEL_JOIN_ROWS_INT64, {INT64_MAX, INT64_MIN, -1, INT64_MIN}, {}}});
  run(extremes);
  Fixture skew({HostKey{PGACCEL_JOIN_ROWS_INT32, std::vector<int64_t>(65, -7), {}}},
               {HostKey{PGACCEL_JOIN_ROWS_INT32, std::vector<int64_t>(1025, -7), {}}});
  run(skew);
  // Cross two prefix levels and exercise skew/duplicates/collisions, with an
  // independent host oracle. Only the test copies row-proportional results.
  for (size_t rows : {size_t{255}, size_t{256}, size_t{257}, size_t{65537}}) {
    HostKey outer{PGACCEL_JOIN_ROWS_INT32, {}, {}}, inner{PGACCEL_JOIN_ROWS_INT32, {}, {}};
    for (size_t row = 0; row < rows; ++row) {
      outer.values.push_back(static_cast<int64_t>(row % 23));
      outer.nulls.push_back(row % 17 == 0 ? 1 : 0);
    }
    for (size_t row = 0; row < 67; ++row) {
      inner.values.push_back(static_cast<int64_t>(row % 19));
      inner.nulls.push_back(row % 13 == 0 ? 1 : 0);
    }
    Fixture boundary({std::move(outer)}, {std::move(inner)});
    run(boundary);
  }
  std::printf("resident join rows: %d passed, %d failed\n", passed, failed);
  return failed == 0 ? 0 : 1;
}
