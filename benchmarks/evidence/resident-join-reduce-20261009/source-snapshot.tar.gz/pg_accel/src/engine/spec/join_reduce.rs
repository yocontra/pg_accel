//! JRS1: pointer-free global SUM/COUNT states over a JQS1 projected batch.
//! Input slots name ordered producer lanes, never fabricated relation OIDs.
//! SQL result projection, grouping and planner admission remain separate.

use super::join::{JoinQuerySpec, JoinSpecError};
use super::scalar::{
    MAX_SCALAR_INPUTS, MAX_SCALAR_INSTRUCTIONS, ScalarInstruction, ScalarProgram, ScalarType,
};

pub const MAX_JOIN_REDUCTIONS: usize = 4;
pub const MAX_REDUCTION_PROGRAM_WORDS: usize = 3 + MAX_SCALAR_INPUTS + 2 * MAX_SCALAR_INSTRUCTIONS;
const MAGIC: i32 = 0x4a52_5331;
const HEADER: usize = 4;
pub const MAX_JOIN_REDUCTION_WORDS: usize =
    HEADER + MAX_JOIN_REDUCTIONS * (2 + MAX_SCALAR_INPUTS + MAX_REDUCTION_PROGRAM_WORDS);

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct JoinReduction {
    /// Program input i borrows projected slot inputs[i]. Repeated slots are
    /// legal; their exact SQL types must match the program input declarations.
    pub inputs: Vec<u32>,
    /// An INT4 expression, including a lazy FILTER encoded as a NULL result.
    /// Both SUM and non-NULL COUNT states are produced. Constant 1 gives COUNT(*).
    pub program: ScalarProgram,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct JoinReductionSpec {
    pub measures: Vec<JoinReduction>,
}

#[cfg_attr(not(any(test, feature = "pg_test")), allow(dead_code))] // Staged consumer wire, not a selected SQL pipeline.
impl JoinReductionSpec {
    fn validate_shape(&self) -> Result<(), JoinSpecError> {
        if !(1..=MAX_JOIN_REDUCTIONS).contains(&self.measures.len()) {
            return Err(JoinSpecError(
                "join reduction requires one to four measures",
            ));
        }
        for measure in &self.measures {
            if measure.inputs.len() != measure.program.inputs().len()
                || measure.inputs.len() > MAX_SCALAR_INPUTS
                || measure
                    .inputs
                    .iter()
                    .any(|&slot| slot >= super::join::MAX_JOIN_COLUMNS as u32)
                || measure.program.result_type() != ScalarType::Int4
                || measure
                    .program
                    .instructions()
                    .contains(&ScalarInstruction::PredicateMask)
            {
                return Err(JoinSpecError(
                    "invalid join reduction program or input slots",
                ));
            }
        }
        Ok(())
    }

    pub fn validate(&self, join: &JoinQuerySpec) -> Result<(), JoinSpecError> {
        join.validate()?;
        self.validate_columns(&join.columns)
    }

    pub(crate) fn validate_columns(
        &self,
        columns: &[super::join::OccurrenceColumn],
    ) -> Result<(), JoinSpecError> {
        self.validate_shape()?;
        if !(1..=super::join::MAX_JOIN_COLUMNS).contains(&columns.len()) {
            return Err(JoinSpecError("invalid join reduction producer width"));
        }
        for measure in &self.measures {
            for (&slot, &expected) in measure.inputs.iter().zip(measure.program.inputs()) {
                let column = columns.get(slot as usize).ok_or(JoinSpecError(
                    "join reduction slot is outside producer schema",
                ))?;
                let actual = match column.type_oid {
                    16 => ScalarType::Bool,
                    23 => ScalarType::Int4,
                    1082 => ScalarType::Date,
                    _ => return Err(JoinSpecError("unsupported join reduction input type")),
                };
                if actual != expected {
                    return Err(JoinSpecError("join reduction input SQL type mismatch"));
                }
            }
        }
        Ok(())
    }

    pub fn encode(&self) -> Result<Vec<i32>, JoinSpecError> {
        self.validate_shape()?;
        let len = HEADER
            + self
                .measures
                .iter()
                .map(|m| 2 + m.inputs.len() + m.program.encoded_word_len())
                .sum::<usize>();
        let mut words = Vec::with_capacity(len);
        words.extend([MAGIC, 1, len as i32, self.measures.len() as i32]);
        for measure in &self.measures {
            words.extend([
                measure.inputs.len() as i32,
                measure.program.encoded_word_len() as i32,
            ]);
            words.extend(measure.inputs.iter().map(|&slot| slot as i32));
            let start = words.len();
            words.resize(start + measure.program.encoded_word_len(), 0);
            measure
                .program
                .encode_into(&mut words[start..])
                .map_err(|_| JoinSpecError("invalid scalar wire"))?;
        }
        Ok(words)
    }

    pub fn decode(words: &[i32]) -> Result<Self, JoinSpecError> {
        if !(HEADER..=MAX_JOIN_REDUCTION_WORDS).contains(&words.len())
            || words[0] != MAGIC
            || words[1] != 1
            || words[2] != words.len() as i32
            || !(1..=MAX_JOIN_REDUCTIONS as i32).contains(&words[3])
        {
            return Err(JoinSpecError("invalid join reduction header"));
        }
        // Prove all section lengths, slot bounds and SPG1 programs before any
        // owned decode allocations. Reject truncation, trailing words and tags.
        let mut sections = [(0, 0, 0); MAX_JOIN_REDUCTIONS];
        let mut cursor = HEADER;
        for section in &mut sections[..words[3] as usize] {
            let header = words
                .get(cursor..cursor + 2)
                .ok_or(JoinSpecError("truncated reduction section"))?;
            if !(0..=MAX_SCALAR_INPUTS as i32).contains(&header[0])
                || !(3..=MAX_REDUCTION_PROGRAM_WORDS as i32).contains(&header[1])
            {
                return Err(JoinSpecError("invalid reduction section counts"));
            }
            let slots = header[0] as usize;
            let program_words = header[1] as usize;
            let start = cursor + 2;
            let end = start + slots + program_words;
            let body = words
                .get(start..end)
                .ok_or(JoinSpecError("truncated reduction program"))?;
            if body[..slots]
                .iter()
                .any(|&slot| !(0..super::join::MAX_JOIN_COLUMNS as i32).contains(&slot))
            {
                return Err(JoinSpecError("invalid reduction slot"));
            }
            let program = &body[slots..];
            let proof = ScalarProgram::validate_wire(program)
                .map_err(|_| JoinSpecError("invalid reduction scalar program"))?;
            if program[2] != slots as i32
                || proof.result_type() != ScalarType::Int4
                || proof.uses_predicate_mask()
            {
                return Err(JoinSpecError("invalid reduction scalar signature"));
            }
            *section = (start, slots, end);
            cursor = end;
        }
        if cursor != words.len() {
            return Err(JoinSpecError("trailing reduction words"));
        }
        let mut measures = Vec::with_capacity(words[3] as usize);
        for &(start, slots, end) in &sections[..words[3] as usize] {
            measures.push(JoinReduction {
                inputs: words[start..start + slots]
                    .iter()
                    .map(|&slot| slot as u32)
                    .collect(),
                program: ScalarProgram::decode(&words[start + slots..end])
                    .map_err(|_| JoinSpecError("invalid reduction scalar program"))?,
            });
        }
        Ok(Self { measures })
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::engine::spec::join::{JoinKey, JoinKind, OccurrenceColumn, RelationOccurrence};
    use crate::engine::spec::scalar::{
        ScalarInstruction as I,
        ScalarType::{Bool, Date, Int4},
    };

    fn producer() -> JoinQuerySpec {
        let col = |occurrence, attno, type_oid| OccurrenceColumn {
            occurrence,
            attno,
            type_oid,
        };
        JoinQuerySpec {
            outer: RelationOccurrence {
                id: 3,
                relation_oid: 42,
            },
            inner: RelationOccurrence {
                id: 9,
                relation_oid: 43,
            },
            kind: JoinKind::Left,
            keys: vec![JoinKey {
                outer: col(3, 2, 23),
                inner: col(9, 2, 23),
            }],
            columns: vec![
                col(3, 2, 23),
                col(9, 2, 23),
                col(3, 3, 16),
                col(9, 3, 1082),
                col(3, 4, 20),
            ],
        }
    }

    fn simple() -> JoinReductionSpec {
        JoinReductionSpec {
            measures: vec![JoinReduction {
                inputs: vec![0, 1],
                program: ScalarProgram::new(
                    vec![Int4, Int4],
                    Int4,
                    vec![I::Input(0), I::Input(1), I::CoalesceInt4(10), I::Add],
                )
                .expect("program"),
            }],
        }
    }

    #[test]
    fn reduction_wire_roundtrip_preserves_slots_aliases_and_programs() {
        let mut spec = simple();
        spec.measures.push(JoinReduction {
            inputs: vec![],
            program: ScalarProgram::new(vec![], Int4, vec![I::Int4(1)]).expect("count star"),
        });
        spec.measures.push(JoinReduction {
            inputs: vec![3],
            program: ScalarProgram::new(
                vec![Date],
                Int4,
                vec![I::Input(0), I::Date(0), I::DateDifference],
            )
            .expect("date offset"),
        });
        spec.measures.push(JoinReduction {
            inputs: vec![2],
            program: ScalarProgram::new(
                vec![Bool],
                Int4,
                vec![
                    I::Input(0),
                    I::JumpIfNotTrue(4),
                    I::Int4(1),
                    I::Jump(5),
                    I::Null(Int4),
                ],
            )
            .expect("bool filter"),
        });
        spec.validate(&producer()).expect("typed producer");
        assert_eq!(
            JoinReductionSpec::decode(&spec.encode().expect("encode")).expect("decode"),
            spec
        );
        let mut duplicate = simple();
        duplicate.measures[0].inputs = vec![1, 1];
        duplicate
            .validate(&producer())
            .expect("repeated slots remain meaningful");
        assert_ne!(
            duplicate.encode().expect("duplicate"),
            simple().encode().expect("distinct")
        );
    }

    #[test]
    fn reduction_rejects_wrong_types_slots_predicate_context_and_counts() {
        let mut spec = simple();
        for slot in [2, 3, 4, 5, u32::MAX] {
            spec.measures[0].inputs[0] = slot;
            assert!(spec.validate(&producer()).is_err());
        }
        spec = simple();
        spec.measures[0].inputs.pop();
        assert!(spec.encode().is_err());
        spec = simple();
        spec.measures.clear();
        assert!(spec.encode().is_err());
        spec.measures = vec![simple().measures[0].clone(); 5];
        assert!(spec.encode().is_err());
        spec.measures = vec![JoinReduction {
            inputs: vec![],
            program: ScalarProgram::new(vec![], Bool, vec![I::Bool(true)]).expect("bool"),
        }];
        assert!(spec.encode().is_err());
        spec.measures[0].program = ScalarProgram::new(
            vec![],
            Int4,
            vec![
                I::PredicateMask,
                I::JumpIfNotTrue(4),
                I::Int4(1),
                I::Jump(5),
                I::Null(Int4),
            ],
        )
        .expect("mask needs external context");
        assert!(spec.encode().is_err());
        let mut bad_join = producer();
        bad_join.inner.id = bad_join.outer.id;
        assert!(simple().validate(&bad_join).is_err());
        assert!(simple().validate_columns(&[]).is_err());
    }

    #[test]
    fn reduction_decode_rejects_truncation_counts_tags_and_trailing_words() {
        let wire = simple().encode().expect("wire");
        for len in 0..wire.len() {
            assert!(JoinReductionSpec::decode(&wire[..len]).is_err());
        }
        for (index, value) in [
            (0, 0),
            (1, 2),
            (2, -1),
            (3, 0),
            (3, 5),
            (4, -1),
            (4, i32::MAX),
            (5, -1),
            (5, i32::MAX),
            (6, -1),
            (6, 16),
            (8, 0),
            (10, 1),
        ] {
            let mut invalid = wire.clone();
            invalid[index] = value;
            assert!(
                JoinReductionSpec::decode(&invalid).is_err(),
                "word {index}={value}"
            );
        }
        let mut trailing = wire;
        trailing.push(0);
        trailing[2] += 1;
        assert!(JoinReductionSpec::decode(&trailing).is_err());
    }

    #[test]
    fn reduction_wire_maximum_and_scalar_inline_encoding_are_exact() {
        let constant = ScalarProgram::new(vec![], Int4, vec![I::Int4(1)]).expect("constant");
        let mut fixed = [0; 5];
        constant.encode_into(&mut fixed).expect("fixed wire");
        assert_eq!(
            fixed,
            [0x5350_4731, 2, 0, 1, 1],
            "SPG1 wire remains byte-for-byte compatible"
        );
        let mut code = vec![I::Input(0)];
        for _ in 0..127 {
            code.extend([I::Dup, I::Drop]);
        }
        code.push(I::Neg);
        let program =
            ScalarProgram::new(vec![Int4; MAX_SCALAR_INPUTS], Int4, code).expect("max program");
        assert_eq!(program.encoded_word_len(), MAX_REDUCTION_PROGRAM_WORDS);
        let mut words = [0; MAX_REDUCTION_PROGRAM_WORDS];
        program.encode_into(&mut words).expect("inline encode");
        assert_eq!(words.as_slice(), program.encode());
        let mut short = [97; 2];
        assert!(program.encode_into(&mut short).is_err());
        assert_eq!(short, [97; 2]);
        let spec = JoinReductionSpec {
            measures: vec![
                JoinReduction {
                    inputs: vec![0; MAX_SCALAR_INPUTS],
                    program
                };
                MAX_JOIN_REDUCTIONS
            ],
        };
        spec.validate(&producer()).expect("max schema");
        let wire = spec.encode().expect("max wire");
        assert_eq!(wire.len(), MAX_JOIN_REDUCTION_WORDS);
        assert_eq!(
            JoinReductionSpec::decode(&wire).expect("max roundtrip"),
            spec
        );
        assert_eq!(
            MAX_JOIN_REDUCTIONS,
            crate::engine::spec::abi::PGACCEL_GROUPED_AGG_MAX_MEASURES
        );
        assert_eq!(
            MAX_REDUCTION_PROGRAM_WORDS,
            crate::engine::spec::abi::PGACCEL_SCALAR_MAX_WORDS
        );
    }
}
