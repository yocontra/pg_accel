//! Live qualification of staged nullable hash counts and INT4 sums. No planner path is added.
//! These tests require a real GPU and H3 installation; neither absence is a pass.

#[pgrx::pg_schema]
mod tests {
    use super::super::{
        DescriptorAggPlan, DescriptorArtifactPolicy, H3MeasureInput, INT8OID,
        validate_internal_runtime_capability, validate_normal_descriptor_capability,
    };
    use crate::engine::spec::{
        AggOutputProjection, AggOutputSlot, AggOutputSource, AggQuerySpec, AggregateKind,
        AggregateOutput, AggregateSource, ColumnRef, FilterSpec, GroupKeyEncoding, GroupKeyRef,
        GroupKeySource, MaskKind, MeasureExpr, MeasureSpec,
    };
    use crate::gpu::GroupedAggKernelMode;
    use pgrx::pg_sys;
    use pgrx::prelude::*;

    fn fresh_snapshot<T>(operation: impl FnOnce() -> T) -> T {
        struct Guard;
        impl Drop for Guard {
            fn drop(&mut self) {
                // SAFETY: exactly one private snapshot is pushed below.
                unsafe { pg_sys::PopActiveSnapshot() };
            }
        }
        // SAFETY: live backend test with an active outer statement snapshot.
        // SPI mutations advance the command ID, not the outer snapshot's copy.
        unsafe {
            pg_sys::PushCopiedSnapshot(pg_sys::GetActiveSnapshot());
            pg_sys::UpdateActiveSnapshotCommandId();
        }
        let _guard = Guard;
        operation()
    }

    fn plan(policy: DescriptorArtifactPolicy) -> DescriptorAggPlan {
        plan_for(policy, false, false)
    }

    fn plan_for(
        policy: DescriptorArtifactPolicy,
        filtered: bool,
        count_star: bool,
    ) -> DescriptorAggPlan {
        plan_for_measure(policy, filtered, count_star, false)
    }

    fn plan_for_measure(
        policy: DescriptorArtifactPolicy,
        filtered: bool,
        count_star: bool,
        sum: bool,
    ) -> DescriptorAggPlan {
        assert!(!sum || !count_star);
        let relid = Spi::get_one::<pg_sys::Oid>("SELECT 'hash_count_rows'::regclass::oid")
            .expect("relation lookup")
            .expect("fixture relation");
        // SAFETY: catalog lookup on the live PostgreSQL backend thread. This
        // proves the extension-owned H3 type/function and pass-by-value layout.
        let catalog = unsafe { crate::engine::ffi::syscache::resolve_h3_catalog() }
            .expect("canonical H3 installation required");
        let value_oid = Spi::get_one::<pg_sys::Oid>(
            "SELECT atttypid FROM pg_attribute WHERE attrelid='hash_count_rows'::regclass AND attname='v'",
        )
        .expect("measure type lookup")
        .expect("measure type");
        let cell = ColumnRef {
            relation_oid: relid.into(),
            attno: 1,
            type_oid: catalog.type_oid.into(),
        };
        let mut spec = AggQuerySpec {
            fact_rel: relid.into(),
            group_keys: vec![GroupKeyRef {
                source: GroupKeySource::H3CellToParent {
                    cell,
                    resolution: 0,
                },
                type_oid: cell.type_oid,
                collation_oid: 0,
                encoding: GroupKeyEncoding::Hash,
            }],
            measures: vec![MeasureSpec {
                expression: if count_star {
                    MeasureExpr::CountStar
                } else {
                    MeasureExpr::Column(ColumnRef {
                        attno: 2,
                        type_oid: value_oid.into(),
                        ..cell
                    })
                },
                filter: if filtered {
                    FilterSpec::Mask {
                        input: ColumnRef {
                            attno: 3,
                            type_oid: pg_sys::BOOLOID.into(),
                            ..cell
                        },
                        kind: MaskKind::Sql,
                    }
                } else {
                    FilterSpec::None
                },
                outputs: vec![AggregateOutput {
                    source: AggregateSource::Value,
                    kind: AggregateKind::Count,
                }],
            }],
            star_dims: vec![],
            fact_filter: FilterSpec::None,
            having: None,
        };
        let mut projection = AggOutputProjection {
            slots: vec![
                AggOutputSlot {
                    source: AggOutputSource::GroupKey { key_index: 0 },
                    source_type_oid: cell.type_oid,
                    result_type_oid: cell.type_oid,
                    result_typmod: -1,
                    result_collation_oid: 0,
                    nullable: true,
                },
                AggOutputSlot {
                    source: AggOutputSource::Aggregate {
                        measure_index: 0,
                        source: AggregateSource::Value,
                        kind: AggregateKind::Count,
                    },
                    source_type_oid: if count_star { 0 } else { value_oid.into() },
                    result_type_oid: INT8OID,
                    result_typmod: -1,
                    result_collation_oid: 0,
                    nullable: false,
                },
            ],
        };
        if sum {
            assert_eq!(value_oid, pg_sys::INT4OID);
            spec.measures[0].outputs.push(AggregateOutput {
                source: AggregateSource::Value,
                kind: AggregateKind::Sum,
            });
            let mut slot = projection.slots[1];
            slot.source = AggOutputSource::Aggregate {
                measure_index: 0,
                source: AggregateSource::Value,
                kind: AggregateKind::Sum,
            };
            slot.nullable = true;
            projection.slots.push(slot);
        }
        spec.validate().expect("valid logical count/sum");
        projection.validate(&spec).expect("valid output contract");
        H3MeasureInput::from_spec(&spec).expect("typed count/filter contract");
        // Reuse every H3 shape restriction. Only the measure's CountStar
        // restriction is replaced by the typed H3MeasureInput proof above.
        let mut star = spec.clone();
        star.measures[0].expression = MeasureExpr::CountStar;
        star.measures[0].filter = FilterSpec::None;
        star.measures[0].outputs.truncate(1);
        let mut star_projection = projection.clone();
        star_projection.slots[1].source_type_oid = 0;
        star_projection.slots.truncate(2);
        validate_internal_runtime_capability(&star, &star_projection).expect("canonical H3 shape");
        assert!(DescriptorAggPlan::new(spec.clone(), projection.clone()).is_err());
        assert!(validate_normal_descriptor_capability(&spec, &projection).is_err());
        let mut plan = DescriptorAggPlan::from_validated_spec(
            spec,
            projection,
            GroupedAggKernelMode::ParallelHash,
        )
        .expect("catalog-validated staged plan");
        plan.qualification_policy = Some(policy);
        let residency =
            fresh_snapshot(|| plan.ensure_artifact()).expect("real resident preparation");
        if filtered {
            let rows = residency
                .relations
                .iter()
                .find(|relation| relation.relid == relid)
                .expect("fact row evidence")
                .row_count;
            let expected = match policy {
                DescriptorArtifactPolicy::CachedReusable => rows * 9,
                DescriptorArtifactPolicy::EphemeralFused => 0,
            };
            assert_eq!(
                residency.artifact_bytes, expected,
                "cached parent+mask charge, no double execution charge"
            );
        }
        assert_eq!(plan.artifact_policy.get(), policy);
        plan
    }

    fn native() -> Vec<(Option<i64>, i64)> {
        native_for(false, false)
    }

    fn native_for(filtered: bool, count_star: bool) -> Vec<(Option<i64>, i64)> {
        Spi::run("SET pg_accel.enabled=off").expect("native oracle arm");
        let mut rows = Spi::connect(|client| {
            client
                .select(
                    &format!("SELECT h3_cell_to_parent(cell,0)::bigint, count({}) {} FROM hash_count_rows GROUP BY 1",
                        if count_star { "*" } else { "v" },
                        if filtered { "FILTER (WHERE p)" } else { "" }),
                    None,
                    &[],
                )
                .expect("PostgreSQL H3 count oracle")
                .map(|row| (row.get(1).expect("key"), row.get(2).expect("count").expect("COUNT is never NULL")))
                .collect::<Vec<_>>()
        });
        Spi::run("SET pg_accel.enabled=on").expect("staged execution arm");
        rows.sort();
        rows
    }

    fn rolled_back(operation: impl FnOnce()) {
        // SAFETY: main backend thread, mirroring PL/pgSQL's internal
        // subtransaction owner/context restoration. The body retains only
        // Rust/device-owned plan state, not aborted PostgreSQL allocations.
        unsafe {
            let context = pg_sys::CurrentMemoryContext;
            let owner = pg_sys::CurrentResourceOwner;
            pg_sys::BeginInternalSubTransaction(std::ptr::null());
            pg_sys::MemoryContextSwitchTo(context);
            operation();
            pg_sys::RollbackAndReleaseCurrentSubTransaction();
            pg_sys::MemoryContextSwitchTo(context);
            pg_sys::CurrentResourceOwner = owner;
        }
    }

    fn execute(plan: &DescriptorAggPlan, expect_rebuild: bool) -> Vec<(Option<i64>, i64)> {
        execute_measures(plan, expect_rebuild)
            .into_iter()
            .map(|(key, count, sum)| {
                assert!(sum.is_none());
                (key, count)
            })
            .collect()
    }

    fn execute_measures(
        plan: &DescriptorAggPlan,
        expect_rebuild: bool,
    ) -> Vec<(Option<i64>, i64, Option<i64>)> {
        fresh_snapshot(|| {
            let mut result = plan.execute_prepared().expect("real hash dispatch");
            assert_eq!(result.kernel_mode, GroupedAggKernelMode::ParallelHash);
            assert_eq!(result.planned_batches, result.batches_executed);
            if result.fact_rows != 0 {
                assert!(
                    result.physical_mode_calls > 0,
                    "nonempty input must dispatch"
                );
            }
            assert_eq!(
                result.residency.is_some(),
                expect_rebuild,
                "generation revalidation"
            );
            assert_eq!(
                plan.artifact_policy.get(),
                plan.qualification_policy.expect("test policy")
            );
            // SAFETY: backend thread; the catalog-validated projection has one
            // by-value H3 key, INT8 count and optional INT8 sum. All attributes are set.
            let (desc, slot) = unsafe {
                let desc = pg_sys::CreateTemplateTupleDesc(
                    i32::try_from(plan.projection.slots.len()).expect("small projection"),
                );
                for (index, field) in plan.projection.slots.iter().enumerate() {
                    pg_sys::TupleDescInitEntry(
                        desc,
                        (index + 1) as i16,
                        c"value".as_ptr(),
                        field.result_type_oid.into(),
                        -1,
                        0,
                    );
                }
                (
                    desc,
                    pg_sys::MakeSingleTupleTableSlot(desc, &raw const pg_sys::TTSOpsVirtual),
                )
            };
            let mut rows = Vec::new();
            // SAFETY: next fills this live slot with exactly the proved attributes.
            while !unsafe { result.output.next(slot) }.is_null() {
                // SAFETY: output.next initialized all Datums and NULL flags.
                unsafe {
                    assert!(
                        !*(*slot).tts_isnull.add(1),
                        "zero counts must not materialize as NULL"
                    );
                    let key = (!*(*slot).tts_isnull).then(|| (*(*slot).tts_values).value() as i64);
                    let count = (*(*slot).tts_values.add(1)).value() as i64;
                    let sum = (plan.projection.slots.len() == 3 && !*(*slot).tts_isnull.add(2))
                        .then(|| (*(*slot).tts_values.add(2)).value() as i64);
                    rows.push((key, count, sum));
                }
            }
            // SAFETY: these test-owned objects are no longer used. The template
            // descriptor is unrefcounted, so slot release does not free it.
            unsafe {
                pg_sys::ExecDropSingleTupleTableSlot(slot);
                pg_sys::FreeTupleDesc(desc);
            }
            rows.sort();
            rows
        })
    }

    #[pg_test]
    fn pg_h3_int4_sum_count_materialization_and_currentness() {
        Spi::run(
            "CREATE EXTENSION IF NOT EXISTS h3; SET pg_accel.auto_load=on; SET pg_accel.enabled=on",
        )
        .expect("H3 SUM qualification setup");
        assert_eq!(
            Spi::get_one::<bool>("SELECT gpu_available FROM pg_accel_device_info()")
                .expect("device probe"),
            Some(true),
            "live SUM qualification requires a GPU"
        );
        let native = |filtered: bool| {
            Spi::run("SET pg_accel.enabled=off").expect("native oracle arm");
            let filter = if filtered { "FILTER (WHERE p)" } else { "" };
            let mut rows = Spi::connect(|client| {
                client.select(
                &format!("SELECT h3_cell_to_parent(cell,0)::bigint, count(v) {filter}, sum(v) {filter} FROM hash_count_rows GROUP BY 1"),
                None, &[]).expect("native PostgreSQL SUM/COUNT oracle")
                .map(|row| (row.get::<i64>(1).expect("key"), row.get::<i64>(2).expect("count").expect("non-NULL count"), row.get::<i64>(3).expect("nullable sum")))
                .collect::<Vec<_>>()
            });
            Spi::run("SET pg_accel.enabled=on").expect("staged execution arm");
            rows.sort();
            rows
        };
        for policy in [
            DescriptorArtifactPolicy::CachedReusable,
            DescriptorArtifactPolicy::EphemeralFused,
        ] {
            for filtered in [false, true] {
                Spi::run("CREATE TEMP TABLE hash_count_rows(cell h3index, v integer, p boolean); \
                    INSERT INTO hash_count_rows \
                    WITH seeds AS (SELECT array_agg(h3_cell_to_center_child(cell,15) ORDER BY cell) cells FROM h3_get_res_0_cells() c(cell)) \
                    SELECT CASE WHEN i%5=0 THEN NULL ELSE cells[1+i%3] END, \
                    CASE WHEN i%3=0 OR i%7=0 THEN NULL WHEN i%2=0 THEN 2147483647 ELSE (-2147483647-1) END, \
                    CASE WHEN i%11=0 THEN NULL ELSE i%3<>1 END \
                    FROM generate_series(1,65537) s(i) CROSS JOIN seeds")
                    .expect("multi-chunk nullable sum fixture");
                let plan = plan_for_measure(policy, filtered, false, true);
                let expected = native(filtered);
                assert_eq!(expected.len(), 4);
                assert!(
                    expected
                        .iter()
                        .any(|(_, count, sum)| *count == 0 && sum.is_none())
                );
                assert_eq!(execute_measures(&plan, false), expected);
                assert_eq!(execute_measures(&plan, false), expected);
                rolled_back(|| {
                    Spi::run("UPDATE hash_count_rows SET v=NULL, p=false")
                        .expect("uncommitted measure/predicate mutation");
                    let rejected = native(filtered);
                    assert!(
                        rejected
                            .iter()
                            .all(|(_, count, sum)| *count == 0 && sum.is_none())
                    );
                    assert_eq!(execute_measures(&plan, true), rejected);
                });
                assert_eq!(execute_measures(&plan, true), expected);
                Spi::run("UPDATE hash_count_rows SET v=(-2147483647-1), p=true")
                    .expect("negative extreme update");
                assert_eq!(execute_measures(&plan, true), native(filtered));
                Spi::run("TRUNCATE hash_count_rows").expect("empty relation generation");
                assert!(execute_measures(&plan, true).is_empty());
                drop(plan);
                Spi::run("SELECT pg_accel_evict('hash_count_rows'::regclass); DROP TABLE hash_count_rows")
                    .expect("release fixture residency");
            }
        }
    }

    #[pg_test]
    fn pg_h3_filtered_counts_resident_predicate_currentness() {
        Spi::run(
            "CREATE EXTENSION IF NOT EXISTS h3; SET pg_accel.auto_load=on; SET pg_accel.enabled=on",
        )
        .expect("H3 filtered qualification setup");
        assert_eq!(
            Spi::get_one::<bool>("SELECT gpu_available FROM pg_accel_device_info()")
                .expect("device probe"),
            Some(true),
            "live FILTER qualification requires a GPU"
        );
        for policy in [
            DescriptorArtifactPolicy::CachedReusable,
            DescriptorArtifactPolicy::EphemeralFused,
        ] {
            for count_star in [false, true] {
                Spi::run("CREATE TEMP TABLE hash_count_rows(cell h3index, v integer, p boolean); \
                    INSERT INTO hash_count_rows \
                    WITH seeds AS (SELECT array_agg(h3_cell_to_center_child(cell,15) ORDER BY cell) cells FROM h3_get_res_0_cells() c(cell)) \
                    SELECT CASE WHEN i%5=0 THEN NULL ELSE cells[1+i%3] END, \
                    CASE WHEN i%7=0 THEN NULL ELSE i END, \
                    CASE WHEN i%11=0 THEN NULL ELSE i%3<>0 END \
                    FROM generate_series(1,65537) s(i) CROSS JOIN seeds").expect("multi-chunk nullable predicate");
                let plan = plan_for(policy, true, count_star);
                let expected = native_for(true, count_star);
                assert_eq!(expected.len(), 4);
                assert!(expected.iter().any(|(key, n)| key.is_some() && *n == 0));
                assert_eq!(execute(&plan, false), expected);
                let before = crate::gpu::gpu_exec_count();
                assert_eq!(execute(&plan, false), expected);
                let expected_calls = match policy {
                    DescriptorArtifactPolicy::CachedReusable => 1,
                    DescriptorArtifactPolicy::EphemeralFused => 3,
                };
                assert_eq!(
                    crate::gpu::gpu_exec_count() - before,
                    expected_calls,
                    "warm cached dispatch must not rebuild the two-chunk mask; fused dispatch still does"
                );
                if policy == DescriptorArtifactPolicy::CachedReusable {
                    check_cached_preparation_interrupts(&plan, &expected);
                } else {
                    check_fused_execution_interrupts(&plan, &expected);
                }
                rolled_back(|| {
                    Spi::run("UPDATE hash_count_rows SET p=false")
                        .expect("predicate-only uncommitted change");
                    let rejected = native_for(true, count_star);
                    assert!(rejected.iter().all(|(_, n)| *n == 0));
                    assert_eq!(execute(&plan, true), rejected);
                });
                assert_eq!(
                    execute(&plan, true),
                    expected,
                    "rollback of resident predicate"
                );
                for mutation in [
                    "UPDATE hash_count_rows SET p=NULL",
                    "UPDATE hash_count_rows SET p=true",
                    "UPDATE hash_count_rows SET v=NULL",
                    "TRUNCATE hash_count_rows",
                    "INSERT INTO hash_count_rows VALUES (NULL,7,true)",
                ] {
                    Spi::run(mutation).expect("filter lifecycle mutation");
                    let expected = native_for(true, count_star);
                    assert_eq!(execute(&plan, true), expected);
                    assert_eq!(execute(&plan, false), expected);
                }
                drop(plan);
                Spi::run("SELECT pg_accel_evict('hash_count_rows'::regclass); DROP TABLE hash_count_rows").expect("fixture cleanup");
            }
        }
    }

    fn check_fused_execution_interrupts(plan: &DescriptorAggPlan, expected: &[(Option<i64>, i64)]) {
        use crate::engine::executor::bounded::postgres_interrupt_pending;
        use crate::engine::residency::resident_live_bytes;

        // Pre-allocation, each mask chunk, mask completion, pre-grouped and
        // post-grouped boundaries. The warmed fixture already owns any pooled
        // workspace, so every failed attempt must return to this exact charge.
        let total_polls = 65_537_usize.div_ceil(crate::gpu::SQL_BOOL_MASK_CHUNK_ROWS) + 4;
        let baseline = resident_live_bytes();
        for stop in 1..=total_polls {
            let mut polls = 0;
            let cancelled = fresh_snapshot(|| {
                pg_sys::PgTryBuilder::new(std::panic::AssertUnwindSafe(|| {
                    let _ = plan
                        .execute_prepared_with_poll(|| {
                            polls += 1;
                            if polls == stop {
                                // SAFETY: test-only flags on the backend main thread;
                                // no PG calls while device/residency owners are live.
                                unsafe {
                                    std::ptr::write_volatile(
                                        &raw mut pg_sys::QueryCancelPending,
                                        1,
                                    );
                                    std::ptr::write_volatile(&raw mut pg_sys::InterruptPending, 1);
                                }
                            }
                            postgres_interrupt_pending()
                        })
                        .expect("fused attempt before cancellation");
                    false
                }))
                .catch_when(PgSqlErrorCode::ERRCODE_QUERY_CANCELED, |caught| {
                    let message = match caught {
                        pg_sys::panic::CaughtError::PostgresError(report)
                        | pg_sys::panic::CaughtError::ErrorReport(report) => {
                            report.message().to_owned()
                        }
                        pg_sys::panic::CaughtError::RustPanic { ereport, .. } => {
                            ereport.message().to_owned()
                        }
                    };
                    assert_eq!(message, "canceling statement due to user request");
                    assert_eq!(
                        resident_live_bytes(),
                        baseline,
                        "mask/output charges released before rethrow"
                    );
                    true
                })
                .execute()
            });
            assert!(cancelled);
            assert!(
                plan.ephemeral_artifact.try_borrow_mut().is_ok(),
                "ephemeral guard released before retry"
            );
            assert_eq!(polls, stop);
            assert_eq!(execute(plan, false), expected);
            assert_eq!(resident_live_bytes(), baseline);
        }
        let mut polls = 0;
        let before = crate::gpu::gpu_exec_count();
        let dispatch = fresh_snapshot(|| {
            plan.execute_prepared_with_poll(|| {
                polls += 1;
                if polls == total_polls {
                    // SAFETY: a signal-only benign wakeup, not query cancellation.
                    unsafe { std::ptr::write_volatile(&raw mut pg_sys::InterruptPending, 1) };
                }
                postgres_interrupt_pending()
            })
        })
        .expect("benign interrupt discards first output and retries");
        assert_eq!(polls, total_polls * 2);
        assert_eq!(
            crate::gpu::gpu_exec_count() - before,
            6,
            "two masks and one grouped call per attempt"
        );
        drop(dispatch);
        assert_eq!(resident_live_bytes(), baseline);
        assert_eq!(execute(plan, false), expected);
    }

    fn check_cached_preparation_interrupts(
        plan: &DescriptorAggPlan,
        expected: &[(Option<i64>, i64)],
    ) {
        use super::super::DescriptorArtifactKind;
        use crate::engine::executor::bounded::postgres_interrupt_pending;
        use crate::engine::residency::resident_live_bytes;

        let DescriptorArtifactKind::H3Parent { max_chunk_rows, .. } = plan.artifact_kind else {
            panic!("cached H3 fixture required");
        };
        let parent_calls = 65_537_usize.div_ceil(max_chunk_rows);
        let mask_calls = 65_537_usize.div_ceil(crate::gpu::SQL_BOOL_MASK_CHUNK_ROWS);
        let total_polls = parent_calls + 1 + mask_calls + 1;
        // Every parent boundary, the parent-to-mask transition, both mask
        // chunks and the final pre-publication boundary must be cancellable.
        for stop in 1..=total_polls {
            Spi::run("SELECT pg_accel_refresh('hash_count_rows'::regclass)")
                .expect("invalidate artifact and reload raw inputs");
            let baseline = resident_live_bytes();
            let mut polls = 0;
            let cancelled = fresh_snapshot(|| {
                pg_sys::PgTryBuilder::new(std::panic::AssertUnwindSafe(|| {
                    let _ = plan
                        .ensure_artifact_with_poll(|| {
                            polls += 1;
                            if polls == stop {
                                // SAFETY: backend-main-thread test signal injection.
                                // Only flags are written under the store borrow;
                                // production delivers the original PG error outside it.
                                unsafe {
                                    std::ptr::write_volatile(
                                        &raw mut pg_sys::QueryCancelPending,
                                        1,
                                    );
                                    std::ptr::write_volatile(&raw mut pg_sys::InterruptPending, 1);
                                }
                            }
                            postgres_interrupt_pending()
                        })
                        .expect("preparation before cancellation");
                    false
                }))
                .catch_when(PgSqlErrorCode::ERRCODE_QUERY_CANCELED, |caught| {
                    let message = match caught {
                        pg_sys::panic::CaughtError::PostgresError(report)
                        | pg_sys::panic::CaughtError::ErrorReport(report) => {
                            report.message().to_owned()
                        }
                        pg_sys::panic::CaughtError::RustPanic { ereport, .. } => {
                            ereport.message().to_owned()
                        }
                    };
                    assert_eq!(message, "canceling statement due to user request");
                    assert_eq!(
                        resident_live_bytes(),
                        baseline,
                        "unpublished lanes and charge dropped before rethrow"
                    );
                    true
                })
                .execute()
            });
            assert!(cancelled);
            assert_eq!(polls, stop);
            fresh_snapshot(|| plan.ensure_artifact()).expect("retry after real PG cancellation");
            assert_eq!(execute(plan, false), expected);
        }

        Spi::run("SELECT pg_accel_refresh('hash_count_rows'::regclass)")
            .expect("invalidate before benign interrupt");
        let mut polls = 0;
        let report = fresh_snapshot(|| {
            plan.ensure_artifact_with_poll(|| {
                polls += 1;
                if polls == total_polls {
                    // SAFETY: benign signal-only wakeup on the backend thread.
                    unsafe { std::ptr::write_volatile(&raw mut pg_sys::InterruptPending, 1) };
                }
                postgres_interrupt_pending()
            })
        })
        .expect("benign interrupt retries instead of fabricating cancellation");
        assert_eq!(polls, 2 * total_polls);
        assert_eq!(report.artifact_bytes, 9 * 65_537);
        assert_eq!(execute(plan, false), expected);
    }

    #[pg_test]
    fn pg_h3_nullable_hash_count_resident_currentness_and_materialization() {
        Spi::run(
            "CREATE EXTENSION IF NOT EXISTS h3; SET pg_accel.auto_load=on; SET pg_accel.enabled=on",
        )
        .expect("H3 qualification setup");
        assert_eq!(
            Spi::get_one::<bool>("SELECT gpu_available FROM pg_accel_device_info()")
                .expect("device probe"),
            Some(true),
            "live hash qualification requires a GPU; absence is not a pass"
        );
        for (sql_type, value) in [
            ("boolean", "false"),
            ("smallint", "-32768"),
            ("integer", "-2147483648"),
            ("bigint", "-9223372036854775808"),
            ("real", "'NaN'"),
            ("double precision", "'Infinity'"),
            ("date", "'-infinity'"),
            ("timestamp", "'infinity'"),
            ("timestamptz", "'-infinity'"),
        ] {
            for policy in [
                DescriptorArtifactPolicy::CachedReusable,
                DescriptorArtifactPolicy::EphemeralFused,
            ] {
                Spi::run(&format!(
                    "CREATE TEMP TABLE hash_count_rows(cell h3index, v {sql_type}); \
                     INSERT INTO hash_count_rows \
                     WITH seeds AS (SELECT array_agg(h3_cell_to_center_child(cell,15) ORDER BY cell) cells FROM h3_get_res_0_cells() c(cell)) \
                     SELECT CASE WHEN i%5=0 THEN NULL ELSE cells[1+i%3] END, \
                     CASE WHEN i%3=0 OR i%7=0 THEN NULL ELSE {value}::{sql_type} END \
                     FROM generate_series(1,4097) s(i) CROSS JOIN seeds"
                )).expect("typed nullable fixture");
                let plan = plan(policy);
                let expected = native();
                assert_eq!(expected.len(), 4, "three base cells plus NULL key");
                assert!(expected.iter().any(|(key, n)| key.is_some() && *n == 0));
                assert_eq!(
                    execute(&plan, false),
                    expected,
                    "{sql_type} {policy:?} cold"
                );
                assert_eq!(
                    execute(&plan, false),
                    expected,
                    "{sql_type} {policy:?} warm"
                );
                rolled_back(|| {
                    Spi::run("UPDATE hash_count_rows SET cell=NULL,v=NULL")
                        .expect("uncommitted mutation");
                    let uncommitted = native();
                    assert_eq!(uncommitted, vec![(None, 0)]);
                    assert_eq!(execute(&plan, true), uncommitted);
                    assert_eq!(execute(&plan, false), uncommitted);
                });
                // The device cache now contains rows loaded inside the aborted
                // scope. It must rebuild even though the outer table is restored.
                assert_eq!(execute(&plan, true), expected, "rollback of loaded rows");
                assert_eq!(execute(&plan, false), expected, "warm after rollback");
                let nonnull = format!("UPDATE hash_count_rows SET v={value}::{sql_type}");
                for mutation in [
                    "UPDATE hash_count_rows SET v=NULL",
                    nonnull.as_str(),
                    "UPDATE hash_count_rows SET cell=NULL",
                    "TRUNCATE hash_count_rows",
                    "INSERT INTO hash_count_rows VALUES (NULL,NULL)",
                ] {
                    Spi::run(mutation).expect("DML/rollback fixture");
                    let expected = native();
                    assert_eq!(
                        execute(&plan, true),
                        expected,
                        "{sql_type} {policy:?}: {mutation}"
                    );
                    assert_eq!(execute(&plan, false), expected, "warm after mutation");
                }
                drop(plan);
                Spi::run("SELECT pg_accel_evict('hash_count_rows'::regclass); DROP TABLE hash_count_rows")
                    .expect("release resident fixture");
            }
        }
    }
}
